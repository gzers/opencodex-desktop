import { createApp, defineComponent, h, ref } from 'vue'
import { createPinia, setActivePinia } from 'pinia'
import UiDialog from '/src/components/ui/UiDialog.vue'
import UiSelectField from '/src/components/ui/UiSelectField.vue'
import AppModal from '/src/components/AppModal.vue'
import TemplateUsageDialog from '/src/features/models/TemplateUsageDialog.vue'
import TemplateComparisonDialog from '/src/features/models/TemplateComparisonDialog.vue'
import NewChannelDialog from '/src/features/models/NewChannelDialog.vue'
import SelectorPreviewDialog from '/src/features/models/SelectorPreviewDialog.vue'
import RuntimeInstallDialog from '/src/features/runtime/components/RuntimeInstallDialog.vue'
import ExtensionDetailModal from '/src/features/extensions/components/ExtensionDetailModal.vue'
import UpdateCenter from '/src/features/updates/UpdateCenter.vue'
import { useAppStore } from '/src/stores/app'
import { useAboutStore } from '/src/features/about/store'
import { useDataRootStore } from '/src/features/data-root/store'
import { useRuntimeStore } from '/src/features/runtime/store'
import { useModelsStore } from '/src/features/models/store'
import { useUpdatesStore } from '/src/features/updates/store'
import { useEffectsStore } from '/src/app/appearance/effects'
import { modelApi, emptyRules, emptyContent } from '/src/features/models/api'
import { managerUpdateStatus, managerInstallProgress } from '/src/features/updates/update'
import '/src/routes/ModelsRoute.vue'
import '/src/styles/tokens.css'
import '/src/styles/base.css'
import '/src/styles/materials.css'
import '/src/styles/effects.css'
const pinia=createPinia();setActivePinia(pinia)
const app=useAppStore(), runtime=useRuntimeStore(), models=useModelsStore(), updates=useUpdatesStore(), effects=useEffectsStore()
const mode=ref(''), saving=ref(false), calls=[]
const source={kind:'managed',path:'/isolated/fixture/runtime/bin/ocx',version:'2.50.0',resolvedAt:null,insideDataRoot:true,managedEntry:'/isolated/fixture/runtime/bin/ocx',managedPrefix:'/isolated/fixture/runtime/opencodex',defaultPrefix:'/isolated/fixture/runtime/opencodex',explicitPath:null,history:[]}
let finishInstall
window.__qaInvoke=async(command,args)=>{
 calls.push({command,args})
 if(command==='get_update_status')return managerUpdateStatus.value
 if(command==='runtime_source')return source
 if(command==='runtime_protection_status')return {state:'none',version:null,backupId:null}
 if(command==='install_runtime')return new Promise(resolve=>{finishInstall=resolve})
 if(command==='cancel_runtime_install')return true
 if(command==='update_release_details')return {target:args.target,channel:args.channel,candidateVersion:args.candidateVersion,notesState:'available',notes:'## 本次更新\n\n改善窗口退出和键盘交互。',notesSource:'fixture',releaseUrl:null,fetchedAt:100,publishedAt:null,cached:false}
 return null
}
useAboutStore().app={version:'0.2.20',platform:'darwin'};useDataRootStore().config={currentDataRoot:'/isolated/fixture'};runtime.source=source
const content=emptyContent(),revision={id:'revision-one',createdAt:'2026-11-04T00:00:00Z',savedLabel:'示例模版',content,digest:'revision',baseRevision:null,changes:[]}
const template={id:'template-one',label:'示例模版',source:'user',defaultRevision:'revision-one',revisions:[revision]}
const snapshot={library:{schemaVersion:1,templates:[template]},policy:{schemaVersion:1,channels:[],templateRefs:[]},libraryDigest:'library',policyDigest:'policy',workspaceDigest:'workspace',workspace:null}
models.acceptTransfer(snapshot)
modelApi.templateUsage=async()=>({templateId:'template-one',revisionId:'revision-one',libraryDigest:'library',policyDigest:'policy',workspaceDigest:'workspace',references:[{state:'已提交策略',location:'示例渠道'}],historicalDependency:false,models:[{state:'已提交策略',channelId:'channel',channelLabel:'示例渠道',modelId:'raw/model-id',matched:true,reason:'已匹配',adopted:true,resolutionError:null}]})
managerUpdateStatus.value={channel:'stable',currentVersion:'0.2.20',availableVersion:'0.2.21',lastCheckedAt:'2026-11-04T00:00:00Z',signatureVerified:false,error:null}
updates.officialProject={displayName:'OpenCodex',version:'2.50.0',rawVersion:'2.50.0',truncated:false};updates.officialRemote={tag:'latest',version:'2.51.0',integrity:null}
function open(value){mode.value=value;if(value==='install')runtime.requestInstallModal('registry');if(value==='update-progress')managerInstallProgress.value={operationId:'fixture',target:'manager',channel:'stable',candidateVersion:'0.2.21',generation:1,sequence:1,stage:'downloading',downloadedBytes:64,totalBytes:128};else if(value.startsWith('update'))managerInstallProgress.value=null}
window.qa={app,runtime,models,effects,calls,open,mode,saving,source,getProgress:()=>managerInstallProgress.value,completeInstall(){finishInstall?.({package:'@bitkyc08/opencodex',version:'2.51.0',target:source.managedPrefix,entry:source.managedEntry,tarballSha256:'a'.repeat(64),source:'registry',scriptsEnabled:false,npmPath:'/fixture/npm',installedAt:'2026-11-04T00:00:00Z',proxyUsed:false,needsRestart:false,protectionReconciliationPending:false})}}
const close=()=>{mode.value=''}
const Root=defineComponent({setup:()=>()=>h('main',{style:'padding:24px'},[
 h('h1',{style:'font-size:18px'},'POST-09 · 软件消费者隔离验证'),
 h('div',{style:'display:flex;gap:10px;flex-wrap:wrap'},['usage','comparison','edit','install','extension','update','update-progress','preview','nested'].map(value=>h('button',{class:'btn',id:'open-'+value,onClick:()=>open(value)},value))),
 h(RuntimeInstallDialog),h(AppModal),
 mode.value==='usage'?h(TemplateUsageDialog,{templateId:'template-one',revisionId:'revision-one',onClose:close}):null,
 mode.value==='comparison'?h(TemplateComparisonDialog,{open:true,template,draft:{templateId:template.id,baseRevision:revision.id,label:'草稿名称',content},libraryDigest:'library',onClose:close}):null,
 mode.value==='edit'?h(NewChannelDialog,{onClose:close}):null,
 mode.value==='extension'?h(ExtensionDetailModal,{title:'design-studio',markdown:'# 设计工作台\n\n用于界面和交互设计。\n\n- 读取已确认规范\n- 验证当前界面',facts:[{label:'源目录',value:'/isolated/fixture/design-studio',wide:true},{label:'文件数',value:'28 个文件'}],enabledClients:['codex'],actions:[{key:'refresh',title:'刷新详情',icon:'refresh'},{key:'delete',title:'卸载',icon:'trash',danger:true}],onClose:close}):null,
 mode.value.startsWith('update')?h(UpdateCenter,{open:true,target:mode.value==='update-progress'?'manager':null,'onUpdate:open':value=>{if(!value)close()}}):null,
 mode.value==='preview'?h(SelectorPreviewDialog,{open:true,projection:{rows:[],knownActiveModels:0,exactCatalogCount:0,notices:[]},channels:[],saved:snapshot.policy,saving:saving.value,onClose:close}):null,
 mode.value==='nested'?h(UiDialog,{open:true,title:'编辑确认 · 父层',onClose:close},{default:()=>[h(UiSelectField,{modelValue:'one',label:'选择版本',options:[{value:'one',label:'版本一'},{value:'two',label:'版本二'}]}),h('button',{class:'btn',id:'open-nested-confirm',onClick:()=>app.openModal({title:'子层确认',body:'<p>取消只关闭这一层。</p>',confirmLabel:'确认'})},'打开确认')],actions:({close})=>h('button',{class:'btn',onClick:close},'取消')}):null,
])})
createApp(Root).use(pinia).mount('#app')
window.qa.ready=true
