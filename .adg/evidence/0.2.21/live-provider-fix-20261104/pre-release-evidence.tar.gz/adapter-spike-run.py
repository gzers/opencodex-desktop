#!/usr/bin/env python3
"""Production-source adapter against the unchanged published 2.84 CLI, tmp+loopback."""
import base64,hashlib,hmac,http.server,importlib.util,json,os,signal,socket,subprocess,sys,threading,time,urllib.request
from pathlib import Path
ROOT=Path('/private/var/folders/fq/l0j4lwrs5ld6gpfx2pppv2640000gn/T/ocx021-live-adapter-6mf24e0q')
CODE=Path('/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes')
OUT=CODE.parent/'governance-main/.adg/evidence/0.2.21/live-provider-fix-20261104'
OFFICIAL=Path('/private/tmp/ocx020-owned-official-284/installation/node_modules/@bitkyc08/opencodex')
KEY='synthetic-live-adapter-loopback-key'
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('owned_base',CODE/'test/smoke/ocx021-owned-routing.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+chr(10))
def fp(path):
    st=path.stat();return dict(sha256=sha(path),bytes=st.st_size,inode=st.st_ino,mtimeNs=st.st_mtime_ns)
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args):return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
seen=[]
class Fixture(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        seen.append(dict(method='GET',path=self.path));data=json.dumps({'data':[]}).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(data)
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers.get('Content-Length',0))))
        seen.append(dict(method='POST',path=self.path,model=body.get('model'),syntheticAuthorization=self.headers.get('Authorization')=='Bearer '+KEY))
        response={'id':'resp_fixture','object':'response','status':'completed','created_at':int(time.time()),'model':body.get('model'),'output':[{'id':'msg_fixture','type':'message','role':'assistant','status':'completed','content':[{'type':'output_text','text':'LIVE_ADAPTER_OK','annotations':[]}]}],'usage':{'input_tokens':1,'output_tokens':1,'total_tokens':2}}
        data=json.dumps(response).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(data)
fixture=http.server.ThreadingHTTPServer(('127.0.0.1',0),Fixture);fixture.daemon_threads=True
threading.Thread(target=fixture.serve_forever,daemon=True).start()
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
policy=ROOT/'adapter-official-runtime.sb'
policy.write_text(base.sandbox_policy(ROOT,[port,fixture.server_port]))
(OUT/'adapter-official-runtime.sb').write_text(policy.read_text())
node=Path('/Users/ezio/.local/bin/node').resolve()
codex=Path('/private/tmp/ocx020-owned-codex-0166/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex')
env=json.loads((ROOT/'environment.json').read_text())
env.update(PATH=str(node.parent)+':/usr/bin:/bin:/usr/sbin:/sbin',CODEX_CLI_PATH=str(codex),CODEX_SQLITE_HOME=str(ROOT/'home/.codex'),XDG_DATA_HOME=str(ROOT/'home/.local/share'),XDG_STATE_HOME=str(ROOT/'home/.local/state'),OPENCODEX_SANDBOX='1',OPENCODEX_SANDBOX_ROOT=str(ROOT/'manager'),OPENCODEX_SANDBOX_BOUNDARY=str(ROOT),OTEL_SDK_DISABLED='true',DO_NOT_TRACK='1',OCX_TEST_HOME_GUARD='1',OCX_REAL_HOME='/Users/ezio')
for rel in ['home/.local/share','home/.local/state','manager']:(ROOT/rel).mkdir(parents=True,exist_ok=True)
# No client installation/default mutation is part of this provider-only spike.
(ROOT/'home/.codex/config.toml').write_text('cli_auth_credentials_store = "file"'+chr(10)+'check_for_update_on_startup = false'+chr(10)+'[analytics]'+chr(10)+'enabled = false'+chr(10))
config={'port':port,'hostname':'127.0.0.1','defaultProvider':'Krill-1',
'providers':{'Krill-1':{'adapter':'openai-responses','authMode':'key','baseUrl':f'http://127.0.0.1:{fixture.server_port}/v1','apiKey':KEY,'headers':{'x-owned-fixture':'synthetic-header'},'models':['owned-routing-model'],'selectedModels':['owned-routing-model'],'liveModels':False,'allowPrivateNetwork':True,'newModelPolicy':'off','note':'Owned note','modelCosts':{'owned-routing-model':{'input':0.25,'output':0.5}}},'xai':{'adapter':'openai-responses','authMode':'key','baseUrl':f'http://127.0.0.1:{fixture.server_port}/v1','apiKey':KEY,'disabled':True,'models':['owned-other-model'],'liveModels':False,'allowPrivateNetwork':True}},
'modelPickerOrder':['Krill-1/owned-routing-model'],'claudeCode':{'systemEnv':False,'enabled':False},'clientIntegrations':{'codex':False,'grok':False,'claude':False},'syncResumeHistory':False,'serviceHealthRecovery':{'enabled':False},'tokenGuardian':{'enabled':False},'oauthOpenBrowser':False,'codexAutoStart':False}
path=ROOT/'official/config.json';path.write_text(json.dumps(config,indent=2)+chr(10))
source_paths=[OFFICIAL/'src/server/management/provider-routes.ts',OFFICIAL/'src/server/auth-cors.ts',CODE/'apps/desktop/tauri/src/modules/model_config/saved_runtime_reconcile.rs',CODE/'apps/desktop/tauri/src/modules/model_config/management.rs']
source_before={str(p):sha(p) for p in source_paths}
result={'scope':'production adapter source + linked real Management; unchanged official CLI provider owner','productExplicitRestartAcceptance':False,'fullCodexDefaultChain':False,'dailyConfigAccess':False,'keychainAccess':False,'dailyRestart':False,'globalRestartEndpointCalled':False,'sourceBefore':source_before,'helperSha256':sha(ROOT/'target/debug/reconcile'),'clientIntegrationsDisabled':True,'ports':[port,fixture.server_port]}
process=None
log_out=(ROOT/'adapter-official.stdout').open('w');log_err=(ROOT/'adapter-official.stderr').open('w')
def attested_get():
    rp=ROOT/'official/runtime-port.json';saved=rp.read_bytes();record=json.loads(saved)
    challenge=base64.urlsafe_b64encode(os.urandom(32)).decode().rstrip('=')
    request=urllib.request.Request(f'http://127.0.0.1:{port}/healthz',headers={'x-opencodex-attestation-challenge':challenge})
    with opener.open(request,timeout=5) as response:
        health=json.load(response);proof=response.headers.get('x-opencodex-attestation-proof','')
    expected=base64.urlsafe_b64encode(hmac.new(record['attestationSecret'].encode(),f'opencodex-local-management-v1\n{challenge}\n{record["pid"]}\n{record["port"]}'.encode(),hashlib.sha256).digest()).decode().rstrip('=')
    assert hmac.compare_digest(expected,proof) and health['service']=='opencodex' and health['pid']==record['pid'] and record['port']==port
    assert rp.read_bytes()==saved
    token=(ROOT/'official/admin-api-token').read_text().strip()
    with opener.open(urllib.request.Request(f'http://127.0.0.1:{port}/api/config',headers={'Authorization':'Bearer '+token}),timeout=10) as response:public=json.load(response)
    assert rp.read_bytes()==saved
    return public
try:
    process=subprocess.Popen(['/usr/bin/sandbox-exec','-f',str(policy),str(node),str(OFFICIAL/'bin/ocx.mjs'),'start','--port',str(port)],env=env,cwd=ROOT/'work',stdin=subprocess.DEVNULL,stdout=log_out,stderr=log_err,start_new_session=True)
    deadline=time.monotonic()+50
    while time.monotonic()<deadline:
        if process.poll() is not None:raise RuntimeError(f'owned official exited {process.returncode}')
        try:
            with opener.open(f'http://127.0.0.1:{port}/readyz',timeout=1) as response:
                if response.status==200:break
        except Exception:pass
        time.sleep(.15)
    else:raise TimeoutError('owned official readiness')
    before=attested_get();assert 'Krill-1' in before['providers'] and 'Krill' not in before['providers']
    disk=json.loads(path.read_bytes());disk['providers']['Krill']=disk['providers'].pop('Krill-1');disk['defaultProvider']='Krill';disk['modelPickerOrder']=['Krill/owned-routing-model']
    path.write_text(json.dumps(disk,indent=2)+chr(10));saved_fp=fp(path);saved_bytes=path.read_bytes();runtime_before=(ROOT/'official/runtime-port.json').read_bytes()
    with (OUT/'adapter-real-owner.stdout').open('w') as out,(OUT/'adapter-real-owner.stderr').open('w') as err:
        call=subprocess.run(['/usr/bin/sandbox-exec','-f',str(policy),str(ROOT/'target/debug/reconcile'),str(ROOT/'official')],env=env,cwd=ROOT/'work',stdout=out,stderr=err,timeout=45)
    receipt=json.loads((OUT/'adapter-real-owner.stdout').read_text());result.update(adapterExitCode=call.returncode,adapterReceipt=receipt,savedFingerprint=saved_fp,afterFingerprint=fp(path))
    assert call.returncode==0,receipt
    after=attested_get();assert set(after['providers'])=={'Krill','xai'} and after['defaultProvider']=='Krill'
    assert path.read_bytes()==saved_bytes and fp(path)==saved_fp
    assert (ROOT/'official/runtime-port.json').read_bytes()==runtime_before and process.poll() is None
    result.update(providerBefore=list(before['providers']),defaultBefore=before['defaultProvider'],providerAfter=list(after['providers']),defaultAfter=after['defaultProvider'],sameOfficialRuntimeRecord=True,configBytesShaInodeMtimeUnchanged=True,hasHeadersPreserved=after['providers']['Krill']['hasHeaders'],xaiDerivedObserved='xaiResponsesOptInState' in after['providers']['xai'],initialSelectionDerivedObserved=any('initialModelSelection' in p for p in after['providers'].values()),status='passed')
    # This optional local request validates actual new provider namespace stripping.
    request=urllib.request.Request(f'http://127.0.0.1:{port}/v1/responses',data=json.dumps({'model':'Krill/owned-routing-model','input':'owned fixture','stream':False}).encode(),headers={'Content-Type':'application/json'},method='POST')
    with opener.open(request,timeout=15) as response:reply=json.load(response)
    assert len(seen)==1 and seen[0]['model']=='owned-routing-model' and seen[0]['syntheticAuthorization']
    assert 'LIVE_ADAPTER_OK' in json.dumps(reply) and path.read_bytes()==saved_bytes
    result.update(localRouteReceivedRawModel=True,localResponseConsumed=True,loopbackRequests=seen)
except Exception as error:
    result.update(status='failed',errorType=type(error).__name__,error=str(error).replace(KEY,'[synthetic-key]'))
finally:
    if process is not None:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:process.wait(timeout=8)
        except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
    log_out.close();log_err.close();fixture.shutdown();fixture.server_close()
    for suffix in ['stdout','stderr']:
        text=(ROOT/('adapter-official.'+suffix)).read_text()
        for sensitive in [KEY,(ROOT/'official/admin-api-token').read_text().strip() if (ROOT/'official/admin-api-token').exists() else '']:
            if sensitive:text=text.replace(sensitive,'[synthetic-redacted]')
        (OUT/('adapter-official.'+suffix)).write_text(text)
    result['sourceAfter']={str(p):sha(p) for p in source_paths};result['ownedProcessExited']=process is None or process.poll() is not None
    result['portsClosed']=all(socket.socket().connect_ex(('127.0.0.1',p))!=0 for p in [port,fixture.server_port])
    dump('adapter-real-owner-result.json',result)
print(json.dumps(result,ensure_ascii=False,indent=2))
if result['status']!='passed':sys.exit(1)
