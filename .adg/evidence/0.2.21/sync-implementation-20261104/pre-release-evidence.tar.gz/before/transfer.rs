//! Portable model objects and exact dependency closure. Transfer never applies runtime state.
use super::{
    schema::*,
    store::{seed_library, sha256, validate_library, ModelStore},
};
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::{Path, PathBuf},
};
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct FamilyScope {
    pub template_ids: Vec<String>,
    pub include_channel_defaults: bool,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PortableChannel {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub family_scope: Option<FamilyScope>,
    pub id: String,
    pub label: String,
    pub protocol: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model_subset: Option<Vec<String>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub connection: Option<PortableConnection>,
    pub selection: ModelSelection,
    pub model_order: Vec<String>,
    pub discovered: Vec<DiscoveredModel>,
    pub template_refs: Vec<TemplateRef>,
    pub model_refs: BTreeMap<String, TemplateRef>,
    pub defaults: ModelRules,
    pub overrides: BTreeMap<String, ModelRules>,
    pub family_overrides: BTreeMap<String, ModelRules>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub naming: BTreeMap<String, ModelNaming>,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PortableConnection {
    pub nodes: Vec<ServiceNode>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider: Option<serde_json::Value>,
}
fn portable_connection(channel: &ChannelPolicy) -> Option<PortableConnection> {
    (!channel.connection.nodes.is_empty()).then(|| PortableConnection {
        nodes: channel.connection.nodes.clone(),
        provider: None,
    })
}
pub(super) fn same_destination(left: &PortableChannel, right: &PortableChannel) -> bool {
    if right.family_scope.is_some() && right.connection.is_none() {
        return true;
    }
    if left.protocol != right.protocol {
        return false;
    }
    match (&left.connection, &right.connection) {
        (Some(a), Some(b)) => {
            a.nodes == b.nodes
                && [
                    "adapter",
                    "baseUrl",
                    "authMode",
                    "apiKeyTransport",
                    "responsesPath",
                    "chatCompletionsPath",
                ]
                .iter()
                .all(|key| {
                    a.provider.as_ref().and_then(|p| p.get(*key))
                        == b.provider.as_ref().and_then(|p| p.get(*key))
                })
        }
        (None, None) => true,
        _ => false,
    }
}
pub(super) fn package_version(payload: &TransferPayload) -> u32 {
    if payload
        .policy
        .iter()
        .flat_map(|p| &p.channels)
        .any(|c| c.family_scope.is_some())
    {
        return 5;
    }
    if payload.candidate.is_some() {
        return 4;
    }
    if payload.policy.iter().flat_map(|p| &p.channels).any(|c| {
        c.model_subset.is_some() || c.connection.as_ref().is_some_and(|v| v.provider.is_some())
    }) {
        return 3;
    }
    if payload.policy.as_ref().is_some_and(|p| {
        p.default_channel_id.is_some() || p.channels.iter().any(|c| c.connection.is_some())
    }) {
        2
    } else {
        1
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PortablePolicy {
    pub template_refs: Option<Vec<TemplateRef>>,
    pub channel_order: Option<Vec<String>>,
    pub channels: Vec<PortableChannel>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub default_channel_id: Option<String>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct TransferPayload {
    pub templates: Vec<Template>,
    pub policy: Option<PortablePolicy>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub candidate: Option<DraftCandidate>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct DraftCandidate {
    pub expected_library: String,
    pub expected_policy: String,
    pub expected_workspace: String,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ModelPackage {
    pub format: String,
    pub format_version: u32,
    pub schema_version: u32,
    pub created_at: String,
    pub digest: String,
    pub payload: TransferPayload,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ExportScope {
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub channel_families: BTreeMap<String, FamilyScope>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub channel_models: BTreeMap<String, Vec<String>>,
    pub include_policy: bool,
    pub channel_ids: Vec<String>,
    pub template_refs: Vec<TemplateRef>,
    pub include_global: bool,
}
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ReceiveScope {
    #[serde(default)]
    pub channel_models: BTreeMap<String, Vec<String>>,
    pub template_refs: Vec<TemplateRef>,
    pub channel_ids: Vec<String>,
    pub include_global: bool,
    #[serde(default)]
    pub preferences: bool,
    #[serde(default)]
    pub extensions: bool,
    #[serde(default)]
    pub endpoint_ids: Vec<String>,
    #[serde(default)]
    pub account_ids: Vec<String>,
    #[serde(default)]
    pub skill_names: Vec<String>,
    #[serde(default)]
    pub mcp_names: Vec<String>,
    #[serde(default)]
    pub channel_mappings: BTreeMap<String, ChannelMapping>,
    #[serde(default)]
    pub asset_mappings: crate::modules::sync::portable_assets::NameMappings,
}
#[derive(Debug, Clone, Deserialize)]
#[serde(
    tag = "mode",
    rename_all = "snake_case",
    rename_all_fields = "camelCase",
    deny_unknown_fields
)]
pub enum ChannelMapping {
    New { label: String },
    Local { target_id: String },
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ChannelBinding {
    pub target_id: String,
    pub keep_local_connection: bool,
    pub label: Option<String>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct IncomingPlan {
    pub id: String,
    /// An explicit file context keeps ordinary imports independent of retired
    /// manager policy/drafts. Missing on historical and model-only callers.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub file_home: Option<PathBuf>,
    pub expected_library: String,
    pub expected_policy: String,
    pub expected_workspace: String,
    #[serde(default)]
    pub expected_layout: Option<String>,
    pub package: ModelPackage,
    pub merged_library: Library,
    pub merged_policy: Option<Policy>,
    pub notices: Vec<String>,
    #[serde(default)]
    pub preview_error: Option<String>,
    #[serde(default)]
    pub available_keys: Vec<String>,
    #[serde(default)]
    pub file_digest: Option<String>,
    #[serde(default)]
    pub manager: Option<crate::modules::sync::portable_manager::Settings>,
    #[serde(default)]
    pub available_webdav_passwords: Vec<String>,
    #[serde(default)]
    pub adoption: Option<ImportAdoption>,
    #[serde(default)]
    pub assets: Option<crate::modules::sync::portable_assets::Summary>,
    #[serde(default)]
    pub available_extension_credentials: bool,
    #[serde(default)]
    pub available_extension_ids: Vec<String>,
    #[serde(default)]
    pub models_accepted: bool,
    #[serde(default)]
    pub protected: bool,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub channel_bindings: BTreeMap<String, ChannelBinding>,
    #[serde(
        default,
        skip_serializing_if = "crate::modules::sync::portable_assets::NameMappings::is_empty"
    )]
    pub asset_mappings: crate::modules::sync::portable_assets::NameMappings,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub extension_source: Option<crate::modules::extensions::ExtensionConfig>,
    /// 设备间同步预览（S18-01），仅在同步下载时填写。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sync: Option<super::sync_state::SyncPreview>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub comparison: Option<super::sync_state::SyncPreview>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ImportAdoption {
    pub keys: bool,
    pub webdav: bool,
    pub completed: bool,
    #[serde(default)]
    pub extension_credentials: bool,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct FileExportPlan {
    pub id: String,
    pub package: ModelPackage,
    pub protected: bool,
    pub file_digest: String,
    #[serde(default)]
    pub credential_count: usize,
    #[serde(default)]
    pub manager: Option<crate::modules::sync::portable_manager::Settings>,
    #[serde(default)]
    pub assets: Option<crate::modules::sync::portable_assets::Summary>,
    #[serde(default)]
    pub credential_counts: Option<super::file_objects::CredentialCounts>,
}
fn export_plan_path(root: &Path, id: &str) -> ModelResult<std::path::PathBuf> {
    require_uuid(id)?;
    let path = root
        .join("manager-state/model-file-exports")
        .join(format!("{id}.json"));
    crate::modules::backup::safety::check_path(root, &path, true)?;
    Ok(path)
}
pub fn prepare_file(
    root: &Path,
    scope: ExportScope,
    passphrase: Option<&str>,
) -> ModelResult<FileExportPlan> {
    prepare_file_with_keys(root, scope, passphrase, false)
}
pub fn prepare_file_with_keys(
    root: &Path,
    scope: ExportScope,
    passphrase: Option<&str>,
    include_keys: bool,
) -> ModelResult<FileExportPlan> {
    prepare_file_scope(
        root,
        scope,
        passphrase,
        include_keys,
        &crate::modules::sync::portable_manager::Scope::default(),
    )
}
pub fn prepare_file_scope(
    root: &Path,
    scope: ExportScope,
    passphrase: Option<&str>,
    include_keys: bool,
    manager_scope: &crate::modules::sync::portable_manager::Scope,
) -> ModelResult<FileExportPlan> {
    let id = uuid::Uuid::new_v4().to_string();
    let no_models = !scope.include_policy
        && scope.template_refs.is_empty()
        && (manager_scope.preferences
            || manager_scope.extensions
            || manager_scope.webdav
            || !manager_scope.skill_names.is_empty()
            || !manager_scope.mcp_names.is_empty()
            || !manager_scope.account_ids.is_empty());
    let source_digest = manager_scope
        .upstream_root
        .as_deref()
        .map(|home| super::config_file::snapshot(root, home).map(|s| s.policy_digest))
        .transpose()?;
    let mut package = if let Some(home) = &manager_scope.upstream_root {
        super::portable_channels::export_file(root, home, scope)?
    } else if let Some(snapshot) = &manager_scope.upstream_snapshot {
        super::portable_channels::export(root, scope, snapshot)?
    } else {
        export(root, scope)?
    };
    if no_models {
        package.payload.templates.clear();
        package.digest = sha256(&serde_json::to_vec(&package.payload)?);
    }
    let plan = freeze_file_package(root, id, package, passphrase, include_keys, manager_scope)?;
    if let (Some(home), Some(expected)) = (&manager_scope.upstream_root, source_digest) {
        if super::config_file::snapshot(root, home)?.policy_digest != expected {
            return Err(invalid(
                "provider_source_drift",
                "导出期间渠道源文件已改变，请重新比较",
            ));
        }
    }
    Ok(plan)
}
fn freeze_file_package(
    root: &Path,
    id: String,
    mut package: ModelPackage,
    passphrase: Option<&str>,
    include_keys: bool,
    manager_scope: &crate::modules::sync::portable_manager::Scope,
) -> ModelResult<FileExportPlan> {
    let (bytes, credential_count, manager, assets) = super::file_objects::seal_manager(
        root,
        &id,
        &package,
        include_keys,
        passphrase,
        manager_scope,
    )?;
    let (saved_package, counts) = super::file_objects::content_view(&bytes, passphrase)?;
    package = saved_package;
    let plan = FileExportPlan {
        id,
        package,
        protected: passphrase.is_some(),
        file_digest: sha256(&bytes),
        credential_count,
        manager: Some(manager),
        assets: Some(assets),
        credential_counts: Some(counts),
    };
    let payload = export_plan_path(root, &plan.id)?.with_extension("ocxdconf");
    crate::modules::backup::safety::check_path(root, &payload, true)?;
    crate::infrastructure::atomic_write::atomic_write(&payload, &bytes, 0o600)?;
    crate::infrastructure::atomic_write::atomic_write(
        &export_plan_path(root, &plan.id)?,
        &serde_json::to_vec(&plan)?,
        0o600,
    )?;
    Ok(plan)
}
pub fn prepare_draft_file(
    root: &Path,
    scope: ExportScope,
    expected: DraftCandidate,
    passphrase: Option<&str>,
) -> ModelResult<FileExportPlan> {
    let mut snapshot = ModelStore::new(root).load()?;
    if snapshot.library_digest != expected.expected_library
        || snapshot.policy_digest != expected.expected_policy
        || snapshot.workspace_digest != expected.expected_workspace
    {
        return Err(invalid(
            "stale_baseline",
            "渠道工作区已变化，请重新核对导出范围",
        ));
    }
    let workspace = snapshot
        .workspace
        .take()
        .ok_or_else(|| invalid("draft_export", "没有已暂存的渠道工作区草稿"))?;
    if !scope.include_policy || scope.channel_ids.is_empty() {
        return Err(invalid("draft_export", "请明确选择至少一个草稿渠道"));
    }
    if scope
        .channel_ids
        .iter()
        .any(|id| !workspace.policy.channels.iter().any(|c| &c.id == id))
    {
        return Err(invalid("draft_export", "所选渠道不在当前工作区"));
    }
    snapshot.policy = workspace.policy;
    let mut package = export_snapshot(&snapshot, scope)?;
    package.payload.candidate = Some(expected);
    package.format_version = package_version(&package.payload);
    package.digest = sha256(&serde_json::to_vec(&package.payload)?);
    validate_package(&package)?;
    freeze_file_package(
        root,
        uuid::Uuid::new_v4().to_string(),
        package,
        passphrase,
        false,
        &Default::default(),
    )
}
/// Freeze a caller-owned, unsaved channel candidate without staging a normal
/// manager draft or consulting the retired policy/workspace.
pub fn prepare_memory_file(
    root: &Path,
    home: &Path,
    scope: ExportScope,
    expected: DraftCandidate,
    policy: Policy,
    passphrase: Option<&str>,
) -> ModelResult<FileExportPlan> {
    let mut snapshot = super::config_file::snapshot(root, home)?;
    if snapshot.library_digest != expected.expected_library
        || snapshot.policy_digest != expected.expected_policy
    {
        return Err(invalid(
            "stale_baseline",
            "文件或模版库已变化，请重新核对草稿导出范围",
        ));
    }
    if !scope.include_policy
        || scope.channel_ids.is_empty()
        || scope
            .channel_ids
            .iter()
            .any(|id| !policy.channels.iter().any(|c| &c.id == id))
    {
        return Err(invalid("draft_export", "请明确选择当前内存草稿中的渠道"));
    }
    snapshot.policy = policy;
    let mut package = export_snapshot(&snapshot, scope)?;
    package.payload.candidate = Some(expected);
    package.format_version = package_version(&package.payload);
    package.digest = sha256(&serde_json::to_vec(&package.payload)?);
    validate_package(&package)?;
    freeze_file_package(
        root,
        uuid::Uuid::new_v4().to_string(),
        package,
        passphrase,
        false,
        &Default::default(),
    )
}
pub fn file_bytes(root: &Path, id: &str) -> ModelResult<Vec<u8>> {
    let plan: FileExportPlan = serde_json::from_slice(&crate::modules::backup::safety::read_file(
        &export_plan_path(root, id)?,
        64 * 1024 * 1024,
    )?)?;
    if plan.id != id {
        return Err(invalid("export_identity", "导出计划身份不一致"));
    }
    let path = export_plan_path(root, id)?.with_extension("ocxdconf");
    crate::modules::backup::safety::check_path(root, &path, false)?;
    let bytes = crate::modules::backup::safety::read_file(
        &path,
        crate::modules::sync::portable_file::FILE_LIMIT as u64,
    )?;
    if sha256(&bytes) != plan.file_digest {
        return Err(invalid("export_digest", "已冻结导出文件发生变化，未导出"));
    }
    Ok(bytes)
}
pub fn file_package(root: &Path, id: &str) -> ModelResult<ModelPackage> {
    let plan: FileExportPlan = serde_json::from_slice(&crate::modules::backup::safety::read_file(
        &export_plan_path(root, id)?,
        64 * 1024 * 1024,
    )?)?;
    if plan.id != id {
        return Err(invalid("export_identity", "导出计划身份不一致"));
    }
    validate_package(&plan.package)?;
    Ok(plan.package)
}
pub fn file_summary(root: &Path, id: &str) -> ModelResult<FileExportPlan> {
    let p: FileExportPlan = serde_json::from_slice(&crate::modules::backup::safety::read_file(
        &export_plan_path(root, id)?,
        64 * 1024 * 1024,
    )?)?;
    if p.id != id {
        return Err(invalid("export_identity", "导出计划身份不同"));
    }
    validate_package(&p.package)?;
    Ok(p)
}
/// Remove only the frozen package files owned by this unattempted preview.
/// The caller serializes this with export/protect using the per-plan attempt lock.
pub fn discard_prepared_file(root: &Path, id: &str) -> ModelResult<bool> {
    require_uuid(id)?;
    let plan_path = export_plan_path(root, id)?;
    crate::modules::backup::safety::check_path(root, &plan_path, true)?;
    if plan_path.exists() {
        let plan = file_summary(root, id)?;
        if plan.id != id {
            return Err(invalid("export_identity", "导出计划身份不同"));
        }
    }
    let paths = [
        plan_path.clone(),
        plan_path.with_extension("ocxdconf"),
        plan_path.with_extension("protection-source.json"),
    ];
    for path in &paths {
        crate::modules::backup::safety::check_path(root, path, true)?;
    }
    let had_files = paths.iter().any(|path| path.exists());
    for path in paths {
        match std::fs::symlink_metadata(&path) {
            Ok(metadata) if metadata.is_file() && !metadata.file_type().is_symlink() => {
                std::fs::remove_file(path)
                    .map_err(|error| invalid("export_discard", error.to_string()))?;
            }
            Ok(_) => {
                return Err(invalid(
                    "export_discard",
                    "临时导出计划包含非普通文件，已保留",
                ))
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(invalid("export_discard", error.to_string())),
        }
    }
    Ok(had_files)
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ProtectionSource {
    id: String,
    base_id: String,
    digest: String,
}
/// Protect the exact reviewed bytes; never reread current channels/resources.
/// A protection-only child remains linked to the original immutable snapshot.
pub fn protect_file(root: &Path, id: &str, password: Option<&str>) -> ModelResult<FileExportPlan> {
    use crate::modules::sync::portable_file;
    let plan = file_summary(root, id)?;
    let bytes = zeroize::Zeroizing::new(file_bytes(root, id)?);
    let password = password.filter(|s| !s.is_empty());
    if super::file_exports::attempted(root, id)? {
        if plan.protected != password.is_some() {
            return Err(invalid(
                "export_intent",
                "原导出保护方式已冻结，请沿结果重试或重新导出",
            ));
        }
        if plan.protected {
            portable_file::open(&bytes, password)?;
        }
        return Ok(plan);
    }
    if !plan.protected && password.is_none() {
        return Ok(plan);
    }
    let link_path = export_plan_path(root, id)?.with_extension("protection-source.json");
    crate::modules::backup::safety::check_path(root, &link_path, true)?;
    let (base_id, source) = if link_path.exists() {
        let link: ProtectionSource = serde_json::from_slice(
            &crate::modules::backup::safety::read_file(&link_path, 4096)?,
        )?;
        if link.id != id {
            return Err(invalid("export_identity", "保护来源身份不同"));
        }
        let source = zeroize::Zeroizing::new(file_bytes(root, &link.base_id)?);
        if sha256(&source) != link.digest {
            return Err(invalid("export_digest", "原冻结内容改变，未重新保护"));
        }
        (link.base_id, source)
    } else {
        if plan.protected {
            portable_file::open(&bytes, password)?;
            return Ok(plan);
        }
        (id.to_string(), bytes)
    };
    let opened = portable_file::open(&source, None)?;
    let new_id = uuid::Uuid::new_v4().to_string();
    let mut manifest = opened.manifest;
    manifest.id = new_id.clone();
    manifest.created_at = chrono::Utc::now().to_rfc3339();
    let protected = portable_file::seal(manifest, &opened.document, password)?;
    let mut next = plan;
    next.id = new_id.clone();
    next.protected = password.is_some();
    next.file_digest = sha256(&protected);
    let path = export_plan_path(root, &new_id)?;
    crate::infrastructure::atomic_write::atomic_write(
        &path.with_extension("ocxdconf"),
        &protected,
        0o600,
    )?;
    crate::infrastructure::atomic_write::atomic_write(
        &path.with_extension("protection-source.json"),
        &serde_json::to_vec(&ProtectionSource {
            id: new_id,
            base_id,
            digest: sha256(&source),
        })?,
        0o600,
    )?;
    crate::infrastructure::atomic_write::atomic_write(&path, &serde_json::to_vec(&next)?, 0o600)?;
    Ok(next)
}
fn revision_refs(policy: &PortablePolicy) -> Vec<&TemplateRef> {
    policy
        .template_refs
        .iter()
        .flatten()
        .chain(
            policy
                .channels
                .iter()
                .flat_map(|c| c.template_refs.iter().chain(c.model_refs.values())),
        )
        .collect()
}
pub(super) fn portable(channel: &ChannelPolicy) -> PortableChannel {
    PortableChannel {
        family_scope: None,
        id: channel.id.clone(),
        label: channel.label.clone(),
        protocol: channel.connection.protocol.clone(),
        model_subset: None,
        connection: portable_connection(channel),
        selection: channel.selection.clone(),
        model_order: channel.model_order.clone(),
        discovered: channel.discovered.clone(),
        template_refs: channel.template_refs.clone(),
        model_refs: channel.model_refs.clone(),
        defaults: channel.defaults.clone(),
        overrides: channel.overrides.clone(),
        family_overrides: channel.family_overrides.clone(),
        naming: channel.naming.clone(),
    }
}
pub(super) fn adopted_portable(
    channel: &ChannelPolicy,
    globals: &[TemplateRef],
) -> PortableChannel {
    let mut result = portable(channel);
    result.template_refs = globals
        .iter()
        .chain(&channel.template_refs)
        .map(|r| (r.template_id.clone(), r.clone()))
        .collect::<BTreeMap<_, _>>()
        .into_values()
        .collect();
    result
}
pub(super) fn complete_dependencies(
    package: &mut ModelPackage,
    library: &Library,
) -> ModelResult<()> {
    let wanted = package
        .payload
        .policy
        .iter()
        .flat_map(revision_refs)
        .collect::<Vec<_>>();
    for reference in wanted {
        let revision = super::matching::revision(library, reference)?;
        if let Some(template) = package
            .payload
            .templates
            .iter_mut()
            .find(|t| t.id == reference.template_id)
        {
            if !template
                .revisions
                .iter()
                .any(|r| r.id == reference.revision_id)
            {
                template.revisions.push(revision.clone());
            }
        } else {
            let mut template = library
                .templates
                .iter()
                .find(|t| t.id == reference.template_id)
                .unwrap()
                .clone();
            template.revisions = vec![revision.clone()];
            if template.default_revision.as_ref() != Some(&revision.id) {
                template.default_revision = None;
            }
            package.payload.templates.push(template);
        }
    }
    Ok(())
}
pub(super) fn restrict_models(
    channel: &PortableChannel,
    ids: &[String],
) -> ModelResult<PortableChannel> {
    let available = channel
        .discovered
        .iter()
        .map(|m| m.id.as_str())
        .chain(channel.model_order.iter().map(String::as_str))
        .chain(channel.model_refs.keys().map(String::as_str))
        .chain(channel.overrides.keys().map(String::as_str))
        .chain(channel.naming.keys().map(String::as_str))
        .chain(match &channel.selection {
            ModelSelection::Whitelist(ids) => ids.iter().map(String::as_str).collect::<Vec<_>>(),
            _ => vec![],
        })
        .chain(
            channel
                .connection
                .iter()
                .flat_map(|c| c.provider.iter())
                .flat_map(|p| p["models"].as_array().into_iter().flatten())
                .filter_map(serde_json::Value::as_str),
        )
        .collect::<BTreeSet<_>>();
    let wanted = ids.iter().collect::<BTreeSet<_>>();
    if ids.len() > 10000
        || wanted.len() != ids.len()
        || ids
            .iter()
            .any(|id| !available.contains(id.as_str()) || id.is_empty())
    {
        return Err(invalid(
            "model_scope",
            "所选型号不属于源渠道或存在重复，请重新比较",
        ));
    }
    let mut result = channel.clone();
    let mut stable = ids.to_vec();
    stable.sort();
    result.model_subset = Some(stable.clone());
    result.discovered.retain(|m| wanted.contains(&m.id));
    result.model_order.retain(|id| wanted.contains(id));
    result.model_refs.retain(|id, _| wanted.contains(id));
    result.overrides.retain(|id, _| wanted.contains(id));
    result.naming.retain(|id, _| wanted.contains(id));
    let selected = match &channel.selection {
        ModelSelection::All => stable.clone(),
        ModelSelection::None => vec![],
        ModelSelection::Whitelist(values) => values
            .iter()
            .filter(|id| wanted.contains(id))
            .cloned()
            .collect(),
    };
    result.selection = if selected.is_empty() {
        ModelSelection::None
    } else {
        ModelSelection::Whitelist(selected)
    };
    if let Some(public) = result.connection.as_mut().and_then(|c| c.provider.as_mut()) {
        let fields = public
            .as_object_mut()
            .ok_or_else(|| invalid("model_scope", "原渠道字段无效"))?;
        for (key, value) in fields.iter_mut() {
            if key.starts_with("model") && value.is_object() {
                value
                    .as_object_mut()
                    .unwrap()
                    .retain(|id, _| wanted.contains(id));
            }
        }
        fields.insert("models".into(), serde_json::json!(stable));
        fields.insert("newModelPolicy".into(), serde_json::json!("off"));
        fields.insert(
            "selectedModels".into(),
            serde_json::json!(match &result.selection {
                ModelSelection::Whitelist(v) => v.clone(),
                _ => vec![],
            }),
        );
        if fields
            .get("defaultModel")
            .and_then(serde_json::Value::as_str)
            .is_some_and(|id| !ids.iter().any(|v| v == id))
        {
            fields.remove("defaultModel");
        }
    }
    Ok(result)
}
fn family_fragment(
    snapshot: &Snapshot,
    source: &ChannelPolicy,
    scope: &FamilyScope,
) -> ModelResult<PortableChannel> {
    let ids: BTreeSet<_> = scope.template_ids.iter().cloned().collect();
    if ids.is_empty() || ids.len() != scope.template_ids.len() || ids.len() > 5000 {
        return Err(invalid("family_scope", "请选择明确且不重复的模型族"));
    }
    let references: BTreeMap<String, TemplateRef> = snapshot
        .policy
        .template_refs
        .iter()
        .chain(&source.template_refs)
        .map(|r| (r.template_id.clone(), r.clone()))
        .collect();
    for id in &ids {
        require_uuid(id)?;
        if !references.contains_key(id) && !source.model_refs.values().any(|r| &r.template_id == id)
        {
            return Err(invalid(
                "family_scope",
                "所选族没有精确采用版本，不能按默认版本猜测片段",
            ));
        }
    }

    let known = source
        .discovered
        .iter()
        .map(|m| m.id.clone())
        .chain(source.model_order.iter().cloned())
        .chain(source.model_refs.keys().cloned())
        .chain(source.overrides.keys().cloned())
        .chain(source.naming.keys().cloned())
        .chain(match &source.selection {
            ModelSelection::Whitelist(ids) => ids.clone(),
            _ => vec![],
        })
        .collect::<BTreeSet<_>>();
    let mut models = vec![];
    for id in known {
        if super::matching::resolve(&snapshot.library, &snapshot.policy, &source.id, &id)?
            .is_some_and(|(r, _)| ids.contains(&r.template_id))
        {
            models.push(id);
        }
    }
    let mut result = portable(source);
    if !models.is_empty() {
        result = restrict_models(&result, &models)?;
    } else {
        result.model_subset = Some(vec![]);
        result.discovered.clear();
        result.model_order.clear();
        result.model_refs.clear();
        result.overrides.clear();
        result.naming.clear();
        result.selection = ModelSelection::None;
    }
    result.template_refs = ids
        .iter()
        .filter_map(|id| references.get(id).cloned())
        .collect();
    result.family_overrides.retain(|id, _| ids.contains(id));
    result.defaults = if scope.include_channel_defaults {
        source.defaults.clone()
    } else {
        ModelRules::default()
    };
    result.connection = None;
    result.family_scope = Some(FamilyScope {
        template_ids: ids.into_iter().collect(),
        include_channel_defaults: scope.include_channel_defaults,
    });
    Ok(result)
}
pub(super) fn scope_families(
    package: &mut ModelPackage,
    scopes: &BTreeMap<String, FamilyScope>,
) -> ModelResult<()> {
    if scopes.is_empty() {
        return Ok(());
    }
    let policy = package
        .payload
        .policy
        .as_ref()
        .ok_or_else(|| invalid("family_scope", "所选文档不含渠道策略"))?;
    if scopes
        .keys()
        .any(|id| !policy.channels.iter().any(|c| &c.id == id))
    {
        return Err(invalid("family_scope", "所选渠道不在文档内"));
    }
    let snapshot = Snapshot {
        library: Library {
            schema_version: SCHEMA_VERSION,
            templates: package.payload.templates.clone(),
            submission_receipts: Default::default(),
        },
        policy: Policy {
            template_refs: policy.template_refs.clone().unwrap_or_default(),
            channels: policy
                .channels
                .iter()
                .map(|c| ChannelPolicy {
                    id: c.id.clone(),
                    label: c.label.clone(),
                    connection: ChannelConnection {
                        protocol: c.protocol.clone(),
                        ..Default::default()
                    },
                    selection: c.selection.clone(),
                    model_order: c.model_order.clone(),
                    discovered: c.discovered.clone(),
                    template_refs: c.template_refs.clone(),
                    model_refs: c.model_refs.clone(),
                    defaults: c.defaults.clone(),
                    overrides: c.overrides.clone(),
                    family_overrides: c.family_overrides.clone(),
                    naming: c.naming.clone(),
                })
                .collect(),
            ..Default::default()
        },
        library_digest: String::new(),
        policy_digest: String::new(),
        workspace_digest: String::new(),
        workspace: None,
    };
    for channel in &mut package.payload.policy.as_mut().unwrap().channels {
        if let Some(scope) = scopes.get(&channel.id) {
            if channel.family_scope.as_ref().is_some_and(|old| {
                scope
                    .template_ids
                    .iter()
                    .any(|id| !old.template_ids.contains(id))
                    || scope.include_channel_defaults && !old.include_channel_defaults
            }) {
                return Err(invalid(
                    "family_scope",
                    "原族片段未携带所选族或渠道共用字段，不能扩大范围",
                ));
            }
            let source = snapshot
                .policy
                .channels
                .iter()
                .find(|c| c.id == channel.id)
                .unwrap();
            *channel = family_fragment(&snapshot, source, scope)?;
        }
    }
    package.format_version = package_version(&package.payload);
    package.digest = sha256(&serde_json::to_vec(&package.payload)?);
    Ok(())
}
fn check_family_fragment(channel: &PortableChannel) -> ModelResult<()> {
    let scope = channel
        .family_scope
        .as_ref()
        .ok_or_else(|| invalid("family_scope", "片段缺少模型族范围"))?;
    let ids = scope.template_ids.iter().collect::<BTreeSet<_>>();
    if ids.is_empty()
        || ids.len() != scope.template_ids.len()
        || scope.template_ids.windows(2).any(|v| v[0] >= v[1])
        || channel.connection.is_some()
        || (!scope.include_channel_defaults && channel.defaults != ModelRules::default())
        || channel.family_overrides.keys().any(|id| !ids.contains(id))
        || channel
            .template_refs
            .iter()
            .any(|r| !ids.contains(&r.template_id))
        || channel
            .model_refs
            .values()
            .any(|r| !ids.contains(&r.template_id))
    {
        return Err(invalid(
            "family_scope",
            "族片段包含范围外引用、连接或未授权共用字段",
        ));
    }
    for id in &scope.template_ids {
        require_uuid(id)?;
        if !channel
            .template_refs
            .iter()
            .chain(channel.model_refs.values())
            .any(|r| &r.template_id == id)
        {
            return Err(invalid("family_scope", "族片段缺少精确采用版本"));
        }
    }
    let models = channel
        .model_subset
        .as_ref()
        .ok_or_else(|| invalid("family_scope", "族片段缺少明确型号范围"))?;
    if !models.is_empty() {
        let canonical = restrict_models(channel, models)?;
        if serde_json::to_value(canonical)? != serde_json::to_value(channel)? {
            return Err(invalid("family_scope", "族片段含范围外型号字段"));
        }
    } else if !channel.discovered.is_empty()
        || !channel.model_order.is_empty()
        || !channel.model_refs.is_empty()
        || !channel.overrides.is_empty()
        || !channel.naming.is_empty()
        || channel.selection != ModelSelection::None
    {
        return Err(invalid(
            "family_scope",
            "无匹配型号的族片段不能夹带型号字段",
        ));
    }
    Ok(())
}
fn merge_family(
    previous: &PortableChannel,
    incoming: &PortableChannel,
) -> ModelResult<PortableChannel> {
    check_family_fragment(incoming)?;
    let scope = incoming.family_scope.as_ref().unwrap();
    let mut result = previous.clone();
    for id in &scope.template_ids {
        if let Some(reference) = incoming.template_refs.iter().find(|r| &r.template_id == id) {
            result.template_refs.retain(|r| &r.template_id != id);
            result.template_refs.push(reference.clone());
        }
        match incoming.family_overrides.get(id) {
            Some(value) => {
                result.family_overrides.insert(id.clone(), value.clone());
            }
            None => {
                result.family_overrides.remove(id);
            }
        }
    }
    if scope.include_channel_defaults {
        result.defaults = incoming.defaults.clone();
    }
    for id in incoming.model_subset.as_ref().unwrap() {
        if let Some(declaration) = incoming.discovered.iter().find(|m| &m.id == id) {
            result.discovered.retain(|m| &m.id != id);
            result.discovered.push(declaration.clone());
        }
        if let Some(value) = incoming.overrides.get(id) {
            result.overrides.insert(id.clone(), value.clone());
        } else {
            result.overrides.remove(id);
        }
        if let Some(value) = incoming.model_refs.get(id) {
            result.model_refs.insert(id.clone(), value.clone());
        } else {
            result.model_refs.remove(id);
        }
        if let Some(value) = incoming.naming.get(id) {
            result.naming.insert(id.clone(), value.clone());
        } else {
            result.naming.remove(id);
        }
        if !result.model_order.contains(id) {
            result.model_order.push(id.clone());
        }
    }
    if let Some(previous_scope) = &mut result.family_scope {
        previous_scope
            .template_ids
            .extend(scope.template_ids.clone());
        previous_scope.template_ids.sort();
        previous_scope.template_ids.dedup();
        previous_scope.include_channel_defaults |= scope.include_channel_defaults;
    }
    if let Some(models) = &mut result.model_subset {
        models.extend(incoming.model_subset.clone().unwrap_or_default());
        models.sort();
        models.dedup();
    }
    Ok(result)
}
fn family_view(
    channel: &PortableChannel,
    incoming: &PortableChannel,
    globals: &[TemplateRef],
) -> serde_json::Value {
    let scope = incoming.family_scope.as_ref().unwrap();
    let families = &scope.template_ids;
    let models = incoming.model_subset.as_ref().unwrap();
    let references = globals
        .iter()
        .chain(&channel.template_refs)
        .filter(|r| {
            incoming
                .template_refs
                .iter()
                .any(|target| target.template_id == r.template_id)
        })
        .map(|r| (r.template_id.clone(), r.clone()))
        .collect::<BTreeMap<_, _>>();
    serde_json::json!({
        "refs": references,
        "families": channel.family_overrides.iter().filter(|(id,_)|families.contains(id)).collect::<BTreeMap<_,_>>(),
        "discovered": channel.discovered.iter().filter(|m| incoming.discovered.iter().any(|target|target.id==m.id)).collect::<Vec<_>>(),
        "rules": channel.overrides.iter().filter(|(id,_)|models.contains(id)).collect::<BTreeMap<_,_>>(),
        "modelRefs": channel.model_refs.iter().filter(|(id,_)|models.contains(id)).collect::<BTreeMap<_,_>>(),
        "names": channel.naming.iter().filter(|(id,_)|models.contains(id)).collect::<BTreeMap<_,_>>(),
        "defaults": if scope.include_channel_defaults {Some(&channel.defaults)} else {None}
    })
}
pub(super) fn is_scoped_channel(
    source: &PortableChannel,
    selected: &PortableChannel,
) -> ModelResult<bool> {
    let expected = if let Some(ids) = &selected.model_subset {
        restrict_models(source, ids)?
    } else {
        source.clone()
    };
    Ok(serde_json::to_value(expected)? == serde_json::to_value(selected)?)
}
pub(super) fn scope_models(
    package: &mut ModelPackage,
    selected: &[String],
    scopes: &BTreeMap<String, Vec<String>>,
) -> ModelResult<()> {
    if scopes.keys().any(|id| !selected.contains(id)) {
        return Err(invalid("model_scope", "不能限定未选择的渠道型号"));
    }
    for channel in package
        .payload
        .policy
        .iter_mut()
        .flat_map(|p| &mut p.channels)
    {
        if let Some(ids) = scopes.get(&channel.id) {
            *channel = restrict_models(channel, ids)?;
        }
    }
    package.format_version = package_version(&package.payload);
    package.digest = sha256(&serde_json::to_vec(&package.payload)?);
    Ok(())
}
pub fn export(root: &Path, scope: ExportScope) -> ModelResult<ModelPackage> {
    let snapshot = ModelStore::new(root).load()?;
    export_snapshot(&snapshot, scope)
}
pub(super) fn export_snapshot(
    snapshot: &Snapshot,
    scope: ExportScope,
) -> ModelResult<ModelPackage> {
    let mut wanted: BTreeSet<(String, String)> = scope
        .template_refs
        .iter()
        .map(|r| (r.template_id.clone(), r.revision_id.clone()))
        .collect();
    let mut policy = if scope.include_policy {
        let channels = snapshot
            .policy
            .channels
            .iter()
            .filter(|c| scope.channel_ids.contains(&c.id))
            .map(|c| adopted_portable(c, &snapshot.policy.template_refs))
            .collect();
        Some(PortablePolicy {
            // 退役字段：导出不再携带，避免跨设备传播。
            default_channel_id: None,
            template_refs: if scope.include_global {
                Some(snapshot.policy.template_refs.clone())
            } else {
                None
            },
            channel_order: if scope.include_global {
                Some(
                    snapshot
                        .policy
                        .channels
                        .iter()
                        .map(|c| c.id.clone())
                        .collect(),
                )
            } else {
                None
            },
            channels,
        })
    } else {
        None
    };
    if !scope.channel_families.is_empty()
        && (!scope.include_policy
            || scope
                .channel_families
                .keys()
                .any(|id| !snapshot.policy.channels.iter().any(|c| &c.id == id)))
    {
        return Err(invalid(
            "family_scope",
            "族片段须明确选择已提交或草稿中的管理器渠道",
        ));
    }
    if scope
        .channel_families
        .keys()
        .any(|id| !scope.channel_ids.contains(id) || scope.channel_models.contains_key(id))
    {
        return Err(invalid(
            "family_scope",
            "族片段须属于所选渠道，且不能同时选择型号子集",
        ));
    }
    if scope
        .channel_models
        .keys()
        .any(|id| !scope.channel_ids.contains(id))
    {
        return Err(invalid("model_scope", "不能限定未选择的渠道型号"));
    }
    for channel in policy.iter_mut().flat_map(|p| &mut p.channels) {
        if let Some(families) = scope.channel_families.get(&channel.id) {
            let source = snapshot
                .policy
                .channels
                .iter()
                .find(|c| c.id == channel.id)
                .ok_or_else(|| invalid("family_scope", "族片段只能来自已读取的管理器策略渠道"))?;
            *channel = family_fragment(snapshot, source, families)?;
        }
        if let Some(ids) = scope.channel_models.get(&channel.id) {
            *channel = restrict_models(channel, ids)?;
        }
    }
    if let Some(policy) = &policy {
        for reference in revision_refs(policy) {
            wanted.insert((reference.template_id.clone(), reference.revision_id.clone()));
        }
        if let Some(id) = &policy.default_channel_id {
            require_uuid(id)?;
            // A global-only package may refer to an existing target channel.
        }
    }
    let full_library = !scope.include_policy && scope.template_refs.is_empty();
    let mut templates = vec![];
    for template in &snapshot.library.templates {
        let mut selected = template.clone();
        selected
            .revisions
            .retain(|r| full_library || wanted.contains(&(template.id.clone(), r.id.clone())));
        if selected.revisions.is_empty() {
            continue;
        }
        if selected
            .default_revision
            .as_ref()
            .is_some_and(|id| !selected.revisions.iter().any(|r| &r.id == id))
        {
            selected.default_revision = None;
        }
        templates.push(selected);
    }
    for (reference, id) in &wanted {
        if !templates
            .iter()
            .any(|t| &t.id == reference && t.revisions.iter().any(|r| &r.id == id))
        {
            return Err(invalid("missing_dependency", "导出范围缺少精确保存版本"));
        }
    }
    let payload = TransferPayload {
        templates,
        policy,
        candidate: None,
    };
    let digest = sha256(&serde_json::to_vec(&payload)?);
    Ok(ModelPackage {
        format: "OCXD_MODEL_CONFIG".into(),
        format_version: package_version(&payload),
        schema_version: SCHEMA_VERSION,
        created_at: chrono::Utc::now().to_rfc3339(),
        digest,
        payload,
    })
}
pub(super) fn validate_package(package: &ModelPackage) -> ModelResult<()> {
    if package.format != "OCXD_MODEL_CONFIG"
        || ![1, 2, 3, 4, 5].contains(&package.format_version)
        || (package.format_version < package_version(&package.payload))
        || package.schema_version != SCHEMA_VERSION
    {
        return Err(invalid("package_version", "模型配置文件格式/版本不受支持"));
    }
    if let Some(candidate) = &package.payload.candidate {
        if [
            &candidate.expected_library,
            &candidate.expected_policy,
            &candidate.expected_workspace,
        ]
        .iter()
        .any(|v| !v.starts_with("sha256:") || v.len() != 71)
            || package.payload.policy.is_none()
        {
            return Err(invalid("draft_export", "草稿候选缺少有效源基准或渠道范围"));
        }
    }
    if sha256(&serde_json::to_vec(&package.payload)?) != package.digest {
        return Err(invalid("package_digest", "模型配置文件摘要不匹配，未接受"));
    }
    if package.payload.templates.len() > 5000
        || package
            .payload
            .policy
            .as_ref()
            .is_some_and(|p| p.channels.len() > 256)
    {
        return Err(invalid("package_limit", "配置包对象超过上限"));
    }
    let mut templates = BTreeSet::new();
    let mut revisions = BTreeSet::new();
    for template in &package.payload.templates {
        require_uuid(&template.id)?;
        if !templates.insert(&template.id)
            || template.label.trim().is_empty()
            || template.label.len() > 256
            || template.revisions.is_empty()
            || template
                .default_revision
                .as_ref()
                .is_some_and(|id| !template.revisions.iter().any(|r| &r.id == id))
        {
            return Err(invalid("package_identity", "模版重复/名称无效/版本为空"));
        }
        for revision in &template.revisions {
            require_uuid(&revision.id)?;
            revision.content.validate()?;
            if !revisions.insert(&revision.id)
                || chrono::DateTime::parse_from_rfc3339(&revision.created_at).is_err()
                || revision.saved_label.trim().is_empty()
                || revision.saved_label.len() > 256
                || super::store::content_digest(&revision.saved_label, &revision.content)?
                    != revision.digest
            {
                return Err(invalid("revision_conflict", "保存版本重复或摘要不符"));
            }
        }
    }
    if let Some(policy) = &package.payload.policy {
        if let Some(id) = &policy.default_channel_id {
            require_uuid(id)?;
        }
        let mut channels = BTreeSet::new();
        for channel in &policy.channels {
            require_uuid(&channel.id)?;
            if !channels.insert(&channel.id)
                || channel.label.trim().is_empty()
                || channel.label.len() > 256
                || channel.protocol.len() > 128
            {
                return Err(invalid("channel", "包内渠道身份重复"));
            }
            if channel.family_scope.is_some() {
                check_family_fragment(channel)?;
            } else if let Some(ids) = &channel.model_subset {
                let canonical = restrict_models(channel, ids)?;
                if serde_json::to_value(&canonical)? != serde_json::to_value(channel)? {
                    return Err(invalid("model_scope", "型号子集含未选声明或字段，未接收"));
                }
            }
            if let Some(connection) = &channel.connection {
                if let Some(provider) = &connection.provider {
                    super::provider_fields::validate_public(provider)?;
                    if provider["adapter"] != channel.protocol
                        || !connection
                            .nodes
                            .iter()
                            .any(|node| provider["baseUrl"] == node.url)
                    {
                        return Err(invalid("provider_fields", "原渠道字段与协议或节点不对应"));
                    }
                }
                let probe = ChannelPolicy {
                    naming: channel.naming.clone(),
                    id: channel.id.clone(),
                    label: channel.label.clone(),
                    template_refs: vec![],
                    model_refs: BTreeMap::new(),
                    connection: ChannelConnection {
                        auth_mode: None,
                        source_read_id: None,
                        imported_config: None,
                        provider_id: "portable-validation".into(),
                        protocol: channel.protocol.clone(),
                        nodes: connection.nodes.clone(),
                        active_node_id: connection
                            .nodes
                            .first()
                            .map(|n| n.id.clone())
                            .unwrap_or_default(),
                        ..Default::default()
                    },
                    selection: ModelSelection::None,
                    model_order: channel.model_order.clone(),
                    discovered: channel.discovered.clone(),
                    defaults: Default::default(),
                    overrides: Default::default(),
                    family_overrides: Default::default(),
                };
                super::compiler::validate_channel(&probe)?;
            }
            let unique = |ids: &[String]| {
                ids.iter().collect::<BTreeSet<_>>().len() == ids.len()
                    && ids.iter().all(|id| !id.is_empty())
            };
            if !unique(&channel.model_order)
                || channel
                    .discovered
                    .iter()
                    .map(|m| &m.id)
                    .collect::<BTreeSet<_>>()
                    .len()
                    != channel.discovered.len()
            {
                return Err(invalid("channel_models", "模型身份或顺序重复"));
            }
            if let ModelSelection::Whitelist(ids) = &channel.selection {
                if !unique(ids) {
                    return Err(invalid("selection", "模型选择包含重复或空身份"));
                }
            }
            channel.defaults.validate()?;
            for rules in channel
                .overrides
                .values()
                .chain(channel.family_overrides.values())
                .chain(channel.discovered.iter().map(|m| &m.rules))
            {
                rules.validate()?;
            }
            let ids = channel
                .template_refs
                .iter()
                .map(|r| &r.template_id)
                .collect::<BTreeSet<_>>();
            if ids.len() != channel.template_refs.len() {
                return Err(invalid("reference", "重复渠道模版引用"));
            }
        }
        if policy.template_refs.as_ref().is_some_and(|refs| {
            refs.iter()
                .map(|r| &r.template_id)
                .collect::<BTreeSet<_>>()
                .len()
                != refs.len()
        }) || policy
            .channel_order
            .as_ref()
            .is_some_and(|ids| ids.iter().collect::<BTreeSet<_>>().len() != ids.len())
        {
            return Err(invalid("reference", "全局引用或渠道顺序重复"));
        }
        for reference in revision_refs(policy) {
            if !package.payload.templates.iter().any(|t| {
                t.id == reference.template_id
                    && t.revisions.iter().any(|r| r.id == reference.revision_id)
            }) {
                return Err(invalid(
                    "missing_dependency",
                    "包内缺少策略所需的精确模版版本",
                ));
            }
        }
    }
    Ok(())
}
/// An incoming whole channel is a copy of this machine's official Codex
/// channel (S18-05) when it carries a local native channel's identity, or when
/// it has no local identity match and repeats a native channel's label,
/// protocol and service address. Older packages carry no provider id and the
/// native ids are minted per machine, so the second rule covers them. A
/// same-named custom channel with another address is still received.
fn is_native_copy(
    channel: &PortableChannel,
    matched: Option<&ChannelPolicy>,
    local_native: &[&ChannelPolicy],
) -> bool {
    if let Some(existing) = matched {
        return super::compiler::channel_is_native(&existing.connection.provider_id);
    }
    let Some(connection) = &channel.connection else {
        return false;
    };
    local_native.iter().any(|native| {
        native.label.eq_ignore_ascii_case(&channel.label)
            && native.connection.protocol == channel.protocol
            && native
                .connection
                .nodes
                .iter()
                .any(|n| connection.nodes.iter().any(|m| m.url == n.url))
    })
}
fn merge(
    local: &Snapshot,
    package: &ModelPackage,
) -> ModelResult<(Library, Option<Policy>, Vec<String>)> {
    validate_package(package)?;
    let mut library = local.library.clone();
    let seeds = seed_library();
    let mut notices = vec![];
    if package.payload.candidate.is_some() {
        notices.push(
            "这是未提交渠道草稿候选；接收只进入本机工作区，不代表源端或本机运行配置已保存".into(),
        );
    }
    for incoming in &package.payload.templates {
        if let Some(existing) = library.templates.iter_mut().find(|t| t.id == incoming.id) {
            for revision in &incoming.revisions {
                if let Some(current) = existing.revisions.iter().find(|r| r.id == revision.id) {
                    if current.content != revision.content
                        || current.digest != revision.digest
                        || current.saved_label != revision.saved_label
                        || current.created_at != revision.created_at
                        || current.changes != revision.changes
                        || current.base_revision != revision.base_revision
                        || current.origin != revision.origin
                    {
                        return Err(invalid(
                            "revision_conflict",
                            "同一完整版本身份有不同内容或历史事实，未覆盖",
                        ));
                    }
                } else {
                    existing.revisions.push(revision.clone());
                }
            }
            if existing.default_revision != incoming.default_revision {
                notices.push(format!(
                    "{}：远端默认指针仅作候选，保持本机默认",
                    existing.label
                ));
            }
        } else {
            let mut candidate = incoming.clone();
            candidate.source = TemplateSource::User;
            candidate.default_revision = None;
            if seeds.templates.iter().any(|t| t.id == candidate.id) {
                return Err(invalid("source", "内置基线身份冲突"));
            }
            notices.push(format!(
                "{}：新增自建来源候选，不授予内置保护或自动采用",
                candidate.label
            ));
            library.templates.push(candidate);
        }
    }
    validate_library(&library)?;
    let policy = if let Some(incoming) = &package.payload.policy {
        let mut policy = local
            .workspace
            .as_ref()
            .map(|w| w.policy.clone())
            .unwrap_or_else(|| local.policy.clone());
        // “默认渠道”已退役：包里即使带该字段也不写入本机草稿，
        // 官方 defaultProvider 由用户自己掌控。
        if let Some(global) = &incoming.template_refs {
            if local
                .workspace
                .as_ref()
                .is_some_and(|w| w.policy.template_refs != local.policy.template_refs)
                && policy.template_refs != *global
            {
                return Err(invalid(
                    "draft_conflict",
                    "全局采用已有未保存修改，请先明确保留或处理本机草稿",
                ));
            }
            policy.template_refs = global.clone();
        }
        let local_native: Vec<&ChannelPolicy> = local
            .policy
            .channels
            .iter()
            .chain(local.workspace.iter().flat_map(|w| &w.policy.channels))
            .filter(|c| super::compiler::channel_is_native(&c.connection.provider_id))
            .collect();
        for channel in &incoming.channels {
            let committed = local.policy.channels.iter().find(|c| c.id == channel.id);
            let working = policy.channels.iter().find(|c| c.id == channel.id);
            if channel.family_scope.is_none()
                && is_native_copy(channel, committed.or(working), &local_native)
            {
                notices.push(format!(
                    "{}：本机官方渠道沿用本机Codex配置，未接收副本",
                    channel.label
                ));
                continue;
            }
            if channel.family_scope.is_none()
                && working != committed
                && working
                    .is_some_and(|c| !is_scoped_channel(&portable(c), channel).unwrap_or(false))
            {
                return Err(invalid(
                    "draft_conflict",
                    "渠道已有未保存修改，未覆盖；请先比较本机草稿",
                ));
            }
            if let Some(family_scope) = &channel.family_scope {
                let previous = working.or(committed).ok_or_else(|| {
                    invalid(
                        "family_target",
                        "族片段需要明确映射到已有渠道，不能作为整渠道创建",
                    )
                })?;
                let merged = merge_family(&portable(previous), channel)?;
                if let Some(saved) = committed {
                    let current_view =
                        family_view(&portable(previous), channel, &policy.template_refs);
                    if current_view
                        != family_view(&portable(saved), channel, &local.policy.template_refs)
                        && current_view != family_view(&merged, channel, &policy.template_refs)
                    {
                        return Err(invalid(
                            "draft_conflict",
                            "所选族字段已有未保存修改，请先明确处理冲突",
                        ));
                    }
                }
                let mut next = previous.clone();
                next.template_refs = merged.template_refs;
                next.family_overrides = merged.family_overrides;
                next.defaults = merged.defaults;
                next.overrides = merged.overrides;
                next.model_refs = merged.model_refs;
                next.naming = merged.naming;
                next.discovered = merged.discovered;
                next.model_order = merged.model_order;
                let index = policy
                    .channels
                    .iter()
                    .position(|c| c.id == channel.id)
                    .unwrap();
                policy.channels[index] = next;
                notices.push(format!("{}：只接收所选族规则与精确型号例外；其他族、连接/Key、公开范围与已有顺序保持{}",channel.label,if family_scope.include_channel_defaults{"，本次另含渠道共用默认字段，影响全部型号"}else{"；源渠道共用默认未携带，最终效果按本机共用值解析"}));
                continue;
            }
            let mut connection = working
                .or(committed)
                .map(|c| c.connection.clone())
                .unwrap_or_default();
            if (working.is_some() || committed.is_some()) && connection.protocol != channel.protocol
            {
                return Err(invalid(
                    "channel_endpoint_conflict",
                    "同一渠道的协议不同，请先映射或跳过；未复用本机Key",
                ));
            }
            if let Some(incoming_connection) = &channel.connection {
                if working.is_some() || committed.is_some() {
                    if connection.protocol != channel.protocol
                        || connection.nodes != incoming_connection.nodes
                    {
                        return Err(invalid("channel_endpoint_conflict", "同一渠道的协议或服务节点不同，请先映射渠道或跳过该对象；未改变本机连接或Key"));
                    }
                } else {
                    connection.provider_id = format!("ocxd_import_{}", channel.id.replace('-', ""));
                    connection.nodes = incoming_connection.nodes.clone();
                    // File exports retain other labeled nodes as layout. Their
                    // order must not redirect the source's actual connection.
                    connection.active_node_id = incoming_connection
                        .provider
                        .as_ref()
                        .and_then(|p| p["baseUrl"].as_str())
                        .and_then(|url| connection.nodes.iter().find(|node| node.url == url))
                        .unwrap_or(&connection.nodes[0])
                        .id
                        .clone();
                    // Staged candidates never inherit the source's enabled state,
                    // active runtime provider, Keychain reference or private-network permission.
                    connection.enabled = false;
                    connection.allow_private_network = false;
                    connection.credential_ref = None;
                }
            }
            connection.protocol = channel.protocol.clone();
            if working.is_none() {
                notices.push(format!(
                    "{}：新增渠道草稿，服务节点需确认，保持停用且未绑定运行渠道",
                    channel.label
                ));
            }
            let mut next = ChannelPolicy {
                id: channel.id.clone(),
                label: channel.label.clone(),
                connection,
                template_refs: channel.template_refs.clone(),
                model_refs: channel.model_refs.clone(),
                selection: channel.selection.clone(),
                model_order: channel.model_order.clone(),
                discovered: channel.discovered.clone(),
                defaults: channel.defaults.clone(),
                overrides: channel.overrides.clone(),
                family_overrides: channel.family_overrides.clone(),
                naming: channel.naming.clone(),
            };
            if let (Some(ids), Some(previous)) = (&channel.model_subset, working.or(committed)) {
                let mut kept = previous.clone();
                for id in ids {
                    match channel.naming.get(id) {
                        Some(value) => {
                            kept.naming.insert(id.clone(), value.clone());
                        }
                        None => {
                            kept.naming.remove(id);
                        }
                    }
                    kept.discovered.retain(|m| &m.id != id);
                    kept.discovered
                        .extend(channel.discovered.iter().filter(|m| &m.id == id).cloned());
                    match channel.model_refs.get(id) {
                        Some(value) => {
                            kept.model_refs.insert(id.clone(), value.clone());
                        }
                        None => {
                            kept.model_refs.remove(id);
                        }
                    }
                    match channel.overrides.get(id) {
                        Some(value) => {
                            kept.overrides.insert(id.clone(), value.clone());
                        }
                        None => {
                            kept.overrides.remove(id);
                        }
                    }
                    if !kept.model_order.contains(id) {
                        kept.model_order.push(id.clone());
                    }
                }
                notices.push(format!("{}：仅接收所选型号的声明、明确覆盖和版本引用；本机渠道共用设置、公开范围、排序及其他型号保持",channel.label));
                next = kept;
            }
            if let Some(index) = policy.channels.iter().position(|c| c.id == channel.id) {
                policy.channels[index] = next;
            } else {
                policy.channels.push(next);
            }
        }
        if let Some(order) = &incoming.channel_order {
            let local_order: Vec<_> = local
                .workspace
                .as_ref()
                .map(|w| &w.policy)
                .unwrap_or(&local.policy)
                .channels
                .iter()
                .map(|c| c.id.clone())
                .collect();
            let committed_order: Vec<_> =
                local.policy.channels.iter().map(|c| c.id.clone()).collect();
            if local.workspace.is_some() && local_order != committed_order && local_order != *order
            {
                return Err(invalid(
                    "draft_conflict",
                    "渠道顺序已有未保存修改，未自动覆盖",
                ));
            }
            let rank: BTreeMap<_, _> = order.iter().enumerate().map(|(i, id)| (id, i)).collect();
            policy
                .channels
                .sort_by_key(|c| rank.get(&c.id).copied().unwrap_or(usize::MAX));
        }
        notices.push("渠道策略仅进入本机草稿；运行保存、预算和重启核对仍须明确执行".into());
        // 旧包可能带 defaultChannelId；不再据此拒绝接收。
        policy.default_channel_id = None;
        Some(policy)
    } else {
        None
    };
    Ok((library, policy, notices))
}
/// Partial uploads preserve every unrelated remote object. The caller still
/// freezes the remote ETag and publishes with a conditional pointer update.
fn merge_model_subset(
    previous: &PortableChannel,
    incoming: &PortableChannel,
) -> ModelResult<PortableChannel> {
    if incoming.family_scope.is_some() {
        return merge_family(previous, incoming);
    }
    let Some(ids) = &incoming.model_subset else {
        return Ok(incoming.clone());
    };
    if !same_destination(previous, incoming) {
        return Err(invalid(
            "model_scope_direction",
            "型号子集不能改变远端已有渠道的共用连接，请先明确完整渠道方向",
        ));
    }
    let mut result = previous.clone();
    for id in ids {
        match incoming.naming.get(id) {
            Some(value) => {
                result.naming.insert(id.clone(), value.clone());
            }
            None => {
                result.naming.remove(id);
            }
        }
        result.discovered.retain(|m| &m.id != id);
        result
            .discovered
            .extend(incoming.discovered.iter().filter(|m| &m.id == id).cloned());
        match incoming.model_refs.get(id) {
            Some(v) => {
                result.model_refs.insert(id.clone(), v.clone());
            }
            None => {
                result.model_refs.remove(id);
            }
        }
        match incoming.overrides.get(id) {
            Some(v) => {
                result.overrides.insert(id.clone(), v.clone());
            }
            None => {
                result.overrides.remove(id);
            }
        }
        if !result.model_order.contains(id) {
            result.model_order.push(id.clone());
        }
    }
    if let Some(old) = &mut result.model_subset {
        old.extend(ids.clone());
        old.sort();
        old.dedup();
    }
    if let (Some(target), Some(source)) = (
        result.connection.as_mut().and_then(|c| c.provider.as_mut()),
        incoming
            .connection
            .as_ref()
            .and_then(|c| c.provider.as_ref()),
    ) {
        let keys = target
            .as_object()
            .unwrap()
            .keys()
            .chain(source.as_object().unwrap().keys())
            .filter(|k| {
                k.starts_with("model")
                    && (target.get(*k).is_some_and(serde_json::Value::is_object)
                        || source.get(*k).is_some_and(serde_json::Value::is_object))
            })
            .cloned()
            .collect::<BTreeSet<_>>();
        for key in keys {
            let map = target
                .as_object_mut()
                .unwrap()
                .entry(key.clone())
                .or_insert_with(|| serde_json::json!({}))
                .as_object_mut()
                .ok_or_else(|| invalid("model_scope", "远端型号覆盖字段不是映射"))?;
            for id in ids {
                map.remove(id);
                if let Some(value) = source[&key].get(id) {
                    map.insert(id.clone(), value.clone());
                }
            }
            if map.is_empty() {
                target.as_object_mut().unwrap().remove(&key);
            }
        }
        let declared = target
            .as_object_mut()
            .unwrap()
            .entry("models")
            .or_insert_with(|| serde_json::json!([]))
            .as_array_mut()
            .ok_or_else(|| invalid("model_scope", "远端型号声明不是列表"))?;
        // A declared raw ID may not have a discovery observation yet. The
        // explicit mask, rather than discovery, owns this migration scope.
        for id in ids {
            if !declared.iter().any(|v| v == id) {
                declared.push(serde_json::json!(id));
            }
        }
    }
    Ok(result)
}
pub(super) fn merge_packages(
    remote: ModelPackage,
    local: ModelPackage,
) -> ModelResult<ModelPackage> {
    validate_package(&remote)?;
    validate_package(&local)?;
    let source_created_at = local.created_at.clone();
    if remote.payload.candidate.is_some() || local.payload.candidate.is_some() {
        return Err(invalid(
            "draft_remote",
            "未提交候选不能作为WebDAV已提交配置合并",
        ));
    }
    let mut payload = remote.payload;
    for incoming in local.payload.templates {
        if let Some(existing) = payload.templates.iter_mut().find(|t| t.id == incoming.id) {
            for revision in incoming.revisions {
                if let Some(old) = existing.revisions.iter().find(|r| r.id == revision.id) {
                    if old != &revision {
                        return Err(invalid(
                            "revision_conflict",
                            "远端同一保存版本有不同内容，未发布",
                        ));
                    }
                } else {
                    existing.revisions.push(revision);
                }
            }
        } else {
            payload.templates.push(incoming);
        }
    }
    if let Some(incoming) = local.payload.policy {
        if let Some(existing) = payload.policy.as_mut() {
            if incoming.template_refs.is_some() {
                existing.template_refs = incoming.template_refs;
            }
            if incoming.channel_order.is_some() {
                existing.channel_order = incoming.channel_order;
            }
            for channel in incoming.channels {
                if let Some(index) = existing.channels.iter().position(|c| c.id == channel.id) {
                    existing.channels[index] =
                        merge_model_subset(&existing.channels[index], &channel)?;
                } else {
                    existing.channels.push(channel);
                }
            }
        } else {
            payload.policy = Some(incoming);
        }
    }
    let result = ModelPackage {
        format: "OCXD_MODEL_CONFIG".into(),
        format_version: package_version(&payload),
        schema_version: SCHEMA_VERSION,
        created_at: source_created_at,
        digest: sha256(&serde_json::to_vec(&payload)?),
        payload,
    };
    validate_package(&result)?;
    Ok(result)
}
fn incoming_path(root: &Path, id: &str) -> ModelResult<std::path::PathBuf> {
    require_uuid(id)?;
    let path = root
        .join("manager-state/model-config-incoming")
        .join(format!("{id}.json"));
    crate::modules::backup::safety::check_path(root, &path, true)?;
    Ok(path)
}
pub fn receive(root: &Path, package: ModelPackage) -> ModelResult<IncomingPlan> {
    receive_bound(root, package, BTreeMap::new(), None)
}
pub(super) fn receive_file(
    root: &Path,
    package: ModelPackage,
    home: &Path,
) -> ModelResult<IncomingPlan> {
    receive_bound(root, package, BTreeMap::new(), Some(home))
}
/// Resolve the baseline from the plan's original context, including on retry.
pub fn local_for_plan(root: &Path, plan: &IncomingPlan) -> ModelResult<Snapshot> {
    local_for_home(root, plan.file_home.as_deref())
}
pub(super) fn file_layout_matches(root: &Path, plan: &IncomingPlan) -> ModelResult<bool> {
    match &plan.expected_layout {
        Some(expected) => Ok(super::config_file::metadata_digest(root)? == *expected),
        None => Ok(true),
    }
}
fn local_for_home(root: &Path, home: Option<&Path>) -> ModelResult<Snapshot> {
    match home {
        Some(home) => super::config_file::snapshot(root, home),
        None => ModelStore::new(root).load(),
    }
}
fn receive_bound(
    root: &Path,
    package: ModelPackage,
    mut bindings: BTreeMap<String, ChannelBinding>,
    home: Option<&Path>,
) -> ModelResult<IncomingPlan> {
    validate_package(&package)?;
    let local = local_for_home(root, home)?;
    let policy = local
        .workspace
        .as_ref()
        .map(|w| &w.policy)
        .unwrap_or(&local.policy);
    for channel in package.payload.policy.iter().flat_map(|p| &p.channels) {
        if channel.model_subset.is_some()
            && !bindings.contains_key(&channel.id)
            && policy.channels.iter().any(|c| c.id == channel.id)
        {
            bindings.insert(
                channel.id.clone(),
                ChannelBinding {
                    target_id: channel.id.clone(),
                    keep_local_connection: true,
                    label: None,
                },
            );
        }
    }
    let effective = mapped_package(&local, &package, &bindings)?;
    let (merged_library, mut merged_policy, mut notices, preview_error) =
        match merge(&local, &effective) {
            Ok((library, policy, notices)) => (library, policy, notices, None),
            Err(error) => (
                local.library.clone(),
                None,
                vec![error.message],
                Some(error.code),
            ),
        };
    if home.is_some() && package.payload.candidate.is_none() {
        for source in effective.payload.policy.iter().flat_map(|p| &p.channels) {
            if let Some(public) = source.connection.as_ref().and_then(|c| c.provider.as_ref()) {
                if let Some(target) = merged_policy
                    .as_mut()
                    .and_then(|p| p.channels.iter_mut().find(|c| c.id == source.id))
                {
                    target.connection.enabled = !bindings
                        .values()
                        .any(|b| b.target_id == source.id && !b.keep_local_connection)
                        && !public["disabled"].as_bool().unwrap_or(false);
                }
            }
        }
    }
    for (source, binding) in &bindings {
        notices.push(if binding.keep_local_connection {
            format!("渠道 {source} → {}：采用模型规则，保留本机协议、节点、当前节点和Key；不采用来源Key", binding.target_id)
        } else {
            format!("渠道 {source} → {}：建立独立停用草稿；模版中原有渠道匹配范围保持，保存前请检查匹配", binding.target_id)
        });
    }
    let plan = IncomingPlan {
        id: uuid::Uuid::new_v4().to_string(),
        file_home: home.map(Path::to_path_buf),
        expected_library: local.library_digest,
        expected_policy: local.policy_digest,
        expected_workspace: local.workspace_digest,
        expected_layout: if home.is_some() {
            Some(super::config_file::metadata_digest(root)?)
        } else {
            None
        },
        package,
        merged_library,
        merged_policy,
        notices,
        preview_error,
        available_keys: vec![],
        file_digest: None,
        manager: None,
        available_webdav_passwords: vec![],
        adoption: None,
        assets: None,
        available_extension_credentials: false,
        available_extension_ids: vec![],
        models_accepted: false,
        protected: false,
        channel_bindings: bindings,
        asset_mappings: Default::default(),
        extension_source: None,
        sync: None,
        comparison: None,
    };
    let bytes = serde_json::to_vec_pretty(&plan)?;
    if bytes.len() > 64 * 1024 * 1024 {
        return Err(invalid("package_limit", "模型包超过64MiB"));
    }
    crate::infrastructure::atomic_write::atomic_write(
        &incoming_path(root, &plan.id)?,
        &bytes,
        0o600,
    )?;
    Ok(plan)
}
fn mapped_package(
    local: &Snapshot,
    source: &ModelPackage,
    bindings: &BTreeMap<String, ChannelBinding>,
) -> ModelResult<ModelPackage> {
    let mut result = source.clone();
    let mut targets = BTreeSet::new();
    let local_policy = local
        .workspace
        .as_ref()
        .map(|w| &w.policy)
        .unwrap_or(&local.policy);
    for (id, binding) in bindings {
        require_uuid(id)?;
        require_uuid(&binding.target_id)?;
        let index = source
            .payload
            .policy
            .as_ref()
            .and_then(|p| p.channels.iter().position(|c| &c.id == id))
            .ok_or_else(|| invalid("channel_mapping", "映射的渠道不在所选范围"))?;
        let channel = &mut result.payload.policy.as_mut().unwrap().channels[index];
        if binding.keep_local_connection {
            let target = local_policy
                .channels
                .iter()
                .find(|c| c.id == binding.target_id)
                .ok_or_else(|| invalid("channel_mapping", "映射的本机渠道已不存在"))?;
            if binding.label.is_some() {
                return Err(invalid("channel_mapping", "保留本机连接不能重命名渠道"));
            }
            channel.label = target.label.clone();
            channel.protocol = target.connection.protocol.clone();
            channel.connection = if channel.family_scope.is_some() {
                None
            } else {
                portable_connection(target)
            };
        } else {
            if local_policy
                .channels
                .iter()
                .any(|c| c.id == binding.target_id)
                || source
                    .payload
                    .policy
                    .iter()
                    .flat_map(|p| &p.channels)
                    .any(|c| c.id == binding.target_id)
                || channel.connection.is_none()
                || binding.label.as_ref().is_none_or(|s| {
                    s.trim().is_empty() || s.len() > 256 || s.chars().any(char::is_control)
                })
            {
                return Err(invalid(
                    "channel_mapping",
                    "新渠道须有独立身份、名称及来源节点",
                ));
            }
            channel.label = binding.label.as_ref().unwrap().clone();
        }
        channel.id = binding.target_id.clone();
    }
    for channel in result.payload.policy.iter().flat_map(|p| &p.channels) {
        if !targets.insert(&channel.id) {
            return Err(invalid("channel_mapping", "多个来源渠道不能映射到同一目标"));
        }
    }
    if let Some(order) = result
        .payload
        .policy
        .as_mut()
        .and_then(|p| p.channel_order.as_mut())
    {
        for id in order {
            if let Some(binding) = bindings.get(id) {
                *id = binding.target_id.clone();
            }
        }
    }
    result.format_version = package_version(&result.payload);
    result.digest = sha256(&serde_json::to_vec(&result.payload)?);
    validate_package(&result)?;
    Ok(result)
}
pub(super) fn key_target<'a>(plan: &'a IncomingPlan, source: &'a str) -> Option<&'a str> {
    match plan.channel_bindings.get(source) {
        Some(binding) if binding.keep_local_connection => None,
        Some(binding) => Some(&binding.target_id),
        None => Some(source),
    }
}
pub fn select_received(root: &Path, id: &str, scope: ReceiveScope) -> ModelResult<IncomingPlan> {
    select_received_context(root, id, scope, None)
}
pub fn select_received_context(
    root: &Path,
    id: &str,
    scope: ReceiveScope,
    passphrase: Option<&str>,
) -> ModelResult<IncomingPlan> {
    if super::file_objects::has_adoption(root, id)? {
        return Err(invalid(
            "import_in_progress",
            "原导入已开始采用，请先核对其结果，不改变原范围",
        ));
    }
    let original: IncomingPlan = serde_json::from_slice(
        &crate::modules::backup::safety::read_file(&incoming_path(root, id)?, 64 * 1024 * 1024)?,
    )?;
    if original.id != id {
        return Err(invalid("incoming_identity", "接收记录身份不一致"));
    }
    let current = local_for_plan(root, &original)?;
    if (
        current.library_digest,
        current.policy_digest,
        current.workspace_digest,
    ) != (
        original.expected_library.clone(),
        original.expected_policy.clone(),
        original.expected_workspace.clone(),
    ) {
        return Err(invalid(
            "stale_baseline",
            "接收后本机基准已变化，请重新比较原文件",
        ));
    }
    if scope.template_refs.is_empty()
        && scope.channel_ids.is_empty()
        && !scope.include_global
        && !scope.preferences
        && !scope.extensions
        && scope.endpoint_ids.is_empty()
        && scope.account_ids.is_empty()
        && scope.skill_names.is_empty()
        && scope.mcp_names.is_empty()
    {
        return Err(invalid("import_scope", "请选择至少一个接收对象"));
    }
    let mut package = original.package.clone();
    validate_package(&package)?;
    if scope.channel_ids.iter().any(|id| {
        package
            .payload
            .policy
            .as_ref()
            .is_none_or(|p| !p.channels.iter().any(|c| &c.id == id))
    }) {
        return Err(invalid("import_scope", "选择了包内不存在的渠道"));
    }
    let mut wanted = scope
        .template_refs
        .iter()
        .map(|r| (r.template_id.clone(), r.revision_id.clone()))
        .collect::<BTreeSet<_>>();
    for reference in &scope.template_refs {
        if !package.payload.templates.iter().any(|t| {
            t.id == reference.template_id
                && t.revisions.iter().any(|r| r.id == reference.revision_id)
        }) {
            return Err(invalid("import_scope", "选择了包内不存在的保存版本"));
        }
    }
    if let Some(policy) = &mut package.payload.policy {
        policy
            .channels
            .retain(|channel| scope.channel_ids.contains(&channel.id));
        if let Some(order) = &mut policy.channel_order {
            order.retain(|id| scope.channel_ids.contains(id));
        }
        if !scope.include_global {
            policy.template_refs = None;
            policy.channel_order = None;
            policy.default_channel_id = None;
        }
        if scope
            .channel_models
            .keys()
            .any(|id| !scope.channel_ids.contains(id))
        {
            return Err(invalid("model_scope", "不能限定未选择的接收渠道"));
        }
        for channel in &mut policy.channels {
            if let Some(ids) = scope.channel_models.get(&channel.id) {
                *channel = restrict_models(channel, ids)?;
            }
        }
        for reference in revision_refs(policy) {
            wanted.insert((reference.template_id.clone(), reference.revision_id.clone()));
        }
        if policy.channels.is_empty()
            && policy.template_refs.is_none()
            && policy.channel_order.is_none()
        {
            package.payload.policy = None;
        }
    } else if scope.include_global {
        return Err(invalid("import_scope", "包内没有全局字段"));
    }
    for template in &mut package.payload.templates {
        template
            .revisions
            .retain(|revision| wanted.contains(&(template.id.clone(), revision.id.clone())));
        if template
            .default_revision
            .as_ref()
            .is_some_and(|id| !template.revisions.iter().any(|r| &r.id == id))
        {
            template.default_revision = None;
        }
    }
    package
        .payload
        .templates
        .retain(|template| !template.revisions.is_empty());
    package.digest = sha256(&serde_json::to_vec(&package.payload)?);
    let mut bindings = BTreeMap::new();
    for (source, action) in scope.channel_mappings {
        if !scope.channel_ids.contains(&source) {
            return Err(invalid("channel_mapping", "映射仅适用于已选择渠道"));
        }
        let binding = match action {
            ChannelMapping::Local { target_id } => ChannelBinding {
                target_id,
                keep_local_connection: true,
                label: None,
            },
            ChannelMapping::New { label } => ChannelBinding {
                target_id: original
                    .channel_bindings
                    .get(&source)
                    .filter(|b| !b.keep_local_connection && b.label.as_ref() == Some(&label))
                    .map(|b| b.target_id.clone())
                    .unwrap_or_else(|| uuid::Uuid::new_v4().to_string()),
                keep_local_connection: false,
                label: Some(label),
            },
        };
        bindings.insert(source, binding);
    }
    let mut selected = receive_bound(root, package, bindings, original.file_home.as_deref())?;
    if !scope.account_ids.is_empty() && original.manager.is_none() {
        return Err(invalid("import_scope", "选择了包内不存在的账户信息"));
    }
    if let Some(manager) = &original.manager {
        if manager.accounts.iter().any(|a| {
            scope.account_ids.contains(&a.id)
                && !crate::modules::sync::portable_accounts::information_supported(a)
        }) {
            return Err(invalid(
                "account_capability",
                "所选账户平台或来源尚未支持信息采用",
            ));
        }
        if scope
            .account_ids
            .iter()
            .any(|id| !manager.accounts.iter().any(|a| &a.id == id))
            || scope.preferences && manager.preferences.is_none()
            || scope.extensions && manager.extensions.is_none()
            || scope
                .endpoint_ids
                .iter()
                .any(|id| !manager.webdav.iter().any(|e| &e.id == id))
        {
            return Err(invalid("import_scope", "选择了包内不存在的管理器配置"));
        }
        selected.manager = Some(crate::modules::sync::portable_manager::Settings {
            accounts: manager
                .accounts
                .iter()
                .filter(|a| scope.account_ids.contains(&a.id))
                .cloned()
                .collect(),
            preferences: if scope.preferences {
                manager.preferences.clone()
            } else {
                None
            },
            extensions: if scope.extensions {
                original
                    .extension_source
                    .as_ref()
                    .or(manager.extensions.as_ref())
                    .map(|config| {
                        crate::modules::sync::portable_manager::mapped_extensions(
                            config,
                            &scope.asset_mappings,
                        )
                    })
                    .transpose()?
            } else {
                None
            },
            webdav: manager
                .webdav
                .iter()
                .filter(|e| scope.endpoint_ids.contains(&e.id))
                .cloned()
                .collect(),
        });
        selected.extension_source = if scope.extensions {
            original
                .extension_source
                .clone()
                .or(manager.extensions.clone())
        } else {
            None
        };
        selected.available_webdav_passwords = original
            .available_webdav_passwords
            .iter()
            .filter(|id| scope.endpoint_ids.contains(id))
            .cloned()
            .collect();
        crate::modules::sync::portable_manager::select(
            root,
            id,
            &selected.id,
            scope.preferences,
            scope.extensions,
            &scope.endpoint_ids,
            &scope.account_ids,
        )?;
        if let Some(config) = selected
            .manager
            .as_ref()
            .and_then(|m| m.extensions.as_ref())
        {
            crate::modules::sync::portable_manager::remap_extensions(root, &selected.id, config)?;
        }
    }
    super::file_objects::copy_source(root, &original, &mut selected)?;
    super::file_objects::select_asset_subset(
        root,
        &original,
        &mut selected,
        &scope.skill_names,
        &scope.mcp_names,
        &scope.asset_mappings,
        passphrase,
    )?;
    super::file_objects::compare_incoming(root, &mut selected, passphrase)?;
    if original.sync.is_some() {
        selected.sync = selected.comparison.clone().map(|mut p| {
            p.source = "remote".into();
            p
        });
        super::sync_state::rebind_pending(root, &original.id, &selected.id)?;
    }
    write_incoming(root, &selected)?;
    super::file_objects::remember_incoming(root, &selected.id)?;
    Ok(selected)
}
pub fn accept(root: &Path, id: &str) -> ModelResult<Snapshot> {
    accept_with_credentials(root, id, &BTreeMap::new())
}
#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct AcceptanceReceipt {
    id: String,
    package_digest: String,
    intent_digest: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    candidate_digest: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    saved_file_digest: Option<String>,
}
#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct FileAcceptanceCandidate {
    workspace: Option<PolicyDraft>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct FileSaveIntent {
    receipt: AcceptanceReceipt,
    policy: Policy,
    #[serde(default)]
    final_bytes: Option<Vec<u8>>,
}
fn read_file_intent(
    root: &Path,
    plan: &IncomingPlan,
    credentials: &BTreeMap<String, String>,
) -> ModelResult<Option<FileSaveIntent>> {
    let path = incoming_path(root, &plan.id)?.with_extension("saving.json");
    crate::modules::backup::safety::check_path(root, &path, true)?;
    if !path.exists() {
        return Ok(None);
    }
    let value: FileSaveIntent = serde_json::from_slice(
        &crate::modules::backup::safety::read_file(&path, 64 * 1024 * 1024)?,
    )?;
    if value
        .final_bytes
        .as_ref()
        .is_some_and(|b| value.receipt.saved_file_digest.as_deref() != Some(sha256(b).as_str()))
    {
        return Err(invalid("incoming_intent", "原保存内容未通过摘要核验"));
    }
    if value.receipt.id != plan.id
        || value.receipt.package_digest != plan.package.digest
        || value.receipt.intent_digest != intent_digest(plan, credentials)?
    {
        return Err(invalid(
            "import_replay_conflict",
            "原文件写入意图与所选范围不同",
        ));
    }
    Ok(Some(value))
}
pub(super) fn saved_file_material(
    root: &Path,
    plan: &IncomingPlan,
) -> ModelResult<Option<(Vec<u8>, Vec<u8>)>> {
    let accepted = incoming_path(root, &plan.id)?.with_extension("accepted.json");
    let pending = incoming_path(root, &plan.id)?.with_extension("saving.json");
    crate::modules::backup::safety::check_path(root, &accepted, true)?;
    crate::modules::backup::safety::check_path(root, &pending, true)?;
    if !accepted.exists() || !pending.exists() {
        return Ok(None);
    }
    let receipt: AcceptanceReceipt =
        serde_json::from_slice(&crate::modules::backup::safety::read_file(&accepted, 4096)?)?;
    let intent: FileSaveIntent = serde_json::from_slice(
        &crate::modules::backup::safety::read_file(&pending, 64 * 1024 * 1024)?,
    )?;
    if receipt.id != plan.id
        || receipt.package_digest != plan.package.digest
        || receipt.intent_digest != intent.receipt.intent_digest
    {
        return Err(invalid("scope_backup", "保存回执与原备份操作不同"));
    }
    let Some(bytes) = intent.final_bytes else {
        return Ok(None);
    };
    if receipt.saved_file_digest.as_deref() != Some(sha256(&bytes).as_str()) {
        return Err(invalid("scope_backup", "已保存内容未通过原回执核验"));
    }
    Ok(Some((
        bytes,
        super::config_file::intended_metadata_bytes(&intent.policy)?,
    )))
}
fn intent_digest(
    plan: &IncomingPlan,
    credentials: &BTreeMap<String, String>,
) -> ModelResult<String> {
    if plan.file_home.is_some() {
        if let Some(layout) = &plan.expected_layout {
            return Ok(sha256(&serde_json::to_vec(&(
                &plan.file_home,
                &plan.expected_policy,
                layout,
                &plan.expected_library,
                &plan.merged_library,
                &plan.merged_policy,
                credentials,
                &plan.channel_bindings,
                &plan.asset_mappings,
            ))?));
        }
        return Ok(sha256(&serde_json::to_vec(&(
            &plan.file_home,
            &plan.expected_policy,
            &plan.expected_library,
            &plan.merged_library,
            &plan.merged_policy,
            credentials,
            &plan.channel_bindings,
            &plan.asset_mappings,
        ))?));
    }
    let imported = plan
        .merged_policy
        .iter()
        .flat_map(|p| &p.channels)
        .filter_map(|c| {
            c.connection
                .imported_config
                .as_ref()
                .map(|reference| (&c.id, reference))
        })
        .collect::<BTreeMap<_, _>>();
    if !imported.is_empty() {
        return Ok(sha256(&serde_json::to_vec(&(
            credentials,
            &plan.channel_bindings,
            &plan.asset_mappings,
            imported,
        ))?));
    }
    if !plan.asset_mappings.is_empty() {
        return Ok(sha256(&serde_json::to_vec(&(
            credentials,
            &plan.channel_bindings,
            &plan.asset_mappings,
        ))?));
    }
    let bytes = if plan.channel_bindings.is_empty() {
        serde_json::to_vec(credentials)?
    } else {
        serde_json::to_vec(&(credentials, &plan.channel_bindings))?
    };
    Ok(sha256(&bytes))
}
pub(super) fn verify_acceptance(
    root: &Path,
    plan: &IncomingPlan,
    credentials: &BTreeMap<String, String>,
) -> ModelResult<bool> {
    let path = incoming_path(root, &plan.id)?.with_extension("accepted.json");
    crate::modules::backup::safety::check_path(root, &path, true)?;
    if !path.exists() {
        return Ok(false);
    }
    let receipt: AcceptanceReceipt =
        serde_json::from_slice(&crate::modules::backup::safety::read_file(&path, 4096)?)?;
    if receipt.id != plan.id
        || receipt.package_digest != plan.package.digest
        || receipt.intent_digest != intent_digest(plan, credentials)?
    {
        return Err(invalid(
            "import_replay_conflict",
            "该接收操作已确认其他范围或凭据选择，请重新比较",
        ));
    }
    Ok(true)
}
pub(super) fn accepted(root: &Path, plan: &IncomingPlan) -> ModelResult<bool> {
    let path = incoming_path(root, &plan.id)?.with_extension("accepted.json");
    crate::modules::backup::safety::check_path(root, &path, true)?;
    if !path.exists() {
        return Ok(false);
    }
    let receipt: AcceptanceReceipt =
        serde_json::from_slice(&crate::modules::backup::safety::read_file(&path, 4096)?)?;
    if receipt.id != plan.id || receipt.package_digest != plan.package.digest {
        return Err(invalid("incoming_identity", "原接收回执与清单不同"));
    }
    Ok(true)
}
pub(super) fn intended_applied(
    root: &Path,
    plan: &IncomingPlan,
    credentials: &BTreeMap<String, String>,
) -> ModelResult<bool> {
    let local = local_for_plan(root, plan)?;
    if plan.file_home.is_some() {
        let path = incoming_path(root, &plan.id)?.with_extension("accepted.json");
        crate::modules::backup::safety::check_path(root, &path, true)?;
        if path.exists() {
            let receipt: AcceptanceReceipt =
                serde_json::from_slice(&crate::modules::backup::safety::read_file(&path, 4096)?)?;
            if let Some(saved) = receipt.saved_file_digest {
                return Ok(receipt.id == plan.id
                    && receipt.package_digest == plan.package.digest
                    && local.policy_digest == saved
                    && local.library == plan.merged_library);
            }
        }
        if plan.package.payload.candidate.is_none() {
            if let Some(pending) = read_file_intent(root, plan, credentials)? {
                if pending.receipt.saved_file_digest.as_deref()
                    == Some(local.policy_digest.as_str())
                    && local.library == plan.merged_library
                {
                    return Ok(true);
                }
            }
        }
        return Ok(plan.preview_error.is_none()
            && local.policy_digest == plan.expected_policy
            && local.library == plan.merged_library);
    }
    let mut policy = plan.merged_policy.clone();
    bind_credentials(&mut policy, credentials)?;
    Ok(plan.preview_error.is_none()
        && local.library == plan.merged_library
        && policy.as_ref().is_none_or(|policy| {
            local
                .workspace
                .as_ref()
                .is_some_and(|w| &w.policy == policy)
        }))
}
pub fn read_incoming(root: &Path, id: &str) -> ModelResult<IncomingPlan> {
    let plan: IncomingPlan = serde_json::from_slice(&crate::modules::backup::safety::read_file(
        &incoming_path(root, id)?,
        64 * 1024 * 1024,
    )?)?;
    if plan.id != id {
        return Err(invalid("incoming_identity", "接收记录身份不一致"));
    }
    validate_package(&plan.package)?;
    Ok(plan)
}
pub(super) fn write_incoming(root: &Path, plan: &IncomingPlan) -> ModelResult<()> {
    crate::infrastructure::atomic_write::atomic_write(
        &incoming_path(root, &plan.id)?,
        &serde_json::to_vec(plan)?,
        0o600,
    )?;
    Ok(())
}
pub(super) fn accept_with_credentials(
    root: &Path,
    id: &str,
    credentials: &BTreeMap<String, String>,
) -> ModelResult<Snapshot> {
    accept_with_file_keys(root, id, credentials, vec![])
}
pub(super) fn accept_with_file_keys(
    root: &Path,
    id: &str,
    credentials: &BTreeMap<String, String>,
    file_keys: Vec<super::config_file::CredentialEdit>,
) -> ModelResult<Snapshot> {
    let path = incoming_path(root, id)?;
    crate::modules::backup::safety::check_path(
        root,
        &crate::infrastructure::locking::lock_path_for(&path),
        true,
    )?;
    let _guard = crate::infrastructure::locking::TargetFileLock::lock(&path)?;
    let plan = read_incoming(root, id)?;
    let local = local_for_plan(root, &plan)?;
    for (channel, reference) in credentials {
        require_uuid(reference)?;
        if plan.package.payload.policy.as_ref().is_none_or(|p| {
            !p.channels
                .iter()
                .any(|c| key_target(&plan, &c.id) == Some(channel.as_str()))
        }) {
            return Err(invalid("credential_scope", "凭据目标不在已选接收渠道内"));
        }
    }
    let intent_digest = intent_digest(&plan, credentials)?;
    let receipt_path = path.with_extension("accepted.json");
    crate::modules::backup::safety::check_path(root, &receipt_path, true)?;
    if plan.file_home.is_some() {
        if plan.package.payload.candidate.is_none() {
            return accept_file_snapshot(
                root,
                &plan,
                local,
                credentials,
                &receipt_path,
                &intent_digest,
                file_keys,
            );
        }
        return accept_file_candidate(
            root,
            &plan,
            local,
            credentials,
            &receipt_path,
            &intent_digest,
        );
    }
    if verify_acceptance(root, &plan, credentials)? {
        return Ok(local);
    }
    let mut intended_policy = plan.merged_policy.clone();
    bind_credentials(&mut intended_policy, credentials)?;
    let already_applied = plan.preview_error.is_none()
        && local.library == plan.merged_library
        && intended_policy.as_ref().is_none_or(|policy| {
            local
                .workspace
                .as_ref()
                .is_some_and(|w| &w.policy == policy)
        });
    if (
        local.library_digest.as_str(),
        local.policy_digest.as_str(),
        local.workspace_digest.as_str(),
    ) != (
        plan.expected_library.as_str(),
        plan.expected_policy.as_str(),
        plan.expected_workspace.as_str(),
    ) && !already_applied
    {
        return Err(invalid(
            "stale_baseline",
            "接收后本地内容已变化，请重新比较导入",
        ));
    }
    let snapshot = if already_applied {
        local
    } else {
        let (library, policy) = recompute_acceptance(root, &plan, &local, credentials)?;
        ModelStore::new(root).accept_import(
            &plan.expected_library,
            &plan.expected_policy,
            &plan.expected_workspace,
            library,
            policy,
        )?
    };
    crate::infrastructure::atomic_write::atomic_write(
        &receipt_path,
        &serde_json::to_vec(&AcceptanceReceipt {
            id: id.into(),
            package_digest: plan.package.digest,
            intent_digest,
            candidate_digest: None,
            saved_file_digest: None,
        })?,
        0o600,
    )?;
    Ok(snapshot)
}
fn recompute_acceptance(
    root: &Path,
    plan: &IncomingPlan,
    local: &Snapshot,
    credentials: &BTreeMap<String, String>,
) -> ModelResult<(Library, Option<Policy>)> {
    let effective = mapped_package(local, &plan.package, &plan.channel_bindings)?;
    let (library, mut policy, _) = merge(local, &effective)?;
    for intended in plan.merged_policy.iter().flat_map(|p| &p.channels) {
        let Some(reference) = &intended.connection.imported_config else {
            continue;
        };
        let source = plan
            .package
            .payload
            .policy
            .iter()
            .flat_map(|p| &p.channels)
            .find(|source| key_target(plan, &source.id) == Some(intended.id.as_str()))
            .and_then(|source| source.connection.as_ref())
            .and_then(|c| c.provider.as_ref());
        let Some(source) = source else {
            continue;
        };
        let target = policy
            .as_mut()
            .and_then(|p| p.channels.iter_mut().find(|c| c.id == intended.id))
            .ok_or_else(|| invalid("provider_import_scope", "重算接收目标缺失"))?;
        let staged = super::provider_import::load(root, target, reference)?;
        if staged.public != *source {
            return Err(invalid(
                "provider_import_scope",
                "受保护原字段不属于当前源渠道",
            ));
        }
        target.connection.imported_config = Some(reference.clone());
        target.connection.auth_mode = source["authMode"].as_str().map(str::to_owned);
        target.connection.enabled = !plan
            .channel_bindings
            .values()
            .any(|b| b.target_id == target.id && !b.keep_local_connection)
            && plan.file_home.is_some()
            && plan.package.payload.candidate.is_none()
            && !source["disabled"].as_bool().unwrap_or(false);
    }
    bind_credentials(&mut policy, credentials)?;
    let mut intended_policy = plan.merged_policy.clone();
    bind_credentials(&mut intended_policy, credentials)?;
    if library != plan.merged_library || policy != intended_policy {
        return Err(invalid(
            "incoming_intent",
            "采用重算与已确认范围不同，未写入",
        ));
    }

    Ok((library, policy))
}
/// Transfer candidates live beside their receipt, never in the ordinary disk
/// draft. Replaying reads current file/library state and returns that candidate.
pub(super) fn accepted_snapshot(root: &Path, plan: &IncomingPlan) -> ModelResult<Snapshot> {
    let mut snapshot = local_for_plan(root, plan)?;
    if plan.file_home.is_none() {
        return Ok(snapshot);
    }
    let receipt_path = incoming_path(root, &plan.id)?.with_extension("accepted.json");
    crate::modules::backup::safety::check_path(root, &receipt_path, false)?;
    let receipt: AcceptanceReceipt = serde_json::from_slice(
        &crate::modules::backup::safety::read_file(&receipt_path, 4096)?,
    )?;
    if receipt.id != plan.id || receipt.package_digest != plan.package.digest {
        return Err(invalid(
            "incoming_identity",
            "接收回执与原操作不同，未替换当前配置",
        ));
    }
    if receipt.id == plan.id
        && receipt.package_digest == plan.package.digest
        && receipt.saved_file_digest.is_some()
    {
        return Ok(snapshot);
    }
    let candidate_path = incoming_path(root, &plan.id)?.with_extension("candidate.json");
    crate::modules::backup::safety::check_path(root, &candidate_path, false)?;
    let bytes = crate::modules::backup::safety::read_file(&candidate_path, 64 * 1024 * 1024)?;
    if receipt.id != plan.id
        || receipt.package_digest != plan.package.digest
        || receipt.candidate_digest.as_deref() != Some(sha256(&bytes).as_str())
    {
        return Err(invalid(
            "import_replay_conflict",
            "接收候选与原回执不同，未替换当前配置",
        ));
    }
    let candidate: FileAcceptanceCandidate = serde_json::from_slice(&bytes)?;
    if candidate
        .workspace
        .as_ref()
        .is_some_and(|w| w.base_policy != plan.expected_policy)
    {
        return Err(invalid("incoming_intent", "接收候选的文件基准不同"));
    }
    attach_candidate(&mut snapshot, candidate.workspace)?;
    Ok(snapshot)
}
fn attach_candidate(snapshot: &mut Snapshot, candidate: Option<PolicyDraft>) -> ModelResult<()> {
    snapshot.workspace_digest = match &candidate {
        Some(candidate) => sha256(&serde_json::to_vec(candidate)?),
        None => sha256(&[]),
    };
    snapshot.workspace = candidate;
    Ok(())
}
fn accept_file_candidate(
    root: &Path,
    plan: &IncomingPlan,
    local: Snapshot,
    credentials: &BTreeMap<String, String>,
    receipt_path: &Path,
    intent: &str,
) -> ModelResult<Snapshot> {
    if verify_acceptance(root, plan, credentials)? {
        return accepted_snapshot(root, plan);
    }
    if local.policy_digest != plan.expected_policy
        || !file_layout_matches(root, plan)?
        || local.workspace_digest != plan.expected_workspace
        || (local.library_digest != plan.expected_library && local.library != plan.merged_library)
    {
        return Err(invalid(
            "stale_baseline",
            "采用前文件或模版库已变化，请重新比较",
        ));
    }
    if let Some(error) = &plan.preview_error {
        return Err(invalid(error, "所选配置仍有冲突，请比较后再采用"));
    }
    let (library, policy) = recompute_acceptance(root, plan, &local, credentials)?;
    let candidate = FileAcceptanceCandidate {
        workspace: policy.map(|policy| PolicyDraft {
            base_policy: plan.expected_policy.clone(),
            policy,
        }),
    };
    let bytes = serde_json::to_vec(&candidate)?;
    let candidate_path = incoming_path(root, &plan.id)?.with_extension("candidate.json");
    crate::modules::backup::safety::check_path(root, &candidate_path, true)?;
    crate::infrastructure::atomic_write::atomic_write(&candidate_path, &bytes, 0o600)?;
    let current = local_for_plan(root, plan)?;
    if current.policy_digest != plan.expected_policy
        || current.library_digest != local.library_digest
    {
        return Err(invalid(
            "stale_baseline",
            "采用前文件或模版库已变化，请重新比较",
        ));
    }
    let committed = ModelStore::new(root).accept_library(&current.library_digest, library)?;
    let mut result = local_for_plan(root, plan)?;
    if result.policy_digest != plan.expected_policy {
        return Err(invalid(
            "stale_baseline",
            "采用期间文件已改变，候选已保留，请重新比较",
        ));
    }
    result.library = committed.library;
    result.library_digest = committed.library_digest;
    attach_candidate(&mut result, candidate.workspace)?;
    crate::infrastructure::atomic_write::atomic_write(
        receipt_path,
        &serde_json::to_vec(&AcceptanceReceipt {
            id: plan.id.clone(),
            package_digest: plan.package.digest.clone(),
            intent_digest: intent.into(),
            candidate_digest: Some(sha256(&bytes)),
            saved_file_digest: None,
        })?,
        0o600,
    )?;
    Ok(result)
}

/// Ordinary committed snapshots update the authoritative file. Only explicit
/// draft packages retain the historical candidate contract above.
fn accept_file_snapshot(
    root: &Path,
    plan: &IncomingPlan,
    local: Snapshot,
    credentials: &BTreeMap<String, String>,
    receipt_path: &Path,
    intent: &str,
    file_keys: Vec<super::config_file::CredentialEdit>,
) -> ModelResult<Snapshot> {
    if plan
        .comparison
        .as_ref()
        .is_some_and(|p| p.changes.is_none())
    {
        return Err(invalid("sync_compare", "无法比较当前内容，未更新保存文件"));
    }
    if verify_acceptance(root, plan, credentials)? {
        return accepted_snapshot(root, plan);
    }
    if let Some(pending) = read_file_intent(root, plan, credentials)? {
        if pending.receipt.saved_file_digest.as_deref() == Some(local.policy_digest.as_str())
            && local.library == plan.merged_library
        {
            let result = super::config_file::finish_recorded(
                root,
                plan.file_home.as_deref().unwrap(),
                &local.policy_digest,
                &pending.policy,
                plan.expected_layout.as_deref(),
            )?;
            crate::infrastructure::atomic_write::atomic_write(
                receipt_path,
                &serde_json::to_vec(&pending.receipt)?,
                0o600,
            )?;
            return Ok(result);
        }
    }
    if plan.preview_error.is_some() {
        return Err(invalid("incoming_preview", "所选配置仍有冲突，请重新比较"));
    }
    if local.policy_digest != plan.expected_policy
        || !file_layout_matches(root, plan)?
        || local.workspace_digest != plan.expected_workspace
        || (local.library_digest != plan.expected_library && local.library != plan.merged_library)
    {
        return Err(invalid(
            "stale_baseline",
            "确认前配置文件或模版库已变化，请重新读取；未覆盖配置",
        ));
    }
    let (library, policy) = recompute_acceptance(root, plan, &local, credentials)?;
    // The library can safely append immutable revisions before the file commit.
    // A failed file save keeps the same plan retryable against this exact library.
    ModelStore::new(root).accept_library(&local.library_digest, library)?;
    let result = if let Some(policy) = policy {
        super::config_file::save_observed_checked(
            root,
            plan.file_home.as_deref().unwrap(),
            super::config_file::SaveRequest {
                expected_file: plan.expected_policy.clone(),
                policy,
                credentials: file_keys,
                scope: None,
            },
            plan.expected_layout.as_deref(),
            |bytes, policy| {
                let path = incoming_path(root, &plan.id)?.with_extension("saving.json");
                crate::modules::backup::safety::check_path(root, &path, true)?;
                let pending = FileSaveIntent {
                    receipt: AcceptanceReceipt {
                        id: plan.id.clone(),
                        package_digest: plan.package.digest.clone(),
                        intent_digest: intent.into(),
                        candidate_digest: None,
                        saved_file_digest: Some(sha256(bytes)),
                    },
                    policy: policy.clone(),
                    final_bytes: Some(bytes.to_vec()),
                };
                crate::infrastructure::atomic_write::atomic_write(
                    &path,
                    &serde_json::to_vec(&pending)?,
                    0o600,
                )?;
                Ok(())
            },
        )?
        .snapshot
    } else {
        local_for_plan(root, plan)?
    };
    crate::infrastructure::atomic_write::atomic_write(
        receipt_path,
        &serde_json::to_vec(&AcceptanceReceipt {
            id: plan.id.clone(),
            package_digest: plan.package.digest.clone(),
            intent_digest: intent.into(),
            candidate_digest: None,
            saved_file_digest: Some(result.policy_digest.clone()),
        })?,
        0o600,
    )?;
    Ok(result)
}
fn bind_credentials(
    policy: &mut Option<Policy>,
    credentials: &BTreeMap<String, String>,
) -> ModelResult<()> {
    for (id, reference) in credentials {
        let channel = policy
            .as_mut()
            .and_then(|p| p.channels.iter_mut().find(|c| &c.id == id))
            .ok_or_else(|| invalid("credential_scope", "接收草稿缺少凭据目标"))?;
        channel.connection.credential_ref = Some(reference.clone());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn protection_uses_only_frozen_content_and_export_retry_keeps_identical_ciphertext() {
        use crate::modules::sync::{portable_file, portable_manager::Scope};
        let root = tempfile::tempdir().unwrap();
        let home = tempfile::tempdir().unwrap();
        let path = home.path().join("config.json");
        let original = serde_json::json!({"providers":{"fixture":{"adapter":"openai-chat","baseUrl":"https://fixture.example/v1","models":["old-model"],"selectedModels":["old-model"],"apiKey":"fixture-original-secret"}}});
        std::fs::write(&path, serde_json::to_vec(&original).unwrap()).unwrap();
        let saved = super::super::config_file::snapshot(root.path(), home.path()).unwrap();
        let plan = prepare_file_scope(
            root.path(),
            ExportScope {
                include_policy: true,
                channel_ids: vec![saved.policy.channels[0].id.clone()],
                include_global: true,
                template_refs: vec![],
                channel_models: Default::default(),
                channel_families: Default::default(),
            },
            None,
            true,
            &Scope {
                upstream_root: Some(home.path().into()),
                ..Default::default()
            },
        )
        .unwrap();
        let before = file_bytes(root.path(), &plan.id).unwrap();
        let frozen = portable_file::open(&before, None).unwrap();
        let mut later = original;
        later["providers"]["fixture"]["models"] = serde_json::json!(["later-model"]);
        later["providers"]["fixture"]["apiKey"] = serde_json::json!("fixture-later-secret");
        std::fs::write(&path, serde_json::to_vec(&later).unwrap()).unwrap();
        let protected =
            protect_file(root.path(), &plan.id, Some("fixture-protection-password")).unwrap();
        assert_ne!(protected.id, plan.id);
        let ciphertext = file_bytes(root.path(), &protected.id).unwrap();
        let opened = portable_file::open(&ciphertext, Some("fixture-protection-password")).unwrap();
        assert_eq!(sha256(&opened.document), sha256(&frozen.document));
        assert_eq!(protected.package.created_at, plan.package.created_at);
        super::super::file_exports::export(root.path(), &protected.id, None).unwrap();
        let retry = protect_file(
            root.path(),
            &protected.id,
            Some("fixture-protection-password"),
        )
        .unwrap();
        assert_eq!(retry.id, protected.id);
        assert_eq!(
            sha256(&file_bytes(root.path(), &retry.id).unwrap()),
            sha256(&ciphertext)
        );
        assert_eq!(
            protect_file(root.path(), &retry.id, None).unwrap_err().code,
            "export_intent"
        );
        assert_eq!(
            std::fs::read(&path).unwrap(),
            serde_json::to_vec(&later).unwrap()
        );
    }
    #[test]
    fn ordinary_file_acceptance_commits_saved_config_and_replay_preserves_later_edits() {
        let root = tempfile::tempdir().unwrap();
        let home = tempfile::tempdir().unwrap();
        let path = home.path().join("config.json");
        let raw = serde_json::json!({"providers":{"demo":{"adapter":"openai-chat","baseUrl":"https://fixture.example/v1","models":["a","b"],"selectedModels":["a"],"apiKey":"fixture-local-key","futureField":42}},"unrelated":true});
        std::fs::write(&path, serde_json::to_vec(&raw).unwrap()).unwrap();
        let local = super::super::config_file::snapshot(root.path(), home.path()).unwrap();
        let mut source = local.clone();
        source.policy.channels[0].selection = ModelSelection::Whitelist(vec!["b".into()]);
        let id = source.policy.channels[0].id.clone();
        let package = export_snapshot(
            &source,
            ExportScope {
                include_policy: true,
                channel_ids: vec![id],
                include_global: false,
                template_refs: vec![],
                channel_models: Default::default(),
                channel_families: Default::default(),
            },
        )
        .unwrap();
        let plan = receive_file(root.path(), package, home.path()).unwrap();
        super::super::transfer_backup::prepare(root.path(), &plan.id, true).unwrap();
        let backup_path = root
            .path()
            .join("backups/transfer-scope")
            .join(format!("{}.json", plan.id));
        let original_backup = std::fs::read(&backup_path).unwrap();
        super::super::transfer_backup::prepare(root.path(), &plan.id, true).unwrap();
        assert_eq!(std::fs::read(&backup_path).unwrap(), original_backup);
        assert_eq!(
            std::fs::read(&path).unwrap(),
            serde_json::to_vec(&raw).unwrap()
        );
        let accepted = accept(root.path(), &plan.id).unwrap();
        super::super::transfer_backup::finish(root.path(), &plan.id).unwrap();
        assert!(
            accepted.workspace.is_none(),
            "ordinary import must commit the saved file"
        );
        let actual: serde_json::Value =
            serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
        assert_eq!(
            actual["providers"]["demo"]["selectedModels"],
            serde_json::json!(["b"])
        );
        assert_eq!(actual["providers"]["demo"]["apiKey"], "fixture-local-key");
        assert_eq!(actual["providers"]["demo"]["futureField"], 42);
        assert_eq!(actual["unrelated"], true);
        let mut later = actual.clone();
        later["unrelated"] = serde_json::json!("later");
        std::fs::write(&path, serde_json::to_vec(&later).unwrap()).unwrap();
        let replay = accept(root.path(), &plan.id).unwrap();
        assert!(replay.workspace.is_none());
        assert_eq!(
            std::fs::read(&path).unwrap(),
            serde_json::to_vec(&later).unwrap()
        );
        super::super::transfer_backup::restore(root.path(), &plan.id, &["channels".into()])
            .unwrap();
        let restored: serde_json::Value =
            serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
        assert_eq!(
            restored["providers"]["demo"]["selectedModels"],
            serde_json::json!(["a"])
        );
        assert_eq!(restored["unrelated"], "later");
    }
    fn family_fixture(root: &Path) -> (Snapshot, TemplateRef, TemplateRef) {
        let mut channel = channel_fixture(root);
        let store = ModelStore::new(root);
        let mut refs = vec![];
        for name in ["family-a", "family-b"] {
            let mut content = TemplateContent::default();
            content.matching.include.push(Pattern {
                kind: MatchKind::Prefix,
                value: format!("{name}-"),
            });
            let saved = store
                .save(SaveTemplate {
                    expected_library: store.load().unwrap().library_digest,
                    template_id: None,
                    base_revision: None,
                    label: name.into(),
                    content,
                })
                .unwrap();
            refs.push(TemplateRef {
                template_id: saved.template_id,
                revision_id: saved.revision_id,
            });
        }
        channel.template_refs = vec![refs[1].clone()];
        channel.model_order = vec!["family-b-one".into(), "family-a-one".into()];
        channel.selection = ModelSelection::Whitelist(channel.model_order.clone());
        channel.discovered = channel
            .model_order
            .iter()
            .map(|id| DiscoveredModel {
                id: id.clone(),
                label: id.clone(),
                rules: ModelRules::default(),
            })
            .collect();
        channel.defaults.fast = Field::Custom(false);
        channel.family_overrides.insert(
            refs[0].template_id.clone(),
            ModelRules {
                fast: Field::Custom(true),
                ..Default::default()
            },
        );
        channel.overrides.insert(
            "family-a-one".into(),
            ModelRules {
                context_window: Field::Custom(32000),
                ..Default::default()
            },
        );
        let before = store.load().unwrap();
        let mut policy = before.policy.clone();
        policy.template_refs = vec![refs[0].clone()];
        policy.channels = vec![channel];
        store
            .commit_runtime_policy(
                &before.library_digest,
                &before.policy_digest,
                &before.workspace_digest,
                policy,
            )
            .unwrap();
        (store.load().unwrap(), refs[0].clone(), refs[1].clone())
    }
    fn family_scope(snapshot: &Snapshot, reference: &TemplateRef, shared: bool) -> ExportScope {
        ExportScope {
            channel_families: BTreeMap::from([(
                snapshot.policy.channels[0].id.clone(),
                FamilyScope {
                    template_ids: vec![reference.template_id.clone()],
                    include_channel_defaults: shared,
                },
            )]),
            channel_models: BTreeMap::new(),
            include_policy: true,
            channel_ids: vec![snapshot.policy.channels[0].id.clone()],
            template_refs: vec![],
            include_global: false,
        }
    }
    #[test]
    fn family_fragment_carries_exact_closure_and_preserves_other_local_state() {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        let (original, a, b) = family_fixture(source.path());
        let scope = family_scope(&original, &a, false);
        let package = export(source.path(), scope.clone()).unwrap();
        validate_package(&package).unwrap();
        assert_eq!(package.format_version, 5);
        assert_eq!(
            package
                .payload
                .templates
                .iter()
                .map(|t| t.id.clone())
                .collect::<Vec<_>>(),
            vec![a.template_id.clone()]
        );
        let policy = package.payload.policy.as_ref().unwrap();
        let fragment = &policy.channels[0];
        assert!(policy.template_refs.is_none() && policy.channel_order.is_none());
        assert!(fragment.connection.is_none());
        assert_eq!(fragment.defaults, ModelRules::default());
        assert_eq!(fragment.template_refs, vec![a.clone()]);
        assert_eq!(fragment.model_subset, Some(vec!["family-a-one".into()]));
        assert!(!fragment.family_overrides.contains_key(&b.template_id));
        let mut full_scope = scope.clone();
        full_scope.channel_families.clear();
        let full = export(source.path(), full_scope).unwrap();
        assert!(full.payload.policy.as_ref().unwrap().channels[0]
            .template_refs
            .contains(&a));
        let templates = export(
            source.path(),
            ExportScope {
                channel_families: Default::default(),
                channel_models: Default::default(),
                include_policy: false,
                channel_ids: vec![],
                template_refs: vec![a.clone(), b.clone()],
                include_global: false,
            },
        )
        .unwrap();
        let seed = receive(target.path(), templates).unwrap();
        accept(target.path(), &seed.id).unwrap();
        let store = ModelStore::new(target.path());
        let before = store.load().unwrap();
        let mut local = original.policy.clone();
        local.channels[0].connection.provider_id = "local-provider".into();
        local.channels[0].connection.nodes[0].url = "https://local.example.test".into();
        local.channels[0].connection.credential_ref = Some(uuid::Uuid::new_v4().to_string());
        local.channels[0].overrides.clear();
        local.channels[0].family_overrides.clear();
        store
            .commit_runtime_policy(
                &before.library_digest,
                &before.policy_digest,
                &before.workspace_digest,
                local.clone(),
            )
            .unwrap();
        // Dependencies arrive with the fragment; receiver need not already have custom templates.
        let current = store.load().unwrap();
        let mut draft = current.policy.clone();
        draft.channels[0].label = "local draft label".into();
        draft.channels[0].overrides.insert(
            "family-b-one".into(),
            ModelRules {
                fast: Field::Custom(true),
                ..Default::default()
            },
        );
        store
            .stage_policy(
                &current.policy_digest,
                &current.workspace_digest,
                draft.clone(),
            )
            .unwrap();
        let review = receive(target.path(), package.clone()).unwrap();
        assert!(review.preview_error.is_none(), "{:?}", review.preview_error);
        let result = accept(target.path(), &review.id).unwrap();
        let actual = &result.workspace.unwrap().policy.channels[0];
        assert_eq!(result.policy, local);
        assert_eq!(actual.connection, draft.channels[0].connection);
        assert_eq!(actual.label, draft.channels[0].label);
        assert_eq!(actual.selection, draft.channels[0].selection);
        assert_eq!(actual.model_order, draft.channels[0].model_order);
        assert_eq!(
            actual
                .template_refs
                .iter()
                .find(|r| r.template_id == b.template_id),
            Some(&b)
        );
        assert_eq!(actual.defaults, draft.channels[0].defaults);
        assert_eq!(
            actual.overrides["family-b-one"],
            draft.channels[0].overrides["family-b-one"]
        );
        assert_eq!(
            actual.overrides["family-a-one"],
            original.policy.channels[0].overrides["family-a-one"]
        );
        assert_eq!(ModelStore::new(source.path()).load().unwrap(), original);
        let mut malformed = package.clone();
        malformed.payload.policy.as_mut().unwrap().channels[0]
            .defaults
            .fast = Field::Custom(true);
        malformed.digest = sha256(&serde_json::to_vec(&malformed.payload).unwrap());
        assert_eq!(
            validate_package(&malformed).unwrap_err().code,
            "family_scope"
        );
        let mut old = package;
        old.format_version = 3;
        assert_eq!(validate_package(&old).unwrap_err().code, "package_version");
    }
    #[test]
    fn family_fragments_keep_model_only_refs_exact_and_allow_rules_without_known_matches() {
        let root = tempfile::tempdir().unwrap();
        let (mut source, a, _) = family_fixture(root.path());
        source.policy.template_refs.clear();
        source.policy.channels[0]
            .model_refs
            .insert("family-a-one".into(), a.clone());
        let package = export_snapshot(&source, family_scope(&source, &a, false)).unwrap();
        validate_package(&package).unwrap();
        let fragment = &package.payload.policy.as_ref().unwrap().channels[0];
        assert!(fragment.template_refs.is_empty());
        assert_eq!(fragment.model_refs["family-a-one"], a);
        let previous = adopted_portable(&source.policy.channels[0], std::slice::from_ref(&a));
        let merged = merge_family(&previous, fragment).unwrap();
        assert!(merged.template_refs.contains(&a));

        source.policy.channels[0].model_refs.clear();
        source.policy.template_refs = vec![a.clone()];
        source.policy.channels[0].discovered.clear();
        source.policy.channels[0].model_order.clear();
        source.policy.channels[0].overrides.clear();
        source.policy.channels[0].selection = ModelSelection::None;
        let package = export_snapshot(&source, family_scope(&source, &a, false)).unwrap();
        validate_package(&package).unwrap();
        assert_eq!(
            package.payload.policy.as_ref().unwrap().channels[0].model_subset,
            Some(vec![])
        );
        let mut whole = export_snapshot(
            &source,
            ExportScope {
                channel_families: Default::default(),
                channel_models: Default::default(),
                include_policy: true,
                channel_ids: vec![source.policy.channels[0].id.clone()],
                template_refs: vec![],
                include_global: true,
            },
        )
        .unwrap();
        scope_families(
            &mut whole,
            &family_scope(&source, &a, false).channel_families,
        )
        .unwrap();
        assert_eq!(
            whole.payload.policy.as_ref().unwrap().channels[0].model_subset,
            Some(vec![])
        );
    }
    #[test]
    fn family_fragment_conflicts_are_scoped_and_remote_merge_requires_explicit_shared_fields() {
        let root = tempfile::tempdir().unwrap();
        let (source, a, b) = family_fixture(root.path());
        let fragment = export_snapshot(&source, family_scope(&source, &a, false)).unwrap();
        let mut changed = source.clone();
        let mut draft = source.policy.clone();
        draft.channels[0].overrides.insert(
            "family-a-one".into(),
            ModelRules {
                context_window: Field::Custom(64000),
                ..Default::default()
            },
        );
        changed.workspace = Some(PolicyDraft {
            base_policy: source.policy_digest.clone(),
            policy: draft,
        });
        assert_eq!(
            merge(&changed, &fragment).unwrap_err().code,
            "draft_conflict"
        );
        let mut declared = source.policy.clone();
        declared.channels[0]
            .discovered
            .iter_mut()
            .find(|m| m.id == "family-a-one")
            .unwrap()
            .rules
            .context_window = Field::Custom(128000);
        changed.workspace = Some(PolicyDraft {
            base_policy: source.policy_digest.clone(),
            policy: declared,
        });
        assert_eq!(
            merge(&changed, &fragment).unwrap_err().code,
            "draft_conflict"
        );
        let mut global = source.policy.clone();
        global.template_refs.clear();
        changed.workspace = Some(PolicyDraft {
            base_policy: source.policy_digest.clone(),
            policy: global,
        });
        assert_eq!(
            merge(&changed, &fragment).unwrap_err().code,
            "draft_conflict"
        );

        let mut remote = export_snapshot(
            &source,
            ExportScope {
                channel_families: Default::default(),
                channel_models: Default::default(),
                include_policy: true,
                channel_ids: vec![source.policy.channels[0].id.clone()],
                template_refs: vec![],
                include_global: false,
            },
        )
        .unwrap();
        remote.payload.policy.as_mut().unwrap().channels[0]
            .defaults
            .fast = Field::Custom(true);
        remote.digest = sha256(&serde_json::to_vec(&remote.payload).unwrap());
        let merged = merge_packages(remote.clone(), fragment).unwrap();
        let actual = &merged.payload.policy.as_ref().unwrap().channels[0];
        assert_eq!(actual.defaults.fast, Field::Custom(true));
        assert!(actual.template_refs.contains(&b));
        assert!(actual.connection.is_some());
        assert!(actual.family_scope.is_none());
        let shared = export_snapshot(&source, family_scope(&source, &a, true)).unwrap();
        let merged = merge_packages(remote, shared).unwrap();
        assert_eq!(
            merged.payload.policy.as_ref().unwrap().channels[0]
                .defaults
                .fast,
            Field::Custom(false)
        );
    }

    #[test]
    fn family_scope_is_applied_to_remote_file_before_key_selection_or_adoption() {
        let root = tempfile::tempdir().unwrap();
        let (source, a, _) = family_fixture(root.path());
        let family = family_scope(&source, &a, false);
        let mut whole = family.clone();
        whole.channel_families.clear();
        let full = export(root.path(), whole).unwrap();
        let manager = crate::modules::sync::portable_manager::Scope::default();
        let (bytes, _, _, _) = super::super::file_objects::seal_manager(
            root.path(),
            &uuid::Uuid::new_v4().to_string(),
            &full,
            false,
            None,
            &manager,
        )
        .unwrap();
        let received = super::super::file_objects::select_remote(
            root.path(),
            &bytes,
            None,
            &family,
            &manager,
            true,
        )
        .unwrap();
        assert!(
            received.preview_error.is_none(),
            "{:?}",
            received.preview_error
        );
        let fragment = &received.package.payload.policy.as_ref().unwrap().channels[0];
        assert!(fragment.family_scope.is_some());
        assert!(fragment.connection.is_none());
        assert_eq!(fragment.model_subset, Some(vec!["family-a-one".into()]));
        assert!(received.available_keys.is_empty());
        assert_eq!(received.package.payload.templates.len(), 1);
        assert_eq!(ModelStore::new(root.path()).load().unwrap(), source);
        let package = export(root.path(), family).unwrap();
        // Even an explicit all-channel Key request must skip a family-only fragment;
        // no OS credential owner or provider connection is consulted.
        let (_, count, _, _) = super::super::file_objects::seal_manager(
            root.path(),
            &uuid::Uuid::new_v4().to_string(),
            &package,
            true,
            Some("fixture-only-password"),
            &manager,
        )
        .unwrap();
        assert_eq!(count, 0);
    }
    #[test]
    fn draft_export_freezes_scoped_candidate_without_committing_or_publishing_it() {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        let original = channel_fixture(source.path());
        let store = ModelStore::new(source.path());
        let before = store.load().unwrap();
        let mut policy = before.policy.clone();
        policy.channels[0].label = "尚未提交的新名称".into();
        policy.channels[0].defaults.fast = Field::Custom(false);
        let template = &before.library.templates[0];
        let reference = TemplateRef {
            template_id: template.id.clone(),
            revision_id: template.revisions[0].id.clone(),
        };
        policy.channels[0].template_refs = vec![reference.clone()];
        let staged = store
            .stage_policy(
                &before.policy_digest,
                &before.workspace_digest,
                policy.clone(),
            )
            .unwrap();
        let scope = ExportScope {
            channel_families: Default::default(),
            channel_models: Default::default(),
            include_policy: true,
            channel_ids: vec![original.id.clone()],
            template_refs: vec![],
            include_global: false,
        };
        let expected = DraftCandidate {
            expected_library: staged.library_digest.clone(),
            expected_policy: staged.policy_digest.clone(),
            expected_workspace: staged.workspace_digest.clone(),
        };
        let ordinary = export(source.path(), scope.clone()).unwrap();
        assert_eq!(
            ordinary.payload.policy.as_ref().unwrap().channels[0].label,
            original.label
        );
        assert!(ordinary.payload.candidate.is_none());
        let plan =
            prepare_draft_file(source.path(), scope.clone(), expected.clone(), None).unwrap();
        assert_eq!(plan.package.format_version, 4);
        assert_eq!(plan.credential_count, 0);
        assert!(plan.manager.as_ref().unwrap().accounts.is_empty());
        let packaged = plan.package.payload.policy.as_ref().unwrap();
        assert_eq!(packaged.channels.len(), 1);
        assert_eq!(packaged.channels[0].label, "尚未提交的新名称");
        assert!(packaged.template_refs.is_none() && packaged.channel_order.is_none());
        assert_eq!(plan.package.payload.templates.len(), 1);
        assert_eq!(plan.package.payload.templates[0].revisions.len(), 1);
        let encoded = serde_json::to_string(&plan.package).unwrap();
        assert!(!encoded.contains(original.connection.credential_ref.as_ref().unwrap()));
        assert_eq!(store.load().unwrap().policy, before.policy);
        assert_eq!(store.load().unwrap().workspace, staged.workspace);
        let bytes = file_bytes(source.path(), &plan.id).unwrap();
        let mut later = policy;
        later.channels[0].label = "导出后的修改".into();
        store
            .stage_policy(&before.policy_digest, &staged.workspace_digest, later)
            .unwrap();
        assert_eq!(file_bytes(source.path(), &plan.id).unwrap(), bytes);
        assert_eq!(
            prepare_draft_file(source.path(), scope, expected, None)
                .unwrap_err()
                .code,
            "stale_baseline"
        );
        let mut downgraded = plan.package.clone();
        downgraded.format_version = 3;
        assert_eq!(
            validate_package(&downgraded).unwrap_err().code,
            "package_version"
        );
        let mut forged = plan.package.clone();
        forged.payload.candidate.as_mut().unwrap().expected_policy = sha256(b"another-policy");
        assert_eq!(
            validate_package(&forged).unwrap_err().code,
            "package_digest"
        );
        assert_eq!(
            merge_packages(ordinary, plan.package.clone())
                .unwrap_err()
                .code,
            "draft_remote"
        );
        let incoming = super::super::file_objects::receive(target.path(), &bytes, None).unwrap();
        assert!(incoming
            .notices
            .iter()
            .any(|n| n.contains("未提交渠道草稿候选")));
        assert!(ModelStore::new(target.path())
            .load()
            .unwrap()
            .policy
            .channels
            .is_empty());
        super::super::file_objects::accept_extended(
            target.path(),
            &incoming.id,
            false,
            false,
            false,
            None,
        )
        .unwrap();
        let received = ModelStore::new(target.path()).load().unwrap();
        assert!(received.policy.channels.is_empty());
        assert_eq!(
            received.workspace.unwrap().policy.channels[0].label,
            "尚未提交的新名称"
        );
        assert!(!target.path().join("providers.json").exists());
    }
    #[test]
    fn explicit_channel_mapping_preserves_local_connection_or_creates_a_separate_draft() {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        let original = channel_fixture(source.path());
        let mut local = channel_fixture(target.path());
        local.id = original.id.clone();
        local.connection.nodes[0].url = "https://local.example.test/v1".into();
        local.connection.protocol = "openai-responses".into();
        commit_fixture(target.path(), local.clone());
        let incoming =
            receive(target.path(), channel_package(source.path(), &original.id)).unwrap();
        assert_eq!(
            incoming.preview_error.as_deref(),
            Some("channel_endpoint_conflict")
        );
        let mapped = select_received(
            target.path(),
            &incoming.id,
            ReceiveScope {
                channel_ids: vec![original.id.clone()],
                channel_mappings: BTreeMap::from([(
                    original.id.clone(),
                    ChannelMapping::Local {
                        target_id: local.id.clone(),
                    },
                )]),
                ..Default::default()
            },
        )
        .unwrap();
        assert!(mapped.preview_error.is_none());
        assert_eq!(key_target(&mapped, &original.id), None);
        let result = accept(target.path(), &mapped.id).unwrap();
        let draft = &result.workspace.as_ref().unwrap().policy.channels[0];
        assert_eq!(draft.connection, local.connection);
        assert_eq!(draft.selection, original.selection);
        // A new comparison uses the current baseline, never silently rewrites an old confirmed plan.
        let incoming =
            receive(target.path(), channel_package(source.path(), &original.id)).unwrap();
        let mapped = select_received(
            target.path(),
            &incoming.id,
            ReceiveScope {
                channel_ids: vec![original.id.clone()],
                channel_mappings: BTreeMap::from([(
                    original.id.clone(),
                    ChannelMapping::New {
                        label: "独立副本".into(),
                    },
                )]),
                ..Default::default()
            },
        )
        .unwrap();
        let target_id = mapped.channel_bindings[&original.id].target_id.clone();
        assert_ne!(target_id, local.id);
        assert_eq!(key_target(&mapped, &original.id), Some(target_id.as_str()));
        let result = accept(target.path(), &mapped.id).unwrap();
        let channels = &result.workspace.as_ref().unwrap().policy.channels;
        assert_eq!(channels.len(), 2);
        assert_eq!(channels[0].connection, local.connection);
        let new = channels.iter().find(|c| c.id == target_id).unwrap();
        assert!(!new.connection.enabled);
        assert_eq!(new.label, "独立副本");
    }
    #[test]
    fn channel_mapping_rejects_unselected_sources_duplicate_targets_and_drift() {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        let original = channel_fixture(source.path());
        let local = channel_fixture(target.path());
        let mut package = channel_package(source.path(), &original.id);
        let mut second = package.payload.policy.as_ref().unwrap().channels[0].clone();
        second.id = uuid::Uuid::new_v4().to_string();
        package
            .payload
            .policy
            .as_mut()
            .unwrap()
            .channels
            .push(second.clone());
        package.digest = sha256(&serde_json::to_vec(&package.payload).unwrap());
        let incoming = receive(target.path(), package).unwrap();
        let mappings = BTreeMap::from([
            (
                original.id.clone(),
                ChannelMapping::Local {
                    target_id: local.id.clone(),
                },
            ),
            (
                second.id.clone(),
                ChannelMapping::Local {
                    target_id: local.id.clone(),
                },
            ),
        ]);
        assert_eq!(
            select_received(
                target.path(),
                &incoming.id,
                ReceiveScope {
                    channel_ids: vec![original.id.clone()],
                    channel_mappings: mappings.clone(),
                    ..Default::default()
                }
            )
            .unwrap_err()
            .code,
            "channel_mapping"
        );
        assert_eq!(
            select_received(
                target.path(),
                &incoming.id,
                ReceiveScope {
                    channel_ids: vec![original.id.clone(), second.id],
                    channel_mappings: mappings,
                    ..Default::default()
                }
            )
            .unwrap_err()
            .code,
            "channel_mapping"
        );
        let mapped = select_received(
            target.path(),
            &incoming.id,
            ReceiveScope {
                channel_ids: vec![original.id.clone()],
                channel_mappings: BTreeMap::from([(
                    original.id,
                    ChannelMapping::Local {
                        target_id: local.id.clone(),
                    },
                )]),
                ..Default::default()
            },
        )
        .unwrap();
        let mut edited = local;
        edited.label = "后来修改".into();
        commit_fixture(target.path(), edited.clone());
        assert_eq!(
            accept(target.path(), &mapped.id).unwrap_err().code,
            "stale_baseline"
        );
        assert_eq!(
            ModelStore::new(target.path())
                .load()
                .unwrap()
                .policy
                .channels[0],
            edited
        );
    }
    fn channel_fixture(root: &Path) -> ChannelPolicy {
        let nodes = vec![
            ServiceNode {
                id: uuid::Uuid::new_v4().to_string(),
                name: "主站".into(),
                url: "https://source.example.test/v1".into(),
            },
            ServiceNode {
                id: uuid::Uuid::new_v4().to_string(),
                name: "备用".into(),
                url: "https://backup.example.test/v1".into(),
            },
        ];
        let channel = ChannelPolicy {
            naming: Default::default(),
            id: uuid::Uuid::new_v4().to_string(),
            label: "便携渠道".into(),
            template_refs: vec![],
            model_refs: BTreeMap::new(),
            connection: ChannelConnection {
                auth_mode: None,
                source_read_id: None,
                imported_config: None,
                provider_id: "source-machine-provider".into(),
                protocol: "openai-chat".into(),
                active_node_id: nodes[1].id.clone(),
                nodes,
                credential_ref: Some(uuid::Uuid::new_v4().to_string()),
                enabled: true,
                allow_private_network: true,
            },
            selection: ModelSelection::Whitelist(vec!["model-a".into()]),
            model_order: vec![],
            discovered: vec![],
            defaults: Default::default(),
            overrides: Default::default(),
            family_overrides: Default::default(),
        };
        commit_fixture(root, channel.clone());
        channel
    }
    fn commit_fixture(root: &Path, channel: ChannelPolicy) {
        let store = ModelStore::new(root);
        let snapshot = store.load().unwrap();
        store
            .commit_runtime_policy(
                &snapshot.library_digest,
                &snapshot.policy_digest,
                &snapshot.workspace_digest,
                Policy {
                    channels: vec![channel],
                    ..Default::default()
                },
            )
            .unwrap();
    }
    fn channel_package(root: &Path, id: &str) -> ModelPackage {
        export(
            root,
            ExportScope {
                channel_families: Default::default(),
                channel_models: Default::default(),
                include_policy: true,
                channel_ids: vec![id.into()],
                template_refs: vec![],
                include_global: false,
            },
        )
        .unwrap()
    }
    fn official(label: &str) -> ChannelPolicy {
        let node = ServiceNode {
            id: uuid::Uuid::new_v4().to_string(),
            name: "服务地址".into(),
            url: "https://api.openai.com/v1".into(),
        };
        ChannelPolicy {
            naming: Default::default(),
            id: uuid::Uuid::new_v4().to_string(),
            label: label.into(),
            template_refs: vec![],
            model_refs: BTreeMap::new(),
            connection: ChannelConnection {
                provider_id: "openai".into(),
                protocol: "openai-responses".into(),
                active_node_id: node.id.clone(),
                nodes: vec![node],
                ..Default::default()
            },
            selection: ModelSelection::None,
            model_order: vec![],
            discovered: vec![],
            defaults: Default::default(),
            overrides: Default::default(),
            family_overrides: Default::default(),
        }
    }
    fn commit_channels(root: &Path, channels: Vec<ChannelPolicy>) {
        let store = ModelStore::new(root);
        let snapshot = store.load().unwrap();
        store
            .commit_runtime_policy(
                &snapshot.library_digest,
                &snapshot.policy_digest,
                &snapshot.workspace_digest,
                Policy {
                    channels,
                    ..Default::default()
                },
            )
            .unwrap();
    }
    #[test]
    fn old_package_official_copies_are_skipped_and_same_named_custom_channels_are_kept() {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        // An old package: the source's official channel travelled with its own
        // per-machine id and no provider id, next to a user channel that is
        // also called "openai" but points at another service.
        let source_official = official("openai");
        let mut custom = channel_fixture(source.path());
        custom.label = "openai".into();
        commit_channels(source.path(), vec![source_official.clone(), custom.clone()]);
        let package = export(
            source.path(),
            ExportScope {
                channel_families: Default::default(),
                channel_models: Default::default(),
                include_policy: true,
                channel_ids: vec![source_official.id.clone(), custom.id.clone()],
                template_refs: vec![],
                include_global: false,
            },
        )
        .unwrap();
        assert_eq!(package.payload.policy.as_ref().unwrap().channels.len(), 2);

        let local_official = official("OpenAI");
        commit_channels(target.path(), vec![local_official.clone()]);
        let incoming = receive(target.path(), package.clone()).unwrap();
        assert!(incoming.preview_error.is_none());
        assert!(incoming
            .notices
            .iter()
            .any(|n| n == "openai：本机官方渠道沿用本机Codex配置，未接收副本"));
        let adopted = accept(target.path(), &incoming.id).unwrap();
        let channels = &adopted.workspace.as_ref().unwrap().policy.channels;
        assert_eq!(channels.len(), 2);
        assert_eq!(channels[0], local_official);
        assert_eq!(channels[1].id, custom.id);
        assert_eq!(channels[1].label, "openai");
        assert_eq!(channels[1].connection.nodes, custom.connection.nodes);
        assert!(!super::super::compiler::channel_is_native(
            &channels[1].connection.provider_id
        ));

        // The same identity as a local official channel is never overwritten,
        // even when its label or address differ.
        let same_id = tempfile::tempdir().unwrap();
        let mut local = source_official.clone();
        local.label = "本机官方".into();
        local.connection.nodes[0].url = "https://proxy.example.test/v1".into();
        commit_channels(same_id.path(), vec![local.clone()]);
        let incoming = receive(same_id.path(), package).unwrap();
        assert!(incoming.preview_error.is_none());
        let adopted = accept(same_id.path(), &incoming.id).unwrap();
        let channels = &adopted.workspace.as_ref().unwrap().policy.channels;
        assert_eq!(channels[0], local);
        assert_eq!(channels.len(), 2);
    }
    #[test]
    fn portable_nodes_restore_as_disabled_draft_with_new_local_binding_and_no_runtime_or_secret_refs(
    ) {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        let original = channel_fixture(source.path());
        let package = channel_package(source.path(), &original.id);
        assert_eq!(package.format_version, 2);
        let encoded = serde_json::to_string(&package).unwrap();
        assert!(!encoded.contains(&original.connection.provider_id));
        assert!(!encoded.contains(original.connection.credential_ref.as_deref().unwrap()));
        assert!(
            !encoded.contains("activeNodeId")
                && !encoded.contains("allowPrivateNetwork")
                && !encoded.contains("credentialRef")
        );
        let incoming = receive(target.path(), package).unwrap();
        assert!(incoming.preview_error.is_none());
        let adopted = accept(target.path(), &incoming.id).unwrap();
        assert!(adopted.policy.channels.is_empty());
        let draft = &adopted.workspace.as_ref().unwrap().policy.channels[0];
        assert_eq!(draft.connection.nodes, original.connection.nodes);
        assert_ne!(
            draft.connection.provider_id,
            original.connection.provider_id
        );
        assert!(!draft.connection.enabled && !draft.connection.allow_private_network);
        assert!(draft.connection.credential_ref.is_none());
        assert_ne!(
            draft.connection.active_node_id,
            original.connection.active_node_id
        );
        super::super::compiler::validate_channel(draft).unwrap();
    }
    #[test]
    fn same_identity_different_endpoint_is_review_conflict_and_same_endpoint_keeps_local_selection()
    {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        let original = channel_fixture(source.path());
        let mut local = original.clone();
        local.connection.active_node_id = local.connection.nodes[0].id.clone();
        local.connection.provider_id = "local-provider".into();
        local.connection.credential_ref = Some(uuid::Uuid::new_v4().to_string());
        commit_fixture(target.path(), local.clone());
        let incoming =
            receive(target.path(), channel_package(source.path(), &original.id)).unwrap();
        let adopted = accept(target.path(), &incoming.id).unwrap();
        assert_eq!(
            adopted.workspace.as_ref().unwrap().policy.channels[0].connection,
            local.connection
        );
        let other = tempfile::tempdir().unwrap();
        local.connection.nodes[0].url = "https://other.example.test/v1".into();
        commit_fixture(other.path(), local.clone());
        let incoming = receive(other.path(), channel_package(source.path(), &original.id)).unwrap();
        assert_eq!(
            incoming.preview_error.as_deref(),
            Some("channel_endpoint_conflict")
        );
        assert_eq!(
            accept(other.path(), &incoming.id).unwrap_err().code,
            "channel_endpoint_conflict"
        );
        assert_eq!(
            ModelStore::new(other.path())
                .load()
                .unwrap()
                .policy
                .channels[0],
            local
        );
    }
    #[test]
    fn old_packages_keep_their_original_digest_and_new_nodes_cannot_masquerade_as_format_one() {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        let channel = channel_fixture(source.path());
        let mut package = channel_package(source.path(), &channel.id);
        package.format_version = 1;
        assert_eq!(
            validate_package(&package).unwrap_err().code,
            "package_version"
        );
        package.payload.policy.as_mut().unwrap().channels[0].connection = None;
        package.digest = sha256(&serde_json::to_vec(&package.payload).unwrap());
        let bytes = serde_json::to_vec(&package).unwrap();
        assert!(!String::from_utf8_lossy(&bytes).contains("connection"));
        let parsed: ModelPackage = serde_json::from_slice(&bytes).unwrap();
        validate_package(&parsed).unwrap();
        let incoming = receive(target.path(), parsed).unwrap();
        assert!(incoming.preview_error.is_none());
        let result = accept(target.path(), &incoming.id).unwrap();
        assert!(result.workspace.unwrap().policy.channels[0]
            .connection
            .nodes
            .is_empty());
    }
    fn create(root: &Path) -> Commit {
        let store = ModelStore::new(root);
        let snapshot = store.load().unwrap();
        let mut content = TemplateContent::default();
        content.matching.include.push(Pattern {
            kind: MatchKind::Prefix,
            value: "test-".into(),
        });
        store
            .save(SaveTemplate {
                expected_library: snapshot.library_digest,
                template_id: None,
                base_revision: None,
                label: "用户模版".into(),
                content,
            })
            .unwrap()
    }
    #[test]
    fn model_subset_filters_declared_ids_overrides_and_keeps_other_local_models_on_acceptance() {
        let source = tempfile::tempdir().unwrap();
        let target = tempfile::tempdir().unwrap();
        let mut policy = Policy::default();
        let id = uuid::Uuid::new_v4().to_string();
        let node = uuid::Uuid::new_v4().to_string();
        let mut channel = ChannelPolicy {
            naming: Default::default(),
            id: id.clone(),
            label: "source".into(),
            template_refs: vec![],
            model_refs: BTreeMap::new(),
            connection: ChannelConnection {
                provider_id: "p".into(),
                protocol: "openai-chat".into(),
                nodes: vec![ServiceNode {
                    id: node.clone(),
                    name: "primary".into(),
                    url: "https://source.example.test".into(),
                }],
                active_node_id: node,
                ..Default::default()
            },
            selection: ModelSelection::All,
            model_order: vec!["a".into(), "b".into()],
            discovered: vec![
                DiscoveredModel {
                    id: "a".into(),
                    label: "a source".into(),
                    rules: ModelRules::default(),
                },
                DiscoveredModel {
                    id: "b".into(),
                    label: "b source".into(),
                    rules: ModelRules::default(),
                },
            ],
            defaults: ModelRules::default(),
            overrides: BTreeMap::new(),
            family_overrides: BTreeMap::new(),
        };
        let rule = ModelRules {
            fast: Field::Custom(false),
            ..Default::default()
        };
        channel.overrides.insert("a".into(), rule.clone());
        channel.overrides.insert("b".into(), rule);
        channel.naming.insert(
            "a".into(),
            ModelNaming {
                alias: Some("a-route".into()),
                display_name: Some("A label".into()),
            },
        );
        channel.naming.insert(
            "b".into(),
            ModelNaming {
                alias: Some("b-route".into()),
                display_name: None,
            },
        );

        policy.channels.push(channel.clone());
        let store = ModelStore::new(source.path());
        let v = store.load().unwrap();
        store
            .commit_runtime_policy(
                &v.library_digest,
                &v.policy_digest,
                &v.workspace_digest,
                policy.clone(),
            )
            .unwrap();
        let mut scope = ExportScope {
            channel_families: Default::default(),
            channel_models: BTreeMap::from([(id.clone(), vec!["a".into()])]),
            include_policy: true,
            channel_ids: vec![id.clone()],
            template_refs: vec![],
            include_global: false,
        };
        let package = export(source.path(), scope.clone()).unwrap();
        assert_eq!(package.format_version, 3);
        let selected = &package.payload.policy.as_ref().unwrap().channels[0];
        assert_eq!(selected.model_subset, Some(vec!["a".into()]));
        assert_eq!(selected.discovered.len(), 1);
        assert!(!selected.overrides.contains_key("b"));
        assert!(selected.naming.contains_key("a"));
        assert!(!selected.naming.contains_key("b"));

        let mut public = portable(&channel);
        public.connection.as_mut().unwrap().provider = Some(
            serde_json::json!({"adapter":"openai-chat","baseUrl":"https://source.example.test","models":["a","b"],"modelDisplayNames":{"a":"A","b":"B"},"modelAliases":{"a":"alias-a","b":"alias-b"},"modelReasoningEfforts":{"a":["low"],"b":["high"]},"note":"shared"}),
        );
        let narrowed = restrict_models(&public, &["a".into()]).unwrap();
        let fields = narrowed
            .connection
            .as_ref()
            .unwrap()
            .provider
            .as_ref()
            .unwrap();
        assert_eq!(fields["models"], serde_json::json!(["a"]));
        assert!(fields["modelAliases"].get("b").is_none());
        assert_eq!(fields["note"], "shared");
        assert!(restrict_models(&narrowed, &["b".into()]).is_err());
        assert!(restrict_models(&public, &["a".into(), "a".into()]).is_err());
        let target_store = ModelStore::new(target.path());
        let v = target_store.load().unwrap();
        policy.channels[0].discovered[1].label = "later local B".into();
        policy.channels[0].defaults.fast = Field::Custom(true);
        target_store
            .commit_runtime_policy(
                &v.library_digest,
                &v.policy_digest,
                &v.workspace_digest,
                policy.clone(),
            )
            .unwrap();
        let incoming = receive(target.path(), package.clone()).unwrap();
        assert!(incoming.channel_bindings[&id].keep_local_connection);
        assert!(key_target(&incoming, &id).is_none());
        let adopted = accept(target.path(), &incoming.id).unwrap();
        let actual = &adopted.workspace.unwrap().policy.channels[0];
        assert_eq!(
            actual
                .discovered
                .iter()
                .find(|m| m.id == "b")
                .unwrap()
                .label,
            "later local B"
        );
        assert_eq!(actual.selection, ModelSelection::All);
        assert_eq!(actual.defaults, policy.channels[0].defaults);
        assert_eq!(actual.model_order, policy.channels[0].model_order);
        assert!(actual.overrides.contains_key("b"));
        assert_eq!(actual.naming["a"].alias.as_deref(), Some("a-route"));
        assert_eq!(actual.naming["b"].alias.as_deref(), Some("b-route"));

        let merged = merge_model_subset(&public, &narrowed).unwrap();
        assert_eq!(merged.discovered.len(), 2);
        assert!(merged.connection.unwrap().provider.unwrap()["modelAliases"]
            .get("b")
            .is_some());
        let mut declarations_only = public.clone();
        declarations_only.discovered.clear();
        let first = restrict_models(&declarations_only, &["a".into()]).unwrap();
        let second = restrict_models(&declarations_only, &["b".into()]).unwrap();
        let joined = merge_model_subset(&first, &second).unwrap();
        assert_eq!(joined.model_subset, Some(vec!["a".into(), "b".into()]));
        assert!(is_scoped_channel(&joined, &joined).unwrap());
        scope.channel_models.insert(id.clone(), vec![]);
        assert_eq!(
            export(source.path(), scope.clone())
                .unwrap()
                .payload
                .policy
                .unwrap()
                .channels[0]
                .selection,
            ModelSelection::None
        );
        scope
            .channel_models
            .insert(uuid::Uuid::new_v4().to_string(), vec![]);
        assert!(export(source.path(), scope).is_err());
    }
    fn all() -> ExportScope {
        ExportScope {
            channel_families: Default::default(),
            channel_models: Default::default(),
            include_policy: false,
            channel_ids: vec![],
            template_refs: vec![],
            include_global: false,
        }
    }
    #[test]
    fn protected_file_export_freezes_bytes_and_never_records_the_passphrase() {
        let root = tempfile::tempdir().unwrap();
        let saved = create(root.path());
        let plan = prepare_file(root.path(), all(), Some("fixture-export-passphrase")).unwrap();
        assert!(plan.protected);
        let metadata = crate::modules::backup::safety::read_file(
            &export_plan_path(root.path(), &plan.id).unwrap(),
            64 * 1024 * 1024,
        )
        .unwrap();
        assert!(!String::from_utf8_lossy(&metadata).contains("fixture-export-passphrase"));
        let bytes = file_bytes(root.path(), &plan.id).unwrap();
        let opened =
            crate::modules::sync::portable_file::open(&bytes, Some("fixture-export-passphrase"))
                .unwrap();
        let payload: serde_json::Value = serde_json::from_slice(&opened.document).unwrap();
        let package: ModelPackage = serde_json::from_value(payload["models"].clone()).unwrap();
        assert_eq!(package.digest, plan.package.digest);
        assert!(package
            .payload
            .templates
            .iter()
            .any(|t| t.id == saved.template_id));
        let store = ModelStore::new(root.path());
        let current = store.load().unwrap();
        let family = current
            .library
            .templates
            .iter()
            .find(|t| t.id == saved.template_id)
            .unwrap();
        let mut content = family.revisions[0].content.clone();
        content.description = "冻结后的人工保存".into();
        store
            .save(SaveTemplate {
                expected_library: current.library_digest,
                template_id: Some(family.id.clone()),
                base_revision: Some(family.revisions[0].id.clone()),
                label: family.label.clone(),
                content,
            })
            .unwrap();
        assert_eq!(file_bytes(root.path(), &plan.id).unwrap(), bytes);
        crate::infrastructure::atomic_write::atomic_write(
            &export_plan_path(root.path(), &plan.id)
                .unwrap()
                .with_extension("ocxdconf"),
            b"changed",
            0o600,
        )
        .unwrap();
        assert_eq!(
            file_bytes(root.path(), &plan.id).unwrap_err().code,
            "export_digest"
        );
    }
    #[test]
    fn importing_versions_is_reviewed_and_preserves_local_defaults_and_runtime() {
        let source = tempfile::tempdir().unwrap();
        let saved = create(source.path());
        let package = export(source.path(), all()).unwrap();
        let target = tempfile::tempdir().unwrap();
        let incoming = receive(target.path(), package).unwrap();
        assert!(!target.path().join(LIBRARY_PATH).exists());
        let accepted = accept(target.path(), &incoming.id).unwrap();
        let template = accepted
            .library
            .templates
            .iter()
            .find(|t| t.id == saved.template_id)
            .unwrap();
        assert!(template.default_revision.is_none());
        assert_eq!(template.revisions[0].id, saved.revision_id);
        assert!(!target.path().join(POLICY_PATH).exists());
        let duplicate = receive(target.path(), export(source.path(), all()).unwrap()).unwrap();
        let after = accept(target.path(), &duplicate.id).unwrap();
        assert_eq!(after.library, accepted.library);
    }
    #[test]
    fn mismatched_identity_or_digest_is_rejected_without_modifying_the_library() {
        let root = tempfile::tempdir().unwrap();
        create(root.path());
        let before = ModelStore::new(root.path()).load().unwrap();
        let mut package = export(root.path(), all()).unwrap();
        package.payload.templates.last_mut().unwrap().revisions[0]
            .content
            .description = "changed".into();
        assert_eq!(
            receive(root.path(), package.clone()).unwrap_err().code,
            "package_digest"
        );
        let revision = &mut package.payload.templates.last_mut().unwrap().revisions[0];
        revision.digest =
            super::super::store::content_digest(&revision.saved_label, &revision.content).unwrap();
        package.digest = sha256(&serde_json::to_vec(&package.payload).unwrap());
        let incoming = receive(root.path(), package).unwrap();
        assert_eq!(incoming.preview_error.as_deref(), Some("revision_conflict"));
        assert_eq!(
            accept(root.path(), &incoming.id).unwrap_err().code,
            "revision_conflict"
        );
        assert_eq!(ModelStore::new(root.path()).load().unwrap(), before);
    }
    #[test]
    fn policy_package_carries_exact_dependencies_but_never_local_node_or_keychain_references() {
        let source = tempfile::tempdir().unwrap();
        let saved = create(source.path());
        let store = ModelStore::new(source.path());
        let snapshot = store.load().unwrap();
        let policy = Policy {
            template_refs: vec![TemplateRef {
                template_id: saved.template_id.clone(),
                revision_id: saved.revision_id.clone(),
            }],
            channels: vec![],
            ..Default::default()
        };
        let staged = store
            .stage_policy(
                &snapshot.policy_digest,
                &snapshot.workspace_digest,
                policy.clone(),
            )
            .unwrap();
        store
            .commit_runtime_policy(
                &staged.library_digest,
                &staged.policy_digest,
                &staged.workspace_digest,
                policy,
            )
            .unwrap();
        let package = export(
            source.path(),
            ExportScope {
                channel_families: Default::default(),
                channel_models: Default::default(),
                include_policy: true,
                channel_ids: vec![],
                template_refs: vec![],
                include_global: true,
            },
        )
        .unwrap();
        assert_eq!(package.payload.templates.len(), 1);
        assert_eq!(
            package.payload.templates[0].revisions[0].id,
            saved.revision_id
        );
        let bytes = serde_json::to_string(&package).unwrap();
        assert!(!bytes.contains("credentialRef"));
        assert!(!bytes.contains("activeNodeId"));
        let target = tempfile::tempdir().unwrap();
        let incoming = receive(target.path(), package).unwrap();
        let accepted = accept(target.path(), &incoming.id).unwrap();
        assert_eq!(
            accepted.workspace.unwrap().policy.template_refs[0].revision_id,
            saved.revision_id
        );
        assert!(!target.path().join(POLICY_PATH).exists());
    }
    #[test]
    fn a_changed_local_baseline_invalidates_old_import_confirmation() {
        let source = tempfile::tempdir().unwrap();
        create(source.path());
        let package = export(source.path(), all()).unwrap();
        let target = tempfile::tempdir().unwrap();
        let incoming = receive(target.path(), package).unwrap();
        create(target.path());
        let current = ModelStore::new(target.path()).load().unwrap();
        assert_eq!(
            accept(target.path(), &incoming.id).unwrap_err().code,
            "stale_baseline"
        );
        assert_eq!(ModelStore::new(target.path()).load().unwrap(), current);
    }
    #[test]
    fn receive_subset_keeps_other_objects_and_adds_exact_channel_dependencies() {
        let source = tempfile::tempdir().unwrap();
        let saved = create(source.path());
        let mut package = export(source.path(), all()).unwrap();
        let channel = PortableChannel {
            family_scope: None,
            naming: Default::default(),
            model_subset: None,
            id: uuid::Uuid::new_v4().to_string(),
            label: "依赖渠道".into(),
            connection: None,
            protocol: "openai-chat".into(),
            selection: ModelSelection::None,
            model_order: vec![],
            discovered: vec![],
            template_refs: vec![TemplateRef {
                template_id: saved.template_id.clone(),
                revision_id: saved.revision_id.clone(),
            }],
            model_refs: BTreeMap::new(),
            defaults: ModelRules::default(),
            overrides: BTreeMap::new(),
            family_overrides: BTreeMap::new(),
        };
        package.payload.policy = Some(PortablePolicy {
            default_channel_id: None,
            template_refs: None,
            channel_order: None,
            channels: vec![channel.clone()],
        });
        package.digest = sha256(&serde_json::to_vec(&package.payload).unwrap());
        let target = tempfile::tempdir().unwrap();
        let before = ModelStore::new(target.path()).load().unwrap();
        let incoming = receive(target.path(), package).unwrap();
        let selected = select_received(
            target.path(),
            &incoming.id,
            ReceiveScope {
                template_refs: vec![],
                channel_ids: vec![channel.id],
                include_global: false,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(selected.package.payload.templates.len(), 1);
        assert_eq!(selected.package.payload.templates[0].id, saved.template_id);
        let after = accept(target.path(), &selected.id).unwrap();
        assert_eq!(
            after.library.templates.len(),
            before.library.templates.len() + 1
        );
        assert_eq!(after.policy, before.policy);
        let draft = after.workspace.unwrap();
        assert_eq!(draft.policy.channels.len(), 1);
        assert!(!draft.policy.channels[0].connection.enabled);
        assert!(draft.policy.channels[0].connection.nodes.is_empty());
    }
    #[test]
    fn unrelated_conflicting_revision_can_be_skipped_but_cannot_be_accepted_or_silently_rebased() {
        let source = tempfile::tempdir().unwrap();
        let saved = create(source.path());
        let mut package = export(source.path(), all()).unwrap();
        let target = tempfile::tempdir().unwrap();
        let local = ModelStore::new(target.path()).load().unwrap();
        let conflict = &mut package.payload.templates[0].revisions[0];
        conflict.content.description = "冲突同身份".into();
        conflict.digest =
            super::super::store::content_digest(&conflict.saved_label, &conflict.content).unwrap();
        package.digest = sha256(&serde_json::to_vec(&package.payload).unwrap());
        let incoming = receive(target.path(), package).unwrap();
        assert!(incoming.preview_error.is_some());
        assert!(accept(target.path(), &incoming.id).is_err());
        assert_eq!(ModelStore::new(target.path()).load().unwrap(), local);
        let selected = select_received(
            target.path(),
            &incoming.id,
            ReceiveScope {
                template_refs: vec![TemplateRef {
                    template_id: saved.template_id,
                    revision_id: saved.revision_id,
                }],
                channel_ids: vec![],
                include_global: false,
                ..Default::default()
            },
        )
        .unwrap();
        assert!(selected.preview_error.is_none());
        let after = accept(target.path(), &selected.id).unwrap();
        assert_eq!(
            after.library.templates.len(),
            local.library.templates.len() + 1
        );
        assert_eq!(
            select_received(
                target.path(),
                &incoming.id,
                ReceiveScope {
                    template_refs: vec![],
                    channel_ids: vec![],
                    include_global: true,
                    ..Default::default()
                }
            )
            .unwrap_err()
            .code,
            "stale_baseline"
        );
    }
}
