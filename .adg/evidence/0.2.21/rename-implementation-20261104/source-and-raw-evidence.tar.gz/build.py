import pathlib,subprocess,os,sys
p=pathlib.Path(__file__).resolve().parent
command=['cargo','test','--offline','--locked','--lib','--no-run']
env=os.environ.copy();env['CARGO_NET_OFFLINE']='true'
with (p/'logs/rust-build.log').open('a') as log:
 log.write(repr(command)+'\n');log.flush()
 result=subprocess.run(command,cwd='/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri',env=env,stdout=log,stderr=subprocess.STDOUT)
print('build_exit='+str(result.returncode));sys.exit(result.returncode)
