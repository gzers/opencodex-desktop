# 同原封6e原包 Esc 输入有界 A/B

结果：原helper关闭1/2，50ms按住helper关闭2/2。四轮共用同一个fresh根、候选PID 15515、原封6e app。A1/B1/A2/B2交错顺序，所有发送前app active且“确认重启”按钮focused。

| 轮次 | 输入 | 关闭 | 通知继续 | 独立恢复 |
| --- | --- | --- | --- | --- |
| A1-original | 原连续down/up立即exit | 通过 | 是 | 无 |
| B1-held50ms | 按住 55.127ms | 通过 | 是 | 无 |
| A2-original | 原连续down/up立即exit | 失败，原8秒窗口超时 | 仍被确认框遮挡 | header X，单列不算Esc通过 |
| B2-held50ms | 按住 51.301ms | 通过 | 是 | 无 |

结论边界：本机实际观察到输入时序差异，支持采用真实50ms按住/释放的原生发送方式。未发现需要产品重建的产品缺陷证据；不声称“产品间歇故障已修复”，也不以2次结果承诺所有设备。A2原始失败、焦点、截图和X恢复完整保留；实验整轮report仍fail，B准入2/2另列。

没有输入重试，没有DOM事件或超时增加。code53、flags0、postToPid和候选PID一致；每轮恰好一对down/up。B仅增加真实按住与发送后短暂runloop/等待，JSON逐post记录精确DispatchTime monotonic前后、PID/code/flags。CGEvent原始timestamp=0如实保存，monotonic是post调用时间而非WebKit收件证明。A源码完全原样，因此A只有host调用边界，没有伪造post时间。

[逐轮结构化结果](latest-summary.json) · [原始实验报告](ocx021-mac-native-e11d1e45-fab2-4910-a384-daccaba0673b/report.json) · [精确四轮事件日志](ocx021-mac-native-e11d1e45-fab2-4910-a384-daccaba0673b/esc-ab-rounds.json) · [仅key代码差异](key-only-change.diff) · [原helper身份](original-helper-identity.json) · [清理](cleanup.json)

[A2失败前焦点](ocx021-mac-native-e11d1e45-fab2-4910-a384-daccaba0673b/A2-original-before-ax.json) · [A2失败后同焦点](ocx021-mac-native-e11d1e45-fab2-4910-a384-daccaba0673b/A2-original-after-failed-ax.json) · [A2独立X恢复](ocx021-mac-native-e11d1e45-fab2-4910-a384-daccaba0673b/A2-original-X-recovery-ax.json)

![A2失败原件](ocx021-mac-native-e11d1e45-fab2-4910-a384-daccaba0673b/A2-original-after-failed.png)

![B2确认关闭且通知继续](ocx021-mac-native-e11d1e45-fab2-4910-a384-daccaba0673b/B2-held50ms-after-closed.png)

原app source6e2197fd0b8a36dcb8d893b62693c5a2a77151cc，EXE SHA275dface26a0d1ab483a67303eb30df3253f1f050163548c51289f1812b8457e，deep/strict seal仍通过。产品未改、未重签、无实际Codex重启；只是打开并退出重启确认框。

本轮没有启动计时observer、没有计时阈值断言，没有全量/ready无关窗口测试。没有OTA。owned15515组已空，daily80916仍在，未发信号；UI已释放。未提交推送。
当前helper key操作采用B方式；其余Swift准入、AX press/type/set/click/move及Python dismiss未改。
