/* Read-only fixed-source replay; never changes active files. */
const fs=require('node:fs'),Module=require('node:module'),{resolve,files,root}=require('./snapshot-source.cjs');
const read=fs.readFileSync;fs.readFileSync=function(file,...args){return read.call(this,resolve(file),...args);};
const compile=Module._extensions['.js'];
function fixed(module,filename){const source=resolve(filename);if(source!==filename)return module._compile(read.call(fs,source,'utf8'),filename);return compile(module,filename);}
Module._extensions['.js']=fixed;Module._extensions['.cjs']=fixed;
