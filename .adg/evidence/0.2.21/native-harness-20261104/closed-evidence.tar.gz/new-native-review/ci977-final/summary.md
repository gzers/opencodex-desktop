CI977 41813816469：backend-windows / Windows final EXE smoke 失败。

11:11:56 UTC：`Unexpected native command in bounded 021 probe: model_agent_preferences`。堆栈在 windows-021-observer.mjs:24，经 verifyWebdav。它是已由20d修复的观察器本地只读漏项；本轮没有编译或pointer失败。

fmt、Clippy -D warnings、Windows backend regression、原生凭据保护、官方 managed upgrade/offline reinstall、release EXE构建均通过。后续安装恢复/路径、Node22、ordinary EXE步骤因前序失败跳过，未宣称已执行。

977、6e、20d 的 Rust src tree 和 UI src tree 均一致；20d原包四格41817246537已全过，可作为该观察器修复后的native证据供父级判断复用。原CI仍保留failure，不把CI重建EXE与6e原包称为同一字节产物。

完整原日志 backend-windows.original.log；结构化记录 result.json；无需下载artifact即可定位。
