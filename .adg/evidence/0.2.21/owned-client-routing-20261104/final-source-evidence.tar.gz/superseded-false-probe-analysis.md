> 已撤回的错误范围判断，仅作历史记录。false 分支本来只重建缓存，不能以其不生成目录作为功能缺口；当前合同见 AUTOMATIC-CHAIN.md。

# 自动目录链：冻结前技术结论

**当前发布门未通过。135035 只覆盖手工绑定后的真实客户端加载/本地路由，不能证明仅重启生效。主线要求等待 source freeze，现已停止生产链接 helper 的构建与运行；以下自动链脚本是已准备、尚未执行的最终检查。**

## 明确接口缺口（静态核验）

| 环节 | 实际实现 | 技术结论 |
| --- | --- | --- |
| 生产 cache_refresh::sync_cache(false) | cache_refresh.rs:206 起，仅执行已绑定入口的 sync-cache，按进程退出码生成 success | 没有重建 catalog 的操作，无法单独使渠道改名进入旧目录 |
| OpenCodex 2.84.0 sync-cache | src/cli/dispatch.ts:532，调用 invalidateCodexModelsCacheWithPermitOutcome；registry.ts 明确描述从 active catalog 刷新缓存 | 只从现有目录生成 models_cache.json；旧目录仍旧。unchanged、contended、no_catalog 也可退出 0，不能把退出 0 当新目录已产生 |
| 生产 sync_cache(true) | Management::restart_codex → POST /api/system/codex-restart | 此路径有真正的目录生成前置；不能用 false 分支的 sync-cache 代称它 |
| 官方重启前置 | app-server-restart-service.ts 的 runCodexRestart 先执行 defaultSyncCatalog；后者调用 syncModelsToCodex，再到 refreshCodexModelCatalog/syncCatalogModels | 是根据保存配置生成新目录的正确 producer；同时受 service-home、目录所有权和目录提交规则约束 |
| 重启结果 | 官方将生成/缓存变化折叠为 synced 布尔值，并吞掉生成异常继续处理重启；生产 restart_result 仅用 synced 区分摘要文案 | restarted=true 本身无法证明新目录已生成。synced=false 也可能是合法无变化，不能简单一律改成错误；需区分 authoritative unchanged 与 refused/failed，并实际验客户端 |

这些是**源码确定的接口行为**，不是本轮已完成的 sync_cache(false) 运行反例。135713/135947 均未启动官方服务：前者构建 E0004，后者构建退出 0 但生产源码摘要发生漂移，按规则停止，没有将不明身份二进制计为最终证据。

cache_refresh.rs 原有注释明确不直接调用可能重写客户端配置的 ocx sync，因此修复不能只改命令名然后忽略作用域。可修入口是生产 cache_refresh.rs 的 refresh_cache_only、management.rs 的明确管理动作，以及上游刷新结果合同。选择已有官方 producer 时须保留期望客户端配置/历史/凭据边界，并验证目录的 authoritative refreshOutcome 和保存后的期望标识。

公开可用 producer 包括 ocx sync，以及已鉴权的 POST /api/sync；两者应核对具体合同：CLI sync 支持 catalogEvenWhenNotInjected 的 catalog-only 分支，API /api/sync 没有同一选项，Codex 集成关闭时会跳过。不能用返回成功但 skipped 的调用来通过本门。本 smoke 的旧客户端 wiring 是显式旧侧配置夹具；若主线采用另一种集成状态，需要在冻结前对齐该前置，不在改名后手工补目录。

## 隔离前置与宿主限制

生产 ProcessContext 仅携带 runtime、working_directory、opencodex_home。refresh_cache_only 会 env_clear；platform::apply_runtime_environment 把 Sandbox HOME 指向 sandbox_root/home，不会透传任意 CODEX_HOME/XDG。脚本的明确 owned wrapper 因而重新导出固定临时 HOME/CODEX_HOME/SQLite/XDG/TMP/Node/Codex 路径，再 exec 未改动的发布入口；它不伪造 sync 输出或注入测试返回值。没有这个接线，不应启动官方命令。

未 seed 的正常入口已有真实失败证据：135338 的 service-home refusal，官方只读诊断为 launchd has a job loaded but its plist is missing。临时 HOME 已正确生效，同名 job 却属于 OS 用户域；不读日常 plist、不修改服务、不重启日常客户端。

用户随后明确允许先 seed 旧安装态/旧 catalog。已准备 --seed-installed-fixture：仅在临时根、改名前写 v1 service-state 与相符 launchd 定义文件，字段来源为发布物 service/state-record.mjs 和 service-manager-probe.ts 的只读合同；不执行 launchctl install/bootstrap/stop。该文件夹具不代表隔离了真实 launchd namespace，最终必须单独披露。此模式目前尚未运行，不能提前声称 ownership 已获官方准入。

## 已准备的严格检查

在代码根，收到主线 source freeze 通知后只执行一次：

    python3 test/smoke/ocx021-owned-routing.py --run --automatic-chain --seed-installed-fixture

1. 验证文件/网络拒绝，再在全新临时环境读取官方版本、帮助、bundled native 模板与 schema。
2. 编译当前生产原路径库；全树摘要漂移或编译失败即停止，不自动重试、不降级用旧 helper。
3. 改名前允许一次旧目录生成/旧 wiring seed，明确保存来源。启动真实 OpenCodex，真实旧 Codex app-server 读到 Krill-1。
4. 保持这个官方 OpenCodex 服务运行，调用真实 save_with_context 改名；然后只调用真实 cache_refresh::sync_cache(false)。**改名后不调用 manual-catalog、不发备用 ocx sync，也不改客户端 wiring。**
5. 新开仅属于临时根的官方 Codex app-server，要求目录含 Krill 且无 Krill-1，catalog 字节已自动改变；失败直接写 gate failed，不进行手工补救。
6. 仅在自动目录检查通过后，才做一次新的本地 Responses 往返，验证真实 Codex 消费夹具响应。它属于新的自动链验证，不重复旧手工链测试来替代本门。
7. 只退出本脚本持有的进程组，确认两个 owned 端口关闭。不会调用枚举/终止 OS 全局 Codex 进程的重启路由。

严格成功只标 automaticDirectoryGatePassed；整体 releaseGatePassed 仍不由 smoke 擅自关闭，桌面 GUI/真实重启继续单列。当前生产 false 分支仍是纯 sync-cache，按静态结论应无法通过第 5 步；主线需先决定并完成必要 producer 接线，再通知冻结。

脚本新增模式目前只通过 Python AST 静态检查，尚未做本版最终运行。先前已成功的手工模式源码快照与日志保留在 provenance，不将新版准备态冒充 135035 运行身份。未改生产源码、其它测试或治理状态，未提交/推送。
