import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'
import path from 'node:path'
const ui='/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/ui'
const evidence=path.dirname(new URL(import.meta.url).pathname)
const require=createRequire(ui+'/package.json')
const {createServer}=await import(pathToFileURL(require.resolve('vite')).href)
const {default:vue}=await import(pathToFileURL(require.resolve('@vitejs/plugin-vue')).href)
const server=await createServer({root:ui,configFile:false,plugins:[{name:'post09-isolated-native-transport',enforce:'pre',resolveId(id){if(id==='@tauri-apps/api/core')return '\0post09-core'},load(id){if(id==='\0post09-core')return 'export const invoke=(...args)=>window.__qaInvoke(...args); export const isTauri=()=>false; export const convertFileSrc=v=>v; export const transformCallback=()=>0; export class Channel { constructor(){this.id=0} }'}},vue()],resolve:{alias:{'@':ui+'/src',vue:require.resolve('vue/dist/vue.esm-bundler.js'),pinia:require.resolve('pinia')}},server:{host:'127.0.0.1',port:5197,strictPort:true,fs:{allow:[ui,evidence]}},clearScreen:false})
await server.listen();console.log('POST09_URL=http://127.0.0.1:5197/@fs/'+evidence+'/browser-harness.html')
process.on('SIGTERM',async()=>{await server.close();process.exit(0)})
