#!/usr/bin/env python3
"""Production parent acceptance preparation. No action unless --run is explicit.

OLD installation/default fixture -> real save_with_context -> real public
prepare_saved_rename_restart -> fresh Codex without model override -> local
raw-model/new-provider route. No post-save test-only owner repair. A separate
mock-restart commit test uses a COPY and retains the actually prepared pending.
Run only once after parent cargo/check and explicit source freeze.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
source = Path(__file__).with_name('ocx021-owned-routing.py')
spec = importlib.util.spec_from_file_location('owned_routing', source)
base = importlib.util.module_from_spec(spec); spec.loader.exec_module(base)

def fingerprint(path):
    stat = path.stat()
    return {'sha256':base.sha(path), 'bytes':stat.st_size, 'inode':stat.st_ino, 'mtimeNs':stat.st_mtime_ns}

class ProductionParent(base.Runner):
    def run_true_route_guards(self):
        # The main cache_refresh tests now exercise private production helpers.
        # Do not clone those helpers to make external test imports compile.
        # Parent's actual cargo checks remain their own source-bound evidence.
        self.result['parentChecks'] = {'source':'user-reported parent checks, not rerun by external helper',
            'cacheRefresh': '19/19 reported before final freeze',
            'liveAdapter': '15/15 reported before final freeze',
            'scope':'must be accompanied by parent source-bound final cargo/check receipts'}
    def helper_json(self, mode, label, extra=(), policy=None, timeout=60):
        _, out, _ = self.command([self.helper, mode, *extra],label,timeout=timeout,policy=policy)
        return json.loads(out)
    def bind_observer(self, observed):
        binding = observed['bindings']
        assert binding['attested'] is True
        integration, runtime = binding['codexIntegration'], binding['codexRuntime']
        assert integration['clientId']=='codex' and integration['installed'] is True
        assert integration['state'] in ['current','stale'], 'official old installation not current/stale; no fake installed state allowed'
        reported = Path(integration['configPath'])
        assert reported.is_absolute() and '..' not in reported.parts and reported.name=='config.toml'
        config = reported.resolve(strict=True)
        assert config.is_relative_to(self.root) and config.parent.name=='.codex'
        codex_home, home = config.parent, config.parent.parent
        assert home.is_relative_to(self.root) and codex_home.is_relative_to(home)
        raw = runtime['path']
        assert runtime['version'] and isinstance(raw,str)
        # Resolve only against this server-bound HOME, never expanduser() or
        # substitute a manually chosen executable/config/default model.
        executable = home / raw[2:] if raw.startswith(('~/','~\\')) else Path(raw)
        assert executable.is_absolute() and '..' not in executable.parts
        executable = executable.resolve(strict=True)
        assert executable.is_file()
        assert base.sha(executable)==self.observer_binary_sha, 'server selected a different/unverified native Codex runtime'
        if hasattr(self,'bound_config'):
            assert config==self.bound_config and executable==self.codex and home==self.bound_home
        self.codex=executable
        self.bound_config,self.bound_codex_home,self.bound_home=config,codex_home,home
        assert Path(self.env['CODEX_HOME']).resolve()==codex_home and Path(self.env['HOME']).resolve()==home
        self.result['officialClientBinding']={'rawCodexRuntime':runtime,'rawIntegration':integration,
            'resolvedExecutable':str(executable),'resolvedConfig':str(config),
            'resolvedCodexHome':str(codex_home),'tildeExpansionHome':str(home),
            'source':'actual attested settings + actual integration; no injected response'}
    def client_models(self,label):
        if label!='codex-before': return super().client_models(label)
        self.observer_binary_sha=base.sha(self.codex)
        state=self.helper_json('observe-production-bindings','official-binding-before-rename')
        self.bind_observer(state)
        rpc=base.Rpc(self,'codex-unseeded-current-config')
        try:
            current=rpc.call(2,'config/read',{'cwd':str(self.work),'includeLayers':True})
            base.dump(self.out/'unseeded-effective-config.json',current)
            assert current['config'].get('profile') in [None,''], 'unbound active profile must fail before any rename/write'
            assert current['config'].get('model') in [None,''], 'fresh fixture must not overwrite a pre-existing user choice'
        finally:rpc.close()
        original=self.bound_config.read_text()
        self.bound_config.write_text('model = "Krill-1/'+base.RAW_MODELS[0]+'"\n'+original)
        shutil.copyfile(self.bound_config,self.out/'old-current-default-fixture.toml')
        base.dump(self.out/'old-default-fixture-source.json',{'seededBeforeRename':True,
            'configPathFromServer':str(self.bound_config),'currentSelection':'Krill-1/'+base.RAW_MODELS[0],
            'activeProfile':None,'postRenameManualClientWritesAllowed':False})
        rpc=base.Rpc(self,'codex-before-production-save')
        try:
            config=rpc.call(2,'config/read',{'cwd':str(self.work),'includeLayers':True})
            models=rpc.call(3,'model/list',{'includeHidden':True,'limit':1000})
            base.dump(self.out/'old-effective-config.json',config)
            base.dump(self.out/'old-client-models.json',models)
            assert config['config']['model']=='Krill-1/'+base.RAW_MODELS[0]
            assert config['origins']['model']['name']['type']=='user'
            assert config['origins']['model']['name'].get('profile') is None
            assert Path(config['origins']['model']['name']['file']).resolve()==self.bound_config
            return [row['id'] for row in models['data']]
        finally:rpc.close()
    def automatic_chain(self):
        self.result.update(scope='actual production prepare integration',productionPrepareInvoked=True,
            candidateOnly=False,globalRestartEndpointCalled=False,postRenameManualClientWrites=0,
            postRenameTestOnlyOwnerRepairCalls=0,explicitExecModelOverride=False,
            releaseGatePassed=False,desktopGuiVerified=False)
        raw=self.root/'official/config.json'
        disk_before=raw.read_bytes();disk_fp=fingerprint(raw)
        pending_path=self.root/'manager/manager-state/provider-client-renames.json'
        pending_before=pending_path.read_bytes();pending=json.loads(pending_before)
        assert self.result['productionSave']['clientRenamePending']['id']==pending['id']
        assert any(row['from']=='Krill-1' and row['to']=='Krill' for row in pending['bindings'])
        base.dump(self.out/'pending-after-production-save.json',pending)
        receipt=self.helper_json('production-prepare','actual-production-prepare')
        assert receipt['entry']=='cache_refresh::prepare_saved_rename_restart' and receipt['success']
        assert receipt['pendingId']==pending['id'] and receipt['pendingRetained'] is True
        assert pending_path.read_bytes()==pending_before, 'production prepare acknowledged pending before actual restart'
        assert raw.read_bytes()==disk_before and fingerprint(raw)==disk_fp, 'production prepare rewrote saved provider config'
        self.result['productionPrepare']=receipt
        state=self.helper_json('observe-production-bindings','official-binding-after-prepare')
        self.bind_observer(state)
        live=state['bindings']['publicConfig']
        assert set(live['providers'])=={'Krill'} and live['defaultProvider']=='Krill'
        base.dump(self.root/'safe-public-state-for-commit.json',live)
        base.dump(self.out/'saved-disk-identity-through-production-prepare.json',{
            'before':disk_fp,'after':fingerprint(raw),'bytesUnchanged':True})
        shutil.copyfile(self.bound_config,self.out/'client-after-production-prepare.toml')
        catalog=self.bound_codex_home/'opencodex-catalog.json'
        shutil.copyfile(catalog,self.out/'catalog-after-production-prepare.json')
        rpc=base.Rpc(self,'fresh-codex-after-production-prepare')
        wanted='Krill/'+base.RAW_MODELS[0]
        try:
            cfg=rpc.call(2,'config/read',{'cwd':str(self.work),'includeLayers':True})
            models=rpc.call(3,'model/list',{'includeHidden':True,'limit':1000})
            thread=rpc.call(4,'thread/start',{'cwd':str(self.work),'ephemeral':True,
                'approvalPolicy':'never','sandbox':'read-only'})
            for name,data in [('effective-config-after-prepare.json',cfg),('models-after-prepare.json',models),('default-thread-after-prepare.json',thread)]:
                base.dump(self.out/name,data)
            assert cfg['config']['model']==thread['model']==wanted
            ids=[row['id'] for row in models['data']]
            assert wanted in ids and not any(model.startswith('Krill-1/') for model in ids)
            assert Path(cfg['origins']['model']['name']['file']).resolve()==self.bound_config
        finally:rpc.close()
        assert not self.seen
        status,_,_=self.command([self.codex,'exec','--json','--skip-git-repo-check','--sandbox','read-only',
            '--ephemeral','--cd',self.work,'--output-last-message',self.root/'production-prepare-last-message.txt',
            'Return the fixture text. Do not call any tools.'],'production-prepare-default-local-turn',timeout=75,check=False)
        last=self.root/'production-prepare-last-message.txt'
        if last.is_file():shutil.copyfile(last,self.out/'production-prepare-last-message.txt')
        assert status==0 and last.read_text().strip()==base.MARKER
        assert len(self.seen)==1 and self.seen[0]['model']==base.RAW_MODELS[0] and self.seen[0]['syntheticAuthorization']
        usage=[json.loads(line) for line in (self.root/'official/usage.jsonl').read_text().splitlines() if line.strip()]
        routed=[row for row in usage if row.get('requestedModel')==wanted]
        base.dump(self.out/'actual-production-prepare-routing.json',routed)
        assert len(routed)==1 and routed[0]['provider']=='Krill' and routed[0]['resolvedModel']==base.RAW_MODELS[0]
        assert routed[0]['routeDecision']['routeKind']=='explicit-provider'
        assert pending_path.read_bytes()==pending_before
        # Safe simulated completion: only a copied manager/home talks to a new
        # synthetic attested fixture. The real intent is retained for real ack.
        policy=self.root/'safe-commit-simulation.sb'
        policy.write_text(base.sandbox_policy(self.root)+
            '(allow network-outbound (remote ip "localhost:*"))\n'
            '(allow network-bind (local ip "localhost:*"))\n'
            '(allow network-inbound (local ip "localhost:*"))\n')
        shutil.copyfile(policy,self.out/'safe-commit-simulation.sb')
        simulated=self.helper_json('simulate-owned-restart-commit','production-safe-commit-simulation',
            extra=(receipt['pendingId'],),policy=policy)
        assert simulated['simulationPassed'] and simulated['originalPreparedPendingRetained']
        assert pending_path.read_bytes()==pending_before
        self.result.update(status='passed-production-prepare-and-safe-commit-copy',
            productionPrepareIntegrationPassed=True,currentDefaultMatchesNewDirectory=True,
            actualUsageProvider='Krill',rawModelAtEndpoint=base.RAW_MODELS[0],localPosts=1,
            localResponseConsumed=True,pendingId=receipt['pendingId'],actualPendingRetained=True,
            actualPendingPath=str(pending_path),safeRestartCommitCopy=simulated,
            automaticClientIntegrationVerified=True,automaticDirectoryGatePassed=True,
            actualDesktopRestartVerified=False,releaseGatePassed=False)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--check-source-freeze-only',action='store_true',
        help='read-only commit/product identity check; no temp runtime, build or official command')
    parser.add_argument('--source-freeze-head')
    parser.add_argument('--cache-target',type=Path,default=base.CACHE_TARGET)
    args=parser.parse_args()
    if args.run and args.check_source_freeze_only:
        parser.error('choose identity-only check or the actual single run')
    if args.check_source_freeze_only:
        if not args.source_freeze_head:parser.error('complete new parent freeze SHA required')
        identity=base.verify_source_freeze(args.source_freeze_head)
        print(json.dumps({key:value for key,value in identity.items() if key!='currentProductSha256'},indent=2))
        return 0
    if not args.run:
        print(json.dumps({'status':'prepared-waiting-for-parent-freeze','helperMode':'production-prepare',
            'productionEntry':'cache_refresh::prepare_saved_rename_restart(root,context)',
            'pendingAck':'only copy in safe sync_cache_after_save(true) transport simulation; original retained',
            'sourceFreeze':'explicit complete new SHA; worktree compared even when HEAD equals freeze',
            'testOnlyHeadAdvance':'allowed only when guarded product files still match freeze',
            'globalRestartAllowed':False,'postRenameTestOnlyOwnerRepairAllowed':False},indent=2));return 0
    if not args.source_freeze_head:parser.error('explicit parent source freeze SHA required')
    options=SimpleNamespace(official=base.OFFICIAL,codex=base.CODEX,node=Path(shutil.which('node')),
        evidence=base.EVIDENCE,source_freeze_head=args.source_freeze_head,automatic_chain=True,
        production_parent=True,manual_client=False,seed_installed_fixture=True,
        allow_owned_coordinator_files=True,reuse_build=None,cache_target=args.cache_target)
    runner=ProductionParent(options)
    status=0
    try:runner.prepare();runner.run()
    except Exception as error:
        runner.result.update(status='failed-production-prepare-check',error=str(error),releaseGatePassed=False)
        runner.log('FAILED: '+str(error));status=1
    finally:
        runner.finish()
        removed=[]
        for raw in runner.result.get('ownedCoordinatorExactFiles',[]):
            path=Path(raw)
            if path.is_file() and not path.is_symlink():path.unlink();removed.append(raw)
        base.dump(runner.out/'owned-coordinator-cleanup.json',{'removed':removed,'otherFilesTouched':False})
    if runner.result['status']!='passed-production-prepare-and-safe-commit-copy':return 1
    return status

if __name__=='__main__':sys.exit(main())
