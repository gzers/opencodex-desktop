/* 全景概览专题：只使用内存 fixture；不扫描本机、不写配置、不发请求。 */
(() => {
 'use strict';
 const root=document.documentElement,host=document.getElementById('connectionMapPage');if(!host)return;
 const $=(q,r=host)=>r.querySelector(q),$$=(q,r=host)=>[...r.querySelectorAll(q)];
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const clone=v=>JSON.parse(JSON.stringify(v));
 const clients=[
  {id:'codex',name:'Codex App',icon:'codex',version:'0.164',installed:true,evidence:'应用安装',connected:true,target:'newapi',model:'gpt-6.1-sol',wire:'WS'},
  {id:'claude',name:'Claude Code',icon:'claude',version:'2.1',installed:true,evidence:'可执行文件',connected:true,target:'aimami',model:'claude-sonnet-4-6',wire:'HTTP'},
  {id:'opencode',name:'OpenCode',icon:'opencode',version:'1.1',installed:true,evidence:'可执行文件',connected:true,target:'krill',model:'gpt-6.1-sol',wire:'HTTP'},
  {id:'codex-cli',name:'Codex CLI',icon:'terminal',version:'0.164',installed:true,evidence:'可执行文件',connected:true,target:'newapi',model:'gpt-6.1-sol',wire:'HTTP'},
  {id:'gemini',name:'Gemini CLI',icon:'gemini',version:'0.30',installed:true,evidence:'可执行文件',connected:false,target:null,model:null},
  {id:'cursor',name:'Cursor',icon:'terminal',version:null,installed:false,evidence:'仅残留配置，未确认安装',connected:false,target:null}
 ];
 const channels=[
  {id:'newapi',name:'NewApi',glyph:'N',model:'gpt-6.1-sol',node:'主节点',probe:'86 ms',color:'blue'},
  {id:'krill',name:'Krill',glyph:'K',model:'gpt-6.1-sol',node:'国内直连',probe:'124 ms',color:'purple'},
  {id:'aimami',name:'Aimami',glyph:'A',model:'claude-sonnet-4-6',node:'默认节点',probe:'103 ms',color:'teal'},
  {id:'official',name:'OpenAI',glyph:'O',model:'gpt-6.1-sol',node:'官方节点',probe:'未检测',color:'neutral'},
  {id:'a6api',name:'A6api',glyph:'A6',model:'gpt-5.4',node:'备用节点',probe:'未检测',color:'neutral'},
  {id:'gateway',name:'Gateway',glyph:'G',model:'gemini-3.1-pro',node:'默认节点',probe:'未检测',color:'neutral'}
 ];
 const scenes={recent:'多客户端聚合',configured:'只有配置',adapter:'Desktop 能力适配',fallback:'一次请求回退',direct:'客户端直连',stopped:'OpenCodex 未运行',many:'大量渠道',unavailable:'状态读取失败'};
 const defaults={clients:['codex','claude','opencode'],pins:[],detail:false,management:true,sync:true,backup:true};
 let layoutBudget=0;
 let preferences=clone(defaults),draft=null,scene='recent',selected=null,requestFocus=false,temporary=null,temporaryClient=null,popover=null,search='',operation='',ready=false,frameKey='',payloadKey='';
 const active=()=>root.dataset.route==='connection-map'&&!document.hidden;
 const icons={terminal:'<path d="m5 6 5 6-5 6m7 0h7"/>',manager:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',settings:'<path d="m10 3-.7 2.1-2 .9-2.1-.4L3 9l1.4 1.6v2.8L3 15l2.2 3.4 2.1-.4 2 .9L10 21h4l.7-2.1 2-.9 2.1.4L21 15l-1.4-1.6v-2.8L21 9l-2.2-3.4-2.1.4-2-.9L14 3Z"/><circle cx="12" cy="12" r="3"/>',sync:'<path d="M20 7v5h-5M4 17v-5h5M6 6a8 8 0 0 1 14 6M18 18a8 8 0 0 1-14-6"/>',adapter:'<path d="M5 3v6h5V3M7.5 9v6a4 4 0 0 0 4 4H16m-2-4 4 4-4 4M16 3v6h5V3"/>',panel:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',restart:'<path d="M19 8a8 8 0 1 0 1 7M19 3v5h-5"/>',close:'<path d="m6 6 12 12M6 18 18 6"/>',chevron:'<path d="m9 5 7 7-7 7"/>',more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>'};
 const icon=id=>['codex','claude','opencode','gemini'].includes(id)?'<svg class="pv-brand-icon" viewBox="0 0 24 24" aria-hidden="true"><use href="#ext-icon-'+id+'"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true">'+(icons[id]||icons.terminal)+'</svg>';
 const button=(label,action,attrs='',cls='')=>'<button type="button" class="pv-action '+cls+'" data-pv="'+action+'" '+attrs+'>'+label+'</button>';
 function directory(){return scene==='many'?[...channels,...Array.from({length:24},(_,i)=>({id:'extra-'+i,name:'渠道 '+String(i+1).padStart(2,'0'),glyph:String(i+1).padStart(2,'0'),model:'gpt-5.4',node:'默认节点',probe:'未检测',color:'neutral'}))]:channels;}
 function state(){
  const known=scene!=='unavailable',running=scene!=='stopped'&&operation!=='stopped',observed=!['configured','direct','stopped','unavailable'].includes(scene)&&running;
  const chosenClients=clients.filter(c=>c.installed&&preferences.clients.includes(c.id));
  if(temporaryClient)chosenClients.sort((a,b)=>Number(b.id===temporaryClient)-Number(a.id===temporaryClient));
  const visibleClients=chosenClients.slice(0,3),hiddenClients=chosenClients.slice(3);
  const focused=visibleClients.find(c=>c.id===selected)||visibleClients.find(c=>c.connected)||null;
  const actualRequest=(requestFocus||scene==='fallback'||scene==='adapter')&&observed;
  const target=scene==='adapter'?'krill':scene==='fallback'?'newapi':focused?.target||'newapi';
  const required=actualRequest?(scene==='fallback'?['krill','newapi']:[target]):selected&&focused?.connected?[target]:[];
  const all=directory();
  const recent=observed?['newapi','krill','aimami']:[];
  const wanted=[...new Set([temporary,...required,...preferences.pins,...recent,...(preferences.backup?['newapi','krill','aimami']:['newapi'])].filter(Boolean))].filter(id=>all.some(c=>c.id===id));
  const budget=(canvas.clientWidth||host.clientWidth||880)<680?2:3;
  const visibleChannels=wanted.slice(0,budget).map(id=>all.find(c=>c.id===id));
  return {known,running,observed,budget,visibleClients,hiddenClients,visibleChannels,hiddenChannels:all.filter(c=>!visibleChannels.some(v=>v.id===c.id)),focused,target,actualRequest,adapter:scene==='adapter',direct:scene==='direct',status:!known?'正在确认':running?'运行中':'未运行',motion:!known?'stale':running?'running':'stopped'};
 }
 function mark(kind,text){return '<span class="pv-state '+kind+'"><i></i>'+esc(text)+'</span>';}
 function clientNode(c,i,total,s){
  const y=total===1?49:28+i*(43/Math.max(total-1,1));
  return '<section class="pv-node pv-client '+(selected===c.id?'is-selected':'')+'" data-node="'+c.id+'" style="--x:12%;--y:'+y+'%"><button type="button" class="pv-node-main" data-pv="select" data-id="'+c.id+'" aria-label="选择 '+c.name+'" aria-pressed="'+(selected===c.id)+'"><span class="pv-tile">'+icon(c.icon)+'</span><strong>'+c.name+'</strong></button><div class="pv-node-info"><span>v'+c.version+'</span><span>'+(!c.connected?'未接入':scene==='direct'?'配置直连':s.adapter?'目标配置':s.observed?'近期请求':'已配置')+'</span></div>'+(preferences.detail?'<small>'+c.evidence+'</small>':'')+'<div class="pv-node-actions">'+button('查看','detail','data-id="'+c.id+'"')+(c.connected?button('接入配置','client-settings','data-id="'+c.id+'"'):'')+'</div></section>';
 }
 function channelNode(c,i,total,s){
  const y=total===1?49:total===2?30+i*36:27+i*22;
  const isAttempt=scene==='fallback'&&['krill','newapi'].includes(c.id),used=!s.adapter&&s.observed&&(s.actualRequest?[s.target,...(scene==='fallback'?['krill']:[])].includes(c.id):s.visibleClients.some(cl=>cl.connected&&cl.target===c.id));
  return '<section class="pv-node pv-channel '+(selected===c.id?'is-selected':'')+'" data-node="'+c.id+'" style="--x:86%;--y:'+y+'%"><button type="button" class="pv-node-main" data-pv="select" data-id="'+c.id+'" aria-label="选择渠道 '+c.name+'" aria-pressed="'+(selected===c.id)+'"><span class="pv-tile pv-provider '+c.color+'">'+c.glyph+'</span><strong>'+c.name+'</strong></button><div class="pv-node-info"><span>'+c.node+'</span>'+mark(isAttempt&&c.id==='krill'?'warning':used?'success':'',isAttempt&&c.id==='krill'?'首次超时':used?'近期采用':'已配置')+'</div><small>'+esc(c.model)+'</small>'+(preferences.detail?'<small>连接探测 '+c.probe+'</small>':'')+'<div class="pv-node-actions">'+button('查看','detail','data-id="'+c.id+'"')+button('模型','model','data-id="'+c.id+'"')+'</div></section>';
 }
 const frame=document.createElement('iframe');frame.className='pv-backdrop';frame.title='全景概览运行形象与背景光';frame.tabIndex=-1;frame.setAttribute('aria-hidden','true');
 const frameSource=new URL('../../../03-项目协作资料/01-协作包/2026-09-12-桌面管理器需求梳理与原型验证/01-需求分析/05-原型/候选/2026-09-28-Logo本体形变/index.html',document.currentScript.src);
 host.innerHTML='<div class="pv-workspace"><div class="pv-note"><div class="proto-annotation" id="ann-connection-map-01" data-annotation-number="01" data-annotation-title="全景概览 · 内存模拟" data-annotation-category="设计探索 · 版本未定"><button class="annotation-marker" type="button" aria-label="原型注释 01：全景概览 · 内存模拟" aria-expanded="false" aria-controls="annotationPopover"><span>原型</span><span>01</span><span>＋</span></button><div class="annotation-source" hidden><p>整页可视化专题，尚未替换正式概览。客户端存在性、版本、聚合渠道、请求、更新和同步均为虚构样例，不扫描本机、不请求模型、不写配置。Desktop 能力适配场景是目标链路示例，不证明当前压缩或历史能力已打通。显示设置只改本专题内存，原有业务草稿和路由不变。</p></div></div></div><header class="pv-toolbar"><div class="pv-breadcrumb">本机 <span>/</span> <strong>连接全景</strong></div>'+button(icon('settings')+'概览设置','settings','','pv-settings-trigger')+'</header><div class="pv-canvas" id="pvCanvas"><svg class="pv-edges" aria-hidden="true"></svg><div id="pvNodes"></div><div class="pv-proxy" data-node="proxy"><button type="button" class="pv-logo-hit" data-pv="select" data-id="proxy" aria-label="选择 OpenCodex 节点"></button><button type="button" class="pv-proxy-title" data-pv="detail" data-id="proxy">OpenCodex '+icon('chevron')+'</button><div class="pv-proxy-state" id="pvStatus"></div><div class="pv-proxy-meta"><span>v2.84.0</span><span>端口 10100</span>'+button('有更新 ↗','update','data-id="proxy"','pv-update')+'</div><div class="pv-proxy-actions" id="pvRuntimeActions"></div></div></div><footer class="pv-footer"><span class="pv-legend"><i></i>近期请求 <i class="config"></i>配置指向 <i class="manage"></i>管理与同步</span><button type="button" data-pv="request" class="pv-request" id="pvRequest"></button></footer><div id="pvFloat" class="pv-float" hidden></div><div id="pvSettingsMask" class="pv-settings-mask" data-pv="settings-cancel" hidden></div><div id="pvSettings" class="pv-settings" role="dialog" aria-modal="true" aria-label="概览设置" hidden></div><div class="pv-notice" id="pvNotice" role="status" hidden></div></div>';
 const canvas=$('#pvCanvas');canvas.prepend(frame);
 function render(){
  const s=state();layoutBudget=s.budget;
  host.dataset.scene=scene;host.dataset.detail=String(preferences.detail);
  $('#pvNodes').innerHTML=(preferences.management?'<section class="pv-node pv-desktop" data-node="desktop" style="--x:47%;--y:7%"><button type="button" class="pv-desktop-name" data-pv="select" data-id="desktop">'+icon('manager')+'Desktop 管理器</button><div class="pv-node-info"><span>v0.2.17</span>'+button('检查更新','update','data-id="desktop"')+'</div><div class="pv-node-actions">'+button('管理详情','detail','data-id="desktop"')+'</div></section>':'')+
   s.visibleClients.map((c,i)=>clientNode(c,i,s.visibleClients.length,s)).join('')+
   (s.hiddenClients.length?'<button type="button" class="pv-more-clients" data-pv="clients">其他客户端 <span>'+s.hiddenClients.length+'</span> '+icon('chevron')+'</button>':'')+
   (!s.visibleClients.length?'<div class="pv-empty">尚未选择展示的客户端<br>'+button('选择客户端','settings')+'</div>':'')+
   s.visibleChannels.map((c,i)=>channelNode(c,i,s.visibleChannels.length,s)).join('')+
   (s.hiddenChannels.length?'<button type="button" class="pv-more-channels" data-pv="channels">其他渠道 <span>'+s.hiddenChannels.length+'</span> '+icon('chevron')+'</button>':'')+
   (s.adapter?'<section class="pv-node pv-adapter" data-node="adapter" style="--x:68%;--y:16%"><button class="pv-node-main" type="button" data-pv="detail" data-id="adapter"><span class="pv-adapter-icon">'+icon('adapter')+'</span><strong>能力适配</strong></button><small>Desktop 后台 · 目标示例</small></section>':'')+
   (preferences.sync?'<section class="pv-node pv-sync" data-node="sync" style="--x:47%;--y:86%"><button class="pv-sync-name" type="button" data-pv="detail" data-id="sync">'+icon('sync')+'配置同步</button><small>WebDAV · 14:20 已同步</small><div class="pv-node-actions">'+button('文件同步','sync','data-tab="file"')+button('WebDAV','sync','data-tab="webdav"')+'</div></section>':'');
  $('#pvStatus').innerHTML=mark(s.known&&s.running?'success':!s.known?'warning':'',s.status);
  $('#pvRuntimeActions').innerHTML=button(icon('panel')+'打开面板','panel','','pv-primary')+button(icon(s.running?'restart':'restart')+(s.running?'重启':'启动'),s.running?'restart':'start')+button(icon('more'),'more','aria-label="OpenCodex 更多操作"');
  $('#pvRuntimeActions').dataset.running=String(s.running);$('#pvRuntimeActions').classList.toggle('is-forced',selected==='proxy');
  $('#pvRequest').textContent=!s.known?'读取失败 · 上次采样 14:30':!s.running?'代理未运行 · 未观察请求':s.direct?'已配置直连 · 尚未观察请求':!s.observed?'尚未观察请求 · 显示已保存配置':scene==='adapter'?'目标链路示例 · Krill 经能力适配':scene==='fallback'?'14:32 · Krill 超时 → NewApi 成功':'14:32 · 最近请求  '+(s.focused?.name||'Codex App')+' → '+(channels.find(c=>c.id===s.target)?.name||'NewApi');
  $('#pvRequest').disabled=!s.observed||s.adapter;$('#pvRequest').setAttribute('aria-pressed',String(requestFocus));
  if(operation==='stopped')$('#pvRequest').textContent='代理已停止 · 保留配置关系';
  renderFloat();syncFrame();scheduleDraw();window.prototypePanel?.refresh();
  $$('[data-pv-scene]',document).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.pvScene===scene)));
 }
 function connections(){
  const s=state(),lines=[];
  if(preferences.management)lines.push({from:'desktop',to:'proxy',kind:'manage',vertical:true,label:''});
  if(preferences.sync&&preferences.management)lines.push({from:'desktop',to:'sync',kind:'manage',around:true,label:''});
  for(const c of s.visibleClients){
   if(!c.connected)continue;
   const relevant=!selected||selected==='proxy'||selected==='desktop'||selected===c.id;
   if(s.actualRequest&&c.id!==s.focused?.id)continue;
   if(s.direct){if(s.visibleChannels.some(v=>v.id===c.target))lines.push({from:c.id,to:c.target,kind:'config',bypass:true,dim:!relevant});continue;}
   lines.push({from:c.id,to:'proxy',kind:!s.running?'warning':s.adapter?'config':s.observed?'observed':'config',dim:!relevant,label:s.adapter?'配置':s.actualRequest?c.wire:''});
  }
  for(const c of s.visibleChannels){
   const related=s.visibleClients.some(cl=>cl.connected&&cl.target===c.id),focused=selected===c.id||s.focused?.target===c.id;
   if(s.direct)continue;
   if(s.actualRequest&&!([s.target,...(scene==='fallback'?['krill']:[])].includes(c.id)))continue;
   const kind=scene==='fallback'&&c.id==='krill'?'warning':s.observed&&related?'observed':'config';
   if(s.adapter&&c.id==='krill'){lines.push({from:'proxy',to:'adapter',kind:'config',label:''},{from:'adapter',to:c.id,kind:'config',label:'目标'});if(preferences.management)lines.push({from:'desktop',to:'adapter',kind:'manage',label:'托管'});}
   else lines.push({from:'proxy',to:c.id,kind:!s.running?'config':kind,dim:!!selected&&!focused&&selected!=='proxy',label:scene==='fallback'?(c.id==='krill'?'超时':'回退'):s.actualRequest?'HTTP':''});
  }
  return lines;
 }
 let drawPending=false;
 function scheduleDraw(){if(drawPending)return;drawPending=true;requestAnimationFrame(()=>{drawPending=false;draw();});}
 function draw(){
  if(!active())return;
  const r=canvas.getBoundingClientRect(),width=canvas.clientWidth||r.width,height=canvas.clientHeight||r.height;if(!r.width||!r.height||!width||!height)return;
  const sx=r.width/width,sy=r.height/height;
  function point(id,side){const el=$('[data-node="'+id+'"]',canvas);if(!el)return null;const target=id==='proxy'?$('.pv-logo-hit',el):$('.pv-tile',el)||$('.pv-adapter-icon',el)||el;const b=target.getBoundingClientRect();return {x:((side==='r'?b.right:side==='l'?b.left:b.left+b.width/2)-r.left)/sx,y:((side==='t'?b.top:side==='b'?b.bottom:b.top+b.height/2)-r.top)/sy};}
  const svg=$('.pv-edges',canvas);svg.setAttribute('viewBox','0 0 '+width+' '+height);
  svg.innerHTML='<defs>'+['observed','config','warning'].map(kind=>'<marker id="pv-arrow-'+kind+'" viewBox="0 0 8 8" refX="6" refY="4" markerWidth="5" markerHeight="5" orient="auto"><path d="M1 1L6 4L1 7" class="pv-arrow '+kind+'"/></marker>').join('')+'</defs>'+connections().map(e=>{
   const a=point(e.from,e.vertical?'b':e.around?'l':'r'),b=point(e.to,e.vertical?'t':e.around?'l':'l');if(!a||!b)return '';
   let d,lx=(a.x+b.x)/2,ly=(a.y+b.y)/2-8;
   if(e.vertical)d='M '+a.x+' '+(a.y+6)+' C '+a.x+' '+ly+' '+b.x+' '+ly+' '+b.x+' '+(b.y-9);
   else if(e.around){const bend=width*.29;d='M '+(a.x-6)+' '+a.y+' C '+bend+' '+a.y+' '+bend+' '+b.y+' '+(b.x-8)+' '+b.y;lx=bend;ly=(a.y+b.y)/2;}
   else if(e.bypass){const y=height*.76;d='M '+(a.x+7)+' '+a.y+' C '+(a.x+45)+' '+y+' '+(b.x-45)+' '+y+' '+(b.x-10)+' '+b.y;ly=y;}
   else{d='M '+(a.x+6)+' '+a.y+' C '+lx+' '+a.y+' '+lx+' '+b.y+' '+(b.x-10)+' '+b.y;}
   return '<path data-from="'+e.from+'" data-to="'+e.to+'" '+(e.kind!=='manage'?'marker-end="url(#pv-arrow-'+e.kind+')"':'')+' d="'+d+'" class="pv-wire '+e.kind+(e.dim?' is-dim':'')+'"/>'+(e.label?'<text class="pv-wire-label" x="'+lx+'" y="'+ly+'">'+e.label+'</text>':'');
  }).join('');
 }
 function syncFrame(){
  const on=active(),effects=root.dataset.effects||'high',renderer=root.dataset.glowRender||'css',key=effects+'|'+renderer;
  if(!on&&!frameKey)return;
  if(on&&key!==frameKey){const url=new URL(frameSource);url.search='?embed=1&layout=hero&effects='+effects+'&render='+renderer;frame.src=url.href;frameKey=key;ready=false;payloadKey='';}
  const w=canvas.clientWidth||880,h=canvas.clientHeight||530,size=w<680?88:112;
  // 同一个iframe同时承载形象与光场，Logo中心与实际连线锚点一致。
  const logoX=w*.47,logoY=h*.455;
  frame.style.width=(w+100)+'px';frame.style.height=(h+180)+'px';frame.style.left=(logoX-(w+100)/2)+'px';frame.style.top='-60px';
  const payload={type:'opencodex-motion-preview',state:state().motion,theme:root.dataset.theme,active:on,presentation:{size,padding:logoY+60-size/2}},serial=JSON.stringify(payload);
  if(ready&&serial!==payloadKey){frame.contentWindow?.postMessage(payload,location.protocol==='file:'?'*':location.origin);payloadKey=serial;}
  host.dataset.active=String(on);
 }
 function facts(id){
  const s=state(),c=clients.find(c=>c.id===id),channel=directory().find(c=>c.id===id);
  if(c)return {title:c.name,rows:[['本机存在',c.installed?'已确认 · '+c.evidence:'未确认'],['版本',c.version||'未知'],['接入',!c.connected?'未接入':s.direct?'配置直连':'OpenCodex 本地实例'],['路径依据',s.observed?'近期请求记录（示例）':'已保存配置（示例）']]};
  if(channel)return {title:channel.name,rows:[['服务节点',channel.node],['模型',channel.model],['连接探测',channel.probe],['路径',s.adapter&&id==='krill'?'Desktop 能力适配（目标示例）':'OpenCodex 聚合选路'],['请求记录',s.observed?'14:32 · 示例':'尚未观察']]};
  if(id==='sync')return {title:'配置同步',rows:[['WebDAV','14:20 · 已同步（示例）'],['文件同步','按选择范围导入／导出'],['对话配置','默认排除'],['对话历史','仅本地恢复，不同步 WebDAV']]};
  if(id==='adapter')return {title:'Desktop 能力适配',rows:[['产品归属','Desktop 后台能力'],['当前场景','目标链路模拟，未生产接入'],['选路责任','OpenCodex 保持聚合和选路'],['兼容范围','不代表原生压缩／history 已打通']]};
  if(id==='desktop')return {title:'Desktop 管理器',rows:[['版本','0.2.17（示例）'],['职责','状态、配置、更新和同步'],['能力适配','按需后台托管'],['日常请求','不经管理界面转发']]};
  return {title:'OpenCodex',rows:[['状态',s.status],['版本','2.84.0（示例）'],['端口','10100'],['渠道',directory().length+' 个已配置渠道'],['聚合','由原版 OpenCodex 选路与回退']]};
 }
 function renderFloat(){
  const f=$('#pvFloat');f.hidden=!popover;if(!popover)return;
  if(popover==='clients'){f.innerHTML='<div class="pv-float-head"><strong>其他本机客户端</strong>'+button(icon('close'),'close','aria-label="关闭客户端清单"')+'</div><div class="pv-channel-results">'+state().hiddenClients.map(c=>'<button type="button" data-pv="expand-client" data-id="'+c.id+'"><span>'+c.name+'</span><small>'+c.evidence+'</small></button>').join('')+'</div>';return;}
  if(popover==='channels'){
   const hidden=state().hiddenChannels,results=hidden.filter(c=>(c.name+' '+c.model).toLowerCase().includes(search.trim().toLowerCase()));
   f.innerHTML='<div class="pv-float-head"><strong>其他渠道 · '+hidden.length+'</strong>'+button(icon('close'),'close','aria-label="关闭渠道清单"')+'</div><input class="input" id="pvChannelSearch" type="search" aria-label="搜索其他渠道" placeholder="搜索渠道或模型" value="'+esc(search)+'"><div class="pv-channel-results">'+(results.length?results.map(c=>'<button type="button" data-pv="expand" data-id="'+c.id+'"><span>'+esc(c.name)+'</span><small>'+esc(c.model)+'</small></button>').join(''):'<p>没有匹配的渠道</p>')+'</div>';return;
  }
  if(popover==='more'){f.innerHTML='<div class="pv-float-head"><strong>OpenCodex 操作</strong>'+button(icon('close'),'close','aria-label="关闭节点操作"')+'</div>'+button('查看运行详情','detail','data-id="proxy"')+button('查看日志','navigate','data-route="logs"')+button('停止 OpenCodex','stop','','pv-danger');return;}
  const info=facts(popover);f.innerHTML='<div class="pv-float-head"><strong>'+info.title+'</strong>'+button(icon('close'),'close','aria-label="关闭节点详情"')+'</div><dl>'+info.rows.map(([k,v])=>'<div><dt>'+k+'</dt><dd>'+esc(v)+'</dd></div>').join('')+'</dl>'+(popover==='sync'?'<div class="pv-float-actions">'+button('文件同步','sync','data-tab="file"')+button('WebDAV','sync','data-tab="webdav"')+'</div>':directory().some(c=>c.id===popover)?'<div class="pv-float-actions">'+button('查看渠道','navigate','data-route="models"')+button('选择模型','model','data-id="'+popover+'"')+'</div>':'');
 }
 function renderSettings(){
  const el=$('#pvSettings');el.hidden=!draft;$('#pvSettingsMask').hidden=!draft;if(!draft)return;
  el.innerHTML='<div class="pv-float-head"><strong>概览设置</strong>'+button(icon('close'),'settings-cancel','aria-label="取消概览设置"')+'</div><div class="pv-settings-body"><fieldset><legend>展示的本机客户端</legend><p>仅选择已确认存在的客户端。显隐不改变接入。</p>'+clients.map(c=>'<label class="pv-option '+(!c.installed?'is-disabled':'')+'"><input type="checkbox" data-client="'+c.id+'" '+(draft.clients.includes(c.id)?'checked':'')+' '+(!c.installed?'disabled':'')+'><span>'+c.name+'<small>'+c.evidence+(!c.connected&&c.installed?' · 未接入':'')+'</small></span></label>').join('')+'</fieldset><fieldset><legend>固定常用渠道</legend><p>画面按空间收敛，其他项从渠道清单展开。</p><div class="pv-pin-options">'+channels.map(c=>'<label><input type="checkbox" data-pin="'+c.id+'" '+(draft.pins.includes(c.id)?'checked':'')+'>'+c.name+'</label>').join('')+'</div></fieldset><fieldset><legend>显示内容</legend>'+[['detail','详细节点信息'],['management','管理关系'],['sync','配置同步'],['backup','备用渠道']].map(([id,name])=>'<label class="pv-option"><input type="checkbox" data-option="'+id+'" '+(draft[id]?'checked':'')+'>'+name+'</label>').join('')+'</fieldset></div><div class="pv-settings-footer">'+button('恢复默认','settings-reset')+button('取消','settings-cancel')+button('应用显示','settings-apply','','pv-primary')+'</div>';
 }
 function restoreSettingsFocus(){ $('.pv-settings-trigger')?.focus({preventScroll:true}); }
 function showNotice(text){$('#pvNotice').textContent=text;$('#pvNotice').hidden=false;clearTimeout(showNotice.timer);showNotice.timer=setTimeout(()=>{$('#pvNotice').hidden=true;},2600);}
 function modelChoice(id){
  const c=directory().find(c=>c.id===id);if(!c)return;
  const rows=window.modelPrototype?.agentChoices?.()||[];
  window.modelPickerPrototype?.choose({title:'查看与选择渠道模型',mode:'single',reasoning:true,fast:true,models:[{kind:'channel',channelId:c.id,modelId:c.model}],getCatalog:()=>rows,onSelect:result=>{showNotice('已选择 '+(result.models[0]?.modelId||'模型')+'；此专题未修改运行配置。');},onCancel:()=>{}});
 }
 host.addEventListener('click',e=>{
  const b=e.target.closest('[data-pv]');if(!b)return;const a=b.dataset.pv,id=b.dataset.id;
  if(a==='settings'){draft=clone(preferences);popover=null;renderFloat();renderSettings();$('.pv-settings input:not(:disabled)')?.focus();}
  else if(a==='settings-cancel'){draft=null;renderSettings();restoreSettingsFocus();}
  else if(a==='settings-apply'){preferences=clone(draft);draft=null;renderSettings();if(!preferences.clients.includes(selected)&&clients.some(c=>c.id===selected))selected=null;render();restoreSettingsFocus();}
  else if(a==='settings-reset'){draft=clone(defaults);renderSettings();}
  else if(a==='select'){selected=selected===id?null:id;requestFocus=false;popover=null;render();$('[data-pv="select"][data-id="'+id+'"]')?.focus({preventScroll:true});}
  else if(a==='detail'){selected=id;popover=id;render();$('#pvFloat button')?.focus({preventScroll:true});}
  else if(a==='close'){popover=null;renderFloat();($('[data-pv="select"][data-id="'+selected+'"]')||$('.pv-logo-hit'))?.focus({preventScroll:true});}
  else if(a==='clients'){popover='clients';renderFloat();$('#pvFloat button')?.focus();}
  else if(a==='expand-client'){temporaryClient=id;selected=id;requestFocus=false;popover=null;render();$('[data-pv="select"][data-id="'+id+'"]')?.focus({preventScroll:true});}
  else if(a==='channels'){popover='channels';search='';renderFloat();$('#pvChannelSearch')?.focus();}
  else if(a==='expand'){temporary=id;selected=id;popover=null;render();$('[data-pv="select"][data-id="'+id+'"]')?.focus({preventScroll:true});}
  else if(a==='request'){requestFocus=!requestFocus;popover=null;render();$('#pvRequest').focus({preventScroll:true});}
  else if(a==='more'){popover='more';renderFloat();$('#pvFloat button')?.focus();}
  else if(a==='stop'){operation='stopped';popover=null;render();showNotice('OpenCodex 已停止（模拟）；其他节点保留配置关系。');}
  else if(a==='restart'||a==='start'){operation='';if(scene==='stopped')scene='recent';render();showNotice('OpenCodex 已就绪（模拟）。');}
  else if(a==='update'){popover=null;openModal((id==='desktop'?'Desktop':'OpenCodex')+' 更新','<p>当前 '+(id==='desktop'?'0.2.17':'2.84.0')+'，此为版本更新入口样例。</p><p>更新操作沿既有更新中心；本专题不检查网络、不下载安装。</p>',null,null,{hideConfirm:true,cancelLabel:'关闭',hideNote:true});}
  else if(a==='model')modelChoice(id);
  else if(a==='panel')setRoute('panel');
  else if(a==='sync')setRoute('sync?tab='+b.dataset.tab);
  else if(a==='navigate')setRoute(b.dataset.route);
  else if(a==='client-settings'){popover=id;renderFloat();showNotice('接入状态在节点详情查看；本专题不修改客户端配置。');}
 });
 host.addEventListener('change',e=>{
  if(!draft)return;const el=e.target;
  if(el.dataset.client&&clients.some(c=>c.id===el.dataset.client&&c.installed)){draft.clients=draft.clients.filter(id=>id!==el.dataset.client);if(el.checked)draft.clients.push(el.dataset.client);}
  if(el.dataset.pin){draft.pins=draft.pins.filter(id=>id!==el.dataset.pin);if(el.checked)draft.pins.push(el.dataset.pin);}
  if(el.dataset.option)draft[el.dataset.option]=el.checked;
 });
 host.addEventListener('input',e=>{if(e.target.id==='pvChannelSearch'){search=e.target.value;const start=e.target.selectionStart;renderFloat();const el=$('#pvChannelSearch');el.focus({preventScroll:true});if(el.setSelectionRange&&el.type!=='search')el.setSelectionRange(start,start);}});
 host.addEventListener('keydown',e=>{
  if(e.key==='Escape'){if(draft){e.preventDefault();draft=null;renderSettings();restoreSettingsFocus();}else if(popover){e.preventDefault();popover=null;renderFloat();$('.pv-logo-hit').focus({preventScroll:true});}}
  if(e.key==='Tab'&&draft){const items=$$('button:not(:disabled),input:not(:disabled)',$('#pvSettings')),first=items[0],last=items.at(-1);if(e.shiftKey&&e.target===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&e.target===last){e.preventDefault();first.focus();}}
 });
 const tool=document.createElement('div');tool.id='connectionMapDemoCard';tool.className='proto-card';tool.dataset.protoContexts='connection-map';
 tool.innerHTML='<div class="proto-note-title">全景概览 · 场景</div><p class="pctl-hint">整页节点布局；全部为内存样例，不扫描本机或修改配置。可在软件右上角调整展示客户端与固定渠道。</p><div class="pv-demo-scenes">'+Object.entries(scenes).map(([id,name])=>'<button type="button" class="btn ghost" data-pv-scene="'+id+'" aria-pressed="'+(scene===id)+'">'+name+'</button>').join('')+'</div><p class="pctl-hint">适配为 Desktop 后台目标示例，未证明上下文缺口已打通。近期请求是历史观察；没有流动动画。“本机存在”的依据在概览设置中模拟。</p>';
 (document.querySelector('#protoStdCards .proto-group-body')||document.getElementById('protoStdCards')).appendChild(tool);
 function setScene(id){if(!scenes[id])return;scene=id;operation='';selected=null;popover=null;temporary=null;temporaryClient=null;requestFocus=false;render();}
 tool.addEventListener('click',e=>{const b=e.target.closest('[data-pv-scene]');if(b)setScene(b.dataset.pvScene);});
 frame.addEventListener('load',()=>{ready=true;payloadKey='';syncFrame();});
 window.addEventListener('message',e=>{if(e.source===frame.contentWindow&&e.data?.type==='opencodex-motion-ready'){ready=true;payloadKey='';syncFrame();}});
 new MutationObserver(()=>{if(!active()){draft=null;popover=null;renderSettings();renderFloat();}syncFrame();scheduleDraw();}).observe(root,{attributes:true,attributeFilter:['data-route','data-theme','data-effects','data-glow-render']});
 if(window.ResizeObserver)new ResizeObserver(()=>{const next=(canvas.clientWidth||host.clientWidth||880)<680?2:3;if(next!==layoutBudget)render();else{syncFrame();scheduleDraw();}}).observe(canvas);
 document.addEventListener('visibilitychange',syncFrame);window.addEventListener('resize',()=>{syncFrame();scheduleDraw();});
 window.connectionMapPrototype={state:()=>({scene,selected,requestFocus,temporary,preferences:clone(preferences),draft:clone(draft),popover,...state(),connections:connections()}),setScene,draw};
 render();
})();

