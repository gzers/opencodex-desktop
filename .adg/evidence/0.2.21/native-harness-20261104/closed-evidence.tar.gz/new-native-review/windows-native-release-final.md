Windows 0.2.21 原生验收：通过。最终四格安装 41817246537 全部 success；实际 0.2.20→0.2.21 beta OTA 41816399916 两格通过；最终产品 Windows native owner 41807732522 两个真实 case 已通过并复用。

被测原包/tag v0.2.21 的产品源：`6e2197fd0b8a36dcb8d893b62693c5a2a77151cc`；最终测试驱动：`20d13334ab9127e013ba6adca8c19023472d015f`。20d 是工具源。已安装包仍是 6e 原件，未重建。产品 src tree：`ccc6cc45044f94b9cd2f0e944b374fc32d49eab8`。

原始 runtime EXE SHA256：`20c6a2477dd0c1f186702b6dc598d281e16410be62ca96e6a9070a905ef5559f`。唯一允许差异是偏移 14390053 的一个 Tauri bundle marker 从 UNK 改为 MSI/NSS；随后要求完整安装 EXE 的 SHA 精确相等，其余字节不接受变化。

| 类型 | 原始 installer SHA256 | 安装后完整 EXE SHA256 |
|---|---|---|
| MSI | `6ebe4256a3566949820ad1252bb1778be03b467b62e9af3059c1bedb80bef098` | `fe12dfe66a707ffebb35d1b9ded67cd45ea57c226293cdab0c88a6991329cd54` |
| NSIS | `df919ef5d500b05b721df1cc52f26f5b0060aaa9922b2371a2cb6e2f93624ccc` | `b97a0cfc23910a59a37a7a31dd14452da6d64276fa26bc1aa4236a1305ae9892` |

| 最终格 | Job | 真实启动范围 | 身份 JSON |
|---|---:|---|---|
| msi-default | 126531022302 | ordinary / 非提权 | /Users/ezio/WorkSpace/Code/tools/opencodex-desktop/governance-main/.adg/evidence/0.2.21/native-harness-20261104/new-native-review/final-installers-41817246537/msi-default.identity.json |
| msi-custom | 126531023648 | ordinary / 非提权 | /Users/ezio/WorkSpace/Code/tools/opencodex-desktop/governance-main/.adg/evidence/0.2.21/native-harness-20261104/new-native-review/final-installers-41817246537/msi-custom.identity.json |
| nsis-default | 126531023357 | any / 提权 | /Users/ezio/WorkSpace/Code/tools/opencodex-desktop/governance-main/.adg/evidence/0.2.21/native-harness-20261104/new-native-review/final-installers-41817246537/nsis-default.identity.json |
| nsis-custom | 126531020107 | ordinary / 非提权 | /Users/ezio/WorkSpace/Code/tools/opencodex-desktop/governance-main/.adg/evidence/0.2.21/native-harness-20261104/new-native-review/final-installers-41817246537/nsis-custom.identity.json |

四格原始 ZIP digest 均与 GitHub artifact digest 一致，原日志和精简原始回执位于 final-installers-41817246537/。四格均通过稳定帧、即时同点命中、trusted pointer、native menu/keyboard、021 行为和 WebDAV IPC 安全观察。custom 两格卸载 EXE 清理及默认保留数据通过；default 两格均使用安装器默认路径，未传路径覆盖参数。

历史失败原样保留：135 的 native inner select open 失败由 9e 加连续帧几何稳定与即时命中守卫处理，原 100×100ms 阈值保持，不回填旧失败根因。135/158 的 model_agent_preferences 拒绝属于观察器对生产组件本地只读偏好的误拦；20d 只加入这一精确 read，保存/生成/网络/重启仍拒绝，Node 17/17。最终新四格 all-pass 不覆盖旧失败结果。

OTA 边界：真实 beta 下载/验签、普通退出保留 020、明确更新后 OS 观察到自动新进程、同一更新 EXE 的显式 sandbox 重启后 Tauri/文件读回、pending 清除；完整 EXE 同上述原包。下载包 SHA/URL 未单独写入 OTA 回执，摘要见 windows-actual-ota-41816399916/summary.json。owner 两个真实 case 的源为最终 6e/product tree，未重跑。

本报告只提供 Windows native gate。通用 CI、Mac OTA、stable 发布门由父级独立填写。机器报告：windows-native-release-final.json。
