# 安装 / 路径旧宿主补齐与剩余调用链交接

本轮实现根仍为 ocx-0219-fixes / codex/0.2.21-fixes。已按扩展写集修复 windows-install-ui.mjs、windows-install-recovery.mjs、windows-path-ui.mjs，新增普通 Node 辅助 windows-021-runtime-host.mjs 和对应测试。没有修改 workflow、发布、OTA、query 或 offline-drop 脚本，没有暂存、提交、推送、触发 CI 或发布。主线 UI 1269/1269 与 build 通过为用户提供的状态，本轮没有重跑或冒充该结果。

三个确定问题的实现：

- 安装 UI 从真实 app_about 获取版本；021 读取真实 wiz-outcome、安装状态文案、生产 runtime store 的 install.phase=done / installing=false / installOutcome，并同时要求 DOM 进度 100%。缺少旧 wiz-finish 不再导致“未完成”；完成态必须是原生 runtime-install-dialog、唯一启用公共标题 X、无 footer，然后由标题 X 关闭并等待宿主消失。020 仍要求旧 wiz-finish 启用，并从原“完成”入口退出。300 秒安装期限、500ms 轮询、默认前缀和实际 runtime_source 读回断言保留。
- 恢复驱动的首次安装完成、真实缺包失败、恢复升级完成均走同一个版本合同。失败必须有真实错误，021 还必须等生产任务 phase=failed 且 installing=false，才用 X 关闭。缺少“允许脚本”按钮现在表示 scriptsEnabled=false，不会把不存在的按钮误认成启用；旧来源、launcher 和 manifest 字节、失败日志、history 原断言均保留。
- 路径确认从真实 app_about 分支。021 使用 dialog.app-modal-dialog[open]，确认它是唯一打开的原生层且确为“打开备份目录”，再执行“继续打开”并等待宿主退出。020 保留旧 .modal-mask 下 role=dialog 入口。生成备份、剪贴板、路径同一性、数据根与 runtime_source 完整读回断言均保留。

接口：runtimeInstallExpression(version) 生成真实 WebView 的只读 DOM/生产任务快照；closeRuntimeInstallTerminal({wait,click},version,'done'|'failed') 等任务终态、断言宿主形态后执行版本对应退出；confirmNativeBackupDirectory({wait,click},version) 处理备份目录确认。两处原有安装驱动和路径驱动已实际调用这些接口，没有仅停留在孤立测试。

新增定向命令（实现根）：node --test test/smoke/windows-021-runtime-host.test.mjs。它覆盖 020/021 关闭分支、outcome 与任务终态不一致、busy、未完成进度、缺 X、空 footer、失败异步收尾、未知版本、路径错误标题/叠层以及真实调用点接线。最终完整 Node 回归及源码摘要分别见 host-followup-node-contracts.json / host-followup-node-contracts.log 和 host-followup-source-manifest.json；Windows EXE / WebView2 未在本机 macOS 执行。

剩余旧宿主审查见 host-followup-audit.json。该报告从当前 CI/release workflow 的字面脚本引用出发，递归遍历 41 个可达 Windows smoke 脚本；它是本地只读来源审查，不是原生执行证据。主线需要继续处理以下写集外问题，不能据本轮三文件修复宣称全链已清零：

| 文件与位置 | 已确认的问题 | 所属链 |
| --- | --- | --- |
| test/smoke/windows-query-ui.mjs:101、106、119、123、146 | 五次使用“关闭更新中心”旧 aria-label；021 UpdateCenter 现在是 UiDialog 公共标题 X，label 为“关闭”。应由其 owner 按真实版本处理，保留查询失败/恢复、安装失败、日志与来源字节断言。 | CI/recovery → verifyWindowsQueryUi |
| test/smoke/windows-ota.mjs:55、66 | 升级后 verify 阶段仍找 [data-testid=update-center] .update-center、.update-center-foot button，末尾仍点“关闭更新中心”。021 的 data-testid 就在原生 dialog 本体，观察态无 footer；当前会在缩放采样时先失败。需要 OTA owner 迁移到实际 native dialog 与 header X，继续保留完整 EXE 身份、100/150/200 缩放、视口与业务配置 hash 断言，不能删 gate。 | release acceptance → windows-ota.ps1 → windows-ota.mjs verify |
| test/smoke/windows-offline-drop.mjs:27 | 仍用 .ui-fault-modal 断言无界面异常；当前 App.vue 是 dialog.ui-fault-dialog，旧选择器可能误漏真实 fault。应由该 owner 改成当前故障宿主，并保留“不能隐藏/关闭 fault 来通过验收”的要求。 | startup/native/install-recovery → verifyWindowsInstallUi → verifyWindowsOfflineDrop |

保留的 wiz-finish 和 .modal-mask 现在只存在于按版本分支的 020 兼容合同，不是 021 未迁移入口。

ready WebDAV 状态门的明确交接：

1. 当前顺序是 verifyWindows021Probes → verifyWindowsInstallUi。首次 startup 没有真实运行环境时只能验证 configured 生产状态、真实连接设置与空候选；概览卡片确实被环境门禁隐藏，原 native021-behavior.json 的 environment-gated / limitations 必须保留，不能当作 ready 文案通过。
2. 可接续的真实机会是已有 ManagedInstall 模式。windows-startup.ps1 已为该模式准备独立 sandbox Node/npm；verifyWindowsInstallUi 的 install=true 分支真实安装 2.91.0 并验证 runtime_source。第二检查点应放在本轮 closeRuntimeInstallTerminal 完成之后、verifyWindowsOfflineDrop 之前。当前本轮仅完成三个确定宿主修复，没有新增 ready 检查调用；该门仍需主线接线并在 Windows 执行。
3. 第二检查点应重读 app_about、不可变/保存数据根、OPENCODEX_HOME、runtime_source、discover_environment 和 get_sync_config；必须是真实 gate=ready，并核对仍是先前保存的合成 WebDAV endpoint revision。通过真实“概览”入口检查已呈现的概览卡片含“已配置 · 未检测”、无远程状态点，生产 observation 为空。不得设置环境 fixture、修改 Pinia 状态、伪造 backend connected 或点击测试/同步来造出该状态。
4. 安装 UI 末尾还有 offline-drop 预览。该辅助虽核对 runtime_source 保持，但不能替代 fresh environment/DOM readiness 核对。第二检查点之后继续执行它，再重读真实来源/环境/概览；若已不 ready 或出现门禁，记录失败/待验和实际 facts，不能静默省略、借用前一截图或继续声称 ready 通过。
5. 未启用 ManagedInstall 的 startup/installer 路径不应为了补文案而安装运行环境或联网；它们继续诚实保留 gated 证据。主线另行安排 ready 原生环境门。
