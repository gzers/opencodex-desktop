import { clientFacingModelLabel, clientFacingModelText, type ClientFacingModelLabel } from "../lib/error-destination";
import { createHash, randomUUID } from "node:crypto";
import { execFile as execFileCallback } from "node:child_process";
import { promisify } from "node:util";
import { opendir } from "node:fs/promises";
import type { AdapterEvent, OcxContentPart, OcxMessage, OcxParsedRequest, OcxProviderConfig, OcxTool, OcxUsage } from "../types";
import { isAllowedToolChoice, namespacedToolName, resolveToolChoiceWireName, toolChoiceToolPredicate } from "../types";
import type { AdapterFetchContext, AdapterRequest, ProviderAdapter } from "./base";
import type { TranslatorBudget } from "../lib/translator-budget";
import { readBoundedResponseBody } from "../lib/bounded-body";
import { clearableDeadline } from "../lib/abort";
import { debugDroppedFrame } from "../lib/debug";
import { configuredReasoningEfforts, modelRecordValue } from "../reasoning-effort";
import { commandCodeReasoningEfforts, refreshCommandCodeReasoningEfforts } from "../providers/command-code-efforts";
import { identifyRoutedModel } from "./identity";
import { buildNonOpenAIToolCatalogNudgeForTools } from "./tool-catalog-nudge";
import { parseDataUrl } from "./image";
import { createAdapterPhysicalSend } from "./physical-send";
import { SendBudgetExhaustedError } from "../lib/upstream-retry";
import {
  isVerifiedModelNotInPlanResponse,
  markVerifiedModelNotInPlanResponse,
  MODEL_NOT_IN_PLAN_CODE,
  MODEL_NOT_IN_PLAN_REFUSAL_MARKER,
} from "../lib/errors";
import { CommandCodeToolTextFilter, type CommandCodeDeclaredTools } from "./command-code-tool-text";
import { EMPTY_COMMAND_CODE_PROJECT_CONTEXT, loadCommandCodeProjectContext } from "./command-code-project-context";

function declaredTools(tools: OcxTool[]): CommandCodeDeclaredTools {
  return new Map(tools.map(tool => [
    namespacedToolName(tool.namespace, tool.name),
    { freeform: tool.freeform === true, schema: tool.parameters },
  ]));
}

// Retain the short ids emitted by the first local integration. New requests use the live catalog's
// provider-native IDs directly; this map is compatibility-only and is not a model fallback list.
const COMMAND_CODE_MODEL_ALIASES: Readonly<Record<string, string>> = {
  "deepseek-v4-flash": "deepseek/deepseek-v4-flash",
  "kimi-k3": "moonshotai/Kimi-K3",
  "glm-5.3": "zai-org/GLM-5.3",
  "glm-5.2": "zai-org/GLM-5.2",
};

function canonicalCommandCodeModelId(modelId: string): string {
  return Object.hasOwn(COMMAND_CODE_MODEL_ALIASES, modelId) ? COMMAND_CODE_MODEL_ALIASES[modelId]! : modelId;
}

/** Flatten tool-result content for the text-only wire output, keeping an `[image]` marker per image part in content order. */
function toolResultText(content: string | OcxContentPart[]): string {
  if (typeof content === "string") return content;
  return content.map(part => (part.type === "text" || part.type === "document" ? part.text : "[image]")).join("");
}

/** Best-effort media type from a remote https URL extension, e.g. image/png. */
function mediaTypeFromUrl(url: string): string | undefined {
  const ext = url.split(/[?#]/)[0]!.match(/\.([a-zA-Z0-9]+)$/)?.[1]?.toLowerCase();
  if (!ext) return undefined;
  const known: Record<string, string> = {
    png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", bmp: "image/bmp",
  };
  return known[ext];
}

/** Wire image part: `{ type, image, mediaType? }` per the /alpha/generate ModelMessage schema. */
function wireImagePart(imageUrl: string): Record<string, unknown> {
  const parsed = parseDataUrl(imageUrl);
  const mediaType = parsed?.mediaType ?? mediaTypeFromUrl(imageUrl);
  return { type: "image", image: imageUrl, ...(mediaType ? { mediaType } : {}) };
}

/**
 * The /alpha/generate wire pairs every assistant `tool-call` with a following `tool` message
 * whose `tool-result.toolCallId` matches it. Codex history is not guaranteed to carry that
 * pairing (interrupted turns, compacted threads, and multi-step tool rounds all can leave an
 * assistant call with no recorded result), and the upstream rejects an unpaired call with
 * `Tool result is missing for tool call <id>`, which currently surfaces as a generic 502
 * (#1383). This builder keeps the pairing invariant:
 *
 * - a `toolResult` that matches a declared assistant call emits the native `tool-result`;
 * - a `toolResult` with no matching declared call degrades to a user carrier so the model
 *   still sees the outcome without a 400-prone standalone `tool` message;
 * - every declared assistant call that never received a result gets an explicit error
 *   `tool-result`, so the upstream never sees an unpaired call.
 */
function wireMessages(messages: OcxMessage[]): Array<Record<string, unknown>> {
  const out: Array<Record<string, unknown>> = [];
  const pendingCalls: Array<{ id: string; name: string }> = [];
  // Image parts returned by a tool cannot live inside the text-only `tool-result` wire
  // output. They ride a follow-up user message, but that user message must not break the
  // adjacency of the assistant turn's tool results, so carriers are buffered and flushed
  // only after every declared call has its native or synthesized result.
  const pendingImageCarriers: Array<Record<string, unknown>> = [];
  // The /alpha/generate wire requires every assistant tool-call to be closed by a matching
  // `tool-result` immediately after the declaring assistant message. Close any declared call
  // that never received a result before a non-toolResult message moves the turn forward, so a
  // synthesized `tool` message never lands after a user message or a new assistant turn.
  const closePendingCalls = (): void => {
    for (const call of pendingCalls) {
      out.push({ role: "tool", content: [{
        type: "tool-result",
        toolCallId: call.id,
        toolName: call.name,
        output: { type: "error-text", value: "[ocx] no tool result was recorded for this tool call; execution status unknown." },
      }] });
    }
    pendingCalls.length = 0;
    if (pendingImageCarriers.length > 0) {
      out.push(...pendingImageCarriers);
      pendingImageCarriers.length = 0;
    }
  };
  for (const message of messages) {
    if (message.role === "assistant") {
      closePendingCalls();
      const content: Array<Record<string, unknown>> = [];
      for (const part of message.content) {
        if (part.type === "text") content.push({ type: "text", text: part.text });
        else if (part.type === "thinking") content.push({ type: "reasoning", text: part.thinking });
        else {
          const wireName = namespacedToolName(part.namespace, part.name);
          content.push({ type: "tool-call", toolCallId: part.id, toolName: wireName, input: part.arguments });
          pendingCalls.push({ id: part.id, name: wireName });
        }
      }
      out.push({ role: "assistant", content });
      continue;
    }
    if (message.role === "toolResult") {
      const images = typeof message.content === "string" ? [] : message.content
        .filter(part => part.type === "image")
        .map(part => wireImagePart((part as { imageUrl: string }).imageUrl));
      const callIndex = pendingCalls.findIndex(call => call.id === message.toolCallId);
      const paired = callIndex >= 0;
      if (paired) pendingCalls.splice(callIndex, 1);
      if (!paired) {
        // Pending calls from an earlier assistant turn must still be closed before any user
        // message lands, or their synthesized results would follow the orphan carrier.
        closePendingCalls();
        // The upstream rejects a standalone tool message whose call was never declared by an
        // assistant turn. Preserve the outcome and images so the model can still act on it.
        const label = message.toolName ? `${message.toolName} (${message.toolCallId})` : message.toolCallId;
        const text = toolResultText(message.content);
        // The orphan result cannot ride a `tool` message; carry it in a user message instead.
        out.push({ role: "user", content: [{ type: "text", text: `[tool result without adjacent tool call: ${label}]\n${text}` }, ...images] });
        continue;
      }
      out.push({ role: "tool", content: [{
        type: "tool-result",
        toolCallId: message.toolCallId,
        toolName: namespacedToolName(message.toolNamespace, message.toolName),
        output: { type: message.isError ? "error-text" : "text", value: toolResultText(message.content) },
      }] });
      // The proprietary wire's tool-result output is text-only; image parts returned by a
      // tool (e.g. Codex view_image) cannot live inside it. Carry them in a follow-up user
      // message using the same image encoding as the user branch so the bytes reach the model.
      if (images.length > 0) {
        pendingImageCarriers.push({ role: "user", content: images });
      }
      continue;
    }
    // User/developer message: no pending tool results may follow it on the wire.
    closePendingCalls();
    const content: Array<Record<string, unknown>> = [];
    if (typeof message.content === "string") content.push({ type: "text", text: message.content });
    else for (const part of message.content) {
      if (part.type === "text") content.push({ type: "text", text: part.text });
      else if (part.type === "image") content.push(wireImagePart(part.imageUrl));
      else if (part.type === "document") content.push({ type: "text", text: part.text });
      else content.push({ type: "text", text: "[video]" });
    }
    out.push({ role: "user", content });
  }
  closePendingCalls();
  return out;
}

function visibleTools(parsed: OcxParsedRequest): OcxTool[] {
  const choice = parsed.options.toolChoice;
  if (choice === "none") return [];
  const tools = parsed.context.tools ?? [];
  if (isAllowedToolChoice(choice)) {
    return tools.filter(toolChoiceToolPredicate(choice, tools));
  }
  if (choice && typeof choice !== "string") {
    const selected = resolveToolChoiceWireName(tools, choice.name);
    return tools.filter(tool => namespacedToolName(tool.namespace, tool.name) === selected);
  }
  return tools;
}

function toolChoiceInstruction(parsed: OcxParsedRequest): string | undefined {
  const choice = parsed.options.toolChoice;
  if (choice === "required" || (isAllowedToolChoice(choice) && choice.mode === "required")) {
    return "Tool choice is required for this turn. Make at least one call from the advertised tool catalog before answering.";
  }
  if (choice && typeof choice !== "string" && !isAllowedToolChoice(choice)) {
    // Resolve the forced name (bare, namespace__name, or namespace.name) to the advertised
    // wire name so the instruction names a tool that is actually in the catalog.
    const wireName = resolveToolChoiceWireName(parsed.context.tools, choice.name);
    return `Tool choice is required for this turn. Call the advertised tool named ${wireName} before answering.`;
  }
  return undefined;
}

function wireTools(tools: OcxTool[]): Array<Record<string, unknown>> {
  return tools.map(tool => ({
    name: namespacedToolName(tool.namespace, tool.name),
    description: tool.description,
    input_schema: tool.parameters,
  }));
}

function currentWorkingDirectory(): string | undefined {
  try { return process.cwd(); } catch { return undefined; }
}

/** Cap the workspace listing so a large directory does not ship every entry name upstream. */
const MAX_WORKSPACE_STRUCTURE_ENTRIES = 64;
/** Cap how many recent commit subjects the config carries. */
const MAX_RECENT_COMMITS = 8;
/** Cap each recent commit entry to keep the request bounded even for long subjects. */
const MAX_RECENT_COMMIT_LENGTH = 512;
/** Cap the git status text sent upstream. */
const MAX_GIT_STATUS_LENGTH = 2048;
/** Keep collected workspace/git metadata fresh for this long (ms) so repeated requests reuse it. */
const WORKSPACE_METADATA_TTL_MS = 30_000;
/** Hard cap on cached workspace metadata entries to prevent unbounded growth across distinct cwds. */
export const MAX_WORKSPACE_METADATA_ENTRIES = 128;

/** Derive a bounded project slug from the working directory for the `x-project-slug` header. */
function projectSlug(cwd: string): string {
  return cwd.replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-|-$/g, "").toLowerCase().slice(0, 64) || "workspace";
}

export function commandCodeSessionId(parsed: OcxParsedRequest): string {
  // Shared prompt-cache cohorts identify a cache population, not one conversation. Using one
  // for session affinity would pin unrelated conversations to the same upstream worker.
  const threadId = parsed._clientThreadId?.trim();
  const replayId = parsed._reasoningReplayScope?.clientThreadId?.trim();
  const cacheKey = parsed._promptCacheKeyIsSharedCohort === false
    ? parsed.options.promptCacheKey?.trim()
    : undefined;
  const identity = threadId
    ? ["thread", threadId]
    : replayId
      ? ["replay", replayId]
      : cacheKey
        ? ["cache", cacheKey]
        : undefined;
  if (!identity) return randomUUID();
  const hex = createHash("sha256").update(`command-code:${identity[0]}\0${identity[1]}`).digest("hex");
  // Replace the digest nibbles at the UUID version and variant positions; the skipped hex characters are intentional.
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-8${hex.slice(17, 20)}-${hex.slice(20, 32)}`;
}

interface GitWorkspaceInfo {
  isGitRepo: boolean;
  currentBranch: string;
  mainBranch: string;
  gitStatus: string;
  recentCommits: string[];
}

export const workspaceMetadataCache = new Map<string, { collectedAt: number; value: GitWorkspaceInfo }>();

/**
 * Evict expired entries first, then the oldest live entry if at capacity.
 * Called before inserting a new key so the cache never exceeds the cap.
 */
export function pruneWorkspaceMetadataCache(now: number): void {
  // Pass 1: remove expired entries.
  for (const [key, entry] of workspaceMetadataCache) {
    if (now - entry.collectedAt >= WORKSPACE_METADATA_TTL_MS) {
      workspaceMetadataCache.delete(key);
    }
  }
  // Pass 2: if still at capacity, evict the oldest live entry.
  if (workspaceMetadataCache.size >= MAX_WORKSPACE_METADATA_ENTRIES) {
    let oldestKey: string | null = null;
    let oldestAt = Infinity;
    for (const [key, entry] of workspaceMetadataCache) {
      if (entry.collectedAt < oldestAt) {
        oldestAt = entry.collectedAt;
        oldestKey = key;
      }
    }
    if (oldestKey !== null) workspaceMetadataCache.delete(oldestKey);
  }
}

const execFile = promisify(execFileCallback);

/** Best-effort git metadata for the upstream config contract; every read fails safe and stays off the event loop. */
async function gitWorkspaceInfo(cwd: string | undefined): Promise<GitWorkspaceInfo> {
  const fallback: GitWorkspaceInfo = { isGitRepo: false, currentBranch: "", mainBranch: "", gitStatus: "", recentCommits: [] };
  if (!cwd) return fallback;
  const cached = workspaceMetadataCache.get(cwd);
  if (cached && Date.now() - cached.collectedAt < WORKSPACE_METADATA_TTL_MS) return cached.value;
  const run = async (args: string[]): Promise<string> => {
    try {
      const { stdout } = await execFile("git", args, { cwd, encoding: "utf8", timeout: 2000, windowsHide: true });
      return stdout.trim();
    } catch {
      return "";
    }
  };
  const root = await run(["rev-parse", "--show-toplevel"]);
  const value = root
    ? {
        isGitRepo: true,
        currentBranch: (await run(["rev-parse", "--abbrev-ref", "HEAD"])) || "HEAD",
        mainBranch: (await run(["symbolic-ref", "--short", "refs/remotes/origin/HEAD"])).replace(/^origin\//, "") || (await run(["rev-parse", "--abbrev-ref", "HEAD"])) || "",
        gitStatus: (await run(["status", "--porcelain"])).slice(0, MAX_GIT_STATUS_LENGTH),
        recentCommits: (await run(["log", "--oneline", `-${MAX_RECENT_COMMITS}`]))
          .split("\n")
          .filter(Boolean)
          .slice(0, MAX_RECENT_COMMITS)
          .map(commit => commit.slice(0, MAX_RECENT_COMMIT_LENGTH)),
      }
    : fallback;
  const now = Date.now();
  if (!workspaceMetadataCache.has(cwd)) pruneWorkspaceMetadataCache(now);
  workspaceMetadataCache.set(cwd, { collectedAt: now, value });
  return value;
}

async function commandCodeConfig(cwd: string | undefined): Promise<Record<string, unknown>> {
  let structure: string[] = [];
  if (cwd) {
    try {
      // Iterate and stop after the cap instead of materializing every entry: a directory with a
      // huge number of names must not stall the request path for 64 metadata rows.
      const dir = await opendir(cwd);
      try {
        for await (const entry of dir) {
          if (entry.name.startsWith(".")) continue;
          structure.push(entry.name);
          if (structure.length >= MAX_WORKSPACE_STRUCTURE_ENTRIES) break;
        }
      } finally {
        await dir.close().catch(() => undefined);
      }
    } catch { /* workspace metadata is optional */ }
  }
  const git = await gitWorkspaceInfo(cwd);
  return {
    ...(cwd ? { workingDir: cwd } : {}),
    date: new Date().toISOString().slice(0, 10),
    environment: process.platform,
    structure,
    ...git,
  };
}

function usage(value: unknown): OcxUsage | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
  const row = value as Record<string, unknown>;
  const inputTokens = typeof row.inputTokens === "number" ? row.inputTokens : 0;
  const outputTokens = typeof row.outputTokens === "number" ? row.outputTokens : 0;
  const details = row.inputTokenDetails && typeof row.inputTokenDetails === "object" && !Array.isArray(row.inputTokenDetails)
    ? row.inputTokenDetails as Record<string, unknown> : {};
  const cachedInputTokens = typeof details.cacheReadTokens === "number" ? details.cacheReadTokens : undefined;
  const cacheCreationInputTokens = typeof details.cacheWriteTokens === "number" ? details.cacheWriteTokens : undefined;
  return {
    inputTokens, outputTokens, totalTokens: inputTokens + outputTokens,
    ...(cachedInputTokens !== undefined ? { cachedInputTokens, cacheReadInputTokens: cachedInputTokens } : {}),
    ...(cacheCreationInputTokens !== undefined ? { cacheCreationInputTokens } : {}),
  };
}

function eventError(value: unknown): string {
  if (typeof value === "string" && value) return value;
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const message = (value as Record<string, unknown>).message;
    if (typeof message === "string" && message) return message;
  }
  return "Command Code stream error";
}

/**
 * True when the upstream rejected a tool-result continuation because an assistant tool call
 * had no matching result (`Tool result is missing for tool call <id>`). The proxy now keeps
 * that pairing invariant before sending, so this error is a distinct provider-side
 * validation failure rather than a generic stream fault; classify it as such for the
 * dashboard/logs instead of a plain upstream 502.
 */
function isMissingToolResultError(value: unknown): boolean {
  const text = eventError(value).toLowerCase();
  return text.includes("tool result is missing") || text.includes("tool_result is missing");
}

function isToolCallFinishReason(reason: string | undefined): boolean {
  return reason === "tool_calls" || reason === "tool-calls" || reason === "tool_use";
}

/** Deliver the queue's ordered events while keeping native and restored call bytes charged until yielded. */
async function* emitOrderedToolEvents(events: AdapterEvent[], budget: TranslatorBudget): AsyncGenerator<AdapterEvent> {
  for (let index = 0; index < events.length; index++) {
    const event = events[index]!;
    if (event.type !== "tool_call_start") { yield event; continue; }
    const delta = events[index + 1];
    const end = events[index + 2];
    if (delta?.type !== "tool_call_delta" || end?.type !== "tool_call_end") {
      throw new Error("Command Code ordered tool call is incomplete");
    }
    yield event;
    budget.openCall(event.id);
    try {
      budget.reserveTransient(new TextEncoder().encode(delta.arguments).byteLength,
        { kind: "tool_args", callId: event.id }).commitRetained();
      yield delta;
      yield end;
    } finally {
      budget.closeCall(event.id);
    }
    index += 2;
  }
}

async function*ndjson(response: Response, budget: TranslatorBudget): AsyncGenerator<Record<string, unknown>> {
  if (!response.body) throw new Error("Command Code response body missing");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";
  let bufferBytes = 0;
  // One live buffer owns one charge; resizing must not reserve old + replacement together.
  const resizeBuffer = (nextBytes: number) => {
    if (nextBytes > bufferBytes) {
      budget.reserveTransient(nextBytes - bufferBytes, { kind: "live_transient" }).commitRetained();
    } else {
      budget.releaseRetained(bufferBytes - nextBytes, { kind: "live_transient" });
    }
    bufferBytes = nextBytes;
  };
  try {
    for (;;) {
      const { value, done } = await reader.read();
      const next = buffer + decoder.decode(value, { stream: !done });
      const nextBytes = encoder.encode(next).byteLength;
      resizeBuffer(nextBytes);
      buffer = next;
      let newline = buffer.indexOf("\n");
      while (newline >= 0) {
        const line = buffer.slice(0, newline).trim(); buffer = buffer.slice(newline + 1);
        if (line) yield* decodeEventLine(line);
        newline = buffer.indexOf("\n");
      }
      resizeBuffer(encoder.encode(buffer).byteLength);
      if (done) break;
    }
    const final = buffer.trim();
    if (final) yield* decodeEventLine(final);
  } finally {
    budget.releaseRetained(bufferBytes, { kind: "live_transient" });
    try { await reader.cancel(); } catch { /* already closed */ }
    reader.releaseLock();
  }
}

/**
 * Yield one NDJSON line as an event record, or nothing.
 *
 * `JSON.parse("null")` returns `null` instead of throwing, so the `try/catch` around the parse
 * cannot see it and the `event.type` read in parseStream crashed the turn — the #1219 defect, on
 * the one streaming transport the #1240 audit did not cover because it is NDJSON rather than SSE.
 *
 * A frame that does not parse to a record is padding, not an event: drop it and continue exactly
 * as an unparseable line is already dropped, so a stream whose only frames are junk ends in the
 * same single terminal `done` as an empty body. Skipping is what preserves an answer whose deltas
 * have already arrived — the observed #1219 case is `null` padding BETWEEN content deltas, where
 * terminating would discard a complete response (#1240).
 *
 * Note this deliberately makes a junk-only stream a quiet `[done]` where it previously threw. That
 * throw was an unguarded type assumption, not a designed failure signal, and `[done]` is already
 * what an empty body, a blank-line-only body and an unparseable-only body all produce here. The
 * broader question — whether this adapter should report *any* no-valid-event stream as a failure
 * rather than an empty success — is pre-existing, applies to all four of those inputs equally, and
 * is deliberately not decided by this change.
 */
function* decodeEventLine(line: string): Generator<Record<string, unknown>> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(stripEventFrame(line));
  } catch {
    debugDroppedFrame("command-code", line);
    return;
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
    debugDroppedFrame("command-code", line);
    return;
  }
  yield parsed as Record<string, unknown>;
}

/** The endpoint is newline-delimited JSON; defensively strip an SSE `data:` frame if the gateway ever switches shapes. */
function stripEventFrame(line: string): string {
  return line.startsWith("data:") ? line.slice("data:".length).trim() : line;
}

function isReasoningEffortRejection(status: number, payload: string): boolean {
  return (status === 400 || status === 422) && /reasoning[_ -]?effort|unsupported effort|invalid effort/i.test(payload);
}

/** Command Code reports exhausted credits as BAD_REQUEST; normalize only that refusal
 * so every caller can reuse the existing OAuth quota rotation and send budget. Key and
 * forward rows keep the 400: a canonical key row has a same-key 429 retry ladder
 * (`rateLimitRetryPolicyFor`) that would replay a credential whose credits are gone. */
async function normalizeCommandCodeCreditRefusal(
  response: Response, oauth: boolean, signal?: AbortSignal,
): Promise<Response> {
  if (!oauth || response.status !== 400) return response;
  try {
    const observed = await readBoundedResponseBody(response.clone(), {
      signal,
      maxBytes: 8 * 1024,
      fatalUtf8: true,
    });
    if (!observed.displaySafe) return response;
    const payload = JSON.parse(observed.text);
    if (payload?.success !== false || payload.error?.code !== "BAD_REQUEST"
      || typeof payload.error?.message !== "string"
      || !payload.error.message.startsWith("You have insufficient credits to make this request.")) return response;
    const headers = new Headers(response.headers);
    headers.set("x-opencodex-upstream-status", "400");
    headers.set("x-opencodex-refusal", "insufficient-credits");
    return new Response(response.body, { status: 429, statusText: "Too Many Requests", headers });
  } catch (error) {
    if (signal?.aborted && error === signal.reason) throw error;
    return response;
  }
}

function requestWithoutReasoningEffort(request: AdapterRequest): AdapterRequest | undefined {
  try {
    const body = JSON.parse(request.body) as { params?: Record<string, unknown> };
    if (!body.params?.reasoning_effort) return undefined;
    delete body.params.reasoning_effort;
    return { ...request, body: JSON.stringify(body), reasoningLog: undefined };
  } catch {
    return undefined;
  }
}

/** The upstream's plan refusal prefix; `MODEL_NOT_IN_PLAN_OTHER` and later mentions do not count. */
const COMMAND_CODE_PLAN_REFUSAL = /^MODEL_NOT_IN_PLAN(?::|$)/;
/**
 * Fixed client copy for a plan refusal. The upstream detail is never quoted: it is free text this
 * proxy does not control, and quota or reasoning-effort words in it would steer the downstream
 * classifiers (quota recording, effort repair) on a refusal that no resend can change.
 */
function commandCodePlanRefusalMessage(model: ClientFacingModelLabel): string {
  return `Command Code refused ${clientFacingModelText(model)}: this account's plan does not include it (MODEL_NOT_IN_PLAN). `
    + "Choose a model the plan includes or change the Command Code plan; retrying this request will not succeed.";
}

/**
 * Command Code refuses a model the account's plan excludes with HTTP 403 and
 * `MODEL_NOT_IN_PLAN: ...` (#7684). Codex reconnects on every 403 through its whole retry budget,
 * and a combo reads a 403 as a provider-wide credential verdict. The refusal names one model on one
 * account, so it becomes a 400 `invalid_request_error` carrying `model_not_in_plan`, which Codex
 * reports without retrying and combo or policy fallback treat as target-local. Every auth mode
 * gets it: no account, key or provider cooldown is involved. Any other 403 stays untouched.
 */
async function normalizeCommandCodePlanRefusal(
  response: Response, modelId: string | undefined, signal?: AbortSignal,
): Promise<Response> {
  if (response.status !== 403) return response;
  try {
    const observed = await readBoundedResponseBody(response.clone(), {
      signal,
      maxBytes: 8 * 1024,
      fatalUtf8: true,
    });
    if (!observed.displaySafe || observed.truncated) return response;
    const payload = JSON.parse(observed.text);
    if (payload?.success !== false || payload.error?.code !== "FORBIDDEN"
      || typeof payload.error?.message !== "string"
      || !COMMAND_CODE_PLAN_REFUSAL.test(payload.error.message)) return response;
    try { void response.body?.cancel().catch(() => {}); } catch { /* already closed */ }
    const headers = new Headers({ "Content-Type": "application/json" });
    headers.set("x-opencodex-upstream-status", "403");
    headers.set("x-opencodex-refusal", MODEL_NOT_IN_PLAN_REFUSAL_MARKER);
    const refusal = new Response(JSON.stringify({ error: {
      type: "invalid_request_error", code: MODEL_NOT_IN_PLAN_CODE, message: commandCodePlanRefusalMessage(clientFacingModelLabel(undefined)),
    } }), { status: 400, statusText: "Bad Request", headers });
    // Identity is the provenance dispatch, combo and policy fallback check; the header is diagnostic.
    markVerifiedModelNotInPlanResponse(refusal);
    return refusal;
  } catch (error) {
    if (signal?.aborted && error === signal.reason) throw error;
    return response;
  }
}

/** Both Command Code refusal rewrites, in the order every send applies them. */
async function normalizeCommandCodeRefusal(
  response: Response, oauth: boolean, modelId: string | undefined, signal?: AbortSignal,
): Promise<Response> {
  return normalizeCommandCodePlanRefusal(await normalizeCommandCodeCreditRefusal(response, oauth, signal), modelId, signal);
}

function requestModelId(request: AdapterRequest): string | undefined {
  try {
    const model = (JSON.parse(request.body) as { params?: { model?: unknown } }).params?.model;
    return typeof model === "string" ? model : undefined;
  } catch { return undefined; }
}

async function fetchCommandCode(request: AdapterRequest, ctx: AdapterFetchContext | undefined, executor: typeof globalThis.fetch): Promise<Response> {
  const deadline = clearableDeadline(ctx?.timeoutMs ?? 200_000, ctx?.abortSignal);
  try {
    return await executor(request.url, {
      method: request.method,
      headers: request.headers,
      body: request.body,
      redirect: "manual",
      signal: deadline.signal,
    });
  } finally {
    deadline.clear();
  }
}

/**
 * Has the operator declared their own ladders authoritative for this provider?
 *
 * Comparing a configured row against the shipped table cannot answer this. `providerConfigSeed`
 * copies the whole table into every materialized preset, and both enrichment and routing keep a
 * persisted row over the current seed, so a row written by an older release keeps its old value
 * and starts LOOKING like an operator edit the moment the shipped table is corrected — at which
 * point the stale row would outrank the correction and disable the rejection repair below.
 * Provenance has to be declared rather than inferred, so it is: `providerConfigSeed` never
 * writes this flag, which makes its presence something only a human can have caused.
 */
function operatorChoseCommandCodeLadder(provider: OcxProviderConfig, canonicalId: string): boolean {
  if (provider.modelReasoningEffortsAuthoritative !== true) return false;
  return modelRecordValue(provider.modelReasoningEfforts, canonicalId) !== undefined;
}

/**
 * Resolve the ladder this request may draw a wire effort from.
 *
 * The shipped table is a default, not a ceiling the operator cannot reach past. Until this
 * existed the adapter read `commandCodeReasoningEfforts() ?? configuredReasoningEfforts()`, so a
 * model with a row ignored configuration outright while a model without one honoured it — and
 * the catalog disagreed with both, because `configuredReasoningEfforts` is what advertises the
 * picker. An operator who widened a pinned row saw the wider ladder offered in Codex and then
 * watched the adapter strip the rung on the way out (#5096).
 *
 * An operator who sets `modelReasoningEffortsAuthoritative` now resolves through the same
 * function the catalog uses, so the picker and the wire agree, and sanitization, tier healing and
 * learned-refusal dropping apply to it. Every other provider keeps the shipped table, including a
 * value learned by a profile refresh.
 */
function commandCodeEffortLadder(provider: OcxProviderConfig, canonicalId: string): readonly string[] | undefined {
  if (operatorChoseCommandCodeLadder(provider, canonicalId)) {
    return configuredReasoningEfforts(provider, canonicalId);
  }
  return commandCodeReasoningEfforts(canonicalId, provider.baseUrl) ?? configuredReasoningEfforts(provider, canonicalId);
}

function supportedCommandCodeEffort(provider: OcxProviderConfig, modelId: string, requested: string | undefined): string | undefined {
  if (!requested || requested === "none") return undefined;
  // Compatibility ids (deepseek-v4-flash / glm-5.2) must resolve to their canonical
  // Command Code id before the effort lookup, or legacy requests silently lose the
  // reasoning effort because the official table is keyed by the canonical ids.
  const canonicalId = canonicalCommandCodeModelId(modelId);
  const supported = commandCodeEffortLadder(provider, canonicalId);
  if (!supported) return undefined;
  // Only remap xhigh/ultra→max for models whose official profile documents that
  // aliasing (deepseek v4, glm-5.2). Muse Spark's upstream accepts xhigh as a
  // distinct wire value and rejects ultra, so it must not be collapsed.
  let wire = requested;
  const lower = canonicalId.toLowerCase();
  const needsAlias =
    lower === "deepseek/deepseek-v4-flash" ||
    lower === "zai-org/glm-5.2";
  if (requested === "xhigh" && !supported.includes("xhigh") && supported.includes("max")) {
    wire = "max";
  } else if (requested === "ultra" && needsAlias && !supported.includes("ultra") && supported.includes("max")) {
    // The xhigh branch above already refuses to alias a rung the ladder advertises; ultra has to
    // match it. No shipped row offers ultra, so this changes nothing for the built-in table — but
    // an authoritative operator ladder that does offer it would otherwise advertise ultra in the
    // picker and quietly send max, which is the catalog/wire disagreement this file just fixed.
    wire = "max";
  }
  return (supported as readonly string[]).includes(wire) ? wire : undefined;
}

export function createCommandCodeAdapter(provider: OcxProviderConfig): ProviderAdapter {
  const executor = (provider as OcxProviderConfig & { fetch?: typeof globalThis.fetch }).fetch ?? globalThis.fetch;
  // Only an OAuth row has sibling accounts for the rewritten 429 to rotate to.
  const creditRefusalRotates = provider.authMode === "oauth";
  // The server builds one adapter per routed request and hands parseStream a guarded wrapper
  // rather than the Response fetchResponse returned, so the stream reads the declared catalog of
  // the request this instance last built. A parser with no built request restores nothing.
  let lastDeclaredTools: CommandCodeDeclaredTools | undefined;
  let restoreMiMoTools = false;
  return {
    name: "command-code",
    async buildRequest(parsed: OcxParsedRequest): Promise<AdapterRequest> {
      if (!provider.apiKey) throw new Error("Command Code credential missing — run ocx login command-code");
      // Every MiMo generation Command Code serves writes the same <tool_call> grammar, and the
      // text echo was reported on V2.5 as well as V2.6 (patlux/pi-commandcode-provider#110).
      restoreMiMoTools = /^xiaomi\/mimo-/i.test(canonicalCommandCodeModelId(parsed.modelId));
      const cwd = currentWorkingDirectory();
      const tools = visibleTools(parsed);
      const toolNudge = buildNonOpenAIToolCatalogNudgeForTools(tools, parsed.options.toolChoice);
      const choiceInstruction = toolChoiceInstruction(parsed);
      const system = identifyRoutedModel([
        ...(parsed.context.systemPrompt ?? []),
        ...(toolNudge ? [toolNudge] : []),
        ...(choiceInstruction ? [choiceInstruction] : []),
      ].join("\n\n"), parsed.modelId);
      const reasoningEffort = supportedCommandCodeEffort(provider, parsed.modelId, parsed.options.reasoning);
      const projectContext = provider.projectContext === "on"
        ? await loadCommandCodeProjectContext(cwd)
        : EMPTY_COMMAND_CODE_PROJECT_CONTEXT;
      const body = {
        config: await commandCodeConfig(cwd), ...projectContext,
        permissionMode: "standard", mode: "agent",
        params: {
          model: canonicalCommandCodeModelId(parsed.modelId),
          messages: wireMessages(parsed.context.messages),
          tools: wireTools(tools),
          system,
          max_tokens: parsed.options.maxOutputTokens ?? provider.defaultMaxOutputTokens ?? 64_000,
          // The proprietary /alpha/generate endpoint is NDJSON-stream-only; the proxy converts
          // the buffered/streamed events to the client's requested shape (parsed.stream).
          stream: true,
          ...(parsed.options.temperature !== undefined ? { temperature: parsed.options.temperature } : {}),
          ...(reasoningEffort ? { reasoning_effort: reasoningEffort } : {}),
        },
      };
      const headers: Record<string, string> = {
        Authorization: `Bearer ${provider.apiKey}`,
        "Content-Type": "application/json",
        "User-Agent": "cli",
        "x-command-code-version": provider.commandCodeVersion ?? "0.52.1",
        "x-cli-environment": "production",
        "x-taste-learning": "false",
        "x-co-flag": "false",
        "x-session-id": commandCodeSessionId(parsed),
      };
      if (cwd) headers["x-project-slug"] = projectSlug(cwd);
      lastDeclaredTools = declaredTools(tools);
      return {
        url: `${provider.baseUrl.replace(/\/$/, "")}/alpha/generate`, method: "POST",
        headers,
        body: JSON.stringify(body),
        ...(reasoningEffort ? { reasoningLog: { effectiveEffort: reasoningEffort, wireField: "reasoning_effort" as const, wireValue: reasoningEffort } } : {}),
      };
    },
    async fetchResponse(request: AdapterRequest, ctx?: AdapterFetchContext): Promise<Response> {
      const send = createAdapterPhysicalSend(ctx, executor);
      const modelId = requestModelId(request);
      const response = await normalizeCommandCodeRefusal(
        await send({ url: request.url, dispatch: physical => fetchCommandCode(request, ctx, physical) }), creditRefusalRotates, modelId, ctx?.abortSignal,
      );
      // A plan refusal is final for this model: no effort downgrade can change the plan.
      if (response.ok || isVerifiedModelNotInPlanResponse(response)) return response;
      const currentEffort = (() => {
        try { return (JSON.parse(request.body) as { params?: { reasoning_effort?: unknown } }).params?.reasoning_effort; } catch { return undefined; }
      })();
      if (typeof currentEffort !== "string") return response;
      let body = "";
      try {
        const observed = await readBoundedResponseBody(response.clone(), { signal: ctx?.abortSignal, maxBytes: 8 * 1024 });
        if (!observed.displaySafe) return response;
        body = observed.text;
      } catch { return response; }
      if (!isReasoningEffortRejection(response.status, body)) return response;
      if (typeof modelId !== "string") return response;
      // An operator who wrote this ladder authorized the rung deliberately. Replaying the turn
      // without it would answer at the provider default and hide a wrong configuration behind a
      // successful-looking response, so the upstream rejection is what the caller gets. The
      // downgrade below stays for the shipped table, where the rung was never the caller's idea.
      if (operatorChoseCommandCodeLadder(provider, canonicalCommandCodeModelId(modelId))) return response;
      const refreshed = await refreshCommandCodeReasoningEfforts(modelId, executor, currentEffort, provider.baseUrl);
      if (!refreshed || refreshed.includes(currentEffort)) return response;
      const retry = requestWithoutReasoningEffort(request);
      if (!retry) return response;
      try {
        return await normalizeCommandCodeRefusal(await send({ url: retry.url, sendClass: "repair", recovery: "reasoning-effort-downgrade",
          beforeDispatch: () => { try { void response.body?.cancel().catch(() => {}); } catch { /* already closed */ } },
          dispatch: physical => fetchCommandCode(retry, ctx, physical) }), creditRefusalRotates, modelId, ctx?.abortSignal);
      } catch (error) {
        if (error instanceof SendBudgetExhaustedError) return response;
        throw error;
      }
    },
    async *parseStream(response: Response, budget: TranslatorBudget): AsyncGenerator<AdapterEvent> {
      let sawFinish = false;
      const toolText = new CommandCodeToolTextFilter(budget, lastDeclaredTools);
      for await (const event of ndjson(response, budget)) {
        switch (event.type) {
          case "text-start": if (restoreMiMoTools) yield* emitOrderedToolEvents(toolText.textStart(event.id), budget); break;
          case "text-delta": if (typeof event.text === "string") {
            if (restoreMiMoTools) yield* emitOrderedToolEvents(toolText.textDelta(event.id, event.text), budget);
            else yield { type: "text_delta", text: event.text };
          } break;
          case "text-end": if (restoreMiMoTools) yield* emitOrderedToolEvents(toolText.textEnd(event.id), budget); break;
          case "tool-input-start": if (restoreMiMoTools) yield* emitOrderedToolEvents(toolText.toolInputStart(event.id, event.toolName), budget); break;
          case "reasoning-delta": if (typeof event.text === "string") {
            const thinking: AdapterEvent = { type: "thinking_delta", thinking: event.text };
            if (restoreMiMoTools) yield* emitOrderedToolEvents(toolText.enqueueEvent(thinking, event.text), budget);
            else yield thinking;
          } break;
          case "tool-call": {
            const id = typeof event.toolCallId === "string" ? event.toolCallId : randomUUID();
            const name = typeof event.toolName === "string" ? event.toolName : "tool";
            const input = event.input ?? event.args ?? {};
            // MiMo markup the gateway echoed as text for this same call must not reach the client.
            if (restoreMiMoTools) {
              yield* emitOrderedToolEvents(toolText.nativeCall(id, name, input), budget);
              break;
            }
            const argumentsText = typeof input === "string" ? input : JSON.stringify(input);
            yield { type: "tool_call_start", id, name };
            budget.openCall(id);
            try {
              const reservation = budget.reserveTransient(new TextEncoder().encode(argumentsText).byteLength, { kind: "tool_args", callId: id });
              reservation.commitRetained();
              yield { type: "tool_call_delta", arguments: argumentsText };
              yield { type: "tool_call_end" };
            } finally {
              budget.closeCall(id);
            }
            break;
          }
          case "finish-step":
          case "finish": {
            // Both events are terminal on the current wire; streams commonly carry both, so
            // only the first one emits the done. finish-step carries `usage`; finish may carry
            // `totalUsage` (current flows) or `usage`.
            if (sawFinish) break;
            sawFinish = true;
            const usageValue = event.totalUsage ?? event.usage;
            let stopReason = typeof event.rawFinishReason === "string" ? event.rawFinishReason : typeof event.finishReason === "string" ? event.finishReason : undefined;
            // The AI SDK's `error` finish reason means the generation failed upstream, not that it
            // stopped. Reporting it as a `done` left the bridge to infer failure from a stop-reason
            // string, which either read as a clean completion or (once classified) mislabelled an
            // upstream error as a content filter and rejected it from the replay cache for the
            // wrong reason.
            if (stopReason === "error") {
              yield* emitOrderedToolEvents(toolText.releaseAll(), budget);
              // Keep the usage: a failed turn still consumed tokens, and dropping it makes the
              // turn look free in accounting and reports zeros to the client.
              yield {
                type: "error",
                message: "Command Code upstream ended the turn with finishReason \"error\"",
                status: 502,
                errorType: "upstream_error",
                usage: usage(usageValue),
              };
              break;
            }
            const restored = (stopReason === "stop" || isToolCallFinishReason(stopReason)) && restoreMiMoTools
              ? toolText.finish() : { events: toolText.releaseAll(), salvaged: false };
            yield* emitOrderedToolEvents(restored.events, budget);
            // Markup restored as a call ends the step on a tool call even when the model's own
            // finish reason says it stopped, because the call is what it meant to send.
            if (restored.salvaged && !isToolCallFinishReason(stopReason)) stopReason = "tool_calls";
            yield { type: "done", usage: usage(usageValue), stopReason };
            break;
          }
          case "error": {
            yield* emitOrderedToolEvents(toolText.releaseAll(), budget);
            const message = eventError(event.error);
            if (isMissingToolResultError(message)) {
              // Provider-side tool-result validation: the request carried an assistant tool
              // call the upstream refused to accept. This is not a network/stream stall; the
              // proxy normally prevents it by pairing every call, so flag it distinctly.
              yield { type: "error", message, status: 502, errorType: "upstream_error", code: "missing_tool_result" };
            } else {
              yield { type: "error", message, status: 502 };
            }
            break;
          }
          default:
            if (restoreMiMoTools) yield* emitOrderedToolEvents(toolText.boundary(), budget);
        }
      }
      // A stream that ends without a finish event still needs a terminal done so the
      // server does not wait on an adapter that silently stopped emitting.
      if (!sawFinish) {
        yield* emitOrderedToolEvents(toolText.releaseAll(), budget);
        yield { type: "done", usage: undefined, stopReason: undefined };
      }
    },
    async parseResponse(response: Response, budget: TranslatorBudget): Promise<AdapterEvent[]> {
      const events: AdapterEvent[] = [];
      for await (const event of this.parseStream(response, budget)) events.push(event);
      return events;
    },
  };
}
