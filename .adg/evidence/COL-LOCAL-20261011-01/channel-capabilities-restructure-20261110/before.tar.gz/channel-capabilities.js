/* Codex 对话策略与渠道能力：仅内存原型，不执行网络、认证、模型调用或持久化。 */
(function(root,factory){
 const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;
 else root.channelCapabilitiesPrototype=api;
})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const clone=v=>JSON.parse(JSON.stringify(v)),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const capabilities=[['call','模型调用'],['fast','Fast'],['ultra','Ultrafast'],['ws','WebSocket'],['compact','原生远程压缩'],['background','后台压缩'],['notes','历史与笔记']];
 const supportWords={supported:'支持',unknown:'待核对',unsupported:'不支持'};
 const sceneWords={normal:'Krill 当前状态',unverified:'尚未认证',auth:'认证失败',network:'网络失败',ready:'支持且已接通'};
 function access(p){return p?.connection?.specialAccess||{site:'generic',mode:'key'};}
 function fingerprint(p,nodeId){const n=p?.nodes?.find(n=>n.id===(nodeId||p.activeNodeId));return JSON.stringify([n?.id,n?.url,p?.connection?.auth,!!p?.connection?.keyConfigured,p?.connection?.credentialRef,access(p)]);}
 function createStore(){
  const records=new Map(),runs=new Map();let serial=0,scene='normal',bound=null,applied=null;
  const key=(p,nid)=>p.id+'::'+(nid||p.activeNodeId);
  function observation(p,nid){return records.get(key(p,nid))||null;}
  function status(p,nid){const r=observation(p,nid),valid=!!r&&r.fingerprint===fingerprint(p,nid);return {record:r,valid,stale:!!r&&!valid,running:runs.get(key(p,nid))?.status==='running'};}
  function auth(p,nid){
   const s=status(p,nid);if(s.running&&s.record?.auth==='checking')return {id:'checking',label:'认证检查中',tone:'info'};
   if(s.stale)return {id:'stale',label:'连接已变化 · 需复验',tone:'warning'};
   const id=s.valid?s.record.auth:'unknown';
   return {id,label:{passed:access(p).mode==='pat'?'原生身份已通过':'凭据检查已通过',failed:'认证失败',network:'本次连接失败',unknown:'尚未认证',checking:'认证检查中'}[id]||'尚未认证',tone:id==='passed'?'success':['failed'].includes(id)?'danger':id==='network'?'warning':'neutral'};
  }
  function row(p,modelId,id,nid){
   const a=access(p),s=status(p,nid),r=s.valid?s.record:null,krill=a.site==='krill';
   let support='unknown',basis='未取得适用的能力依据',detail='选择接入方式后检测';
   const explicitModel=['gpt-6.1-sol','gpt-6-astra','gpt-6.1-terra'].includes(modelId);
   if(krill){
    if(id==='call'){support='supported';basis='该站点接入说明';}
    if(id==='fast'&&explicitModel){support='supported';basis='所选型号目录声明';}
    if(id==='ultra'&&explicitModel){support=modelId==='gpt-6.1-terra'?'unsupported':'supported';basis=modelId==='gpt-6.1-terra'?'所选型号明确不支持':'官网说明与型号目录';}
    if(id==='ws'){support='supported';basis='站点接入规则 · 当前节点需另验';}
    if(id==='notes'){support='unknown';basis='旧版客户端机制存在';}
   }
   const observed=r?.features?.[id],applicable=observed?.modelId===modelId;
   if(applicable&&observed.support){support=observed.support;basis=observed.basis||basis;}
   let condition='待检测',tone='neutral';
   if(s.stale){condition='需重新检测';tone='warning';detail='此结果属于旧连接，不能用于当前地址或认证。';}
   else if(s.running&&r?.checking?.includes(id)){condition='验证中…';tone='info';detail='正在模拟所选功能验证';}
   else if(!r||r.auth==='unknown'){condition='待认证';detail='先检查当前节点的认证与目录。';}
   else if(r.auth==='failed'){condition='认证未通过';tone='danger';detail='凭据检查未通过（401），原配置保留。';}
   else if(r.auth==='network'){condition='本次检测失败';tone='warning';detail='连接超时，已有支持依据保留；可重试。';}
   else if(r.auth==='passed'){
    const v=applicable?observed:null;condition=support==='unsupported'?'不可使用':v?.condition||(support==='supported'&&['fast','ultra'].includes(id)?'可选择':'待验证');tone=support==='unsupported'?'neutral':v?.tone||'neutral';detail=v?.detail||'认证通过不代表本项已经验证。';
    if(v?.support){support=v.support;basis=v.basis||basis;}
   }
   if(support==='unsupported'){condition='当前型号不可使用';detail='可更换为支持该档位的型号，其他能力不受影响。';}
   return {id,name:capabilities.find(x=>x[0]===id)?.[1]||id,support,supportLabel:supportWords[support],basis,condition,tone,detail};
  }
  function outcome(p,modelId){
   const pat=access(p).mode==='pat',ready=scene==='ready',krill=access(p).site==='krill';
   return Object.fromEntries(capabilities.map(([id])=>[id,
    id==='call'?{condition:'可使用',tone:'success',detail:'模拟生成响应完成；型号与目标一致。',support:'supported',basis:'本轮有效响应'}:
    id==='fast'?{condition:'可选择',tone:'success',detail:'所选型号支持 Fast；本次接受 priority 参数。',...(krill?{}:{condition:'待核对',tone:'neutral',detail:'未取得此站点的型号档位声明。'})}:
    id==='ultra'?{condition:modelId==='gpt-6.1-terra'?'当前型号不可使用':krill?'可选择':'待核对',tone:krill?'success':'neutral',detail:krill?'Sol／Astra 支持 Ultrafast。default 回显另属效果核实，不否定支持。':'需按此站点与型号核对，不能套用 Krill 结论。'}:
    id==='ws'?{condition:ready?'可使用':krill?'本机入口待开启':'待核对',tone:ready?'success':'warning',detail:ready?'上游与本机入口均已模拟接通，实际采用仍待观察。':'Krill 上游支持 WSS；当前 OpenCodex 入口未启用，第三方出口仍走 HTTP/SSE。'}:
    id==='compact'?{condition:ready?'可使用':'当前为代理摘要',tone:ready?'success':'warning',detail:ready?'模拟原生状态回传与续聊通过。':'压缩及续聊可完成，但代理摘要不能标作原生远程压缩。',...(ready?{support:'supported',basis:'模拟原生协议与续聊'}:{})}:
    id==='background'?{condition:ready?'可使用':'引擎条件待接通',tone:ready?'success':'warning',detail:ready?'模拟远程 v2 与后台调度前提满足。':'需要相应引擎、远程 v2，且历史与笔记模式不同时开启；真实长上下文未验证。',...(ready?{support:'supported',basis:'模拟引擎与调度检查'}:{})}:
    {condition:!pat?'需原生身份接入':ready?'可使用':'当前服务不可用',tone:ready&&pat?'success':'warning',detail:!pat?'普通 API Key 凭据通过不等于原生 PAT 身份成立。':ready?'仅供评审的“服务恢复且完整接通”样例，非当前 Krill 结果。':'原生 thread_hint、历史列表及笔记列表均 404。客户端工具存在，完整服务未接通。',...(ready&&pat?{support:'supported',basis:'模拟完整历史／笔记服务'}:{})}
   ]));
  }
  function begin(p,nid,kind,modelId,ids){
   const k=key(p,nid),old=records.get(k),run={token:++serial,key:k,providerId:p.id,nodeId:nid,fingerprint:fingerprint(p,nid),modelId,kind,ids:ids||capabilities.map(x=>x[0]),status:'running'};
   run.previous=old?.fingerprint===run.fingerprint?clone(old):null;runs.set(k,run);records.set(k,{...(old?.fingerprint===run.fingerprint?old:{}),fingerprint:run.fingerprint,auth:kind==='connection'?'checking':old?.auth||'unknown',checking:kind==='features'?run.ids:[],modelId});return clone(run);
  }
  function finish(p,run){
   const current=runs.get(run.key);if(!current||current.token!==run.token||current.status!=='running')return false;
   current.status='done';if(!p||fingerprint(p,run.nodeId)!==run.fingerprint){current.status='stale';return false;}
   const old=records.get(run.key),authId=scene==='auth'?'failed':scene==='network'?'network':'passed';
   const next={...old,fingerprint:run.fingerprint,checking:[],finishedAt:new Date().toLocaleTimeString('zh-CN',{hour12:false}),modelId:run.modelId};
   if(run.kind==='connection'){next.auth=authId;next.directory=authId==='passed'?'已读取型号目录':'尚未读取目录';next.features=old?.features||{};}
   else if(old?.auth==='passed'){
    if(scene==='network'){next.lastError='网络超时 · 已有支持与上次结果保留';}
    else {const all=outcome(p,run.modelId);next.features={...(old?.features||{})};for(const id of run.ids)next.features[id]={...all[id],modelId:run.modelId};delete next.lastError;}
   }
   records.set(run.key,next);return true;
  }
  function stop(p,nid){const r=runs.get(key(p,nid));if(r?.status==='running'){r.status='stopped';if(r.previous)records.set(r.key,clone(r.previous));else{const v=records.get(r.key);if(v){v.checking=[];if(v.auth==='checking')v.auth='unknown';}}return true;}return false;}
  function binding(providers,savedProviders){
   if(!bound)return {label:'当前 Codex 实例尚未绑定接入',tone:'neutral',active:false};
   const p=providers.find(p=>p.id===bound.pid),saved=savedProviders?.find(p=>p.id===bound.pid);
   if(p?.enabled===false)return {label:p.name+' · 渠道已停用',tone:'warning',active:false};
   if(!p||fingerprint(p,bound.nodeId)!==bound.fingerprint)return {label:'已绑定连接发生变化 · 需复验',tone:'warning',active:false};
   if(!saved||fingerprint(saved,bound.nodeId)!==bound.fingerprint)return {label:p.name+' · 接入修改尚未保存',tone:'warning',active:false};
   if(auth(p,bound.nodeId).id!=='passed')return {label:p.name+' · 当前认证需要重新检查',tone:'warning',active:false};
   return {label:p.name+' · '+(p.nodes.find(n=>n.id===bound.nodeId)?.name||'节点')+(applied?.fingerprint===bound.fingerprint?' · 已模拟连接，采用待观察':' · 已绑定，待重新连接 Codex'),tone:applied?.fingerprint===bound.fingerprint?'success':'warning',active:applied?.fingerprint===bound.fingerprint,pid:p.id};
  }
  return {status,auth,row,begin,finish,stop,binding,setScene:v=>{if(sceneWords[v])scene=v;},scene:()=>scene,
   bind(p){if(auth(p).id!=='passed'||p.enabled===false)return false;bound={pid:p.id,nodeId:p.activeNodeId,fingerprint:fingerprint(p)};applied=null;return true;},
   reconnect(ps,saved){const b=binding(ps,saved);if(!b.pid)return false;applied=clone(bound);return true;},
   seed(p){if(access(p).site!=='krill'||scene==='unverified')return;const run=this.begin(p,p.activeNodeId,'connection',p.models[0]?.id);this.finish(p,run);if(scene!=='auth'&&scene!=='network'){const f=this.begin(p,p.activeNodeId,'features',p.models[0]?.id);this.finish(p,f);}},
   reset(){records.clear();runs.clear();bound=applied=null;serial++;},snapshot:()=>clone({records:[...records],runs:[...runs],bound,applied,scene})};
 }
 const store=createStore();let bridge=null,view={part:'connection',nodeId:null,modelId:null,ids:new Set(['call','ws'])};let timer=null;
 function enabled(){if(typeof document==='undefined')return false;const scope=document.documentElement.dataset.designScope;return scope?scope==='conversations':['conversations','capabilities'].includes(new URLSearchParams(location.search).get('design'));}
 const allowed=p=>!p?.prototypeCapabilityFixture||enabled();
 function heading(p){if(!enabled()||p.id==='native'||p.availability?.kind&&!['unknown','available'].includes(p.availability.kind))return null;return store.auth(p);}
 const btn=(label,action,attrs='',primary=false)=>'<button type="button" class="btn '+(primary?'primary':'ghost')+' btn-sm" data-cc="'+action+'" '+attrs+'>'+label+'</button>';
 const option=(v,t,s)=>'<option value="'+esc(v)+'" '+(v===s?'selected':'')+'>'+esc(t)+'</option>';
 function seed(policy,makeProvider){
  if(!enabled()||policy.providers.some(p=>p.id==='krill-demo'))return;
  const p=makeProvider('krill-demo','Krill',3,3);p.prototypeCapabilityFixture=true;p.connection.specialAccess={site:'krill',mode:'pat'};
  ['gpt-6.1-sol','gpt-6-astra','gpt-6.1-terra'].forEach((id,i)=>p.models[i].id=id);
  p.nodes=[{id:'primary',name:'海外线路',url:'https://api.kbsfdxc.net/codex/v1'},{id:'backup',name:'备用线路',url:'https://backup.krill.example/codex/v1'}];p.activeNodeId='primary';policy.providers.push(p);
 }
 function models(p){return p.models?.filter(m=>m.selected!==false)||[];}
 function selectedModel(p){return p.models.find(m=>m.id===view.modelId)?.id||models(p)[0]?.id||p.models[0]?.id||'';}
 function tableHTML(p,nid,mid,interactive=false){
  return '<div class="cc-table" role="table" aria-label="特殊能力支持与当前条件"><div class="cc-table-head" role="row"><span>功能</span><span>支持情况</span><span>当前使用条件</span></div>'+capabilities.map(([id,name])=>{
   const r=store.row(p,mid,id,nid);return '<div class="cc-cap-row" role="row" data-capability="'+id+'"><div class="cc-cap-name">'+(interactive?'<input type="checkbox" data-cc-check="'+id+'" aria-label="验证'+name+'" '+(view.ids.has(id)?'checked':'')+' '+(store.status(p,nid).running?'disabled':'')+'>':'')+'<span>'+name+'</span></div><span class="cc-support" data-support="'+r.support+'">'+(r.support==='supported'?'✓ ':r.support==='unsupported'?'— ':'◦ ')+r.supportLabel+'</span><details><summary class="cc-condition '+r.tone+'">'+esc(r.condition)+'</summary><p>'+esc(r.detail)+'</p><small>依据：'+esc(r.basis)+' · '+esc(mid)+'</small></details></div>';
  }).join('')+'</div>';
 }
 function authHTML(p,nid){const a=store.auth(p,nid),s=store.status(p,nid);return '<div class="cc-auth '+a.tone+'" role="status"><span class="cc-status-icon">'+(a.id==='passed'?'✓':a.id==='failed'?'!':'◦')+'</span><div><strong>'+esc(a.label)+'</strong><small>'+esc(s.valid?s.record.directory||'当前节点连接':s.stale?'旧结果保留，当前连接需要复验':'目录可访问与身份认证分别检查')+(s.record?.finishedAt?' · '+esc(s.record.finishedAt):'')+'</small></div></div>';}
 function summaryHTML(p){if(!enabled()||p.id==='native')return '';const mid=models(p)[0]?.id,rows=capabilities.map(([id])=>store.row(p,mid,id)),usable=rows.filter(r=>['可使用','可选择'].includes(r.condition)).length;return '<button type="button" class="cc-summary-link" data-cc="open-features" data-channel="'+esc(p.id)+'" title="查看接入与特殊能力">'+(usable?usable+' 项可用 · '+(rows.length-usable)+' 项待处理':'能力待核对')+' ›</button>';}
 function connectionHTML(p){
  if(!enabled()||p.id==='native')return '';const a=access(p),locked=bridge?.busy(),mid=selectedModel(p);
  return '<section class="cc-access" aria-label="接入与特殊能力"><div class="cc-section-title"><div><h3>接入与能力</h3><p>认证、站点支持与本机接通情况分别显示。</p></div>'+btn('检测连接与能力','open-connection','data-channel="'+esc(p.id)+'" '+(locked?'disabled':''),true)+'</div><div class="cc-access-fields"><label>站点适配<select class="mp-select" data-cc-setting="site" data-channel="'+esc(p.id)+'" aria-label="站点适配" '+(locked?'disabled':'')+'>'+option('generic','通用兼容',a.site)+option('krill','Krill',a.site)+'</select></label><label>Codex 接入方式<select class="mp-select" data-cc-setting="mode" data-channel="'+esc(p.id)+'" aria-label="Codex 接入方式" '+(locked?'disabled':'')+'>'+option('key','普通 API Key',a.mode)+(a.site==='krill'?option('pat','原生身份（PAT）',a.mode):'<option value="pat" disabled>原生身份 · 需站点适配</option>')+'</select></label></div><p class="cc-muted">复用此渠道的凭据；选择适配不会自动认证或启用功能。</p><div data-cc-auth-host="'+esc(p.id)+'">'+authHTML(p)+'</div><div class="cc-instance"><div><span>当前 Codex 实例</span><strong data-cc-binding>'+esc(store.binding(bridge.providers(),bridge.savedProviders()).label)+'</strong></div>'+btn('用于当前 Codex','bind','data-channel="'+esc(p.id)+'" '+(store.auth(p).id!=='passed'||p.enabled===false||locked?'disabled':''))+'</div><div class="cc-section-title cc-model-heading"><label>查看型号<select class="mp-select" data-cc-model data-channel="'+esc(p.id)+'" aria-label="能力适用型号">'+models(p).map(m=>option(m.id,m.id,mid)).join('')+'</select></label><span class="cc-muted">特殊能力按具体型号判断</span></div><div data-cc-table-host="'+esc(p.id)+'">'+tableHTML(p,p.activeNodeId,mid)+'</div><p class="cc-muted">保存接入设置后，仍需重新连接 Codex；执行采用以实际记录为准。</p></section>';
 }
 function modelHTML(p,m){if(!enabled()||access(p).site!=='krill')return '';const r=store.row(p,m.id,'ultra');return '<small class="cc-model-tier" title="'+esc(r.detail)+'">Ultrafast · '+esc(r.supportLabel)+'</small>';}
 function nodeHTML(p,n){if(!enabled()||p.id==='native')return '';return '<small class="cc-node-note">'+esc(store.auth(p,n.id).label)+(n.id===p.activeNodeId?' · 当前连接':' · 与当前节点分别核对')+'</small>';}
 function dialogHTML(p,original){
  if(!enabled())return original;if(!p.nodes.some(n=>n.id===view.nodeId))view.nodeId=p.activeNodeId;const mid=selectedModel(p);view.modelId=mid;
  return '<div class="cc-detection '+(document.querySelector('.window')?.offsetHeight<680?'cc-compact':'')+'" id="ccDetection" data-channel="'+esc(p.id)+'"><div class="cc-dialog-tabs" role="tablist" aria-label="检测分区">'+[['connection','连接与认证'],['features','特殊能力']].map(([id,name])=>'<button type="button" role="tab" data-cc="tab" data-part="'+id+'" aria-selected="'+(view.part===id)+'" tabindex="'+(view.part===id?0:-1)+'" aria-controls="ccPanel-'+id+'">'+name+'</button>').join('')+'</div><section id="ccPanel-connection" role="tabpanel" '+(view.part==='connection'?'':'hidden')+'>'+original+'<div class="cc-auth-check"><div><h4>节点认证</h4><label class="cc-auth-node">检测节点<select class="mp-select" data-cc-target="node" aria-label="认证检测节点">'+p.nodes.map(n=>option(n.id,n.name,view.nodeId)).join('')+'</select></label><p class="cc-muted">'+esc(p.nodes.find(n=>n.id===view.nodeId)?.name)+' · '+(access(p).mode==='pat'?'原生 PAT 身份':'API Key 凭据')+'</p></div>'+btn('检查连接与认证','check-auth','data-channel="'+esc(p.id)+'" '+(store.status(p,view.nodeId).running?'disabled':''))+'</div><div data-cc-dialog-auth>'+authHTML(p)+'</div><p class="cc-muted">上方节点检测读取接口响应，不能代替原生身份和特殊功能验证。</p></section><section id="ccPanel-features" role="tabpanel" '+(view.part==='features'?'':'hidden')+'><div class="cc-detect-fields"><label>检测节点<select class="mp-select" data-cc-target="node" aria-label="功能检测节点">'+p.nodes.map(n=>option(n.id,n.name,view.nodeId)).join('')+'</select></label><label>适用型号<select class="mp-select" data-cc-target="model" aria-label="功能检测型号">'+models(p).map(m=>option(m.id,m.id,mid)).join('')+'</select></label></div><div id="ccFeatureResults">'+tableHTML(p,view.nodeId,mid,true)+'</div><div class="cc-run-status" id="ccRunStatus" role="status">'+runStatus(p)+'</div><div class="cc-detect-footer"><p class="cc-muted">验证可能产生模型用量。历史与笔记只检查服务条件，不写入内容。</p>'+btn('验证所选功能','check-features','data-channel="'+esc(p.id)+'" '+(store.auth(p,view.nodeId).id!=='passed'||!view.ids.size||store.status(p,view.nodeId).running?'disabled':''),true)+btn('停止','stop','data-channel="'+esc(p.id)+'" '+(!store.status(p,view.nodeId).running?'disabled':''))+'</div></section></div>';
 }
 function runStatus(p){const s=store.status(p,view.nodeId);return s.running?'验证中，结果只对应所选节点与当前连接':s.stale?'连接已变化，旧检测不能覆盖新配置':s.record?.lastError||(!s.valid?'先在此节点通过认证检查':s.record.finishedAt?'上次检查 '+s.record.finishedAt+' · 结果不自动修改配置':'已选择 '+view.ids.size+' 项功能');}
 function refresh(){
  if(!bridge||typeof document==='undefined')return;
  if(!enabled()){policyBanner();return;}
  const replaceTable=(el,html)=>{const opened=[...el.querySelectorAll('.cc-cap-row details[open]')].map(d=>d.closest('[data-capability]').dataset.capability);el.innerHTML=html;for(const id of opened){const details=el.querySelector('[data-capability="'+id+'"] details');if(details)details.open=true;}};
  for(const p of bridge.providers()){
   document.querySelectorAll('[data-cc-auth-host="'+p.id+'"]').forEach(el=>el.innerHTML=authHTML(p));
   document.querySelectorAll('[data-cc-table-host="'+p.id+'"]').forEach(el=>replaceTable(el,tableHTML(p,p.activeNodeId,selectedModel(p))));
   document.querySelectorAll('.cc-summary-link[data-channel="'+p.id+'"]').forEach(el=>{const usable=capabilities.filter(([id])=>['可使用','可选择'].includes(store.row(p,models(p)[0]?.id,id).condition)).length;el.textContent=usable?usable+' 项可用 · '+(capabilities.length-usable)+' 项待处理 ›':'能力待核对 ›';});
   const state=heading(p),badge=p.id===bridge.current()&&document.querySelector('#mpChannelHeadingStatus [data-channel-availability]');if(state&&badge){badge.textContent=state.label;badge.className='mp-template-state '+state.tone;badge.dataset.channelAvailability=state.id;}
   const section=document.querySelector('.cc-access');if(section){const b=section.querySelector('[data-cc="bind"]');if(b?.dataset.channel===p.id)b.disabled=bridge.busy()||p.enabled===false||store.auth(p).id!=='passed';}
  }
  document.querySelectorAll('[data-cc-binding]').forEach(el=>el.textContent=store.binding(bridge.providers(),bridge.savedProviders()).label);
  const dialog=document.querySelector('#ccDetection');if(dialog){const p=bridge.provider(dialog.dataset.channel);if(p){const auth=dialog.querySelector('[data-cc-dialog-auth]');if(auth)auth.innerHTML=authHTML(p,view.nodeId);const table=dialog.querySelector('#ccFeatureResults');if(table)replaceTable(table,tableHTML(p,view.nodeId,selectedModel(p),true));const status=dialog.querySelector('#ccRunStatus');if(status)status.textContent=runStatus(p);const running=store.status(p,view.nodeId).running;const authAction=dialog.querySelector('[data-cc="check-auth"]');authAction.disabled=bridge.busy();authAction.textContent=store.status(p,view.nodeId).running?'停止检查':'检查连接与认证';dialog.querySelector('[data-cc="check-features"]').disabled=running||!view.ids.size||store.auth(p,view.nodeId).id!=='passed';dialog.querySelector('[data-cc="stop"]').disabled=!running;dialog.querySelectorAll('[data-cc-target]').forEach(x=>{x.disabled=running;x.value=x.dataset.ccTarget==='node'?view.nodeId:selectedModel(p);});}}
  policyBanner();const controls=document.querySelector('#ccDetection')||document.querySelector('.cc-access');if(controls)window.prototypeSelect?.enhance(controls);
 }
 function run(p,kind){
  const nid=view.nodeId||p.activeNodeId;if(!p.nodes.find(n=>n.id===nid)?.url||!p.connection?.keyConfigured){bridge.notice('请先配置服务节点与凭据');return;}
  if(kind==='features'&&store.auth(p,nid).id!=='passed')return;
  if(store.status(p,nid).running)return;const r=store.begin(p,nid,kind,selectedModel(p),[...view.ids]);refresh();
  timer=setTimeout(()=>{store.finish(bridge.provider(p.id),r);refresh();window.dispatchEvent(new Event('prototype:channel-capabilities'));},650);
 }
 function open(pid,part){if(!enabled()||bridge?.busy())return;view.part=part;view.nodeId=bridge.provider(pid)?.activeNodeId;bridge.open(pid);}
 function policyBanner(){
  const page=document.querySelector('#settings-dialog-policy');if(!page)return;let el=page.querySelector('#ccPolicyBinding');
  if(!enabled()){el?.remove();return;}if(!el){el=document.createElement('div');el.id='ccPolicyBinding';el.className='cc-policy-binding';page.prepend(el);}
  const b=store.binding(bridge.providers(),bridge.savedProviders());const p=b.pid&&bridge.provider(b.pid),notes=p&&store.row(p,models(p)[0]?.id,'notes');
  el.innerHTML='<span>实例接入</span><strong>'+esc(b.label)+'</strong><small>'+esc(notes?'历史与笔记：'+notes.condition:'依赖功能需绑定实际模型连接，不能借用其他渠道认证')+'</small>'+btn('查看渠道接入','manage-binding','data-channel="'+esc(b.pid||'krill-demo')+'"');
 }
 function connect(api){
  bridge=api;if(typeof document==='undefined')return;bridge.ensureFixture();for(const p of bridge.providers())if(p.prototypeCapabilityFixture)store.seed(p);
  const card=document.createElement('div');card.id='channelCapabilityDemoCard';card.className='proto-card';card.dataset.protoContexts='models:channels';card.innerHTML='<div class="proto-note-title">渠道接入与能力 · 协作包</div><p class="pctl-hint">内存模拟；不访问真实服务或使用真实 Key。切换情景只改变检测演示。</p><div class="pctl-grid">'+Object.entries(sceneWords).map(([id,name])=>btn(name,'scene','data-scene="'+id+'"')).join('')+'</div><div class="pctl-grid">'+btn('查看 Krill 接入','demo-channel')+btn('模拟重新连接 Codex','reconnect')+'</div>';(document.querySelector('#protoStdCards .proto-group-body')||document.querySelector('#protoStdCards'))?.appendChild(card);
  document.addEventListener('click',e=>{
   const b=e.target.closest?.('[data-cc]');if(!b||b.disabled||!enabled())return;const a=b.dataset.cc,p=bridge.provider(b.dataset.channel||document.querySelector('#ccDetection')?.dataset.channel||bridge.current());
   if(a==='open-connection'||a==='open-features')open(p.id,a==='open-features'?'features':'connection');
   else if(a==='tab'){view.part=b.dataset.part;const dialog=b.closest('.cc-detection');dialog.querySelectorAll('[role="tab"]').forEach(t=>{t.setAttribute('aria-selected',String(t===b));t.tabIndex=t===b?0:-1;});dialog.querySelectorAll('[role="tabpanel"]').forEach(x=>x.hidden=x.id!=='ccPanel-'+view.part);}
   else if(a==='check-auth'){if(store.status(p,view.nodeId).running){store.stop(p,view.nodeId);refresh();}else run(p,'connection');}else if(a==='check-features')run(p,'features');
   else if(a==='stop'){store.stop(p,view.nodeId);refresh();}
   else if(a==='bind'){if(store.bind(p)){refresh();bridge.notice('接入已绑定到当前实例 · 待重新连接；没有切换真实配置');}}
   else if(a==='reconnect'){const ok=store.reconnect(bridge.providers(),bridge.savedProviders());refresh();bridge.notice(ok?'已模拟重新连接 · 实际采用待观察':'先保存并认证所绑定的连接');}
   else if(a==='manage-binding'||a==='demo-channel'){bridge.show(p?.id||'krill-demo');}
   else if(a==='scene'){
    store.reset();store.setScene(b.dataset.scene);const demo=bridge.provider('krill-demo');if(demo)store.seed(demo);bridge.render();refresh();bridge.notice('原型场景：'+sceneWords[b.dataset.scene]+'；不改变真实服务');
   }
  });
  document.addEventListener('change',e=>{
   if(!enabled())return;const el=e.target;
   if(el.dataset.ccSetting){const p=bridge.provider(el.dataset.channel);if(!p||bridge.busy())return;bridge.edit(p.id,target=>{target.connection.specialAccess={...access(target),[el.dataset.ccSetting]:el.value};if(el.dataset.ccSetting==='site'&&el.value==='generic')target.connection.specialAccess.mode='key';});refresh();}
   else if(el.hasAttribute('data-cc-model')){view.modelId=el.value;refresh();}
   else if(el.dataset.ccTarget){if(el.dataset.ccTarget==='node')view.nodeId=el.value;else view.modelId=el.value;refresh();}
   else if(el.dataset.ccCheck){el.checked?view.ids.add(el.dataset.ccCheck):view.ids.delete(el.dataset.ccCheck);const dialog=document.querySelector('#ccDetection');if(dialog){dialog.querySelector('[data-cc="check-features"]').disabled=!view.ids.size||store.auth(bridge.provider(dialog.dataset.channel),view.nodeId).id!=='passed';}}
  });
  document.addEventListener('keydown',e=>{const tab=e.target.closest?.('.cc-dialog-tabs [role="tab"]');if(!tab||!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();e.stopPropagation();const tabs=[...tab.parentNode.children],i=tabs.indexOf(tab),n=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;tabs[n].click();tabs[n].focus();});
  new MutationObserver(()=>{card.hidden=!enabled();bridge.ensureFixture();if(enabled()){const p=bridge.provider('krill-demo');if(p&&!store.status(p).record)store.seed(p);}if(!enabled()&&bridge.provider('krill-demo')?.id===bridge.current())bridge.show('newapi',false);else bridge.render();policyBanner();window.prototypePanel?.refresh();}).observe(document.documentElement,{attributes:true,attributeFilter:['data-design-scope']});
  card.hidden=!enabled();policyBanner();
  if(enabled()&&new URLSearchParams(location.search).get('channel')==='krill-demo')setTimeout(()=>bridge.show('krill-demo'),0);
 }
 return {enabled,allowed,seed,connect,heading,connectionHTML,summaryHTML,modelHTML,nodeHTML,dialogHTML,refresh,open,createStore,fingerprint,state:()=>store.snapshot()};
});
