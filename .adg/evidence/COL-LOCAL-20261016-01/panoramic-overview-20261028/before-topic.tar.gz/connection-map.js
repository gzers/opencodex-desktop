/* 独立连接关系打样：只使用内存 fixture；复用既有 Logo 形变 iframe。 */
(() => {
 'use strict';
 const root=document.documentElement,host=document.getElementById('connectionMapPage');if(!host)return;
 const $=(q,r=host)=>r.querySelector(q),$$=(q,r=host)=>[...r.querySelectorAll(q)];
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const sceneLabels={recent:'最近请求',configured:'仅配置指向',direct:'原生直连',stopped:'代理未运行',fallback:'渠道回退',multiple:'多个来源',unavailable:'读取失败'};
 let scene='recent',view='graph',selected=null,ready=false,frameKey='',payloadKey='',activeLast=false;
 const icons={client:'<rect x="3" y="3" width="18" height="13" rx="2"/><path d="M8 21h8m-4-5v5"/>',terminal:'<path d="m5 6 5 6-5 6m7 0h7"/>',proxy:'<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/>',provider:'<path d="M6 18a4 4 0 0 1-.5-8A6.5 6.5 0 0 1 18 8a5 5 0 0 1 0 10Z"/>',manager:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>'};
 const icon=(id,cls='')=>'<svg class="'+cls+'" viewBox="0 0 24 24" aria-hidden="true">'+(id==='brand'?'<use href="#tray-logo-mono"/>':icons[id]||icons.proxy)+'</svg>';
 const active=()=>root.dataset.route==='connection-map'&&!document.hidden;
 function data(){
  const known=scene!=='unavailable',running=scene!=='stopped',direct=scene==='direct',observed=['recent','fallback','multiple'].includes(scene);
  const nodes=[{id:'desktop',name:'Desktop 管理器',icon:'manager',hint:'状态、配置与进程管理',state:known?'管理可达':'状态未更新',facts:[['管理对象','本机 OpenCodex'],['管理接口',known?'已校验':'本次读取失败'],['采样时间',known?'14:32:10':'14:30:04（上次）']]},
   {id:'app',name:'Codex App',icon:'client',hint:'本机 · 当前来源',state:direct?'原生直连':observed?'最近有请求':'已配置',facts:[['连接目标',direct?'Krill · 国内直连':'OpenCodex 本地代理'],['路径来源',observed?'最近请求记录':'已保存配置'],['对话关联',observed?'模型配置与对话边界':'尚无请求记录']]},
   {id:'proxy',name:'OpenCodex',icon:'brand',hint:'127.0.0.1:10100',state:!known?'上次运行中':!running?'未运行':direct?'已绕过':'服务就绪',ghost:direct||!running||!known,facts:[['版本','2.84.0'],['运行状态',!known?'本次未确认':running?'运行中':'未运行'],['路径角色',direct?'当前来源使用直连':'本地模型请求代理']]},
   {id:'krill',name:'Krill',icon:'provider',hint:'国内直连 · Responses',state:scene==='fallback'?'本次请求超时':observed?'最近采用':'已配置',warning:scene==='fallback',model:'gpt-6.1-sol · 高 · Fast',facts:[['服务节点','国内直连'],['模型','gpt-6.1-sol'],['推理／速度','高 · Fast'],['连接探测','124 ms · 14:30:00'],['请求结果',scene==='fallback'?'超时，已转入备用渠道':observed?'成功 · 1.8 s':'尚未观察']] }];
  if(scene==='multiple')nodes.push({id:'cli',name:'Codex CLI',icon:'terminal',hint:'本机 · 终端',state:'已配置',facts:[['连接目标','OpenCodex 本地代理'],['请求记录','本例未观察']]});
  if(scene==='fallback')nodes.push({id:'backup',name:'NewApi',icon:'provider',hint:'备用渠道 · Responses',state:'回退成功',model:'gpt-6.1-sol · 高',facts:[['路径来源','同一请求的第二次尝试'],['请求结果','成功 · 2.6 s'],['回退原因','首选渠道超时']]});
  return {nodes,known,running,direct,observed,status:!known?'正在确认':running?'运行中':'未运行',motion:!known?'stale':running?'running':'stopped',source:!known?'上次快照 · 14:30:04':observed?'最近请求 · 14:32:08':'已保存配置 · 14:31:20'};
 }
 function edges(d){
  const lines=[{from:'desktop',to:'proxy',kind:'management',label:'状态与配置'}];
  if(d.direct)lines.push({from:'app',to:'krill',kind:'config',label:'直连 · 配置指向',bypass:true});
  else{lines.push({from:'app',to:'proxy',kind:!d.running?'warning':d.observed?'observed':'config',label:d.observed?'WS':'配置'});lines.push({from:'proxy',to:'krill',kind:scene==='fallback'?'warning':d.observed?'observed':'config',label:scene==='fallback'?'超时':d.observed?'HTTP':'配置'});}
  if(scene==='multiple')lines.push({from:'cli',to:'proxy',kind:'config',label:''});
  if(scene==='fallback')lines.push({from:'proxy',to:'backup',kind:'observed',label:'回退'});
  return lines;
 }
 function node(n){return '<button type="button" class="cm-node '+(n.ghost?'is-ghost ':'')+(n.warning?'is-warning':'')+'" data-cm-node="'+n.id+'" data-cm="node" aria-label="查看 '+n.name+'" aria-pressed="'+(selected===n.id)+'"><span class="cm-node-heading"><span class="cm-node-icon">'+icon(n.icon,n.icon==='brand'?'cm-brand':'')+'</span><strong>'+n.name+'</strong></span><small>'+n.hint+'</small><span class="cm-node-state"><i></i>'+n.state+'</span>'+(n.model?'<small class="cm-model-caption">'+n.model+'</small>':'')+'</button>';}
 function render(){
  const d=data(),find=id=>d.nodes.find(n=>n.id===id),graph= view==='graph';
  $('#cmStatus').innerHTML=d.status+'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg>';
  $('#cmRuntimeCaption').textContent=!d.known?'上次采样 14:30:04 · 本次读取失败':'本机 · OpenCodex 2.84.0 · 端口 10100';
  $('#cmSource').textContent=d.source;
  $('#cmViews').innerHTML=[['graph','连接图'],['list','列表']].map(([id,name])=>'<button type="button" data-cm="view" data-view="'+id+'" aria-pressed="'+(view===id)+'">'+name+'</button>').join('');
  $('#cmGraph').hidden=!graph;$('#cmList').hidden=graph;
  if(graph){$('#cmGraph').innerHTML='<svg class="cm-edges" aria-hidden="true"></svg><button type="button" class="cm-manager" data-cm-node="desktop" data-cm="node" aria-pressed="'+(selected==='desktop')+'" aria-label="查看 Desktop 管理器">'+icon('manager')+'Desktop 管理器</button><div class="cm-mainpath"><div class="cm-clients">'+node(find('app'))+(find('cli')?node(find('cli')):'')+'</div>'+node(find('proxy'))+node(find('krill'))+'</div>'+(find('backup')?'<div class="cm-fallback-row">'+node(find('backup'))+'</div>':'');}
  else $('#cmList').innerHTML='<table class="cm-table"><thead><tr><th>关系</th><th>路径</th><th>依据</th></tr></thead><tbody>'+edges(d).map(e=>'<tr class="'+([e.from,e.to].includes(selected)?'is-selected':'')+'"><td>'+({management:'管理',observed:'请求',config:'配置',warning:'异常'})[e.kind]+'</td><td><button type="button" data-cm="node" data-node="'+e.to+'">'+find(e.from).name+' → '+find(e.to).name+'</button></td><td>'+esc(e.label||'配置指向')+'</td></tr>').join('')+'</tbody></table>';
  $('#cmObservation').innerHTML=!d.known?'<strong>读取失败，保留上次连接信息</strong><span>最后成功采样 14:30:04</span>':scene==='stopped'?'<strong>配置指向本地代理，服务当前未运行</strong><span>实际请求未观察</span>':scene==='fallback'?'<strong>同一请求：Krill 超时 → NewApi 成功</strong><span>14:32:08 · 共 2 次尝试</span>':d.observed?'<strong>最近请求使用 Krill / gpt-6.1-sol</strong><span>14:32:08 · 成功 · 1.8 s</span>':'<strong>配置已指向'+(d.direct?'Krill 直连':'OpenCodex 本地代理')+'</strong><span>实际请求未观察</span>';
  renderDetail();syncFrame();requestAnimationFrame(draw);
  $$('[data-cm-scene]',document).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.cmScene===scene)));
  window.prototypePanel?.refresh();
 }
 function renderDetail(){const n=data().nodes.find(n=>n.id===selected),slot=$('#cmDetail');slot.hidden=!n;if(!n)return;slot.innerHTML='<div class="cm-detail-head"><h3>'+n.name+'</h3><button type="button" data-cm="close-detail" aria-label="关闭连接详情">×</button></div><p>'+n.hint+'</p><dl>'+n.facts.map(([k,v])=>'<div><dt>'+esc(k)+'</dt><dd>'+esc(v)+'</dd></div>').join('')+'</dl>';}
 function draw(){
  if(!active()||view!=='graph')return;
  const map=$('#cmGraph'),box=map.getBoundingClientRect(),w=map.clientWidth||box.width,h=map.clientHeight||box.height;if(!w||!h||!box.width||!box.height)return;
  const sx=box.width/w,sy=box.height/h,point=(id,side)=>{const el=$('[data-cm-node="'+id+'"]',map);if(!el)return null;const r=el.getBoundingClientRect();return {x:((side==='right'?r.right:side==='left'?r.left:r.left+r.width/2)-box.left)/sx,y:((side==='bottom'?r.bottom:side==='top'?r.top:r.top+r.height/2)-box.top)/sy};};
  const svg=$('.cm-edges',map);svg.setAttribute('viewBox','0 0 '+w+' '+h);
  svg.innerHTML=edges(data()).map(e=>{
   const a=point(e.from,e.kind==='management'?'bottom':'right'),b=point(e.to,e.kind==='management'?'top':'left');if(!a||!b)return '';
   let path,lx,ly;if(e.kind==='management'){path='M '+a.x+' '+(a.y+2)+' L '+b.x+' '+(b.y-5);lx=a.x;ly=(a.y+b.y)/2;}
   else if(e.bypass){const low=Math.max(a.y,b.y)+64;path='M '+(a.x+2)+' '+a.y+' C '+(a.x+38)+' '+low+' '+(b.x-38)+' '+low+' '+(b.x-4)+' '+b.y;lx=(a.x+b.x)/2;ly=low-8;}
   else{const mid=(a.x+b.x)/2;path='M '+(a.x+2)+' '+a.y+' C '+mid+' '+a.y+' '+mid+' '+b.y+' '+(b.x-4)+' '+b.y;lx=mid;ly=(a.y+b.y)/2-12;}
   const arrow=e.kind==='management'?'':'<path d="M '+(b.x-8)+' '+(b.y-3)+' L '+(b.x-4)+' '+b.y+' L '+(b.x-8)+' '+(b.y+3)+'" class="cm-wire is-'+e.kind+'"/>';
   const text=e.label,width=Math.max(32,text.length*(/[\u4e00-\u9fff]/.test(text)?8:5.4)+12);const label=text?'<g class="cm-wire-label"><rect x="'+(lx-width/2)+'" y="'+(ly-9)+'" width="'+width+'" height="18" rx="5"/><text x="'+lx+'" y="'+ly+'">'+esc(text)+'</text></g>':'';
   return '<path d="'+path+'" class="cm-wire is-'+e.kind+'"/>'+arrow+label;
  }).join('');
 }
 const frame=document.createElement('iframe');frame.className='cm-backdrop';frame.title='连接专题运行状态形象';frame.tabIndex=-1;frame.setAttribute('aria-hidden','true');
 const frameSource=new URL('../../../03-项目协作资料/01-协作包/2026-09-12-桌面管理器需求梳理与原型验证/01-需求分析/05-原型/候选/2026-09-28-Logo本体形变/index.html',document.currentScript.src);
 function syncFrame(){
  const effects=root.dataset.effects||'high',renderer=root.dataset.glowRender||'css',key=effects+'|'+renderer;
  // 懒加载：普通业务页面不为本专题额外创建动画实例。
  if(!active()&&!frameKey)return;
  if(key!==frameKey&&active()){const url=new URL(frameSource);url.search='?embed=1&layout=hero&effects='+effects+'&render='+renderer;frame.src=url.href;frameKey=key;ready=false;payloadKey='';}
  const payload={type:'opencodex-motion-preview',state:data().motion,theme:root.dataset.theme,active:active(),presentation:((host.clientWidth||880)<650?{size:88,padding:66}:{size:112,padding:76})},serial=JSON.stringify(payload);
  if(ready&&serial!==payloadKey){frame.contentWindow?.postMessage(payload,location.protocol==='file:'?'*':location.origin);payloadKey=serial;}
  host.dataset.active=String(active());
 }
 host.innerHTML='<div class="cm-note-anchor"><div class="proto-annotation" id="ann-connection-map-01" data-annotation-number="01" data-annotation-title="连接关系与现有光场搭配" data-annotation-category="设计探索 · 版本未定"><button type="button" class="annotation-marker" aria-label="原型注释 01：连接关系与现有光场搭配" aria-expanded="false" aria-controls="annotationPopover"><span>原型</span><span>01</span><span>＋</span></button><div class="annotation-source" hidden><p>独立模拟专题，未替换概览。复用概览既有 Logo 形变与光场，连接图使用内存示例；管理关系与请求路径分别展示。主连线静态，最近请求不是正在请求。样例不读取真实状态、不请求渠道、不改配置。版本与开发时机未定。</p></div></div></div><section class="cm-hero"><button type="button" class="cm-status" id="cmStatus" data-cm="runtime" aria-label="查看模拟运行详情"></button><p id="cmRuntimeCaption"></p></section><section class="cm-card" aria-labelledby="cmTitle"><div class="cm-card-head"><div><h2 id="cmTitle">连接关系</h2><small id="cmSource"></small></div><div class="cm-view" id="cmViews" role="group" aria-label="连接展示方式"></div></div><div class="cm-map" id="cmGraph"></div><div class="cm-table-wrap" id="cmList" hidden></div><div class="cm-legend"><span><i></i>最近请求</span><span><i class="cm-dashed"></i>配置指向</span><span><i class="cm-management-key"></i>管理</span><span class="cm-selection-hint">点击节点查看详情</span></div><div class="cm-observation" id="cmObservation" role="status"></div></section><section class="cm-detail" id="cmDetail" aria-label="连接详情" hidden></section>';
 $('.cm-hero').prepend(frame);
 const tool=document.createElement('div');tool.id='connectionMapDemoCard';tool.className='proto-card';tool.dataset.protoContexts='connection-map';
 tool.innerHTML='<div class="proto-note-title">连接关系 · 模拟效果专题</div><p class="pctl-hint">复用现有 Logo 和背景光；下方仅切内存场景，未替换正式概览。明暗、特效和软件尺寸沿全局评审条件。</p><div class="cm-demo-grid">'+Object.entries(sceneLabels).map(([id,name])=>'<button type="button" class="btn ghost" data-cm-scene="'+id+'" aria-pressed="'+(scene===id)+'">'+name+'</button>').join('')+'</div><p class="pctl-hint">入口 WS 与上游 HTTP 分别展示。管理线只表达 Desktop 的状态与配置管理；首版静态连线。所有时间、地址和结果均为示例。</p>';
 (document.querySelector('#protoStdCards .proto-group-body')||document.getElementById('protoStdCards')).appendChild(tool);
 tool.addEventListener('click',e=>{const b=e.target.closest('[data-cm-scene]');if(b){scene=b.dataset.cmScene;selected=null;render();}});
 host.addEventListener('click',e=>{const b=e.target.closest('[data-cm]');if(!b)return;const action=b.dataset.cm;if(action==='view'){view=b.dataset.view;render();$('#cmViews [data-view="'+view+'"]').focus({preventScroll:true});}else if(action==='node'){selected=b.dataset.cmNode||b.dataset.node;renderDetail();$$('[data-cm-node]').forEach(n=>n.setAttribute('aria-pressed',String(n.dataset.cmNode===selected)));if(view==='list')render();}else if(action==='close-detail'){const prior=selected;selected=null;renderDetail();$$('[data-cm-node]').forEach(n=>n.setAttribute('aria-pressed','false'));$('[data-cm-node="'+prior+'"]')?.focus({preventScroll:true});if(view==='list')render();}else if(action==='runtime'){selected='proxy';renderDetail();}});
 frame.addEventListener('load',()=>{ready=true;payloadKey='';syncFrame();});
 window.addEventListener('message',e=>{if(e.source===frame.contentWindow&&e.data?.type==='opencodex-motion-ready'){ready=true;payloadKey='';syncFrame();}});
 new MutationObserver(()=>{const now=active();syncFrame();if(now&&!activeLast)requestAnimationFrame(draw);activeLast=now;}).observe(root,{attributes:true,attributeFilter:['data-route','data-theme','data-effects','data-glow-render']});
 if(window.ResizeObserver)new ResizeObserver(()=>{syncFrame();draw();}).observe(host);
 window.addEventListener('resize',draw);document.addEventListener('visibilitychange',syncFrame);
 window.connectionMapPrototype={state:()=>({scene,view,selected,...data()}),setScene:id=>{if(sceneLabels[id]){scene=id;selected=null;render();}},draw};
 render();
})();
