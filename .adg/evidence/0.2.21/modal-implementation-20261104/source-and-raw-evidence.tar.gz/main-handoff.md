# POST-09 主线交接

本贡献：18 个实现文件、21 个测试文件，摘要见 owned-files.json；只改独占写集及对应测试。下面是排除消费者的原缺口与当前接入要求，不代表其最终所有者验收。

## 公共接入 API

UiDialog 的 actions 插槽提供 close；底部取消调用该函数，最终进入原 @close owner。header-actions 总在公共 X 左侧。beforeClose 支持同步/异步拒绝，busy 与兼容 hideClose 一起限制 X/Esc/原生cancel/backdrop/slot.close。不要把同一清理放到guard和@close执行两次。旧按钮直接调用本地关闭函数仍能绕过公共限制，必须迁移。

查看型只保留真实业务动作；没有动作或条件插槽全空时无footer。hideClose显示禁用X只是兼容，不算迁移完成。本贡献消费者已全部消除hideClose。专用宿主接UiDialog后删除自己的捕获阶段Esc/焦点循环/重复标题X。动态AppModal可直接用ModalContentSpec的mode:view/edit/confirm、busy、beforeClose，不必改stores/app.ts或types/ui.ts。

原生dialog Teleport到body。测试装tests/helpers/nativeDialog.ts的jsdom stub并查document.body里的dialog[open]，等nextTick/flushPromises后断言开关/焦点；不可继续把旧inline .modal当真弹窗。实际浏览器另由双引擎验证。

## 排除写集消费者

主线最新回报：全部 sync 组件已完成对应迁移，其回归正在运行。下表保留原审计接入要求供回归核对，不再将 sync 记作未实施。核心 CI 与四宿主形态见 ci-native-handoff.md。

| 路径（相对 apps/desktop/ui/src） | 所需动作/观察 |
| --- | --- |
| features/sync/ConnectionDialog.vue | 主线已移除常驻hide-close并接slot.close；继续验测试/保存busy同守卫、关闭晚回和Key清理。 |
| features/sync/ImportedConnections.vue | 主线已接slot.close；激活busy同守卫，取消不启用连接；候选读取失败/空/晚回属AC-021-06。 |
| features/sync/ModelTransfer.vue | 取消均改slot.close -> @close closePreview；只保留一次discardPendingFilePlans/清密码的清理。移除导出态动态hide-close；发布/采用完成结果删底部完成/关闭及空栏，保留重读等业务动作。busy真正写入期间同守卫。 |
| features/sync/ObjectScopeTree.vue | 对象详情为查看型，删常驻hide-close和底部关闭。主线已在改入；build捕获第5行UiButton未使用，请随删除底部按钮移除导入。 |
| features/sync/SyncResultDialog.vue | 移除常驻hide-close及底部关闭；保留重读/重试/核对/重新比较/打开目录。区分观察running回执与executing真正重试写入，仅后者按真实能力限制退出。 |
| features/models/ChannelsView.vue | 复制渠道取消改slot.close -> 原copySource=null；copyBusy限制全部退出。主线已接slot.close，需验取消不建草稿/不复用凭据。 |
| features/models/ChannelEditor.vue | 手动添加型号取消仍须slot.close；busy同守卫，退出不添加型号且保留外层渠道草稿。改名只归主线。 |
| features/models/ChannelModelTable.vue | 编辑明细和批量修改两处取消改slot.close，validating同守卫；X/Esc不提交行缓冲，仅明确加入草稿才改。 |
| features/models/AgentExecutionField.vue | Agent配置取消改slot.close并按busy禁用；嵌套ModelPicker先消费Escape，再返回选择执行模型触发点，X不保存共用设置。 |
| features/models/ModelPicker.vue | 取消改slot.close；允许读取中退出时勿滥用busy。确定选择独立；取消不采用选择，嵌套父窗口保持。 |
| features/models/SaveResultNotice.vue | 主线已将@close改为仅结束confirming并接slot.close。确认X/Esc/遮罩/取消只退出确认并续计，不调用later收整张通知；重启进行中同守卫，去自动聚焦由POST01负责。 |
| features/models/ChannelNodeSelect.vue | 主线检测UiDialog已接入；关观察不得stop/cancel测量、不自动选节点/保存；停止仍显式。结果晚回/改址由检测owner验证。 |
| routes/ModelsRoute.vue | 版本管理的取消当前只撤销内嵌删除，不等于退出；需明确取消删除语义或独立确认层。匹配预览/外部任务结果为查看，不加退出footer；检查匹配为业务动作。 |
| routes/OverviewRoute.vue | 运行详情/环境两处自有mask接公共宿主，删手写X和底部关闭，保留打开目录/环境指引。嵌套层Esc先消费，关观察不取消刷新/运行任务。 |
| routes/SettingsRoute.vue | 卸载宿主接公共X/焦点/退出；uninstallRunning让所有退出同closeUninstall守卫；结果删关闭/完成，保留真实重试/目录动作。 |
| App.vue | ui-fault-modal是自有alertdialog。主线改UiDialog(open=!!app.uiFault,title=界面出现异常,@close=app.clearUiFault)，删关闭提示，保留reloadUi重新加载界面。无须扩写全局CSS。 |
| app/useLifecycleController.ts | 官方恢复引导为查看/复制命令，可显式mode:view移除稍后处理退出footer；恢复前确认/生成备份仍confirm。保持异步摘要的modalStore.generation校验。 |
| features/extensions/components/ClientsPanel.vue | 历史cancelLabel=关闭由modalMode推导view，真实业务confirm/resolve/delete仍保留。业务意图不同须显式mode。 |

## 本贡献已落实的例外

- SelectorPreviewDialog：属本贡献，取消已接slot.close。busy解析当前草稿允许退出，saving才限制所有退出。父@close只退出预览，不能确认保存、取消真实保存或丢外层草稿。已有四通道消费者测试。
- UpdateCenter：确认页取消/主操作；查看和更新进度均无退出footer。安装/下载/备份可在后台继续，不能把session busy传给UiDialog busy。当前未传busy，业务按钮单独禁用；X不会重试/重启。
- RuntimeInstallDialog：安装未结束时统一busy，X禁用，Esc/原生cancel/遮罩消费但不退出；只有取消安装请求cancel_runtime_install。完成/普通失败为查看，无底部完成/关闭；脚本授权失败保留真实重试。
- BatchAgentDialog：关窗和卸载不再暗中stopGeneration；后台结果可恢复。仅停止检查取消，saving锁退出；保存结果无取消/空footer。
- ExternalTaskDialog：准备只读预览可关；明确复制激活grant期间busy同守卫。四通道消费者测试验证激活/剪贴板只执行一次。

## App.vue 的具体变更需求（已告知主线，未跨界编辑）

ui-fault-modal改UiDialog：open=!!app.uiFault，title=界面出现异常，@close=app.clearUiFault()；正文保留错误详情，actions只留reloadUi()的重新加载界面。删除关闭提示按钮；公共层承接X/Esc/遮罩及焦点，不要求改全局字号或全局CSS。

## 尚未完成的集成检查

owned-consumer-regression-final.log：28文件/256测试通过，无未处理异常。browser-results.json：双引擎24组流程/布局、30项几何检查通过，无pageerror；真实软件Vue组件+内存Tauri夹具，不是系统原生/真实事务验收。

当前build-final.log阻断为排除写集ObjectScopeTree.vue:5未使用UiButton；本贡献不改此文件。之前构建曾通过，最终须以主线同一源码重跑。全UI捕获ui-full-regression-second.log：22失败/1168通过，3未处理异常，涉及channel-node-select、model-save-feedback、model-save-result-flow、overview-mods、post01-save-notice、sync-connection-020、sync、workspace。主线并行迁移中，保留反例；该捕获不作最终关闭证据。

review:modal-native仍需macOS/Windows原生；浏览器WebKit不能代替。同步/检测/卸载/异常窗迁移后再统一完整UI/typecheck/build、必要后端及发布门。本贡献未关闭TASK或改共享DMD/IMP/清单。

系统原生选择器、官方页面自有窗口、AgentPanel等非模态助手、通知中心非模态面板本体按归属排除；本贡献只迁移通知中心清理确认。没有额度/未来功能，没有日常配置或日常Codex重启，没有git add/commit/push。
