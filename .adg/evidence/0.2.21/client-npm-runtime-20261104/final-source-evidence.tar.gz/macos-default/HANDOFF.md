# 正式 darwin-arm64 npm 默认入口增量

接口仍为 resolve_npm_native(launcher: &Path, expected_version: &str) -> ModelResult<PathBuf>。parent 在原始已绑定路径为 symlink、canonical 目标为 JS 时调用，须传原始链接路径；原生文件与普通 native symlink 继续由现有 owner 处理。模块不改 parent 接线、owner transport、保存/重启事务或其它产品文件；本轮未提交。

本次扩展针对 macos-native-20261104/default-runtime/README.md 已证实的当前默认入口缺口：上游 2.84.0 原始 resolver/settings 实际返回 npm/node_modules/.bin/codex；该链接需 Node 才能运行，系统-only PATH 实测 exit127。此前强制 native 的 actual 链不覆盖这个默认入口。本增量只将明确标准 npm link 关联到同包原生文件，不运行 Node 或 shell。

## 标准链接与来源边界

新增 Mac 分支只在正式 aarch64 架构处理 basename=codex 的入口。local 位置必须是 node_modules/.bin/codex，原始 readlink 字节必须恰为 ../@openai/codex/bin/codex.js；global 位置必须是 prefix/bin/codex，链接恰为 ../lib/node_modules/@openai/codex/bin/codex.js。链接目标先逐字核对，再检查 canonical 身份，绝不先 canonicalize 任意 wrapper 再把结果当合法来源。多余 ./、额外 ../、绝对链接、另一包、链接链、regular JS 和 shell wrapper 均拒绝。

两种链接由实际 npm bin-links/link-bins.js（top=false / top=true）在临时目录生成并读取，npm-macos-symlinks.json 为生成结果，macos-provenance.json/source-provenance.json 记录 npm 源文件摘要；local 与真实 default-runtime/run-context.json 中的 npmSymlink.link 一致。global 是已核验 npm 生成合同，未冒称用户日常 global 安装已操作。

HOME/tmp 等父目录、主包、JS、optional 包和 native 的其它 symlink 分量仍由原 checked_path 拒绝。fixture 和后续 actual agent 应从 canonical 临时根开始，避免 /tmp 到 /private/tmp 这种已知父级链接；本模块不放宽跨包边界来绕过它。

主包 name、bin、type、版本及完整官方 JS selector 摘要均核验；复用已证实的 e14fc83739c13c1074b12bd1acce4010c893c7f6fbfc1593b4a31d74cabb57af 合同。darwin-arm64 alias 要求 npm:@openai/codex@<expected>-darwin-arm64，同包 optional manifest 实际 name=@openai/codex、version=<expected>-darwin-arm64、os=[darwin]、cpu=[arm64]。require.resolve 对应的标准 hoisted/nested optional 包优先，只有不存在包候选时才使用主包内 embedded vendor；optional 有包但缺 native 时拒绝，不伪造 fallback。

多个 optional、外部 ancestor shadow、不明 exports、任何 x64 optional 平台包、embedded 回退中的 x64 native 都拒绝。当前只支持发布物实际使用的 thin 64-bit ARM64 MH_EXECUTE，核验 magic/cputype/filetype、load-command 上限/文件尺寸和执行权限；不接受脚本、x86/Rosetta、fat/universal、dylib、截断头或非 executable 文件。原生摘要只用于证据，不固定进生产；expected_version 仍与元数据逐项关联，不写死 0.166.0。

## 本轮验证

仅运行 tests/client_npm_runtime.rs 的 macos_default 过滤组，7 passed、0 failed、0 ignored、13 filtered out。原 Windows 13 项未重跑。tests 直接链接 parent 已注册的库模块。

- 正常合同：local/global × hoisted/nested optional，以及 embedded；真实官方 selector 的 optional 优先语义和缺文件拒绝。
- 有意义拒绝：非标准 link/绝对 link/规范化后等价却非标准 link、regular wrapper、跨包/额外 symlink、主/optional 版本和 alias 不一致、selector 修改、多个或 x64 包、Mach-O 格式/权限不符。
- actual-macos-selector.json：本地缓存官方 Codex 0.166.0 原生文件 SHA256=39acf979729dd290f9a24ee38b2914e036c91b65952872e28ae2a6b88a7db7c1，与原 actual probe 一致。四种代表布局中，产品 resolver 返回值与未修改官方 JS 的路径选择完全相同。
- 真实 JS 探针保留当前主机 darwin/arm64，截获 process.execve / child_process.spawn 只记录路径，不启动 native。它证明路径选择等价，不冒充实际产品 owner/producer/restart 链通过。
- windows-body-unchanged.json：从 3dfbab470 的 Windows 解析起点至 Ok(native) 返回的函数体逐字相同。
- windows-typecheck.json：新源码通过 MSVC x64 目标检查；只编译，没有重新执行 Windows 测试或 owner。
- verification.json：模块、测试、测试二进制与 Node 摘要，源码运行前后保持一致。OS 沙箱拒绝全部网络、日常用户树和 Keychain；只允许明确 public cache / fixtures / Node，HOME/work 使用 canonical 临时根。

普通合同测试使用明确标注的合成 Mach-O 头，未当作官方 native 证据；官方缓存测试单列并实际运行。没有访问 daily 配置/Key、没有 turn/start/exec、没有运行 npm link 或 native，也没有调用全局重启。

## 后续验收

本模块可供 parent 新 freeze；实际默认 runtime → 原生 config owner → producer → restart 的产品链仍由 actual agent 运行。此处不把 selector 等价、旧强制 native 链或 Windows thin trace 改标为新默认产品链完成。正式范围为 darwin-arm64；darwin-x64、fat/universal、pnpm/Bun 自定义链接和其它未知 wrapper 均未支持。

复现：cargo test --locked --offline --test client_npm_runtime macos_default --no-run，然后将绝对测试二进制、明确缓存 node_modules、Node 路径交给本目录 run-isolated.py --test-binary ... --public-root ... --node ...。runner 自带 macos_default 过滤，不重跑 Windows 13。
