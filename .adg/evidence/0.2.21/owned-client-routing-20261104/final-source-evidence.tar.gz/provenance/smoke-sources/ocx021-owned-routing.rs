//! External smoke helper: links the current production library without changing it.
use opencodex_desktop_lib::{
    infrastructure::runtime_executable::FixedRuntimeExecutable,
    modules::{model_config::config_file, test_sandbox},
    state::ProcessContext,
};
use serde_json::{json, Value};
use std::{collections::BTreeMap, path::PathBuf, sync::{Arc, Mutex}};

type Secrets = Arc<Mutex<BTreeMap<String, Vec<u8>>>>;
struct MemoryBuilder(Secrets);
struct MemorySecret { values: Secrets, account: String }
impl keyring::credential::CredentialBuilderApi for MemoryBuilder {
    fn build(&self, _: Option<&str>, service: &str, user: &str) -> keyring::Result<Box<keyring::credential::Credential>> {
        Ok(Box::new(MemorySecret { values: self.0.clone(), account: format!("{service}/{user}") }))
    }
    fn as_any(&self) -> &dyn std::any::Any { self }
}
impl keyring::credential::CredentialApi for MemorySecret {
    fn set_secret(&self, value: &[u8]) -> keyring::Result<()> {
        self.values.lock().unwrap().insert(self.account.clone(), value.to_vec()); Ok(())
    }
    fn get_secret(&self) -> keyring::Result<Vec<u8>> {
        self.values.lock().unwrap().get(&self.account).cloned().ok_or(keyring::Error::NoEntry)
    }
    fn delete_credential(&self) -> keyring::Result<()> {
        self.values.lock().unwrap().remove(&self.account).map(|_| ()).ok_or(keyring::Error::NoEntry)
    }
    fn as_any(&self) -> &dyn std::any::Any { self }
}
fn main() {
    keyring::set_default_credential_builder(Box::new(MemoryBuilder(Default::default())));
    let container = PathBuf::from(std::env::var_os("OCX021_CONTAINER").expect("explicit owned container"));
    assert!(container.is_absolute() && container.is_dir());
    assert!(test_sandbox::enabled());
    let manager = test_sandbox::resolve_data_root(&container.join("never-use-daily")).unwrap();
    assert_eq!(manager, container.join("manager"));
    let boundary = test_sandbox::resolve_boundary(&manager).unwrap();
    let home = container.join("official");
    let work = container.join("work");
    for p in [&manager, &home, &work] { test_sandbox::check_boundary(boundary.as_deref(), p).unwrap(); }
    let context = ProcessContext {
        runtime: FixedRuntimeExecutable::resolved(container.join("ocx")),
        working_directory: work,
        opencodex_home: home.clone(),
    };
    assert!(context.executable().unwrap().is_file());
    let before = config_file::snapshot(&manager, &home).expect("production snapshot");
    let mut policy = before.policy.clone();
    let channel = policy.channels.iter_mut().find(|c| c.connection.provider_id == "Krill-1").expect("old channel");
    let stable_id = channel.id.clone();
    let models_before = json!([channel.model_order, channel.discovered, channel.model_refs]);
    channel.label = "Krill".into();
    channel.connection.provider_id = "Krill".into();
    let request = config_file::SaveRequest {
        expected_file: before.policy_digest, policy, credentials: vec![],
        scope: Some(config_file::SaveScope { channel_id: stable_id.clone() }),
    };
    let result = config_file::save_with_context(&manager, &context, request);
    if let Err(error) = &result {
        println!("{}", json!({"entry":"config_file::save_with_context","success":false,"error":error}));
        std::process::exit(20);
    }
    let result = result.unwrap();
    assert!(result.changed);
    let after = config_file::snapshot(&manager, &home).unwrap();
    let channel = after.policy.channels.iter().find(|c| c.id == stable_id).unwrap();
    assert_eq!(channel.label, "Krill");
    assert_eq!(channel.connection.provider_id, "Krill");
    assert_eq!(json!([channel.model_order, channel.discovered, channel.model_refs]), models_before);
    let raw: Value = serde_json::from_slice(&std::fs::read(home.join("config.json")).unwrap()).unwrap();
    assert!(raw["providers"].get("Krill-1").is_none());
    assert_eq!(raw["defaultProvider"], "Krill");
    assert_eq!(raw["modelPickerOrder"], json!(["Krill/owned-routing-model", "Krill/owned-second-model"]));
    assert_eq!(raw["disabledModels"], json!(["Krill/owned-hidden-model"]));
    println!("{}", json!({
        "entry":"config_file::save_with_context", "success":true, "changed":result.changed,
        "stableChannelId":stable_id, "stableChannelIdPreserved":true, "modelIdentityPreserved":true,
        "providerBefore":"Krill-1", "providerAfter":channel.connection.provider_id,
        "sandboxRoot":manager, "sandboxBoundary":boundary,
        "processContext":{"executable":context.executable().unwrap(),"workingDirectory":context.working_directory,"opencodexHome":context.opencodex_home},
        "credentialBackend":"process-local memory; synthetic inline provider key"
    }));
}
