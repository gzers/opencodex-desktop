> 最终执行结果：43c6253b5 的真实生产 prepare/default/catalog/provider/rawModel/response 和 copy ack gate 已通过，见 [FINAL-43.md](FINAL-43.md)。下文保留准备/历史合同，不替代最终源身份。

> 已执行更新：最终 d20 实测见 [FINAL-D20.md](FINAL-D20.md)。目录 producer 成功，但暴露 live provider 未重载；发布门未过。以下保留冻结前准备合同，不代表当前仍在等待。

# true 路径 producer 组合证据：待最终冻结

**用户真实路径是保存→立即重启，即生产 sync_cache(true)。false 分支本来只重建缓存，保持原合同，不要求它生成目录，不改成会修改配置的 sync。此前把 false 的行为称为缺口是范围误判，已撤回。**

目前没有发现由现有静态源码即可断言的 true 目录 producer 缺失。135035 只证明手工绑定子项，不是本发布门完成。最终自动组合运行尚未执行，等待用户对 file_objects v4 补丁复核后的新 freeze/具体 commit；第一轮冻结核对在编译前停止，没有产物冒称同 SHA。

## 同 producer 的精确关系

| 路径 | 实际调用 | 差异与覆盖边界 |
| --- | --- | --- |
| Rust sync_cache(context,true) | 绑定实际 runtime、本机证明后读取 owned token；Management::restart_codex 发空 POST /api/system/codex-restart | 不经过 sync-cache；必须保留身份校验与重启结果守卫 |
| 官方 runCodexRestart.defaultSyncCatalog | syncModelsToCodex(livePort,undefined,null)，undefined 触发 loadConfig() 默认值 | 生成结果只折叠为 catalogWritten 或 cacheSynced，然后才做 OS 进程退出/桌面重启 |
| 官方 POST /api/sync | readRuntimePort(process.pid) 取得实际端口，loadConfig()，syncModelsToCodex(runtime.port,config,null) | config 与端口来源等价；额外返回详细结果、同步其它已启用集成、附加只读 stale hint，不执行退出/重启 IO |
| 共同 producer | syncModelsToCodex → refreshCodexModelCatalog → syncCatalogModels，再 injectCodexConfig | 真实的目录 gather、配置/所有权校验、catalog commit/cache 与注入均不替换 |

API 路径足以证明 true 重启前置的目录生成、加载和路由。它不单独证明 Rust true 动作被调度、HTTP/身份守卫或桌面退出重启，需与生产 Rust true 路由测试组合；GUI 仍独立报告。API fan-out 在本夹具中只开启 Codex，Grok/Claude 等明确关闭；stale hint 可能只读探测进程，不能把它误称为重启或通过它终止日常进程。

synced=false 本来可以表示目录无变化；不能据此把生产重启成功判定改成错误。最终证明使用确实发生改名的输入，要求 producer 的 applied/ok、catalogWritten=true、refreshOutcome=committed，以及真实新客户端目录结果；不会靠 synced 的真假替代客户端加载。

## 一次最终运行的脚本

收到新 freeze 后在代码根执行，FINAL_CORE_SHA 必须替换为用户确认的具体提交：

    python3 test/smoke/ocx021-owned-routing.py --run --automatic-chain --seed-installed-fixture --source-freeze-head FINAL_CORE_SHA

自动模式拒绝复用旧 build。构建前核对 HEAD，编译前后核对实际生产源码摘要；本轮只构建一次 helper 和 tests。所有产物在新的系统临时根，生产源码和其它测试保持只读。运行结束重新核对源码并否决漂移身份。

1. Seatbelt 合成读/端口拒绝探针先通过，才启动官方命令。HOME/CODEX_HOME/SQLite/XDG/TMP/work/Node/Codex 入口全部固定为本次临时路径；不会透传宿主凭据。服务/客户端只放行两个明确 loopback 端口。
2. Rust helper 直接链接冻结生产库，执行真实 save_with_context。另将现有 cache_refresh_tests.rs 原样按绝对路径注册到 helper test target，链接同一生产库。该文件所有重启 HTTP 都指向它自己构造的 attested 本机 fixture，不连接真实官方全局重启端点。单独测试进程仅放行 loopback 随机测试端口。
3. 用户已授权的旧安装文件夹具：改名前在临时 home 写 v1 service-state 和相符 plist；字段来源为官方 state-record.mjs/service-manager-probe.ts。只写文件，不注册/启动/修改/停止 launchd job；此夹具不代表拥有日常 job 或独立 OS 服务命名空间。原始 native 模板来自实际 Codex debug models --bundled。
4. Codex 集成保持开启。启动未改动的官方 OpenCodex，要求 startup 自己生成旧 Krill-1 catalog 与客户端配置；不调用 manual-catalog sidecar。用真实 Codex app-server model/list 验证旧前缀，关闭仅本次 owned app-server，保持官方服务运行。
5. 真实保存 Krill-1→Krill 后，只由 attested owned runtime 的 POST /api/sync 触发上述共同 producer。读 token 之前先 HMAC 校验 runtime 证明；只发空 body，不导出或归档 token。不调用 false sync-cache、备用 sync、手工目录生成或任何全局重启路由。
6. 要求 API 返回 applied/ok、真实 catalog commit 且目录字节改变；再新开官方 Codex app-server，验证 Krill/原始ID 存在、Krill-1/ 消失。只有此步通过才执行一次 Codex exec→官方 OpenCodex→本机 Responses 夹具往返。
7. 回收仅本脚本持有的进程组，核对端口关闭，保留来源、源码/二进制摘要、RPC、HTTP 回执和 local wire。机器结果区分 automaticDirectoryGatePassed、trueRouteProducerCompositeVerified、desktopGuiVerified=false；脚本不替主线关闭整版 releaseGate。

## 隔离前置的已知实况

未 seed 的官方启动曾真实拒绝 service-home：launchd has a job loaded but its plist is missing（run-20261104-134338）。Bun homedir 和 HOME 已是临时 home；OS 用户域同名注册无法靠 HOME 隔离。没有读取日常 plist/配置/凭据，也没有修改或重启服务。

本次允许的旧安装文件夹具只作用于测试临时根，是否被该发布物准入须以最终真实输出为准。如果仍拒绝，将保留原始 409/拒绝原因并停止，不冒造成功，也不放开日常文件访问。可行的后续安全路径是独立 OS 用户/VM；或者在 test-only driver 中只替换服务/进程枚举、退出/重启 IO，保留真实 default syncCatalog 及其文件/目录 producer，明确披露 seam。当前准备脚本没有采用后者，也不把未运行的方案当证据。

## 冻结记录与交接

第一轮观察 HEAD c32917d76603139850238b75da93afac33563d2d；15 份旧 source-final 摘要在编译前出现 file_objects 格式补丁差异，用户随后明确撤销该轮最终运行、等待新 freeze。核对记录见 freeze-check-before-format-v4.json，finalBuildStarted=false。后来再读到的差异均只记录，不开始编译。

此前 135713/135947 是冻结前的并行编译/身份漂移，不计最终证据。135035 的手工子项与来源快照保留，不重放它来替代自动门。最新脚本和 hash 在 prepared-true-producer/、automatic-chain-pre-freeze.json；当前仅 Python AST 静态检查通过，未宣称新脚本运行通过。
