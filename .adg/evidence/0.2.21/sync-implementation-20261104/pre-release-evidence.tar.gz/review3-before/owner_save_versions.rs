//! Write-ahead content receipts for owners with an existing transaction lock.
//! Lock order: owner -> receipt -> versions. Replay only reads bounded bytes;
//! no closure here may acquire an owner/model lock or manufacture a clock.
use super::super::{schema::*, store::sha256};
use super::{record_at_validated, SaveState};
use crate::{
    infrastructure::{atomic_write::atomic_write, locking::TargetFileLock},
    modules::backup::safety,
};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
#[derive(Clone, Copy)]
pub enum Owner {
    Preferences,
    Templates,
    Extensions,
}
impl Owner {
    fn name(self) -> &'static str {
        match self {
            Self::Preferences => "preferences",
            Self::Templates => "templates",
            Self::Extensions => "extensions",
        }
    }
    fn file(self) -> &'static str {
        match self {
            Self::Preferences => "manager-state/preferences.json",
            Self::Templates => super::super::schema::LIBRARY_PATH,
            Self::Extensions => crate::modules::extensions::projection::CONFIG_RELATIVE_PATH,
        }
    }
}
#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Receipt {
    before: SaveState,
    after: SaveState,
    before_file: Option<String>,
    after_file: String,
    saved_at: String,
}
fn path(root: &Path, owner: Owner) -> ModelResult<PathBuf> {
    let path = root
        .join("manager-state/content-save-events")
        .join(format!("{}.json", owner.name()));
    safety::check_path(root, &path, true)?;
    safety::check_path(
        root,
        &crate::infrastructure::locking::lock_path_for(&path),
        true,
    )?;
    Ok(path)
}
fn digest(root: &Path, owner: Owner) -> ModelResult<Option<String>> {
    let path = root.join(owner.file());
    safety::check_path(root, &path, true)?;
    if !path.exists() {
        return Ok(None);
    }
    Ok(Some(sha256(&safety::read_file(&path, 16 * 1024 * 1024)?)))
}
pub struct Prepared {
    root: PathBuf,
    owner: Owner,
    path: PathBuf,
    _guard: TargetFileLock,
}
pub fn begin(
    root: &Path,
    owner: Owner,
    before: &SaveState,
    after: &SaveState,
    bytes: &[u8],
) -> ModelResult<Option<Prepared>> {
    recover(root, owner)?;
    if before == after {
        return Ok(None);
    }
    let path = path(root, owner)?;
    let guard = TargetFileLock::lock(&path)?;
    let receipt = Receipt {
        before: before.clone(),
        after: after.clone(),
        before_file: digest(root, owner)?,
        after_file: sha256(bytes),
        saved_at: chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Nanos, true),
    };
    atomic_write(&path, &serde_json::to_vec(&receipt)?, 0o600)?;
    // Keep the receipt guard through the business write. A concurrent reader
    // cannot discard a staged intent while the owner is still writing it.
    Ok(Some(Prepared {
        root: root.into(),
        owner,
        path,
        _guard: guard,
    }))
}
pub fn commit(prepared: Option<Prepared>) -> ModelResult<()> {
    if let Some(prepared) = prepared {
        replay(&prepared.root, prepared.owner, &prepared.path)?;
    }
    Ok(())
}
/// Called after the owner's exact readback, or at its next read/save entry.
/// A pre-write failure/compensation or later external content discards the
/// obsolete intent, while exact applied bytes replay their original receipt.
pub fn recover(root: &Path, owner: Owner) -> ModelResult<()> {
    let path = path(root, owner)?;
    if !path.exists() {
        return Ok(());
    }
    let _guard = TargetFileLock::lock(&path)?;
    if !path.exists() {
        return Ok(());
    }
    replay(root, owner, &path)
}
fn replay(root: &Path, owner: Owner, path: &Path) -> ModelResult<()> {
    let receipt: Receipt = serde_json::from_slice(&safety::read_file(path, 8 * 1024 * 1024)?)?;
    let expected = Some(receipt.after_file.as_str());
    if digest(root, owner)?.as_deref() != expected {
        std::fs::remove_file(path)?;
        return Ok(());
    }
    record_at_validated(
        root,
        &receipt.before,
        &receipt.after,
        &receipt.saved_at,
        || {
            if digest(root, owner)?.as_deref() != expected {
                return Err(invalid(
                    "content_version_changed",
                    "原保存文件在版本提交前改变",
                ));
            }
            Ok(())
        },
    )?;
    if digest(root, owner)?.as_deref() != expected {
        return Err(invalid(
            "content_version_changed",
            "原保存文件在回执清理前改变",
        ));
    }
    std::fs::remove_file(path)?;
    Ok(())
}
