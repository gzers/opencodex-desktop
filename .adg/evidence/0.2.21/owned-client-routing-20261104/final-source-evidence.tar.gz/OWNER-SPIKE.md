# 候选真实 owner 接线 spike：可行，非现产品验收

**结论：用户提出的两处 owner 接入已实际跑通。bodyless capability reload(new) + secret-free no-op PUT /api/providers 可在原 config.json 字节/摘要/inode/mtime 均不变时完整接纳新 live roster/default、移除旧 provider；Codex config/value/write CAS 可更新当前默认选择，新客户端无 model 覆盖加载新标识并真实路由到 Krill/原始型号。**

这是 test-only 候选接线验证，**candidateOnly=true、productAcceptancePass=false、releaseGatePassed=false**。没有修改或编译当前产品源码。此前 live provider 路由失败和当前 model 残留的原始证据均保留，不追改为通过。

[机器结果：17 项候选检查通过](owner-spike-result.json)，[原始运行 145952](run-20261104-145952/result.json)。复用唯一 d20ac7f9ca73f155a77d536618ab8ba3d6b32da3 的已验证保存 helper（二进制 SHA 匹配原 142530 构建）。观察到工作区 HEAD=9f91f755addc450f87d84342df18de1ee471afaf，仅作上下文，不冒称 spike 链接了该提交的新产品实现。

## 原始事实

| 步骤 | 实际结果 | 证据 |
| --- | --- | --- |
| 真实保存改名 | 实际 d20 save_with_context；磁盘仅有 Krill/default=Krill，稳定身份保持 | [保存回执](run-20261104-145952/production-save.stdout) |
| owner 前 live | providers=[Krill-1]，default=Krill-1，复现原缺口 | [GET /api/config](run-20261104-145952/live-before-owner.json) |
| 单渠道真实 reload | HMAC capability 空 POST /api/providers/reload，HTTP200；live=[Krill-1,Krill]，default 仍旧，证实单次 reload 不足 | [reload](run-20261104-145952/reload-new-provider.json)、[之后 live](run-20261104-145952/live-after-single-reload.json) |
| no-op batch owner | safe DTO 仅取已保存磁盘 providers 的集合和磁盘 default；baseline==next；空密钥 DTO，PUT /api/providers HTTP200 | [请求](run-20261104-145952/noop-roster-owner-request.json)、[回执](run-20261104-145952/noop-roster-owner.json) |
| live 完整接纳 | 只剩 providers=[Krill]，default=Krill；旧 live provider 已删除 | [GET 读回](run-20261104-145952/live-after-batch-owner.json) |
| 原保存配置未改写 | 保存后、reload 后、PUT 前后字节一致，SHA256/inode/mtimeNs/size 一致，后续 producer 与本地请求后再次字节核对一致 | [原始 no-op 证明](run-20261104-145952/disk-noop-proof.json) |
| 官方目录 producer | 真实 POST /api/sync，applied、committed；无手工目录生成 | [producer 回执](run-20261104-145952/official-producer-after-owners.json) |
| 默认 model owner | 实际 config/read 的 user 层 origin.file/version，config/value/write CAS 将旧值更新为 Krill/owned-routing-model；status=ok、overriddenMetadata=null | [实际请求](run-20261104-145952/actual-cas-owner-request.json)、[结果](run-20261104-145952/actual-cas-owner-result.json) |
| CAS 重读/冲突 | config/read 值和版本匹配写回；重放旧版本欲写旧值，真实 owner 返回 configVersionConflict，文件字节未变 | [重读](run-20261104-145952/config-read-after-cas.json)、[拒绝](run-20261104-145952/stale-cas-rejection.json) |
| 新客户端默认一致 | 全新官方 Codex app-server，config/read=model/list/thread/start；不传 model 或 config 覆盖，默认为 Krill/owned-routing-model，新目录无 Krill-1 | [新 RPC](run-20261104-145952/codex-after-owners.json)、[无覆盖默认线程](run-20261104-145952/fresh-default-thread.json) |
| 原始型号有效路由 | 官方 Codex exec 没有 --model；唯一 POST 到本机夹具，model=owned-routing-model、合成认证匹配；Codex 消费固定返回，exit0 | [exec](run-20261104-145952/default-model-local-turn.stdout)、[终点请求](run-20261104-145952/fixture-requests.json)、[最终消息](run-20261104-145952/owner-spike-last-message.txt) |
| 实际选择身份 | 官方 usage.provider=Krill，resolvedModel=owned-routing-model，routeKind=explicit-provider；排除默认渠道误回退 | [真实路由日志](run-20261104-145952/actual-owner-routing-usage.json) |

磁盘配置 SHA256 始终为 f17ed3cc230b49494ed7e69446b1a6d955772d8057bff98959862eed300e48be，inode=416183654，mtimeNs=1793775598692025021。endpoint 返回没有顶层 changed 字段；“changed=false 分支”由 baseline==next、原始文件身份完全不变和已核对的发布物实现共同证明。回执 catalogRefresh.changed=true 指目录实际改变，不能把它误解为 config.json 被写入。

## DTO 与 owner 合同

上游 2.84.0 provider-routes.ts:1038-1140 严格要求请求根仅 baseline、next；两者各仅 defaultProvider、providers。它将 baseline 与磁盘 providerEditorConfigDTO 深比较；解析/并发/目的地校验不放宽。no-op 分支虽然不持久化 candidate，后续仍真实调用 adoptProviderEditorCandidate(config,outcome.value.config)、reconcile、清缓存和 convergeCodexCatalog。

实际 GET /api/config 是 live safeConfigDTO，单 reload 后同时包含新旧两行，default 也仍旧。因此不能原样 round-trip 整个 GET 来替换磁盘：本 spike 用保存后磁盘 provider 键集限定行、用已保存磁盘 default，行值来自 GET 新行。仅移除明确的 hasApiKey、hasHeaders、initialModelSelection、xaiResponsesOptInState；本夹具实际出现并删除的是前两项，[DTO 来源记录](run-20261104-145952/batch-dto-provenance.json)。未做未知字段任意过滤，若 parser 拒绝会保留实际错误并停止。

HTTP PUT body 中无 apiKey、apiKeyPool、headers、access/refresh token 或合成 Key 值；reload 请求不传 provider 对象/Key，只使用绑定 nonce、method/path、provider 名、PID、port 和 10 秒 expiry 的 one-shot HMAC capability。每次 owner 调用先核验 runtime 本机证明再读取临时 token，期间 runtime record 不变；token/capability 值未归档。

## 主线可采用的最小接线顺序

1. 真正保存完成，保留 expected 磁盘摘要及 old→new provider 映射。绑定实际官方运行身份；先 capability reload(new)，让 safe GET 提供新行。不将单 reload 当完整改名收口。
2. safe GET 新行经严格 DTO 投影，限定已保存磁盘完整 provider 集合/default，形成 baseline==next。调用 no-op batch owner，检查 HTTP/JSON/目录权威结果，并重验原保存磁盘摘要和 live roster/default。GET 全量旧行不可直接回写；密钥/headers 仍由官方 owner 从盘内保留。
3. 当前 Codex model 若完整 provider 段引用旧标识，使用实际 config/read origin/version，走官方 config/value/write CAS 到对应来源文件；检查 status=ok、未被覆盖、读回版本与值。漂移不得无条件重试覆盖。本 spike 的 stale version 确实被原 owner 拒绝。
4. 真正新客户端不加 --model、不加 config override，检查当前默认/model list/thread start 一致，再验证新 provider、原始型号、目的地/认证和响应消费。本候选已经在本机夹具完成这个闭环；生产重启调度与错误恢复仍需主线实现并验收。

保存已落盘后 live 同步或 CAS 可以失败；这是跨两个 owner 的部分完成问题，不能把 owner 任一返回 200 当整体成功。主线需明确失败文案、重试/补偿、事务身份与重启提示的时机；no-op PUT 的服务端 baseline 是公开 DTO，原始文件摘要的外部复核不能被省略。此 spike 不宣称解决并发时所有密钥变化/全部 rollback 合同。

## 覆盖与边界

只实测一个通用 key-auth openai-responses 渠道、根 user config 当前 model、OpenCodex 2.84.0、Codex 0.166.0。canonical/OAuth/保护来源、多渠道、真实 Keychain/Key 池/headers=true、profiles/managed/project 配置层未由本 spike 覆盖；已有核心回滚/凭据证据独立。成功不降低 DMD，也不外推其它上游版本。

没有运行产品真 sync_cache(true) 的全局重启 endpoint，没有 OS 全局 kill，没有服务重启或日常客户端操作。启动和退出仅本次 owned 官方进程组。所有状态临时 HOME/CODEX_HOME/SQLite/XDG/TMP/work；外网与真实用户树被 OS 沙箱拒绝，数据 HTTP 只放行两个明确本机端口。协调锁仅放行新临时 CODEX_HOME 摘要命名的独占新文件，已在进程退出后精确删除。owned 两端口均 ECONNREFUSED；[清理](run-20261104-145952/owned-coordinator-cleanup.json)。

旧 model 只在改名前作为当前用户选择 fixture seed；改名后 config/catalog 只由上述真实 owners 写入。全部合成凭据/返回/用量由本地夹具提供，不请求模型供应商或 WebDAV。

## 可复现来源

代码根新 smoke：test/smoke/ocx021-owned-routing.owners.py。依赖本组主 harness 与 coordinator old-installation 模块。原运行全部源码按运行时 hash 精确归档于 run-20261104-145952/source/，发布 owner 源摘要在 owner-source-manifest.json；原保存 helper 来源和 hash 在原 142530 及当前 result 中。

在代码根运行：

    python3 test/smoke/ocx021-owned-routing.owners.py --immutable-build ../governance-main/.adg/evidence/0.2.21/owned-client-routing-20261104/run-20261104-142530 --immutable-core d20ac7f9ca73f155a77d536618ab8ba3d6b32da3

命令不会编译，也不会将当前工作区产品源码冒称为已链接。旧临时构建回收后，应由主线在新冻结身份重新构建 helper 并保留来源；不能临时伪造 binary hash 继续。

本 worker 仅新增指定 smoke 与本证据，没有改产品代码、原生脚本/CI、其它测试、治理状态或执行 git add/commit/push。现产品两项失败结论保持，候选通过单独供主线决定接线。
