# macOS 0.2.20 → 0.2.21 OTA 准备

状态：prepared-awaiting-parent-publication。真实 OTA 尚未执行，不能计为通过。当前没有父级021 beta发布通知/source SHA，不启动旧 app、不查询 beta。

新 driver：代码工作树 test/smoke/ocx021-macos-ota.py；只读进程 monitor：ocx021-macos-ota.swift；使用说明：ocx021-macos-ota.md。现有 native.py/.swift 不改。

| 独立准备项 | 结果 |
| --- | --- |
| 原封020发布 archive 摘要/旧公钥验签 | pass |
| b175/0.2.20原 app、deep strict seal、逐文件复制 | pass |
| AX/capture权限与helper编译 | pass |
| 系统拒绝直连、允许本轮loopback隧道端口 | pass |
| 缺父级发布输入禁止execute | pass |
| 本地隧道拒绝供应商、伪GitHub域名与非443端口 | pass |
| archive路径穿越拒绝 | pass |
| 真实020→021下载/安装/自动重启/同进程读回 | 待父级通知后执行 |

[成功准备回执](ocx021-mac-ota-15aafede-aec9-4c5a-9245-26054a0d8b6e/report.json) · [run-context](ocx021-mac-ota-15aafede-aec9-4c5a-9245-26054a0d8b6e/run-context.json) · [后续执行输入合同](ocx021-mac-ota-15aafede-aec9-4c5a-9245-26054a0d8b6e/execution-contract.json) · [九项离线安全检查](offline-safety-checks.json) · [准备汇总/进程审计](preparation-summary.json)

固定旧版来自已公开0.2.20/b175；archive SHA-256 8fe307fe2f5daaa87c41abbcccc38ef7db346cd5e88ee1456d3285bfb1d8d0f9；EXE SHA-256 544de246de1a498b8c681c0bd6ce254c7043ffe4b5fe754d67d3477a8fe4370b。已用旧来源公开公钥验签，不读取签名secret。

执行设计要求旧UI两次真实保存和精确前像；生产beta更新器检查/下载/验签/安装；整包等于实际发布原签名载荷；只点击生产重启后，在同一自动新PID核验继承根/新source并读回全部业务摘要。禁止二次脚本启动代替读回，不重签、不改二进制、不假IPC。父级负责021最终all/overview，本driver不重复。

网络是仅转发GitHub443的真实TLS CONNECT，不终止TLS、不替换响应、不提供假manifest。候选OS sandbox只允许访问本轮loopback tunnel；真实vendor/sync直连禁止。准备只运行本地拒绝检查，没有发出GitHub/beta/供应商请求。

准备历史原件保留：57b6是系统Python3.9缺少tar filter关键字；008f是Seatbelt要求localhost而不接受127.0.0.1 host字面量；96e已通过主要准备，后续只读monitor离线检查发现Foundation路径别名，15aa改用physical realpath并完整准备通过。它们均未启动app、未执行OTA。

所有准备子轮均无owned app进程；daily80916保持运行，未发送信号。仅新增允许的ota.py/.swift/.md和本证据目录；未提交、推送、发布或读取日常配置/凭据。

下一步只等待父级明确发布通知、最终source SHA、release ID/archive SHA及原tar.gz/.sig；见执行输入合同，不以当前准备回执代替实际OTA。
