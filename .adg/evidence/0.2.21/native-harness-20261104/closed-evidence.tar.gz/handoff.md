# 0.2.21 Windows 原生验收驱动交接

最终稳定状态见 final-stable-handoff.md / final-stable-source-manifest.json；已修复后续发现的 query、OTA、offline-drop 旧宿主依赖并实际接入安装后 ready 门，以下首轮与 followup 记录保留历史，不代表当前未完。

后续安装/恢复/路径宿主补齐、剩余 CI/release 旧选择器及 ready WebDAV 门，见同目录 host-followup-handoff.md；最终追加回归见 host-followup-node-contracts.json。首轮证据保留为历史记录。

实现根：/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes，分支 codex/0.2.21-fixes。证据位于 docs/governance-main。本次只改已分配的 smoke 驱动与测试；DMD021/IMP29 保持 in_progress。没有暂存、提交、推送、触发 CI 或发布。

本地宿主是 macOS arm64，未执行 Windows EXE、PowerShell、WebView2 或真实 Tauri 后端。Node 契约结果见 node-contracts.json / node-contracts.log；它们使用普通 Node、V8 Inspector、临时文件和本机 loopback CDP 模拟，不作为 Windows 原生通过证据。最终文件摘要见 source-manifest.json。

| 路径（相对实现根） | 接口与归属 |
| --- | --- |
| test/smoke/windows-model-ui.mjs | verifyWindowsModelUi(call, output, facts, expected) 原接口保留；新增 nativeModelUiContract(version) 与 confirmNativeTemplateDefault(driver, version)。0.2.21 使用 dialog.app-modal-dialog[open] 和标题栏 X；0.2.20 保留 .modal-mask 与旧关闭入口。 |
| test/smoke/windows-ui-alignment.mjs | 原参数对象新增 publicDialogs；021 核验 sync-connection-dialog 的原生标题、唯一 X 和取消/保存操作顺序。 |
| test/smoke/windows-021-probes.mjs | verifyWindows021Probes({call,evaluate,wait,click,invoke,output}, facts, expected)。只接受准确 0.2.21、Windows、已激活且保存值一致的不可变 sandbox 根及内部 OPENCODEX_HOME。 |
| test/smoke/windows-021-observer.mjs | observe021Ipc(driver) 使用非暂停 V8 函数断点，只记录真实 invoke 的命令名；以真实 app_about 自检，检查 invoke 身份保持，结束移除断点与观测对象。另含纯 DOM/真实浏览器时钟观测器。 |
| test/smoke/windows-native.ps1 | 原前台 EXE、进程令牌、SHA-256 和完整源 commit 核验保留；向 windows-webview.mjs 传入它自己创建的 taskSandbox，使本次新增探针在原生窗口验收流程也必跑。 |

调用路径为 windows-startup.ps1 / windows-native.ps1 → windows-webview.mjs → verifyWindowsModelUi → 原有原生键盘/内层菜单检测 → verifyUiAlignment → 仅准确 0.2.21 必跑 verifyWindows021Probes。021 的 nativeModelKeyboardChecksRequired 仍为 true。新版不存在静默跳过探针的选项；旧 020 升级包不导入新行为探针。windows-webview、windows-startup、workflow、发布与 OTA 脚本均未修改。

新增探针的实际行为：

- 渠道改名：生产 model_file_save 建立两个停用、纯合成 Key 的渠道；仅在已核对根的真实 config.json 写入默认渠道、交错顺序及不应替换的 opaque 字段夹具，再用生产 snapshot 读回。经真实输入、返回保留、单渠道保存，验证完整 JSON 的精确迁移，稳定 channel.id、默认渠道身份、渠道/型号顺序、节点、规则、完整带斜杠型号、所有 Key 与相邻前缀渠道保持。验证一份普通精确备份和一份改名恢复目录中的精确 pre/post image，成功后不能有 pending journal；全页 reload 后再次读回 Key 与顺序。
- 保存通知：不改变计时器和时间。先验证保存通知不抢当前焦点，真实消耗约两秒后依次打开重启确认，分别由标题 X、真实 CDP Esc、取消按钮、cancel 事件、真实遮罩鼠标退出。每次保持至少 1100ms 验证暂停，退出后不手动移开焦点即须续计，通知身份与剩余比例不能重置。按真实 WebView 时钟扣除暂停段后验证八秒预算（允许观测调度误差：7950–8500ms），自动收起不能抢页面焦点。绝不点击确认重启；IPC 名称回执拒绝 refresh_cache 和任何非许可副作用。
- 节点检测：只点列表“检测”入口打开观察，不点“一键检测”或节点检测。实际几何须在视口居中，标题唯一启用 X，无 footer，所有节点为“未检测”。验证 X/Esc/cancel/遮罩退出、真实鼠标来源焦点归还、Tab/Shift+Tab 圈定；真实 IPC 记录中不得出现测量/发现命令。config 与备份集合须保持。
- WebDAV：仅在后端确实无连接、空候选的 startup sandbox，通过生产 save_sync_endpoint 保存 HTTPS .invalid 地址、独立目录、合成账号/密码；Windows 凭据由既有 credentials.rs 写 sandbox 内 DPAPI 文件，不调用系统钥匙串，不发送测试/同步请求。实际 endpoint 文件和后端 revision 均读回。全页 reload 后核对生产 sync store 为 configured、没有检测 observation，以及真实连接设置内容、空密码框、取消副作用与候选入口隐藏。空候选必须先出现实际异步组件加载 DOM 再消失，避免把尚未导入的组件判成空列表。

WebDAV 概览的显式边界：ready 原生环境必须实际渲染“已配置 · 未检测”，线上版本不画状态点。无运行环境的 startup sandbox 会显示真实三项环境准备门禁并隐藏全部概览卡片；此时只读核对生产 Pinia 状态与后端 revision，同时实际验证同步页连接入口及空候选 DOM。证据写明 environment-gated 和“概览文案仍需 ready 原生环境”，不注入环境、不伪造后端连接成功、不把未呈现的概览文案记为已验证。native021-behavior.json 的 limitations 保留这个边界。

测试命令在实现根运行（不触发 CI）：

~~~sh
node --test test/smoke/windows-cdp.test.mjs test/smoke/windows-model-ui.test.mjs test/smoke/windows-ota-channel.test.mjs test/smoke/windows-ota-fixture.test.mjs test/smoke/windows-ui-alignment.test.mjs test/smoke/windows-021-probes.test.mjs test/smoke/windows-bundle-identity.test.mjs
~~~

待主线在真实 Windows runner 执行：

1. 先把全部已审查的源码形成实际构建身份，使用该 EXE 的完整 40 位源 commit、EXE SHA-256 与原进程令牌准入，不复用本地工作树 HEAD 冒充已构建身份。
2. 继续既有 startup / installer / 原生窗口验收入口；无需新增 workflow 或开关。示例参数：windows-startup.ps1 -Executable <完整EXE路径> -Node <node.exe完整路径> -OutputDirectory <本轮输出目录> -ExpectedCommit <完整40位构建commit> -Mode ordinary。不启用 ManagedInstall 即不会由本探针安装运行环境。
3. 前台窗口验收继续用 windows-native.ps1 -Executable <完整EXE路径> -Node <node.exe完整路径> -OutputDirectory <独立本轮输出目录> -Mode ordinary；administrator 模式按原流程另跑。它自己创建新 sandbox；不要传日常配置目录给 JS 接口。
4. 复用原版 0.2.20 OTA 基线工具，不在升级前对旧包施加 021 断言。升级后准确 021 原生入口按上面的生产路径必跑新探针。
5. 检查 model-dialog-keyboard-native.json、model-menu-position-native.json、model-ui.json、ui021-alignment.json 以及 native021-behavior.json / native021-notice-trace.json。新增截图为 native021-channel-rename.png、native021-node-detection.png、native021-webdav-configured.png、native021-webdav-empty-candidates.png；失败保留 native021-failure.png 和现有 timeout 诊断。原生结果未实际产生前不得宣称本版 Windows 原生验收通过。
