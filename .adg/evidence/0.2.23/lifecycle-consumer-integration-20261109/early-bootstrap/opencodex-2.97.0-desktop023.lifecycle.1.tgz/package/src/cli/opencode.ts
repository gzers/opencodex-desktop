/**
 * `ocx opencode [opencode args...]` — launch opencode wired to the local proxy.
 *
 * Mirrors `ocx claude` (src/cli/claude.ts): ensure the proxy is running, then exec the
 * client with stdio inherited. The wiring channel differs — opencode reads providers
 * from merged JSON config layers rather than env slots.
 *
 * The launcher never copies or rewrites the user's opencode config files. It may read
 * global/project config to detect an existing `provider.opencodex` override, then injects
 * only the generated provider block through OpenCode's inline runtime layer
 * (`OPENCODE_CONFIG_CONTENT`), which outranks project/global/custom config and avoids
 * duplicating API keys, MCP credentials, or breaking relative `{file:…}` paths.
 *
 * The admission key is never serialized into that inline config. The provider block
 * carries opencode's documented `{env:VAR}` reference and the real value is passed
 * only through the child process environment.
 */
import { spawn } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, join } from "node:path";
import { loadConfig } from "../config";
import {
  OPENCODE_API_KEY_ENV,
  OPENCODE_CONFIG_SCHEMA,
  OPENCODE_PROVIDER_BLOCK_DEFAULT_CONFIG,
  OPENCODE_PROVIDER_ID,
  buildOpencodeProviderBlockFromCatalog,
  opencodeGlobalConfigPath,
  opencodeProviderBlocks,
  opencodeProxyBaseUrl,
  opencodeV2ProviderBlock,
} from "../clients/config-export";
import type {
  OpencodeCatalogModel,
  OpencodeGeneratedConfig,
  OpencodeLaunchEnv,
  OpencodeProviderBlock,
  OpencodeProviderBlocks,
  OpencodeV2ProviderBlock,
} from "../clients/config-export";
import type { EffectiveModelExportMetadata } from "../clients/config-export/contracts";
import { resolveExportReasoningAxes } from "../clients/config-export/reasoning-metadata";
import { filterCatalogVisibleModels, visibleNativeSlugs } from "../codex/catalog";
import { commandInvocation } from "../lib/win-exec";
import { configuredAdminToken, opencodeCatalogToken } from "../lib/admin-secrets";
import { localManagementOrigin } from "../lib/local-destinations";
import { directLocalHttpFetch } from "../server/direct-local-http";
import { loadServiceTokenFromFile, serviceApiTokenFilePath } from "../lib/service-secrets";
import { providerCodexAccountMode } from "../providers/registry";
import { findLiveProxy, probeHostname, type LiveProxy } from "../server/proxy-liveness";
import type { OcxConfig } from "../types";
import { withProcessRuntimeProvenance } from "../lib/bun-runtime";
import { selfLaunchArgv } from "../lib/self-launch-argv";
import { withoutSiblingMarker } from "../codex/sibling-start";
import { parseJsonc } from "../lib/jsonc";
export { parseJsonc };

/**
 * The provider-block serializer, its constants, and the config-path helpers now live in
 * `src/clients/config-export.ts`, shared with every other client-config export surface.
 * They are re-exported here so the launcher's long-standing import surface is unchanged.
 */
export {
  OPENCODE_API_KEY_ENV,
  OPENCODE_API_KEY_ENV_REF,
  OPENCODE_PROVIDER_BLOCK_DEFAULT_CONFIG,
  OPENCODE_PROVIDER_ID,
  SCHEMA_REQUIRED_OUTPUT_BUDGET,
  buildOpencodeProviderBlockFromCatalog,
  opencodeGlobalConfigPath,
  opencodeProxyBaseUrl,
  opencodeV2ProviderBlock,
} from "../clients/config-export";
export type {
  OpencodeCatalogModel,
  OpencodeGeneratedConfig,
  OpencodeLaunchEnv,
  OpencodeModelEntry,
  OpencodeProviderBlock,
  OpencodeProviderBlocks,
  OpencodeV2ProviderBlock,
} from "../clients/config-export";

/** One proxy-routed model destined for the generated provider block. */
export interface OpencodeRoutedModel {
  provider: string;
  id: string;
  /** Authoritative context window (CatalogModel.contextWindow); optional. */
  contextWindow?: number;
  /** Authoritative display label (CatalogModel.displayName); optional. */
  displayName?: string;
  /** Declared effort ladder; exported as opencode model variants when present. */
  reasoningEfforts?: readonly string[];
  supportsReasoning?: boolean;
  supportsThinkingToggle?: boolean;
  supportsReasoningEffort?: boolean;
  defaultThinkingEnabled?: boolean;
  defaultReasoningEffort?: string;
}

/** Row shape from authenticated GET /api/models on the running proxy. */
export interface OpencodeProxyModelRow {
  /** Hub-resolved availability, independent of the launcher's local Fast setting. */
  fastRowAvailable?: boolean;
  provider?: string;
  id?: string;
  namespaced?: string;
  native?: boolean;
  disabled?: boolean;
  displayName?: string;
  displayNameSource?: "operator" | "provider" | "fallback";
  contextWindow?: number;
  /** Authoritative output limit (CatalogModel.maxOutputTokens); optional. */
  maxOutputTokens?: number;
  /** Authoritative input ceiling (CatalogModel.maxInputTokens); optional. */
  maxInputTokens?: number;
  /**
   * Derived on the hub from known evidence; absent means unknown, never a negative. An
   * explicit `false` from the hub is evidence too and is carried through unchanged.
   */
  supportsTools?: boolean;
  supportsReasoning?: boolean;
  supportsReasoningSummaries?: boolean;
  /** Declared input modalities from `/api/models`; carried into opencode model capabilities. */
  inputModalities?: string[];
  /** Declared effort ladder from `/api/models`; carried into opencode model variants. */
  reasoningEfforts?: string[];
  supportsThinkingToggle?: boolean;
  supportsReasoningEffort?: boolean;
  defaultThinkingEnabled?: boolean;
  /** Declared default effort from `/api/models`. */
  defaultReasoningEffort?: string;
  /**
   * Effective export metadata `/api/models` attaches to every row it produces. Custom row
   * fields are the operator's stored overrides, so this object is the authoritative
   * projection a client consumes; routed and native rows carry their declared default in it
   * because the row-level default is the picker's preference order. When present, an absent
   * field inside means "no declared value" — never "fall back to the row" — and every field
   * below still works for rows without it (older hubs, hand-built rows).
   */
  exportMetadata?: EffectiveModelExportMetadata;
}

const PROJECT_CONFIG_FILENAMES = ["opencode.json", "opencode.jsonc"] as const;

/**
 * OpenCode's inline runtime config layer. It merges after project/global/custom config
 * and carries only the generated provider block for this launch.
 */
export const OPENCODE_CONFIG_CONTENT_ENV = "OPENCODE_CONFIG_CONTENT";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Model key as the proxy routes it: `provider/id` for routed models, bare slug for native OpenAI entries. */
export function opencodeModelKey(provider: string, id: string): string {
  return provider === "native" ? id : `${provider}/${id}`;
}

/**
 * Native OpenAI slugs advertised to opencode. Omitted in Codex Direct mode because native
 * chat-completions require the caller's real ChatGPT OAuth bearer, not proxy admission.
 */
export function opencodeLaunchNativeSlugs(config: OcxConfig): string[] {
  if (providerCodexAccountMode("openai", config.providers?.openai) === "direct") return [];
  return [...visibleNativeSlugs(config)];
}

/** Catalog rows for the slugs/routed models a caller assembled by hand. */
function opencodeLaunchCatalog(
  nativeSlugs: readonly string[],
  routedModels: readonly OpencodeRoutedModel[],
  nativeContextWindow: (slug: string) => number | undefined,
): OpencodeCatalogModel[] {
  return [
    ...nativeSlugs.map(id => ({
      namespaced: id,
      native: true,
      provider: "openai",
      id,
      contextWindow: nativeContextWindow(id),
    })),
    ...routedModels.map(model => ({
      namespaced: opencodeModelKey(model.provider, model.id),
      native: false,
      provider: model.provider,
      id: model.id,
      contextWindow: model.contextWindow,
      displayName: model.displayName,
      ...(model.reasoningEfforts !== undefined
        ? { reasoningEfforts: [...model.reasoningEfforts] }
        : {}),
      ...(model.supportsReasoning !== undefined ? { supportsReasoning: model.supportsReasoning } : {}),
      ...(model.supportsThinkingToggle !== undefined ? { supportsThinkingToggle: model.supportsThinkingToggle } : {}),
      ...(model.supportsReasoningEffort !== undefined ? { supportsReasoningEffort: model.supportsReasoningEffort } : {}),
      ...(model.defaultThinkingEnabled !== undefined ? { defaultThinkingEnabled: model.defaultThinkingEnabled } : {}),
      ...(model.defaultReasoningEffort !== undefined ? { defaultReasoningEffort: model.defaultReasoningEffort } : {}),
    })),
  ];
}

/** Back-compat helper for unit tests that assemble slugs/routed rows directly. */
export function buildOpencodeProviderBlock(
  port: number,
  nativeSlugs: readonly string[],
  routedModels: readonly OpencodeRoutedModel[],
  nativeContextWindow: (slug: string) => number | undefined = () => undefined,
  hostname?: string,
  config: OcxConfig = OPENCODE_PROVIDER_BLOCK_DEFAULT_CONFIG,
): OpencodeProviderBlock {
  return buildOpencodeProviderBlockFromCatalog(
    port,
    opencodeLaunchCatalog(nativeSlugs, routedModels, nativeContextWindow),
    hostname,
    config,
  );
}

/**
 * V2 counterpart of `buildOpencodeProviderBlock`. The launcher injects both generations,
 * because only the V2 block carries selectable reasoning efforts.
 */
export function buildOpencodeV2ProviderBlock(
  port: number,
  nativeSlugs: readonly string[],
  routedModels: readonly OpencodeRoutedModel[],
  nativeContextWindow: (slug: string) => number | undefined = () => undefined,
  hostname?: string,
  config: OcxConfig = OPENCODE_PROVIDER_BLOCK_DEFAULT_CONFIG,
): OpencodeV2ProviderBlock {
  return opencodeBlocks(
    port,
    opencodeLaunchCatalog(nativeSlugs, routedModels, nativeContextWindow),
    hostname,
    config,
  ).v2;
}

/**
 * Both generations from one catalog, in one pass. Every production path uses this: the two
 * blocks are one document's fragments and have to agree on model set, names, connection, and
 * variants, which building them together guarantees instead of merely expecting.
 */
export function buildOpencodeProviderBlocksFromCatalog(
  port: number,
  catalogModels: readonly OpencodeCatalogModel[],
  hostname?: string,
  config: OcxConfig = OPENCODE_PROVIDER_BLOCK_DEFAULT_CONFIG,
): OpencodeProviderBlocks {
  return opencodeBlocks(port, catalogModels, hostname, config);
}

function opencodeBlocks(
  port: number,
  catalogModels: readonly OpencodeCatalogModel[],
  hostname?: string,
  config: OcxConfig = OPENCODE_PROVIDER_BLOCK_DEFAULT_CONFIG,
): OpencodeProviderBlocks {
  return opencodeProviderBlocks(opencodeProxyBaseUrl(port, hostname), catalogModels, config);
}

/** Default deadline for authenticated GET /api/models during `ocx opencode` launch. */
export const OPENCODE_PROXY_MODELS_TIMEOUT_MS = 8_000;

function opencodeManagementOrigin(live: LiveProxy, override?: string): string {
  if (!override && (!Number.isInteger(live.port) || live.port < 1 || live.port > 65535)) {
    throw new Error("The local management port is invalid.");
  }
  let url: URL;
  try { url = new URL(override ?? `http://${probeHostname(live.hostname)}:${live.port}`); }
  catch { throw new Error("The local management address is invalid."); }
  if (url.protocol !== "http:" || url.username || url.password || url.pathname !== "/" || url.search || url.hash) {
    throw new Error("The catalog requires a local HTTP management origin without credentials or a path.");
  }
  const host = url.hostname.toLowerCase();
  if (["localhost", "localhost.", "127.0.0.1", "0.0.0.0", "[::]"].includes(host)) url.hostname = "127.0.0.1";
  else if (host !== "[::1]") {
    throw new Error("The catalog requires a loopback management listener. On a hub, enable hub.managementIngress.");
  }
  const port = Number(url.port || 80);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("The local management port is invalid.");
  return url.origin;
}

/** Fetch the live model catalog from a running proxy's management API. */
export async function fetchOpencodeProxyModels(
  live: LiveProxy,
  managementToken: string,
  deps: { fetchImpl?: typeof fetch; timeoutMs?: number; managementOrigin?: string } = {},
): Promise<OpencodeProxyModelRow[]> {
  const baseUrl = opencodeManagementOrigin(live, deps.managementOrigin);
  const fetchImpl = deps.fetchImpl ?? directLocalHttpFetch;
  const headers = new Headers({ Accept: "application/json" });
  const token = managementToken.trim();
  if (!token) throw new Error("No local admin token is available for the model catalog.");
  headers.set("X-OpenCodex-API-Key", token);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), deps.timeoutMs ?? OPENCODE_PROXY_MODELS_TIMEOUT_MS);
  const abortIfTimedOut = (): Promise<never> => new Promise((_, reject) => {
    if (controller.signal.aborted) {
      reject(new DOMException("The operation was aborted.", "AbortError"));
      return;
    }
    controller.signal.addEventListener(
      "abort",
      () => reject(new DOMException("The operation was aborted.", "AbortError")),
      { once: true },
    );
  });

  let response: Response;
  let text: string;
  try {
    response = await Promise.race([
      fetchImpl(`${baseUrl}/api/models`, {
        headers,
        redirect: "error",
        cache: "no-store",
        signal: controller.signal,
      }),
      abortIfTimedOut(),
    ]);
    if (response.status >= 300 && response.status < 400) {
      void response.body?.cancel().catch(() => {});
      throw new Error("Management catalog redirects are refused.");
    }
    text = await Promise.race([response.text(), abortIfTimedOut()]);
  } catch (error) {
    const timedOut = error instanceof Error && error.name === "AbortError";
    throw new Error(
      timedOut
        ? "Management API timed out while fetching /api/models."
        : `Management API is unreachable: ${error instanceof Error ? error.message : String(error)}`,
    );
  } finally {
    clearTimeout(timeout);
  }
  let body: unknown = null;
  if (text) {
    try { body = JSON.parse(text); }
    catch { body = text; }
  }
  if (!response.ok) {
    const message = body && typeof body === "object" && typeof (body as Record<string, unknown>).error === "string"
      ? (body as Record<string, string>).error
      : `Management request failed (${response.status})`;
    throw new Error(message);
  }
  if (!Array.isArray(body)) {
    throw new Error("Management API returned an unexpected /api/models payload.");
  }
  return body as OpencodeProxyModelRow[];
}

/**
 * Visible OpenCode catalog entries from proxy /api/models rows. Disabled rows are omitted;
 * native rows are omitted in Codex Direct mode.
 *
 * Custom rows carry their effective projection in `exportMetadata`; when it is present it
 * wins over the row's own fields, which for a custom row are the operator's stored overrides
 * rather than the resolved capabilities. Routed/native projections also distinguish declared
 * defaults from picker preferences; older hubs without the field retain their row values. The empty-vs-undefined ladder distinction
 * survives: a row declaring `reasoningEfforts: []` exports `[]`, not an absent key.
 */
export function opencodeCatalogFromProxyRows(
  rows: readonly OpencodeProxyModelRow[],
  config: OcxConfig,
): OpencodeCatalogModel[] {
  const omitNative = providerCodexAccountMode("openai", config.providers?.openai) === "direct";
  const routedRows = rows.filter((row): row is OpencodeProxyModelRow & { provider: string; id: string } =>
    row.native !== true && typeof row.provider === "string" && typeof row.id === "string");
  const visibleRouted = new Set<OpencodeProxyModelRow>(filterCatalogVisibleModels(routedRows, config));
  const seen = new Set<string>();
  const catalog: OpencodeCatalogModel[] = [];
  for (const row of rows) {
    const namespaced = row.namespaced?.trim();
    if (!namespaced || row.disabled === true) continue;
    if (omitNative && row.native === true) continue;
    if (row.native !== true && typeof row.provider === "string" && typeof row.id === "string"
      && !visibleRouted.has(row)) continue;
    if (seen.has(namespaced)) continue;
    seen.add(namespaced);
    const effective = row.exportMetadata;
    const maxTokens = effective?.maxTokens ?? row.maxOutputTokens;
    const maxInputTokens = effective?.maxInputTokens ?? row.maxInputTokens;
    const inputModalities = effective?.inputModalities ?? row.inputModalities;
    const { supportsThinkingToggle, supportsReasoningEffort, defaultThinkingEnabled,
      reasoningEfforts, defaultReasoningEffort } = resolveExportReasoningAxes(effective, row);
    const supportsTools = effective?.supportsTools ?? row.supportsTools;
    const supportsReasoning = effective?.supportsReasoning ?? row.supportsReasoning;
    const supportsReasoningSummaries = effective?.supportsReasoningSummaries ?? row.supportsReasoningSummaries;
    catalog.push({
      namespaced,
      native: row.native === true,
      provider: row.provider,
      id: row.id,
      contextWindow: effective?.contextWindow ?? row.contextWindow,
      ...(typeof maxTokens === "number" ? { maxTokens } : {}),
      ...(typeof maxInputTokens === "number" ? { maxInputTokens } : {}),
      displayName: row.displayNameSource === "fallback" ? undefined : row.displayName,
      ...(Array.isArray(inputModalities) && inputModalities.length > 0
        ? { inputModalities: [...inputModalities] }
        : {}),
      ...(typeof row.fastRowAvailable === "boolean" ? { fastRowAvailable: row.fastRowAvailable } : {}),
      // `[]` is a declaration, not an absence: an explicit no-rungs ladder stays empty here.
      ...(Array.isArray(reasoningEfforts) ? { reasoningEfforts: [...reasoningEfforts] } : {}),
      ...(typeof supportsThinkingToggle === "boolean" ? { supportsThinkingToggle } : {}),
      ...(typeof supportsReasoningEffort === "boolean" ? { supportsReasoningEffort } : {}),
      ...(typeof defaultThinkingEnabled === "boolean" ? { defaultThinkingEnabled } : {}),
      ...(typeof defaultReasoningEffort === "string" && defaultReasoningEffort.length > 0
        ? { defaultReasoningEffort }
        : {}),
      // An explicit false survives the hop; only derivation is true-or-nothing.
      ...(typeof supportsTools === "boolean" ? { supportsTools } : {}),
      ...(typeof supportsReasoning === "boolean" ? { supportsReasoning } : {}),
      ...(typeof supportsReasoningSummaries === "boolean" ? { supportsReasoningSummaries } : {}),
    });
  }
  return catalog;
}

export type OpencodeRuntimeConfigError = { error: string };

/** True when mergeOpencodeRuntimeConfig rejected inherited inline config. */
export function isOpencodeRuntimeConfigError(
  value: OpencodeGeneratedConfig | OpencodeRuntimeConfigError,
): value is OpencodeRuntimeConfigError {
  return "error" in value;
}

/**
 * Merge inherited `OPENCODE_CONFIG_CONTENT` and override only our own blocks:
 * `provider.opencodex` (V1 maps) and `providers.opencodex` (native V2 arrays).
 * When no inline layer is present, emit the minimal runtime object for this launcher.
 */
export function mergeOpencodeRuntimeConfig(
  inheritedContent: string | undefined,
  blocks: OpencodeProviderBlocks,
): OpencodeGeneratedConfig | OpencodeRuntimeConfigError {
  if (!inheritedContent?.trim()) {
    return {
      $schema: OPENCODE_CONFIG_SCHEMA,
      provider: { [OPENCODE_PROVIDER_ID]: blocks.v1 },
      providers: { [OPENCODE_PROVIDER_ID]: blocks.v2 },
    };
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(inheritedContent);
  } catch {
    return { error: "OPENCODE_CONFIG_CONTENT is not valid JSON." };
  }
  if (!isRecord(parsed)) {
    return { error: "OPENCODE_CONFIG_CONTENT must be a JSON object." };
  }
  const existingProvider = parsed.provider;
  if (existingProvider !== undefined && !isRecord(existingProvider)) {
    return { error: "OPENCODE_CONFIG_CONTENT provider must be a JSON object when present." };
  }
  const existingProviders = parsed.providers;
  if (existingProviders !== undefined && !isRecord(existingProviders)) {
    return { error: "OPENCODE_CONFIG_CONTENT providers must be a JSON object when present." };
  }
  return {
    ...parsed,
    $schema: typeof parsed.$schema === "string" ? parsed.$schema : OPENCODE_CONFIG_SCHEMA,
    provider: {
      ...(isRecord(existingProvider) ? existingProvider : {}),
      [OPENCODE_PROVIDER_ID]: blocks.v1,
    },
    providers: {
      ...(isRecord(existingProviders) ? existingProviders : {}),
      [OPENCODE_PROVIDER_ID]: blocks.v2,
    },
  } as OpencodeGeneratedConfig;
}

/** Inline runtime config carrying only the provider block this launcher owns. */
export function buildOpencodeConfig(
  port: number,
  nativeSlugs: readonly string[],
  routedModels: readonly OpencodeRoutedModel[],
  nativeContextWindow: (slug: string) => number | undefined = () => undefined,
  hostname?: string,
  config: OcxConfig = OPENCODE_PROVIDER_BLOCK_DEFAULT_CONFIG,
): OpencodeGeneratedConfig {
  const merged = mergeOpencodeRuntimeConfig(undefined, {
    v1: buildOpencodeProviderBlock(port, nativeSlugs, routedModels, nativeContextWindow, hostname, config),
    v2: buildOpencodeV2ProviderBlock(port, nativeSlugs, routedModels, nativeContextWindow, hostname, config),
  });
  if (isOpencodeRuntimeConfigError(merged)) {
    throw new Error(merged.error);
  }
  return merged;
}

/** Serialize the inline runtime config OpenCode merges on launch. */
export function serializeOpencodeRuntimeConfig(config: OpencodeGeneratedConfig): string {
  return JSON.stringify(config);
}

function findGitRoot(start: string): string | null {
  let dir = start;
  while (true) {
    if (existsSync(join(dir, ".git"))) return dir;
    const parent = dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

/**
 * True when the file declares our provider in either generation. Both count: the launcher
 * overwrites `provider.opencodex` and `providers.opencodex` alike, so a config that carries
 * only the V2 block is overridden just as silently as one carrying only the V1 block.
 */
function configFileDefinesProvider(path: string): boolean {
  if (!existsSync(path)) return false;
  try {
    const parsed = parseJsonc(readFileSync(path, "utf8"));
    if (!isRecord(parsed)) return false;
    const legacy = isRecord(parsed.provider) && OPENCODE_PROVIDER_ID in parsed.provider;
    const v2 = isRecord(parsed.providers) && OPENCODE_PROVIDER_ID in parsed.providers;
    return legacy || v2;
  } catch {
    return false;
  }
}

/**
 * Detect global or project-level opencode.json/jsonc that defines our provider key.
 * Informational only: the inline runtime layer from `OPENCODE_CONFIG_CONTENT` outranks both.
 */
export function opencodeProviderOverridePath(
  cwd: string,
  env: OpencodeLaunchEnv = process.env,
  home: string = homedir(),
): string | null {
  const globalPath = opencodeGlobalConfigPath(env, home);
  if (configFileDefinesProvider(globalPath)) return globalPath;

  const gitRoot = findGitRoot(cwd);
  let dir = cwd;
  while (true) {
    for (const name of PROJECT_CONFIG_FILENAMES) {
      const candidate = join(dir, name);
      if (configFileDefinesProvider(candidate)) return candidate;
    }
    if (gitRoot && dir === gitRoot) break;
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

/** @deprecated Use {@link opencodeProviderOverridePath}. */
export function projectConfigOverridesProvider(cwd: string): string | null {
  return opencodeProviderOverridePath(cwd);
}

function serviceTokenLookupEnv(env: OpencodeLaunchEnv): OpencodeLaunchEnv {
  if (env.OCX_API_TOKEN_FILE?.trim()) return env;
  return { ...env, OCX_API_TOKEN_FILE: serviceApiTokenFilePath() };
}

/**
 * Child env for a detached `ocx start` from `ocx opencode`. When the admission token is
 * not already in the environment, pass through an existing `OCX_API_TOKEN_FILE` or the
 * default hardened service token path so `handleStart` can load it before bind.
 */
export function opencodeProxyStartEnv(base: OpencodeLaunchEnv = process.env): OpencodeLaunchEnv {
  const withTokenFile = base.OPENCODEX_API_AUTH_TOKEN?.trim()
    ? base
    : serviceTokenLookupEnv(base);
  return { ...withTokenFile, OCX_SERVICE: "1" };
}

/**
 * Env assembly (unit-tested). Inherited inline config is merged and only our own blocks are
 * replaced — `provider.opencodex` and `providers.opencodex`; disk config layers stay
 * untouched. The admission key travels in the child env rather than in the inline config
 * payload.
 */
export function buildOpencodeEnv(
  blocks: OpencodeProviderBlocks,
  apiKey: string,
  base: OpencodeLaunchEnv,
): OpencodeLaunchEnv | OpencodeRuntimeConfigError {
  const runtimeConfig = mergeOpencodeRuntimeConfig(base[OPENCODE_CONFIG_CONTENT_ENV], blocks);
  if (isOpencodeRuntimeConfigError(runtimeConfig)) return runtimeConfig;
  return {
    ...Object.fromEntries(Object.entries(base).filter(([name]) => name.toUpperCase() !== "OPENCODEX_ADMIN_AUTH_TOKEN")),
    [OPENCODE_CONFIG_CONTENT_ENV]: serializeOpencodeRuntimeConfig(runtimeConfig),
    [OPENCODE_API_KEY_ENV]: apiKey,
  };
}

/**
 * Admission key for the proxy: env token, hardened service token file, configured API
 * key, then the open-loopback placeholder. Never serialized into runtime config.
 */
export function opencodeApiKey(config: OcxConfig, env: OpencodeLaunchEnv = process.env): string {
  const envToken = env.OPENCODEX_API_AUTH_TOKEN?.trim();
  if (envToken) return envToken;
  const serviceToken = loadServiceTokenFromFile(serviceTokenLookupEnv(env));
  if (serviceToken) return serviceToken;
  return config.apiKeys?.[0]?.key || "ocx";
}

async function ensureProxyForOpencode(config: OcxConfig): Promise<LiveProxy | null> {
  const live = await findLiveProxy();
  if (live) return live;
  const cfgPort = config.port;
  const pinPort = typeof cfgPort === "number" && cfgPort > 0 ? cfgPort : 10100;
  const child = spawn(process.execPath, selfLaunchArgv(["start", "--port", String(pinPort)]), {
    detached: true,
    stdio: "ignore",
    windowsHide: true,
    // An ordinary owner: a stray sibling marker would otherwise mark it before any probe.
    env: withProcessRuntimeProvenance(opencodeProxyStartEnv(withoutSiblingMarker(process.env)) as NodeJS.ProcessEnv),
  });
  // Without a listener an 'error' (bad argv[1], EMFILE, AV denial) throws synchronously
  // and kills this process; the health poll below already reports the failure properly.
  child.on("error", () => { /* handled by the deadline loop returning null */ });
  child.unref();
  const deadline = Date.now() + 8_000;
  while (Date.now() < deadline) {
    const started = await findLiveProxy();
    if (started) return started;
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  return null;
}

const OPENCODE_INSTALL_HINT = "❌ `opencode` CLI not found. Install it first: npm install -g opencode-ai";

/**
 * cmd.exe reports command-not-found as exit 9009 (the win32 launcher routes `.cmd`
 * shims through cmd.exe, so ENOENT never fires there). Signal exits are not hints.
 * Same contract as claudeNotFoundHint (devlog 260715_cross_platform_audit/020).
 */
export function opencodeNotFoundHint(
  code: number | null,
  signal: NodeJS.Signals | null,
  platform: NodeJS.Platform = process.platform,
): string | null {
  return platform === "win32" && code === 9009 && !signal ? OPENCODE_INSTALL_HINT : null;
}

export async function cmdOpencode(args: string[]): Promise<number> {
  const startupConfig = loadConfig();
  const live = await ensureProxyForOpencode(startupConfig);
  if (!live) {
    console.error("❌ Proxy did not become healthy after starting.");
    return 1;
  }

  const apiKey = opencodeApiKey(startupConfig);
  let proxyModels: OpencodeProxyModelRow[];
  try {
    const managementToken = configuredAdminToken();
    if (!managementToken) throw new Error("No local admin token is available; check the running proxy's home.");
    proxyModels = await fetchOpencodeProxyModels(live, opencodeCatalogToken(managementToken), {
      managementOrigin: localManagementOrigin({ ...startupConfig, hostname: live.hostname }, live.port),
    });
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    console.error(`❌ Could not fetch the model catalog from the proxy: ${reason}`);
    return 1;
  }
  // /api/models may have completed and persisted initial provider selection.
  const config = loadConfig();
  const catalog = opencodeCatalogFromProxyRows(proxyModels, config);
  const blocks = buildOpencodeProviderBlocksFromCatalog(live.port, catalog, live.hostname, config);
  const baseUrl = blocks.v1.options.baseURL;
  const modelCount = Object.keys(blocks.v1.models).length;
  console.error(`✅ opencode wired to ${baseUrl} — ${modelCount} model(s) under provider \`${OPENCODE_PROVIDER_ID}\`.`);
  console.error("   Your existing opencode config files are left untouched; only the runtime provider blocks are injected.");
  const providerOverride = opencodeProviderOverridePath(process.cwd());
  if (providerOverride) {
    console.error(`ℹ ${providerOverride} also defines our provider key; the runtime layer from ocx opencode overrides it for this launch.`);
  }

  const builtEnv = buildOpencodeEnv(blocks, apiKey, process.env);
  if ("error" in builtEnv) {
    console.error(`❌ ${builtEnv.error}`);
    return 1;
  }
  const env = builtEnv;
  return await new Promise<number>(resolve => {
    const inv = commandInvocation("opencode", args);
    const child = spawn(inv.file, inv.args, { stdio: "inherit", env: env as NodeJS.ProcessEnv, ...inv.options });
    child.on("error", (err: NodeJS.ErrnoException) => {
      if (err.code === "ENOENT") {
        console.error(OPENCODE_INSTALL_HINT);
      } else {
        console.error(`❌ Failed to launch opencode: ${err.message}`);
      }
      resolve(1);
    });
    child.on("exit", (code, signal) => {
      const hint = opencodeNotFoundHint(code, signal);
      if (hint) console.error(hint);
      resolve(signal ? 1 : code ?? 0);
    });
  });
}
