# BF production prepare refusal retained

Actual save succeeded and pending was retained, but actual prepare returned client_selection_changed. Parent confirmed verify_client_route double-prefixes sha256:. No post-prepare model/route or commit simulation ran. Original result.json stays failed.

See [machine receipt](production-prepare-bf-result.json), [actual prepare](run-20261104-160341/actual-production-prepare.stdout), [old raw config](run-20261104-160341/old-current-default-fixture.toml), [old native config/read](run-20261104-160341/old-effective-config.json). The raw file hash differs from the native origin version too; that additional old-side observation is separate from the confirmed prefix bug. New 1313 run must preserve real owner CAS and decide from its actual result.
