const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'../../../..'),prototype='docs/04-项目资料/01-项目支撑资料/01-产品原型/原型/';
const files=new Map(JSON.parse(fs.readFileSync(path.join(__dirname,'baseline.json'),'utf8')).files.map(f=>[f.path,path.join(__dirname,'preimage',f.path)]));
for(const f of JSON.parse(fs.readFileSync(path.join(__dirname,'source-manifest.json'),'utf8')).files)files.set(f.path,path.join(__dirname,'final',path.basename(f.path)));
function resolve(file){if(typeof file!=='string')return file;const relative=path.relative(root,path.resolve(file));return files.get(relative)||file;}
module.exports={root,prototype,resolve,files};
