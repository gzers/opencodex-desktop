//! Events for ordinary config-file saves. Call outside config/layout/store locks.
//! Transfers keep using save_observed_checked and inherit their source receipts.
use super::super::{
    config_file::{self, SaveRequest, SaveResult},
    config_remote::{self, Scope},
    schema::*,
};
use super::{record_save, SaveState};
use std::{collections::BTreeSet, path::Path};

pub struct Event {
    channel_ids: BTreeSet<String>,
    global: bool,
    before: SaveState,
}
fn capture_supported(root: &Path, scope: &Scope) -> ModelResult<SaveState> {
    match config_remote::capture_save(root, scope) {
        Ok(state) => Ok(state),
        // The ordinary save preserves fields and unresolved credential references
        // which the portable exporter deliberately cannot carry. Such content
        // remains uncertified; it must not prevent the owner's valid save or
        // be assigned a made-up time. IO/version-store failures still propagate.
        Err(e)
            if [
                "provider_fields",
                "provider_auth_reference",
                "provider_auth_portable",
                "credential_unavailable",
            ]
            .contains(&e.code.as_str()) =>
        {
            Ok(SaveState::new())
        }
        Err(e) => Err(e),
    }
}
fn capture(
    root: &Path,
    home: &Path,
    ids: &BTreeSet<String>,
    global: bool,
    snapshot: &Snapshot,
) -> ModelResult<SaveState> {
    let mut out = SaveState::new();
    if global {
        out.extend(capture_supported(
            root,
            &Scope {
                all_channels: true,
                include_global: true,
                preferences: false,
                extensions: false,
                upstream_root: Some(home.into()),
                ..Default::default()
            },
        )?);
    }
    for channel in snapshot
        .policy
        .channels
        .iter()
        .filter(|c| ids.contains(&c.id))
    {
        let scope = Scope {
            channel_ids: vec![channel.id.clone()],
            preferences: false,
            extensions: false,
            upstream_root: Some(home.into()),
            ..Default::default()
        };
        // Public-only receipts are independent of secret availability.
        out.extend(capture_supported(root, &scope)?);
        out.extend(capture_supported(
            root,
            &Scope {
                include_keys: true,
                credential_ids: Some(vec![format!("channel:{}", channel.id)]),
                ..scope
            },
        )?);
    }
    Ok(out)
}
/// Capture only this request's effective targets. New IDs need no prior object.
/// Unrelated channel drafts in a scoped request never cause credential reads.
pub fn begin(root: &Path, home: &Path, request: &SaveRequest) -> ModelResult<Event> {
    let snapshot = config_file::snapshot(root, home)?;
    let channel_ids = if let Some(scope) = &request.scope {
        BTreeSet::from([scope.channel_id.clone()])
    } else {
        request
            .policy
            .channels
            .iter()
            .filter(|candidate| {
                snapshot
                    .policy
                    .channels
                    .iter()
                    .find(|old| old.id == candidate.id)
                    != Some(*candidate)
                    || request
                        .credentials
                        .iter()
                        .any(|edit| edit.channel_id == candidate.id)
            })
            .map(|c| c.id.clone())
            .collect()
    };
    let global = request.scope.is_none()
        && (snapshot.policy.template_refs != request.policy.template_refs
            || snapshot.policy.default_channel_id != request.policy.default_channel_id
            || snapshot
                .policy
                .channels
                .iter()
                .map(|c| &c.id)
                .collect::<Vec<_>>()
                != request
                    .policy
                    .channels
                    .iter()
                    .map(|c| &c.id)
                    .collect::<Vec<_>>());
    let before = capture(root, home, &channel_ids, global, &snapshot)?;
    if config_file::snapshot(root, home)? != snapshot {
        return Err(invalid(
            "file_changed",
            "捕获保存版本期间配置改变，尚未保存，请重新读取",
        ));
    }
    Ok(Event {
        channel_ids,
        global,
        before,
    })
}
/// Call only for Ok(SaveResult), after save_internal released all its guards.
/// Do not gate on result.changed: layout-only semantic saves also have receipts.
pub fn finish(root: &Path, home: &Path, event: Event, result: &SaveResult) -> ModelResult<()> {
    let work = || -> ModelResult<()> {
        let actual = config_file::snapshot(root, home)?;
        if actual != result.snapshot {
            return Err(invalid("file_changed", "保存后配置已改变"));
        }
        let after = capture(root, home, &event.channel_ids, event.global, &actual)?;
        if config_file::snapshot(root, home)? != actual {
            return Err(invalid("file_changed", "读回期间配置已改变"));
        }
        record_save(root, &event.before, &after)
    };
    work().map_err(|_| {
        invalid(
            "saved_content_version_unconfirmed",
            "配置已保存，但保存版本未认证；请重新读取核对，未将其标记为可靠新版",
        )
    })
}

#[cfg(test)]
mod tests {
    use super::super::super::{
        config_file::{CredentialEdit, SaveScope},
        file_objects,
    };
    use super::*;
    struct Fixture {
        _temp: tempfile::TempDir,
        root: std::path::PathBuf,
        home: std::path::PathBuf,
    }
    impl Fixture {
        fn new() -> Self {
            file_objects::test_credentials::install();
            let temp = tempfile::tempdir().unwrap();
            let root = temp.path().join("data");
            let home = temp.path().join("official");
            std::fs::create_dir_all(&root).unwrap();
            std::fs::create_dir_all(&home).unwrap();
            // A request-local hook must never resolve the unrelated missing key.
            std::fs::write(home.join("config.json"), serde_json::to_vec(&serde_json::json!({"providers":{
                "selected":{"adapter":"openai-chat","authMode":"key","baseUrl":"https://selected.invalid/v1","apiKey":"synthetic-selected","models":["model-a"]},
                "unrelated":{"adapter":"openai-chat","authMode":"key","baseUrl":"https://unrelated.invalid/v1","apiKey":"keychain:NEVER-READ-UNRELATED","models":["model-b"]}
            }})).unwrap()).unwrap();
            Self {
                _temp: temp,
                root,
                home,
            }
        }
        fn request(&self, scoped: bool) -> SaveRequest {
            let snapshot = config_file::snapshot(&self.root, &self.home).unwrap();
            let id = snapshot
                .policy
                .channels
                .iter()
                .find(|c| c.connection.provider_id == "selected")
                .unwrap()
                .id
                .clone();
            SaveRequest {
                expected_file: snapshot.policy_digest,
                policy: snapshot.policy,
                credentials: vec![],
                scope: scoped.then_some(SaveScope { channel_id: id }),
            }
        }
        fn fact(&self, id: String) -> file_objects::ContentFact {
            config_remote::source_fact(
                &self.root,
                &Scope {
                    channel_ids: vec![id],
                    include_keys: true,
                    preferences: false,
                    extensions: false,
                    upstream_root: Some(self.home.clone()),
                    ..Default::default()
                },
            )
            .unwrap()
        }
    }
    #[test]
    fn ordinary_save_is_bounded_and_covers_scoped_key_only_and_new_objects() {
        for scoped in [true, false] {
            let f = Fixture::new();
            let mut request = f.request(scoped);
            let id = request
                .policy
                .channels
                .iter()
                .find(|c| c.connection.provider_id == "selected")
                .unwrap()
                .id
                .clone();
            request
                .policy
                .channels
                .iter_mut()
                .find(|c| c.id == id)
                .unwrap()
                .connection
                .nodes[0]
                .url = "https://saved.invalid/v1".into();
            let saved = config_file::save(&f.root, &f.home, request).unwrap();
            assert!(saved.changed);
            assert!(f.fact(id.clone()).saved_at.is_some());
            let original = f.fact(id.clone());
            let same = config_file::save(&f.root, &f.home, f.request(scoped)).unwrap();
            assert!(!same.changed);
            assert_eq!(f.fact(id.clone()), original);
            let mut metadata_only = f.request(scoped);
            metadata_only
                .policy
                .channels
                .iter_mut()
                .find(|c| c.id == id)
                .unwrap()
                .label = "layout label".into();
            let saved = config_file::save(&f.root, &f.home, metadata_only).unwrap();
            assert!(
                !saved.changed,
                "file bytes are unchanged for layout-only updates"
            );
            assert_ne!(f.fact(id.clone()).content_digest, original.content_digest);
            assert!(f.fact(id.clone()).saved_at.is_some());
            let mut request = f.request(scoped);
            request.credentials.push(CredentialEdit {
                channel_id: id.clone(),
                action: "replace".into(),
                value: Some("synthetic-key-only".into()),
            });
            config_file::save(&f.root, &f.home, request).unwrap();
            assert_ne!(f.fact(id).content_digest, original.content_digest);
            assert!(f.fact(original_id(&f)).saved_at.is_some());
        }
        let rename = Fixture::new();
        let mut request = rename.request(true);
        let id = request.scope.as_ref().unwrap().channel_id.clone();
        let channel = request
            .policy
            .channels
            .iter_mut()
            .find(|c| c.id == id)
            .unwrap();
        channel.label = "renamed".into();
        channel.connection.provider_id = "renamed".into();
        let result = config_file::save(&rename.root, &rename.home, request).unwrap();
        assert_eq!(
            result
                .snapshot
                .policy
                .channels
                .iter()
                .find(|c| c.id == id)
                .unwrap()
                .connection
                .provider_id,
            "renamed"
        );
        assert!(rename.fact(id).saved_at.is_some());
        let f = Fixture::new();
        let mut request = f.request(true);
        let mut added = request
            .policy
            .channels
            .iter()
            .find(|c| c.connection.provider_id == "selected")
            .unwrap()
            .clone();
        let id = uuid::Uuid::new_v4().to_string();
        added.id = id.clone();
        added.label = "added".into();
        added.connection.provider_id = "added".into();
        request.policy.channels.push(added);
        request.scope = Some(SaveScope {
            channel_id: id.clone(),
        });
        request.credentials.push(CredentialEdit {
            channel_id: id.clone(),
            action: "replace".into(),
            value: Some("synthetic-new-object".into()),
        });
        config_file::save(&f.root, &f.home, request).unwrap();
        assert!(f.fact(id).saved_at.is_some());
    }
    fn original_id(f: &Fixture) -> String {
        f.request(true).scope.unwrap().channel_id
    }
    #[test]
    fn failure_and_post_save_receipt_failure_do_not_report_a_certified_save() {
        let f = Fixture::new();
        let before_file = std::fs::read(f.home.join("config.json")).unwrap();
        let mut invalid = f.request(true);
        invalid.expected_file = "stale".into();
        assert!(config_file::save(&f.root, &f.home, invalid).is_err());
        assert_eq!(
            std::fs::read(f.home.join("config.json")).unwrap(),
            before_file
        );
        assert!(!f
            .root
            .join("manager-state/saved-content-versions.json")
            .exists());
        let mut request = f.request(true);
        request
            .policy
            .channels
            .iter_mut()
            .find(|c| c.connection.provider_id == "selected")
            .unwrap()
            .connection
            .nodes[0]
            .url = "https://saved.invalid/v2".into();
        let event = begin(&f.root, &f.home, &request).unwrap();
        let result = config_file::save(&f.root, &f.home, request).unwrap();
        let saved = std::fs::read(f.home.join("config.json")).unwrap();
        let version_file = f.root.join("manager-state/saved-content-versions.json");
        if version_file.exists() {
            std::fs::remove_file(&version_file).unwrap();
        }
        std::fs::create_dir(&version_file).unwrap();
        assert_eq!(
            finish(&f.root, &f.home, event, &result).unwrap_err().code,
            "saved_content_version_unconfirmed"
        );
        assert_eq!(std::fs::read(f.home.join("config.json")).unwrap(), saved);
    }
}
