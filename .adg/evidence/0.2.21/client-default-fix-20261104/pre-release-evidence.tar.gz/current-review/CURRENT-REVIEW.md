# 当前 model / review_model 引用修复

本轮修正前一轮覆盖边界：review_model 是当前配置引用，不能作为历史会话保留旧 provider。前一轮真实测试有意保留 review_model=OLD 的结果只证明了单 model 模块；不构成两个当前引用均完成。原证据未重写，本子轮给出扩展后的生产模块和真实 owner 结果。

生产写集仍仅 client_selection_rename.rs 与 tests/client_selection_rename.rs；不改父线保存/live/restart 编排、不改 UI/DMD/版本，不提交或推送。父线已注册生产 path module，集成测试直接从 opencodex_desktop_lib::modules::model_config::cache_refresh::client_selection_rename 导入，未再 path include 模块副本。

## 稳定接口

preflight_current_selection(context, codex_executable, home_directory, codex_home, working_directory, active_profile, provider_renames) → ClientSelectionRenamePlan，随后 plan.apply() → ModelResult<ClientSelectionRename>。签名和 Unchanged / Updated 不变。主线继续预检 → live reconcile/producer → apply → 官方 restart，false 缓存分支不扩大。

内部 CurrentScalar 是封闭枚举，仅 model 和 review_model；不遍历任意未来参数、不遍历历史线程、不对配置做全文替换。两个值各自只替换首个斜杠前的完整 provider 段；不同原始型号后缀逐字保持。

## 原生 owner 合同与实际核验

ConfigBatchWriteParams.json 从同一官方 0.166.0 二进制导出。原生方法为 config/batchWrite，请求为明确 filePath、expectedVersion、edits 数组，各项只有 keyPath / mergeStrategy=replace / value。本模块显式 reloadUserConfig=false，不把热重载当默认线程生效证明。

native-batch-probe.json / native-batch-rpc.json 先于生产扩展核验：同一 root user owner 实际给出两个字段的 origin/file/version；一次 batch 把两个不同型号后缀改为新 provider，status=ok、overriddenMetadata 为空，config/read 两字段值和版本均匹配。旧 expectedVersion 重放拒绝；第二项空 keyPath 非法 edit 拒绝；两类失败的整份文件字节保持。没有直接编辑改名后的客户端文件。

二进制为已归档的官方 Codex 0.166.0，SHA256=39acf979729dd290f9a24ee38b2914e036c91b65952872e28ae2a6b88a7db7c1。所有原生运行均为临时 HOME/CODEX_HOME/cwd/SQLite，OS 拒绝全部网络、日常用户树与 Keychain；不调用 turn/start、exec 或真实工具，不使用真实 Key。

## 预检与写入边界

两个待更新字段先完整预检，各自检查 user origin、明确 CODEX_HOME 内的规范化文件、活动 profile、layer、原值和版本。值为 None 或没有 origin 的字段是 noop，不猜 root。存在 origin 且旧 provider 命中的字段，若为 managed/project/不匹配文件/未绑定 profile/版本与 layer 不一致，则整个计划写前失败。

一次 native batch 仅保证同一文件 owner 内的原子性，因此两个命中字段必须同 file/profile/source/version。即使 root 和 profile 各自可写，若本轮命中跨两个文件，也在预检拒绝，不拆成两个可能半成功的写操作。profile 成功分支由明确 user/profile layer 的合成 owner 检验；真实 0.166.0 的 app-server 不支持 --profile，这一版本只计实际写前拒绝，未宣称真实活动 profile 更新成功。

apply 在 producer 后重新读取两个计划字段，要求各自原值和来源不变；无关 injection 字段改变版本被允许，以新观测 version 做 CAS。双字段一次 config/batchWrite；仅一个字段命中时保留 config/value/write 路径，包含 review_model 单独命中的情况。

写后必须 status=ok、没有 overriddenMetadata，并由 config/read 对每个计划字段核验新值/同来源/同回执版本。任何字段不符均失败；有有效回执则按该回执 expectedVersion 一次恢复本轮原字段集合，读回对应 layer。后续外部编辑导致补偿 CAS 冲突时，保留外部编辑，明确返回 repair_conflict，绝不借新版本覆盖。丢失/无效回执仍如实报结果未确认，不假称回滚完成。

## 测试及证据索引

- verification.json、tests.stdout、tests.stderr：本子轮实际测试二进制与源码 SHA，真实 owner 加失败反例的完整运行结果。
- real-root-default.json：生产双字段模块一次实际 root owner 更新；新官方进程 config/read 两字段均为新 provider，无 model/config 覆盖的 thread/start 采用新 model，历史哨兵保持。
- real-single-review-unset.json：真实单 model、review_model 单独设置、其它 model 保持、两值 None noop。
- real-batch-atomic-refusal.json：实际 native batch 的非法第二项和 stale CAS 拒绝，两字段/整份文件字节保持。
- real-selection-profile-refusal.json：真实新选择保持及当前版本活动 profile 写前拒绝。
- windows-typecheck.json：同一扩展模块及实际 platform / OwnedQueryJob 的 MSVC 目标编译检查；不代表实际 Windows owner 运行已验收。

失败反例覆盖 review_model 单独来自 project/system/另一 profile、两字段版本不一致、producer 后 review 值/来源漂移、各自合法但跨 root/profile 文件、batch 被覆盖/读回任一字段不符、整批补偿和外部编辑保护。None / 缺 origin 的 noop 与未知 future_model 保持有独立断言。原单 model 的环境清理、超时、stdout/stderr 上限和进程树回收测试继续运行。

此处证明的是已注册生产模块的两个明确 current scalar，完整 live provider 接纳、credential pool/header、GUI restart、发布 gate 由父线另行验收；不把上游候选 spike 或本模块测试替代整条产品链。
