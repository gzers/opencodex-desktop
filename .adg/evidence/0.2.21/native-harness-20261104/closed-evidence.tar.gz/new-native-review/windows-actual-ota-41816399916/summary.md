Windows actual OTA 41816399916：MSI、NSIS 两格通过，0.2.20 → 0.2.21，真实 beta 渠道。

产品启动日志均读回 6e2197fd0b8a36dcb8d893b62693c5a2a77151cc；原始构建 SHA256 为 20c6a2477dd0c1f186702b6dc598d281e16410be62ca96e6a9070a905ef5559f。

| 路径 | 两次完整下载字节数 | 已安装 EXE SHA256 | 验签 / 自动重启 / 文件读回 / pending 清除 |
|---|---:|---|---|
| MSI | 7434240 | fe12dfe66a707ffebb35d1b9ded67cd45ea57c226293cdab0c88a6991329cd54 | 全部通过 |
| NSIS | 5303851 | b97a0cfc23910a59a37a7a31dd14452da6d64276fa26bc1aa4236a1305ae9892 | 全部通过 |

普通退出保留 0.2.20；明确确认更新后观察到新的 0.2.21 进程。自动重启由 OS 进程记录证明，随后用同一更新 EXE 的显式 sandbox 重启做 Tauri 与真实文件读回。合成 Key/config 字节与不可变根保持，pending 清除。

两份原始 ZIP 的服务端 digest 已核对；完整包、日志、摘要均在同目录。安装器下载 URL/包 SHA 未单独写入 OTA 回执；same-original 依据完整安装 EXE SHA、原包身份回执、真实 beta 签名验证及完整下载字节数。

独立 9e 安装矩阵保持 failure：MSI custom 在 WebDAV 观察阶段被漏列的本地只读 model_agent_preferences 误拦；安装/几何输入检查已通过。这是检查工具漏项，无已证实软件故障。精确白名单补齐与拒绝保存测试已 17/17；修复后原包 case 由父级复验。既有三格和新 MSI default 的跨明确驱动身份组合见 ../windows-original-installers-four-cells.identity.json。
