# 1313 真实生产 prepare：native CAS 版本域仍不匹配

**未放行。前缀修复已生效，但真实生产 prepare 仍返回 client_selection_changed。原始文件字节 SHA 不能直接作为 Codex config/read 的 owner 版本，本轮两者值实际不同。没有去 guard、fallback、手工改配置或重跑。**

冻结完整提交 1313e676cb6f10607dddc8cf91a7d01db5818f7d。[一次实际运行 160917](run-20261104-160917/result.json)，[机器分析](production-prepare-1313-result.json)。本轮只重链一次，helper SHA256=22a9b601b51398361a15494b280d3a7ecba3dc4a4539ce47b22d0d59603f90ad。213 项实际生产/构建输入从编译前到运行后完全一致。BF pending 与失败没有改写为通过。

## 实际覆盖

1. 隔离预检、官方旧 producer、未修改 OpenCodex CLI /readyz 全通过。
2. 实际 Management 使用 native-integrations 唯一 Codex 行，state=current、installed=true、返回的绝对 configPath/runtime.path 已核验。旧官方 Codex 读取旧当前 model 和两条 Krill-1 目录。
3. 实际 save_with_context changed=true，真实 ClientEffects 写入 pending e400c1ce-5043-45b3-9e39-e1c38c6ce9ff。
4. 实际 prepare_saved_rename_restart 返回 client_selection_changed / 未覆盖新选择，exit23。pending 在 save stdout、prepare stdout 和最终原文件三处逐值一致，未 ack。
5. prepare 失败后停止：没有运行新客户端无覆盖/default route、模型请求或 safe-commit 副本检查。本次不存在可计为全链成功的回执。

[保存](run-20261104-160917/production-save.stdout)、[实际拒绝](run-20261104-160917/actual-production-prepare.stdout)、[保留 pending](run-20261104-160917/actual-pending-after-refusal.json)。

## 版本证据

同一旧当前 config 文件：

- [原始 config.toml](run-20261104-160917/old-current-default-fixture.toml) 的 raw-file SHA256：a77eeded4314a761675aac18805e64cfaa19d3f20ceb758823a73184c3ca969c。
- [真实 Codex config/read](run-20261104-160917/old-effective-config.json) 的 origins.model.version：sha256:d9d83d2826ad70f0324e084f9e45b0595e7f9db974346e588cb4402dd86e1526。
- config origin 指向的文件正是同一临时 .codex/config.toml。无需假设外部来源或历史会话才能解释此差异。
- 同次运行的 [被动只读快照](run-20261104-160917/passive-owned-client-snapshots/manifest.json) 记录 seed 前后原始字节，没有任何运行态写操作；带旧 model 的快照 raw hash 与归档旧文件完全相同。观察是采样而非每次系统调用 trace；未冒称捕获了内部 CAS 参数。

1313 的 verify_client_route 现在直接返回 store::sha256(&bytes)，虽然前缀只有一次，仍然是 raw-byte SHA。client_selection_rename::apply_at_version 把这个值和原生 owner 的 origins/layers version 比较；它们属于不同版本域，不能凭同为 sha256: 就视为同一合同。详情见 [native-version-contract-mismatch.json](run-20261104-160917/native-version-contract-mismatch.json)。

## 保留门禁的最小接入方向

将两个证明分开：root route 校验保留原始文件 digest，确认实际 owner/endpoint；原生 expectedVersion 只能取真实 Codex config/read 对同一已验证文件/字段的版本。读取原生 token 时用前后 raw-file digest/来源一致性把它锚定到那份已验路由文件，再交给原生 CAS，不自行构造 native version。若期间变化仍拒绝，不能删掉 apply_at_version 以求通过。

本报告没有断言 Codex 内部具体怎样规范化 TOML 来派生版本，只记录原始值实测不相等；主线可按实际原生合同接线并补回归。产品修改归 parent，本 worker 未改源码或扩大 setup。

## 安全收尾

无 global restart，无模型/真实 WebDAV/外网请求，无日常配置或凭据操作。全部 owned 子进程已回收，61950/61949 均 ECONNREFUSED；新临时 home 专属 SQLite 文件已精确清理。原 pending 与 owned 合成状态保留作审计。source/ 是本轮运行时 smoke 和生成 helper 的逐字节归档，不冒称为 BF 或未来版本。

releaseGatePassed=false。等待 parent 对 native token 域合同修复后再明确新冻结，不能把本次重跑或回填为通过。
