import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'
import path from 'node:path'
const ui='/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/ui'
const evidence=path.dirname(new URL(import.meta.url).pathname)
const require=createRequire(ui+'/package.json')
const {createServer}=await import(pathToFileURL(require.resolve('vite')).href)
const {default:vue}=await import(pathToFileURL(require.resolve('@vitejs/plugin-vue')).href)
const inert=['AppSidebar','TrayRoute','ToastHost','TaskProgressHost','NotificationCenter','RuntimeInstallDialog','SyncDialogHost']
const server=await createServer({root:ui,configFile:false,plugins:[{name:'remaining-isolated-fixtures',enforce:'pre',resolveId(id){if(id==='@tauri-apps/api/core')return '\0remaining-core'},load(id){if(id==='\0remaining-core')return 'export const invoke=(...args)=>window.__qaInvoke(...args); export const isTauri=()=>false; export const convertFileSrc=v=>v; export const transformCallback=()=>0; export class Channel { constructor(){this.id=0} }'},transform(source,id){if(id===ui+'/src/App.vue'){for(const name of inert)source=source.replace(new RegExp("import "+name+" from [^\\n]+\\n"),'const '+name+' = { render: () => null }\n');source=source.replace(/import \{ useAppController \} from [^\n]+\n/,'const useAppController = () => ({})\n');return source}if([ui+'/src/routes/OverviewRoute.vue',ui+'/src/routes/SettingsRoute.vue',ui+'/src/routes/ModelsRoute.vue'].includes(id)){source=source.replace(/import AppTopbar from [^\n]+\n/,'const AppTopbar = { render: () => null }\n');if(id.endsWith('/OverviewRoute.vue'))source=source.replace(/import \{ useAppController \} from [^\n]+\n/,'const useAppController = () => window.qaController\n');return source}}},vue()],resolve:{alias:{'@':ui+'/src',vue:require.resolve('vue/dist/vue.esm-bundler.js'),pinia:require.resolve('pinia')}},server:{host:'127.0.0.1',port:5198,strictPort:true,fs:{allow:[ui,evidence]}},clearScreen:false})
await server.listen();console.log('URL=http://127.0.0.1:5198/@fs/'+evidence+'/browser-harness.html')
process.on('SIGTERM',async()=>{await server.close();process.exit(0)})
