> 补充当前配置默认项：[CURRENT-DEFAULT.md](CURRENT-DEFAULT.md) 已实测确认 config.toml 的旧 model 未迁移，新 Codex 无覆盖 thread/start 仍取旧标识；这也是当前引用发布门，不属于历史兼容。

# d20 true producer 隔离验证：目录通过，运行态改名路由未通过

**结论：自动目录生成、新官方 Codex 加载和本机响应消费均有真实证据；完整改名路由未通过，发布门保留。发现旧运行态 provider/default 未接纳磁盘改名，不能将本机收到响应当作新 provider 路由正确。**

源码核心身份：d20ac7f9ca73f155a77d536618ab8ba3d6b32da3。最终运行时工作区 HEAD 为 b6da17601669000ab0891957cde28c7372a70e0a（主线随后提交 native 测试）；对 d20 的 tauri/src、Cargo/build/tauri 配置差异为空。核心冻结后只构建一次（142530），后续仅复用该二进制与 17/17 守卫证据，逐项匹配原始生产源码、helper、guard 源码/二进制摘要。210 份受检生产文件从最终构建到运行结束没有漂移。

## 已完成的实际链

最终尝试为 [143309](run-20261104-143309/result.json)，原始结果失败保留；拆分事实见 [verification.json](verification.json)，未把历史失败改写成成功。

| 步骤 | 实际结果 |
| --- | --- |
| 生产 true 路由守卫 | [17/17](run-20261104-142530/production-true-route-guards.stdout)；原生产 cache_refresh_tests.rs 按路径原样注册，链接 d20 生产库。测试 HTTP 全部是自建 attested loopback fixture，无官方全局重启 |
| 旧集成准备 | 临时 v1 service-state/plist 文件夹具；官方 transition-state 初始化自身协调状态，然后实际 syncModelsToCodex 生成旧集成；无手写 routed catalog |
| 旧客户端 | 真 Codex app-server model/list 返回 Krill-1/owned-routing-model 和 Krill-1/owned-second-model |
| 实际保存 | [save_with_context](run-20261104-143309/production-save.stdout) changed=true，稳定 channel.id/型号身份及当前配置引用保持，provider/default 改为 Krill |
| 真实 producer | 同一个已启动的官方 OpenCodex 服务接收空 POST /api/sync；先核验本机 HMAC 身份才读取临时 token。返回 applied、ok=true、refreshOutcome=committed、added=2、catalogWritten=true、cacheSynced=true |
| 自动新目录 | 新官方 Codex app-server 返回 Krill/owned-routing-model 和 Krill/owned-second-model，旧前缀消失；本轮改名后 manual-catalog 调用数为 0 |
| 本地往返 | Codex exec 选择 Krill/owned-routing-model，唯一 POST 到受控 127.0.0.1:/v1/responses，合成 Key 匹配；消费 OCX021_LOCAL_FIXTURE_OK，turn.completed、退出 0 |
| 路由失败点 | 终点 body.model 实际为 Krill/owned-routing-model，预期为 owned-routing-model；官方 usage.provider 仍是 Krill-1，routeKind=default-provider |

直接证据：[producer 回执](run-20261104-143309/official-producer-sync.json)、[新 Codex RPC](run-20261104-143309/codex-after-official-producer.json)、[请求](run-20261104-143309/fixture-requests.json)、[实际官方路由日志](run-20261104-143309/owned-routing-usage.json)、[exec 输出](run-20261104-143309/automatic-chain-local-turn.stdout)、[最终消息](run-20261104-143309/automatic-last-message.txt)。日志/配置/凭据/用量全部是 owned 合成夹具，无供应商参与。

## 明确原因与主线可修入口

实际官方路由日志同时给出：requestedModel=Krill/owned-routing-model、provider=Krill-1、routeKind=default-provider、resolvedModel=Krill/owned-routing-model。它排除了“只是一处显示名或测试解析错误”的解释。

1. 管理器 config_file::save_with_context 写磁盘并更新真实引用，但没有刷新上游服务内存配置；commands/model_config.rs 的保存接线未触发运行态 provider 重载。
2. OpenCodex 2.84.0 server/index.ts:216-227 在启动时取得 config 对象供路由使用。/api/sync（config-routes.ts:855-884）重新 loadConfig 交给真实目录 producer，却没有把新 provider/default 接纳进这个 live 对象。
3. 新 Codex 根据已正确生成的新目录发送 Krill/...。router.ts:832 起的显式 namespace 查找在旧 live providers 中找不到 Krill，于是走旧 defaultProvider Krill-1。core-normalize.ts:162 起只在解析出不同原始 modelId 时剥离 namespace；这次默认 fallback 没有剥离，因此终点仍带 Krill/ 前缀。
4. runCodexRestart.defaultSyncCatalog 调用同一 syncModelsToCodex，然后只退出/拉起 Codex app-server/桌面；它本身并不重新启动或接纳 OpenCodex live provider。API producer 与 true 入口在这一点没有可用于消除本问题的差异。

主线需要一个真实运行态同步步骤，且不得扩大 false 分支合同。已有上游 POST /api/providers/reload（provider-routes.ts:955-1037）使用进程绑定 HMAC capability，可从磁盘接纳一个 provider；普通 admin Bearer 对该路由不够。该操作底层 adoptPersistedProviderIntoLiveConfig（config/live-reconcile.ts:129）只加/换指定 provider，不自动删除旧 Krill-1 或改 default。因此它是可修接线的起点，**单独调用一次 reload 不能被当作完整 rename 事务已满足**。需要同时处理旧 provider 撤销、默认项/相关 live 引用、缓存失效及真实上游的原子/回滚合同，或采用明确授权的等价官方运行服务重载方式。

本 worker 未改生产代码，也未执行补救 reload 或偷偷重启官方 proxy 来制造通过。这个失败由最终真实用户链输入暴露，不能靠重开 OpenCodex proxy 或改用新启动服务来替代“保存→立即重启 Codex”的验收。

## 隔离调整与尝试身份

- 142530：d20 构建成功、guard 17/17。官方启动时 SQLite 报 unable to open database file；没有执行保存。原因是发布物 user-identity.ts 的 POSIX coordinator 固定使用 /private/tmp/opencodex-runtime-v1-501，不跟随 HOME/TMPDIR，原全局写拒绝阻断了新临时 home 的专属锁。
- 143144：没有重编译。只给新临时 CODEX_HOME 的 SHA256 对应两组 SQLite 名及 -journal/-wal/-shm 精确例外，整个共享目录其它库读取仍拒绝；先验证官方锁序列化。服务能生成旧 catalog，但 raw SQLite 预检留下的空库缺 transition row，被官方防残留保护拒绝注入。尚未保存；失败保留。
- 143309：仍复用 d20 一次编译。旧侧夹具在 routed catalog 出现前通过原发布物 openCodexCoordinatorTransaction 初始化，再用真实 syncModelsToCodex 建立一致旧集成。随后的未修改官方 CLI 启动就绪，完成上述真实保存/共享 producer/新客户端/本地请求，最终路由断言失败。

只对新临时 CODEX_HOME 的完整 SHA256 精确路径开例外，运行前所有对应文件均不存在；未读写其它锁库。两次新专属 coordinator 文件已在回收 owned 子进程后精确清理，共删除 4 个新 SQLite 文件，保留共享目录与所有其它文件。[清理回执](owned-coordinator-cleanup.json)。

全部配置 HOME/CODEX_HOME/SQLite/XDG/TMP/工作目录明确指向新临时根；Node/Bun/Codex 使用核验绝对入口；不继承账号/渠道/代理环境。OS 沙箱拒绝真实用户树、Keychain IPC、外网，只放行两个 owned 本机端口；guard 测试专用进程因动态 fixture 端口仅放行 loopback。唯一额外 API integration 回执为 claude-desktop busy_or_unsafe，未成功接纳；它仍受真实用户树拒读保护，不作为 Codex 证据。

没有调用官方 /api/system/codex-restart；没有终止/重启日常 Codex，没有服务管理器变更，没有真实 WebDAV/模型网络。owned 服务/客户端均回收，两个端口 ECONNREFUSED。桌面 GUI 真实退出/拉起未验证。

## 可复用脚本和后续检查

脚本在代码根 test/smoke/ocx021-owned-routing.py、.rs、.mjs、.coordinator.mjs。默认只读清单；自动模式改名后禁止 sidecar。真正执行版本的逐字节源码在 provenance-final-d20/run-*，已与 143309 运行时 smokeSourceSha256 全部匹配；后续仅增强结果拆分与 usage 路由断言，没有重跑，差异单列在 source-identity.json。

安全的复现命令（会重新构建；须用届时主线确认的产品提交，不把未来提交冒称 d20）：

    python3 test/smoke/ocx021-owned-routing.py --run --automatic-chain --seed-installed-fixture --allow-owned-coordinator-files --source-freeze-head d20ac7f9ca73f155a77d536618ab8ba3d6b32da3

当前源码行为下应保留新目录通过、live provider 路由失败。修复接线后，下一轮只需确认新 freeze 与运行态同步调用位置，再复用严格原始型号/实际 provider 断言；不能删断言、把默认渠道回退算成功或重放手工 135035 结果。

主线发布门仍需：修复/明确 live provider rename 同步并补对应错误/回滚证据；重验此组合链；将真实 GUI 重启边界与已存在原生 keychain 1/1、平台验收分别汇总。没有改 DMD、关闭 TASK 或做 git add/commit/push。
