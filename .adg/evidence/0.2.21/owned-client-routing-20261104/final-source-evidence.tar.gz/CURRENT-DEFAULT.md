# 当前客户端默认模型引用：隔离实测未通过

**确认第二项当前配置缺口：目录已自动改为 Krill/...，config.toml 的 model 默认选择仍是 Krill-1/...；新 Codex 不带显式覆盖的线程也继续采用旧值，没有迁移或可核验 fallback。它属于当前配置引用，不是历史会话兼容。**

[机器结果](current-default-verification.json)，[原始运行](run-20261104-144504/result.json)。复用 d20ac7f9ca73f155a77d536618ab8ba3d6b32da3 的已核验保存 helper，没有重新编译产品源码。与 143309 的 live provider 未重载是两项独立问题，均保留，不互相抵消。

## 旧证据的覆盖边界

143309 初始 config.toml 没有根 model 设置；producer 后归档 automatic-config.toml 也没有该设置。那次 exec 使用 --model Krill/owned-routing-model，因此只证明显式新选择器的行为，**不能证明已保存的默认选择一致**。没有把它补算为默认引用已通过。

## 新的实际检查

1. 全新临时 HOME/CODEX_HOME/XDG/SQLite/work 中，原始 native metadata、旧安装态夹具及官方 transition owner 建立合法旧集成。旧 catalog/注入由未修改的实际 syncModelsToCodex 生成。
2. 仅在改名前 seed 合成用户当前选择：model = "Krill-1/owned-routing-model"。真实旧 Codex 的 config/read 先确认已加载该设置。
3. 实际 d20 config_file::save_with_context 改 Krill-1→Krill；之后仅实际官方 syncModelsToCodex 写目录和客户端注入。本轮没有运行手工 catalog sidecar，没有手改改名后的客户端 model。
4. producer 实际返回 applied、ok=true、refreshOutcome=committed、catalogWritten=true、cacheSynced=true。新 Codex model/list 为 Krill/owned-routing-model 与 Krill/owned-second-model。
5. 同一新 Codex 的 config/read 仍返回 model=Krill-1/owned-routing-model。thread/start 的请求**没有 model 或 config 覆盖字段**，ephemeral=true；返回 model 同样为 Krill-1/owned-routing-model，没有可核验 fallback。

直接证据：

- [旧默认夹具来源](run-20261104-144504/old-current-model-fixture.json)
- [改名前 config.toml](run-20261104-144504/client-config-before-rename.toml)
- [producer 后 config.toml](run-20261104-144504/client-config-after-producer.toml)：两份字节完全相同，摘要见机器结果
- [真实 producer 原始结果](run-20261104-144504/official-producer-current-default.stdout)
- [新客户端实际 config/read](run-20261104-144504/codex-config-after.json)
- [新目录](run-20261104-144504/codex-models-after.json)
- [无 model 覆盖的 RPC 原文](run-20261104-144504/codex-default-after.json)
- [默认 thread/start 返回](run-20261104-144504/codex-default-thread-start.json)

没有 turn/start 或 exec，没有生成请求；该专用探针从 OS 层拒绝全部网络（包括 loopback）。thread/start 可能尝试本机 WebSocket 预连接并被拒绝，原始 stderr 已保存，不把被拒绝的连接当模型请求或 fallback 证明。未触碰任何日常配置、历史线程或真实凭据。owned app-server 已回收，两个新专属 SQLite 文件已精确清理。

## 原因与最小 owner 接入

OpenCodex 2.84.0 的 inject/plan.ts 管理 openai_base_url、model_catalog_json、provider/profile 等注入字段，未消费渠道 old→new 映射去更新用户根 model。本次运行证明它在成功生成目录后仍保留旧默认值。它没有在 producer 回执中声明改名 fallback；Codex 新线程也实际保留旧值，因此不能依赖隐式 fallback。

可用的**官方客户端配置 owner**是 Codex 0.166.0 app-server 的 config/value/write，具体 schema 已从原生发布二进制导出并归档：[参数](run-20261104-144504/ConfigValueWriteParams.json)、[返回](run-20261104-144504/ConfigWriteResponse.json)。config/read.origins.model 给出真实 user 层文件和版本，本次为临时 CODEX_HOME/config.toml、profile=null。官方接口支持 filePath、keyPath="model"、mergeStrategy="replace"、value 及 expectedVersion。

主线最小可审接线：

1. 在保存/确认计划内保留真实 old→new provider 映射，并从绑定的官方 Codex 会话读取当前配置及 model 来源/版本；只有当前 model 的完整 provider 段确为旧标识时形成迁移意图，原始模型后缀逐字保留，不全局替换。
2. 让官方 config/value/write 在已确认的实际配置 owner 文件上执行期望版本写入。遇到 managed/project/profile 覆盖、版本漂移或不可写来源，应明确拒绝/重新预览；不能盲写默认根文件来掩盖有效层覆盖。已有 profiles/其它 current selector 字段本轮没有 seed，仍需按真实来源补齐范围。
3. 检查返回 status、overriddenMetadata、version，再 config/read 读回；okOverridden 不能当有效默认已变更。与管理器配置保存的失败/回滚/补偿和通知事实需由主线事务明确连接；不能保存一半后无条件显示成功。
4. 再重开客户端验证不带 model 覆盖的 thread/start 选择新标识，并与新 catalog 一致；修复 143309 的 live provider/default 问题后才验证真正新 provider 的原始型号路由。

[具体待审 owner 请求](run-20261104-144504/proposed-owner-request-not-executed.json) 已按实际 origin/version 构造，**没有执行**。该建议由已导出的官方 schema 支持，但接线与完整错误合同尚未实现；本 worker 不手改客户端后再计通过。

ConfigBatchWriteParams 的 reloadUserConfig 文档明确不热更新 session-static model/reasoning/service-tier 默认，因此即使采用官方写 owner，也仍需新客户端/新线程证明；不能把一个写成功回执代替默认选择生效。

## 复现

在代码根，仅用仍保留的不可变 d20 构建：

    python3 test/smoke/ocx021-owned-routing.defaults.py --build-evidence ../governance-main/.adg/evidence/0.2.21/owned-client-routing-20261104/run-20261104-142530 --source-freeze-head d20ac7f9ca73f155a77d536618ab8ba3d6b32da3

原运行全部 smoke 源快照已按运行时 SHA-256 保存在 run-20261104-144504/source/。交付脚本另加防止 Python 导入写 bytecode 的设置；未重跑，不改原运行身份。仅新增指定 smoke 文件与本证据，无生产代码修改，无提交/推送。当前默认一致性 gatePassed=false。
