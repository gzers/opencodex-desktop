const test=require('node:test'),assert=require('node:assert/strict');
const {make}=require('./component-topic-harness.cjs');
const clean=h=>{assert.deepEqual(h.errors,[]);assert.equal(h.network.length,0);};
test('非功能菜单进入独立专题，复用Logo源并保持业务草稿与概览独立',async t=>{
 const h=await make('#conversations'),{w,document:d}=h;t.after(()=>h.dispose());
 const saved=JSON.stringify(w.conversationPrototype.state().saved),model=JSON.stringify(w.modelPrototype.state().saved),frame=d.querySelector('.cm-backdrop');
 assert.equal(frame.hasAttribute('src'),false);assert.ok(d.querySelector('[aria-labelledby="launchNonFunctionalTitle"] [data-launch="connection-map"]'));
 h.click('[data-launch="connection-map"]');await h.settle();assert.equal(d.documentElement.dataset.route,'connection-map');assert.match(frame.src,/Logo%E6%9C%AC%E4%BD%93|Logo本体/);assert.match(frame.src,/layout=hero/);assert.equal(d.querySelector('#connectionMapDemoCard').hidden,false);
 assert.ok(!d.querySelector('#route-overview #cmTitle'));assert.equal(JSON.stringify(w.conversationPrototype.state().saved),saved);assert.equal(JSON.stringify(w.modelPrototype.state().saved),model);clean(h);
});
test('直连、代理停止和读取失败分别表达路径与运行状态，不生成请求观察',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());
 h.click('[data-cm-scene="direct"]');assert.equal(w.connectionMapPrototype.state().direct,true);assert.match(d.querySelector('#cmObservation').textContent,/直连.*实际请求未观察/);assert.match(d.querySelector('[data-cm-node="proxy"]').textContent,/已绕过/);
 h.click('[data-cm-scene="stopped"]');assert.equal(w.connectionMapPrototype.state().motion,'stopped');assert.match(d.querySelector('#cmObservation').textContent,/未运行.*未观察/);
 h.click('[data-cm-scene="unavailable"]');assert.match(d.querySelector('#cmObservation').textContent,/读取失败.*上次/);assert.equal(w.connectionMapPrototype.state().known,false);clean(h);
});
test('图和列表共用回退及多来源关系，选中详情与关闭保持关联',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());
 h.click('[data-cm-scene="fallback"]');assert.ok(d.querySelector('[data-cm-node="backup"]'));h.click('[data-cm-node="backup"]');assert.equal(w.connectionMapPrototype.state().selected,'backup');assert.match(d.querySelector('#cmDetail').textContent,/第二次尝试/);
 h.click('[data-view="list"]');assert.equal(d.querySelector('#cmGraph').hidden,true);assert.match(d.querySelector('#cmList').textContent,/管理.*Desktop 管理器 → OpenCodex.*OpenCodex → Krill.*OpenCodex → NewApi/s);assert.equal(w.connectionMapPrototype.state().selected,'backup');h.click('[data-cm="close-detail"]');assert.equal(d.querySelector('#cmDetail').hidden,true);
 h.click('[data-cm-scene="multiple"]');assert.match(d.querySelector('#cmList').textContent,/Codex CLI → OpenCodex/);h.click('[data-view="graph"]');assert.ok(d.querySelector('[data-cm-node="cli"]'));clean(h);
});
test('场景与主题变更保留同一Logo容器，离开停止活跃，重新进入保留场景',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());const frame=d.querySelector('.cm-backdrop');
 h.click('[data-cm-scene="multiple"]');d.documentElement.dataset.theme='dark';await h.settle();assert.equal(d.querySelector('.cm-backdrop'),frame);assert.equal(d.querySelector('#connectionMapPage').dataset.active,'true');
 h.click('[data-route="overview"]');await h.settle();assert.equal(d.querySelector('#connectionMapPage').dataset.active,'false');h.click('[data-launch="connection-map"]');await h.settle();assert.equal(w.connectionMapPrototype.state().scene,'multiple');assert.equal(d.querySelector('.cm-backdrop'),frame);clean(h);
});
