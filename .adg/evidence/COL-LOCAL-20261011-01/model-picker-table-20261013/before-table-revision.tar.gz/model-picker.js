/* 公共渠道模型选择器：独立非功能打样，所有目录和返回结果均为内存 fixture。 */
(() => {
 'use strict';
 const $=(q,r=document)=>r.querySelector(q), $$=(q,r=document)=>[...r.querySelectorAll(q)];
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const clone=v=>JSON.parse(JSON.stringify(v));
 const modal=$('#modal'),body=$('#modalBody'),footer=$('.modal-actions',modal);
 if(!modal||!$('#launchNonFunctionalTitle'))return;
 const keyFor=ref=>ref.kind==='native'?JSON.stringify(['native',ref.nativeModelId]):JSON.stringify(['channel',ref.channelId,ref.modelId]);
 const resultFor=(kind,ids)=>({kind,...(kind==='models'?{models:ids.map(id=>clone(catalog.find(m=>m.key===id)?.ref||unresolved.get(id)?.ref)).filter(Boolean)}:{})});
 let mode='single',scenario='normal',inheritEnabled=true,orderEnabled=true,recommendedEnabled=true,isOpen=false;
 let catalog=[],channels=[],pending=[],channel='all',query='',sort='configured',inherited=false,pickedOpen=false,opener=null;
 let originals={},committed={single:{kind:'models',models:[{kind:'channel',channelId:'newapi',modelId:'gpt-5.4'}]},multiple:{kind:'models',models:[{kind:'channel',channelId:'newapi',modelId:'gpt-5.4'},{kind:'channel',channelId:'aimami',modelId:'gpt-5.4-mini'}]}};
 let unresolved=new Map(),lastOutcome='尚未返回选择。',browseScroll=0,channelScroll=0;
 const lastOutcomes={single:'尚未返回选择。',multiple:'尚未返回选择。'};
 let commonWasOpen=false;
 const inheritedRefs=[{kind:'channel',channelId:'newapi',modelId:'gpt-5.4'}];
 const recommendedRefs=[{kind:'channel',channelId:'newapi',modelId:'gpt-5.4-mini'},{kind:'channel',channelId:'aimami',modelId:'gpt-5.4'}];
 const titleFor=id=>catalog.find(m=>m.key===id)?.name||unresolved.get(id)?.name||'未解析模型';
 const locationFor=id=>{const m=catalog.find(m=>m.key===id);return m?m.channelName+' / '+m.rawId:unresolved.get(id)?.description||'引用无法解析';};
 function loadCatalog(){
  const state=window.modelPrototype?.state();channels=(state?.saved.providers||[]).map((p,i)=>({id:p.id,name:p.name,position:i,enabled:p.enabled,availability:p.availability?.kind}));catalog=[];
  for(const p of state?.saved.providers||[])for(const [i,m] of p.models.entries()){
   const ref=p.id==='native'?{kind:'native',nativeModelId:m.id}:{kind:'channel',channelId:p.id,modelId:m.id};
   let reason=!p.enabled?'渠道已停用':({ 'no-credit':'渠道无额度（示例）','auth-failed':'认证未通过','connection-failed':'连接不可用',unavailable:'上游不可用'})[p.availability?.kind]||'';
   const name=m.naming?.displayName||(m.id==='gpt-5.4'?'GPT 5.4':m.id==='gpt-5.4-mini'?'GPT 5.4 mini':m.id);
   catalog.push({key:keyFor(ref),ref,channel:p.id,channelName:p.name,name,rawId:m.id,alias:m.naming?.alias||'',position:catalog.length,mainPickerSelected:!!m.selected,reason});
  }
  if(scenario==='long'){
   channels.push({id:'enterprise-demo',name:'企业自建模型网关 · 长渠道名称示例',position:channels.length});
   for(let i=0;i<8;i++){const ref={kind:'channel',channelId:'enterprise-demo',modelId:'company-development-model-with-a-very-long-upstream-identifier-'+(i+1)};catalog.push({key:keyFor(ref),ref,channel:'enterprise-demo',channelName:channels.at(-1).name,name:'企业研发模型 · 长名称换行 '+(i+1),rawId:ref.modelId,alias:'company-'+(i+1),position:catalog.length,reason:'',mainPickerSelected:false});}
  }
  if(scenario==='empty')catalog=[];
  unresolved=new Map();
  for(const item of Object.values(committed))for(const ref of item.models||[])if(!catalog.some(m=>m.key===keyFor(ref)))unresolved.set(keyFor(ref),{ref:clone(ref),name:ref.modelId||ref.nativeModelId,description:(ref.channelId||'原生')+' / '+(ref.modelId||ref.nativeModelId)+' · 当前目录缺失'});
 }
 const matches=m=>!query||[m.name,m.rawId,m.alias].some(x=>x.toLocaleLowerCase().includes(query.toLocaleLowerCase().trim()));
 function filtered(){
  const rows=catalog.filter(m=>(channel==='all'||m.channel===channel)&&matches(m));
  if(sort==='name-asc'||sort==='name-desc')rows.sort((a,b)=>(sort==='name-asc'?1:-1)*(a.name.localeCompare(b.name,'zh-CN')||a.rawId.localeCompare(b.rawId))||a.position-b.position);
  else if(sort==='recommended'){const preferred=recommendedRefs.map(keyFor);rows.sort((a,b)=>{const ai=preferred.indexOf(a.key),bi=preferred.indexOf(b.key);return (ai<0?100000:ai)-(bi<0?100000:bi)||a.position-b.position;});}
  return rows;
 }
 const eligible=()=>filtered().filter(m=>!m.reason).map(m=>m.key);
 function channelHTML(){
  const count=id=>catalog.filter(m=>(id==='all'||m.channel===id)&&matches(m)).length;
  const row=(id,name)=>'<button type="button" class="mpk-channel" data-mpk="channel" data-id="'+esc(id)+'" aria-label="查看'+esc(name)+'模型" aria-current="'+(channel===id)+'"><span>'+esc(name)+'</span><small>'+count(id)+'</small></button>';
  return row('all','全部')+'<div class="mpk-channels-list">'+channels.map(c=>row(c.id,c.name)).join('')+'</div>';
 }
 function inheritHTML(){
  if(!inheritEnabled)return '';
  const refs=mode==='single'?inheritedRefs:inheritedRefs.concat([{kind:'channel',channelId:'newapi',modelId:'gpt-5.4-mini'}]);
  const text=refs.map(r=>locationFor(keyFor(r))).join('、');
  return '<div class="mpk-inherit"><button type="button" data-mpk="inherit" aria-label="'+(mode==='single'?'沿用上层模型':'沿用上层模型列表')+'">'+(mode==='single'?'继承：':'继承列表：')+esc(text)+'<small>来自项目设置 · 继承会跟随上层变化</small></button><span class="mpk-badge">'+(inherited?'当前选择':mode==='single'?'可选':'整体继承')+'</span></div>';
 }
 function rowHTML(m){
  const checked=!inherited&&pending.includes(m.key),recommended=recommendedEnabled&&recommendedRefs.some(r=>keyFor(r)===m.key);
  const text='<span class="mpk-row-text"><strong>'+esc(m.name)+'</strong><small>'+esc(m.rawId)+(m.alias?' · 别名 '+esc(m.alias):'')+' · '+esc(m.channelName)+'</small>'+(m.reason?'<span class="mpk-row-reason">'+esc(m.reason)+'</span>':'')+'</span><span class="mpk-row-mark">'+(recommended?'推荐':checked?'已选':m.mainPickerSelected?'':'目录模型')+'</span>';
  if(mode==='single')return '<button type="button" class="mpk-row '+(checked?'is-picked ':'')+(m.reason?'is-disabled':'')+'" data-mpk="pick" data-key="'+esc(m.key)+'" aria-label="选择 '+esc(m.channelName+' / '+m.rawId)+'" '+(m.reason?'disabled':'')+'><span class="mpk-radio" aria-hidden="true"></span>'+text+'</button>';
  return '<label class="mpk-row '+(checked?'is-picked ':'')+(m.reason?'is-disabled':'')+'"><input type="checkbox" data-mpk-pick="'+esc(m.key)+'" aria-label="选择 '+esc(m.channelName+' / '+m.rawId)+'" '+(checked?'checked':'')+(m.reason&&!checked?' disabled':'')+'>'+text+'</label>';
 }
 function listHTML(){
  if(scenario==='loading')return '<div class="mpk-empty" role="status">正在读取已保存的模型目录…<br>渠道列表和已有选择保持。'+button('显示加载完成示例','load-finished')+'</div>';
  if(scenario==='failed')return '<div class="mpk-empty" role="status">目录读取失败<br>原选择没有改变。'+button('重试读取示例','load-finished')+'</div>';
  const rows=filtered();
  return rows.length?rows.map(rowHTML).join(''):'<div class="mpk-empty" role="status">'+(catalog.length?'没有匹配的模型<br>清空搜索或切到全部渠道。':'此目录暂无模型<br>已有选择可查看与移除。')+'<div>'+button('清空搜索','clear-search')+(channel==='all'?'':button('查看全部','all'))+'</div></div>';
 }
 const button=(name,action,attrs='')=>'<button type="button" class="btn ghost" data-mpk="'+action+'" '+attrs+'>'+name+'</button>';
 function batchHTML(){
  if(mode!=='multiple')return '';
  const ids=eligible(),count=inherited?0:ids.filter(id=>pending.includes(id)).length;
  return '<label><input type="checkbox" id="mpkSelectResults" aria-label="全选当前可选结果" '+(ids.length&&count===ids.length?'checked':'')+(ids.length?'':' disabled')+'>全选当前结果 · '+ids.length+' 个可选</label>';
 }
 function selectedHTML(){
  const ids=inherited?[]:pending;
  if(inherited)return '<p class="mpk-picked-title">整体继承上层列表，不混合本层额外模型。</p>';
  if(!ids.length)return '<p class="mpk-picked-title">尚未选择模型。</p>';
  return '<div class="mpk-picked-title">'+(orderEnabled?'已选优先级 · 浏览排序不会改变此顺序':'已选模型')+'</div>'+ids.map((id,i)=>'<div class="mpk-picked-row"><span>'+(orderEnabled?(i+1)+'. ':'')+esc(locationFor(id))+(!catalog.some(m=>m.key===id)?'<small> · 当前目录缺失</small>':'')+'</span>'+(orderEnabled?button('↑','move','data-key="'+esc(id)+'" data-direction="-1" aria-label="上移 '+esc(locationFor(id))+'" '+(i===0?'disabled':''))+button('↓','move','data-key="'+esc(id)+'" data-direction="1" aria-label="下移 '+esc(locationFor(id))+'" '+(i===ids.length-1?'disabled':'')):'')+button('移除','remove','data-key="'+esc(id)+'" aria-label="移除 '+esc(locationFor(id))+'"')+'</div>').join('');
 }
 function renderFooter(){
  const before=$('#mpkFooter');before?.remove();
  const summary=document.createElement('div');summary.id='mpkFooter';summary.className='mpk-summary';
  if(mode==='single')summary.textContent=pending.some(id=>unresolved.has(id))?'当前选择的模型已不在目录中；可重新选择，取消保持原引用。':'单选 · 点击模型即返回，配置保存由页面负责';
  else {
   const visibleKeys=new Set(filtered().map(m=>m.key)),outside=pending.filter(id=>!visibleKeys.has(id)).length;
   summary.innerHTML='<span role="status">'+(inherited?'继承上层列表':'已选 '+pending.length+' 项'+(outside?' · 列表外 '+outside+' 项':''))+'</span>'+button(pickedOpen?'收起已选':'查看已选','show-picked','aria-expanded="'+pickedOpen+'"')+button('清空选择','clear-picked',!pending.length&&!inherited?'disabled':'');
  }
  footer.prepend(summary);$('#modalConfirm').disabled=mode==='multiple'&&!inherited&&pending.some(id=>!catalog.some(m=>m.key===id)||catalog.find(m=>m.key===id)?.reason);
 }
 function renderLists(resetScroll=false){
  if(!isOpen)return;const list=$('#mpkModels'),nav=$('.mpk-channels-list');
  if(list)browseScroll=resetScroll?0:list.scrollTop;if(nav)channelScroll=nav.scrollTop;
  $('#mpkChannels').innerHTML=channelHTML();$('.mpk-channels-list').scrollTop=channelScroll;
  $('#mpkModels').innerHTML=listHTML();$('#mpkModels').scrollTop=browseScroll;
  $('#mpkScopeName').textContent=channel==='all'?'全部模型':channels.find(c=>c.id===channel)?.name||'当前渠道';
  $('#mpkResultCount').textContent=filtered().length+' 个结果';
  $('#mpkBatch').innerHTML=batchHTML();$('#mpkBatch').hidden=mode!=='multiple';
  const batch=$('#mpkSelectResults');if(batch){const ids=eligible(),picked=ids.filter(id=>pending.includes(id)).length;batch.indeterminate=!inherited&&picked>0&&picked<ids.length;}
  $('#mpkInheritSlot').innerHTML=inheritHTML();$('#mpkPicked').innerHTML=selectedHTML();$('#mpkPicked').hidden=!pickedOpen||mode!=='multiple';
  $('#mpkClearSearch').hidden=!query;renderFooter();
 }
 function shellHTML(){
  return '<div class="mpk-root"><div class="mpk-toolbar"><div class="mpk-search-box"><input class="input" id="mpkSearch" type="search" placeholder="搜索模型名称 / ID / 别名" aria-label="搜索模型" value="'+esc(query)+'"><button type="button" class="mpk-clear-search" id="mpkClearSearch" data-mpk="clear-search" aria-label="清空模型搜索" '+(!query?'hidden':'')+'>×</button></div><select id="mpkSort" aria-label="模型浏览排序"><option value="configured">已配置顺序</option><option value="name-asc">名称 A → Z</option><option value="name-desc">名称 Z → A</option>'+(recommendedEnabled?'<option value="recommended">推荐优先</option>':'')+'</select></div><div class="mpk-body"><nav class="mpk-channels" id="mpkChannels" aria-label="模型渠道"></nav><section class="mpk-browser" aria-label="模型浏览"><div class="mpk-scope-line"><strong id="mpkScopeName"></strong><span id="mpkResultCount"></span></div><div id="mpkInheritSlot"></div><div class="mpk-batch" id="mpkBatch"></div><div class="mpk-models" id="mpkModels" aria-label="可选模型列表" tabindex="0"></div></section></div><div class="mpk-picked" id="mpkPicked" hidden></div></div>';
 }
 function publishResult(){
  const result=committed[mode],items=result.kind==='inherit'?'<p>沿用上层设置，未固定模型快照。</p>':'<ol>'+(result.models||[]).map(ref=>'<li>'+esc((ref.channelId||'官方 / 原生')+' / '+(ref.modelId||ref.nativeModelId))+'</li>').join('')+'</ol>';
  $('#mpkDemoResult').innerHTML='<strong>本次返回</strong><p>'+esc(lastOutcome)+'</p>'+items;
  const launchResult=$('#mpkLaunchResult');if(launchResult){const models=result.models||[];launchResult.textContent=lastOutcome==='尚未返回选择。'?'单选 / 多选形式打样；不修改业务配置。':lastOutcome+'：'+(result.kind==='inherit'?'沿用上层':models.slice(0,2).map(ref=>(ref.channelId||'官方 / 原生')+' / '+(ref.modelId||ref.nativeModelId)).join('、')+(models.length>2?' 等 '+models.length+' 项':'')||'空列表');}
 }
 function accept(ids=pending,useInheritance=inherited){
  committed[mode]=useInheritance?{kind:'inherit'}:resultFor('models',ids);
  lastOutcome=mode==='single'?'单选已返回 · 仅打样结果，未改业务配置':'多选已确定 · '+(useInheritance?'整体继承':'返回 '+ids.length+' 个模型引用');
  lastOutcomes[mode]=lastOutcome;
  publishResult();closeModal();
 }
 function open(){
  if(isOpen)closeModal();if($('#modalMask').style.display==='flex')closeModal();
  loadCatalog();originals=clone(committed);pending=(committed[mode].models||[]).map(keyFor);inherited=committed[mode].kind==='inherit'&&inheritEnabled;
  if(scenario==='missing'){
   const ref={kind:'channel',channelId:'retired-demo',modelId:'removed-model'};const id=keyFor(ref);unresolved.set(id,{ref,name:ref.modelId,description:'已移除渠道 / removed-model'});if(mode==='single')pending=[id];else if(!pending.includes(id))pending.push(id);
  }
  channel='all';query='';sort='configured';pickedOpen=scenario==='missing'&&mode==='multiple';browseScroll=channelScroll=0;opener=document.activeElement;commonWasOpen=$('#protoCommon').open;$('#protoCommon').open=false;
  isOpen=true;
  openModal('选择模型',shellHTML(),'确定选择',()=>accept(),{hideNote:true,hideConfirm:mode==='single',confirmKeepsOpen:true,headActions:'<span class="mpk-badge">'+(mode==='single'?'单选':'多选')+'</span>'});
  modal.classList.add('mpk-dialog');document.documentElement.dataset.prototypeDialog='model-picker';document.documentElement.dataset.prototypePickerMode=mode;
  window.__modalOnClose=()=>{isOpen=false;$('#mpkFooter')?.remove();modal.classList.remove('mpk-dialog');delete document.documentElement.dataset.prototypeDialog;delete document.documentElement.dataset.prototypePickerMode;if(commonWasOpen)$('#protoCommon').open=true;window.prototypePanel?.refresh();opener?.isConnected&&opener.focus({preventScroll:true});};
  renderLists();window.prototypeSelect?.enhance();window.prototypePanel?.refresh();requestAnimationFrame(()=>$('#mpkSearch')?.focus({preventScroll:true}));
 }
 function updateScenario(value){scenario=value;if(isOpen)open();}
 function updateMode(value){mode=value==='multiple'?'multiple':'single';lastOutcome=lastOutcomes[mode];$$('[data-mpk-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mpkMode===mode)));publishResult();if(isOpen)open();}
 document.addEventListener('click',event=>{
  const trigger=event.target.closest('[data-mpk]');if(!trigger||trigger.disabled)return;const action=trigger.dataset.mpk,id=trigger.dataset.id,key=trigger.dataset.key;
  if(action==='launch'||action==='reopen')open();
  else if(!isOpen)return;
  else if(action==='channel'){channel=id;renderLists(true);$('[data-mpk="channel"][data-id="'+CSS.escape(id)+'"]')?.focus({preventScroll:true});}
  else if(action==='all'){channel='all';renderLists(true);}
  else if(action==='clear-search'){query='';$('#mpkSearch').value='';renderLists(true);$('#mpkSearch').focus();}
  else if(action==='pick'){const m=catalog.find(m=>m.key===key);if(m&&!m.reason)accept([key],false);}
  else if(action==='inherit'){if(mode==='single')accept([],true);else{inherited=true;pending=[];renderLists();}}
  else if(action==='show-picked'){pickedOpen=!pickedOpen;renderLists();}
  else if(action==='clear-picked'){pending=[];inherited=false;renderLists();}
  else if(action==='remove'){pending=pending.filter(item=>item!==key);renderLists();}
  else if(action==='move'){const i=pending.indexOf(key),to=i+Number(trigger.dataset.direction);if(i>=0&&to>=0&&to<pending.length){[pending[i],pending[to]]=[pending[to],pending[i]];renderLists();}}
  else if(action==='load-finished'){scenario='normal';$('#mpkDemoScenario').value='normal';loadCatalog();renderLists(true);}
 });
 document.addEventListener('input',event=>{if(isOpen&&event.target.id==='mpkSearch'){query=event.target.value;renderLists(true);}});
 document.addEventListener('change',event=>{
  const el=event.target;
  if(el.id==='mpkDemoScenario'){updateScenario(el.value);return;}
  if(el.id==='mpkDemoInheritance'){inheritEnabled=el.checked;if(isOpen)open();return;}
  if(el.id==='mpkDemoRecommendations'){recommendedEnabled=el.checked;if(isOpen)open();return;}
  if(el.id==='mpkDemoOrder'){orderEnabled=el.checked;if(isOpen)renderLists();return;}
  if(!isOpen)return;
  if(el.id==='mpkSort'){sort=el.value;renderLists(true);}
  else if(el.dataset.mpkPick){const id=el.dataset.mpkPick;inherited=false;pending=el.checked?(pending.includes(id)?pending:[...pending,id]):pending.filter(k=>k!==id);renderLists();$$('[data-mpk-pick]').find(input=>input.dataset.mpkPick===id)?.focus({preventScroll:true});}
  else if(el.id==='mpkSelectResults'){inherited=false;const ids=eligible();if(el.checked)pending=[...pending,...ids.filter(id=>!pending.includes(id))];else pending=pending.filter(id=>!ids.includes(id));renderLists();$('#mpkSelectResults')?.focus({preventScroll:true});}
 });
 document.addEventListener('keydown',event=>{
  if(!isOpen||event.key==='Escape')return;
  if(event.key==='Tab'&&modal.contains(document.activeElement)){
   const focusable=$$('button:not([disabled]),input:not([disabled]),[tabindex="0"]',modal).filter(e=>e.getClientRects().length);const first=focusable[0],last=focusable.at(-1);
   if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
  }
  if(event.key==='ArrowDown'&&event.target.id==='mpkSearch'){const target=$('.mpk-row:not(.is-disabled)',modal);event.preventDefault();(target?.querySelector('input')||target)?.focus();}
  else if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)&&event.target.closest('.mpk-row')){
   const items=$$('.mpk-row:not(.is-disabled)',modal).map(row=>row.querySelector('input')||row);const i=items.indexOf(document.activeElement);if(i<0)return;event.preventDefault();const n=event.key==='Home'?0:event.key==='End'?items.length-1:Math.max(0,Math.min(items.length-1,i+(event.key==='ArrowDown'?1:-1)));items[n]?.focus();
  }
 });
 const section=$('#launchNonFunctionalTitle').closest('section'),entry=document.createElement('button');entry.type='button';entry.dataset.mpk='launch';entry.textContent='渠道模型选择器';$('.pctl-tiles',section).appendChild(entry);
 const launchResult=document.createElement('p');launchResult.id='mpkLaunchResult';launchResult.className='pctl-hint';launchResult.setAttribute('role','status');section.appendChild(launchResult);
 const demo=document.createElement('div');demo.className='proto-card';demo.id='modelPickerDemoCard';demo.dataset.protoContexts='model-picker';demo.innerHTML='<div class="proto-note-title">公共渠道模型选择器 · 打样</div><div class="mpk-demo-mode"><button type="button" class="btn ghost" data-mpk-mode="single" aria-pressed="true">单选模式</button><button type="button" class="btn ghost" data-mpk-mode="multiple" aria-pressed="false">多选模式</button></div><label class="mpk-demo-field">目录场景<select id="mpkDemoScenario"><option value="normal">完整目录 · 超过 100 项</option><option value="long">长渠道名 / 长模型 ID</option><option value="empty">目录为空</option><option value="loading">读取中</option><option value="failed">读取失败</option><option value="missing">当前已选引用缺失</option></select></label><label class="mpk-demo-check"><input id="mpkDemoInheritance" type="checkbox" checked>显示上层继承示例</label><label class="mpk-demo-check"><input id="mpkDemoRecommendations" type="checkbox" checked>提供明确的推荐列表</label><label class="mpk-demo-check"><input id="mpkDemoOrder" type="checkbox" checked>已选列表有优先级</label>'+button('重新打开选择器','reopen')+'<div class="mpk-demo-result" id="mpkDemoResult" role="status"></div><p class="pctl-hint">目录来自已保存模型 mock，使用完整发现清单。搜索 / 浏览排序不改配置顺序。结果仅返回打样区，没有接入命名、搜索、子 Agent 或模型业务入口。</p>';
 ($('#protoStdCards .proto-group-body')||$('#protoStdCards')).appendChild(demo);
 demo.addEventListener('click',e=>{const b=e.target.closest('[data-mpk-mode]');if(b)updateMode(b.dataset.mpkMode);});
 window.modelPickerPrototype={open,state:()=>clone({mode,scenario,isOpen,channel,query,sort,pending,inherited,pickedOpen,committed,lastOutcome,catalogSize:catalog.length,channels:channels.map(c=>({id:c.id,name:c.name})),visible:filtered().map(m=>({ref:m.ref,name:m.name,reason:m.reason})),hasUnsavedSelection:isOpen&&JSON.stringify(inherited?{kind:'inherit'}:resultFor('models',pending))!==JSON.stringify(originals[mode])}),updateMode,updateScenario};
 loadCatalog();publishResult();window.prototypePanel?.refresh();
})();
