# AC02 owned 官方客户端验证

**最新 freeze86：default npm 完整生产 prepare 组合门已通过，35/35 证据核对。** 实际 run-20261104-181831 取得真实 save→prepare→新官方 Codex 无模型覆盖默认→Krill provider/rawModel/本机 Responses 回包；真实 pending 保留，copy-only ack 正反门均通过。未 forced native、未改名后手修 config/catalog、未打全局 restart。

[86 最终报告及实际复现命令](FINAL-86.md) · [86 机器结果](production-prepare-86-result.json) · [86 交付清单](DELIVERY-86-MANIFEST.json) · [86 证据清单](EVIDENCE-86-MANIFEST.json) · [86 验证入口](verification-86.json)

产品为 86eee1dbff23823eead733cb65308cf02fd95f9e，实际 HEAD 6e2197fd0b8a36dcb8d893b62693c5a2a77151cc；433 份产品输入全过程同源。默认入口是 owned tools/npm-client/node_modules/.bin/codex 标准 npm symlink + 独立 Node；实际上游首次 source=path，旧安装 producer 自然持久化为 origin=discovered/source=configured，服务原 DTO 未替换。此前 172919 的 nested /home/ fixture 显示脱敏拒绝保留，原因和修正范围见报告。

真实 GUI 重启没有执行；本项为用户指定的生产 true producer/客户端重开/本地路由与副本 ack 组合证据，需并入父级 true 路由守卫及独立平台/CI/发布证据。脚本已 ready，父级可统一提交；本 worker 无剩余运行阻断、未提交推送。

## 43 历史结果（显式 native 模式）

以下 43 结果与入口原文保留，仅覆盖其当时范围。旧 manifest 的完整原始基准快照在 archive-43-final-before-86/；verification.json 与旧 manifests 不作改写。该次显式 native 成功不替代上述 default npm 验证。


**43c6253b582c3fe19ba67c8d1ccfeb4adabd7068 的用户指定生产 prepare 闭环通过。** 实际保存→生产 prepare→新官方 Codex 无 model 覆盖默认→真实 Krill provider/原始型号/本机 Responses 回包均取得；真实 pending 保留。重启 ack 仅在安全副本验证。

[最终报告](FINAL-43.md) · [26 项机器核对](production-prepare-43-result.json) · [验证总入口](verification.json) · [交付脚本清单](DELIVERY-MANIFEST.json) · [证据摘要](EVIDENCE-FINAL-MANIFEST.json)

实际全链只跑一次（162210）；最后 copy driver 的两处夹具错误修正后独立重链，只复验副本，生产 rlib 未变化。原 result.json 的 driver failure 与源码原样保留；组合通过结果在 run-20261104-162210/combined-production-and-copy-result.json，不是改写旧失败。

## 可复用脚本

在代码根执行，默认不运行官方进程；完整新冻结 SHA 明确指定后才 --run：

    python3 test/smoke/ocx021-owned-routing.production.py
    python3 test/smoke/ocx021-owned-routing.production.py --check-source-freeze-only --source-freeze-head FULL_SHA
    python3 test/smoke/ocx021-owned-routing.production.py --run --source-freeze-head FULL_SHA --cache-target OWNED_DEPENDENCY_TARGET

需要复验已成功真实链的模拟 ack 副本，可用 --copy-gate-only EVIDENCE_RUN --source-freeze-head SAME_FULL_SHA；不重复真实 owner 或模型请求。文件、参数、已实测命令见 FINAL-43.md 和交付清单。

## 来源、隔离与范围

缓存发布物：@bitkyc08/opencodex 2.84.0、OpenAI 官方 @openai/codex 0.166.0 darwin-arm64、Bun 1.4.2、绝对 Node 路径。registry tarball/integrity/包源摘要在 provenance/ 与 cached-package-source-manifest.json，实际运行版本和二进制摘要在各 run。

Sandbox/ProcessContext 明确临时 root/home/work；OS 沙箱拒绝日常配置、Keychain IPC 和外网，只允许 owned loopback 及新临时 home 摘要对应的精确 SQLite 协调文件。改名前合法旧安装/当前选择夹具来源明确；改名后没有手工 owner 补救、没有改目录/config。官方 actual settings/integration、root routing ownership、raw/native token 分域与 CAS 都走产品代码。

未调用 global restart、未读取/重启日常 Codex、未请求供应商/WebDAV。仅本次 owned 客户端重开；真实 pending 未 ack。真实 GUI 退出/拉起不在本次证据内，copy HTTP/重启回执明确模拟。全局发布、其它平台与 parent review/profile/负向回归由主线独立汇总。

## 保留的历史

| 证据 | 原结论 |
| --- | --- |
| [135035 手工路径](FINAL-D20.md) | 只证明手工绑定，不能替代产品 prepare |
| [143309 d20 路由](FINAL-D20.md) | 旧 live provider 未接纳，原始型号失败 |
| [144504 默认引用](CURRENT-DEFAULT.md) | 旧当前 model 未迁移，默认线程仍旧 |
| [145952 候选真实 owners](OWNER-SPIKE.md) | 候选技术方案可行，不曾标现产品 pass |
| [154805 f0](FINAL-F0.md) | native integration 请求路径 HTTP400，保存前拒绝 |
| [160341 BF](FINAL-BF.md) | double prefix 导致 prepare 拒绝，pending 保留 |
| [160917 1313](FINAL-1313.md) | raw-file SHA 与 native version 领域不同，prepare 拒绝 |
| [162210 43](FINAL-43.md) | 真实生产 prepare/default/目录/路由通过，copy gate 单独补齐 |

本目录只记录本 worker 贡献者证据，不变更 DMD/IMP/TASK、无提交/推送。旧结果和归档 hash 均不覆盖；新 manifest 区分实际运行源与交付修正源。
