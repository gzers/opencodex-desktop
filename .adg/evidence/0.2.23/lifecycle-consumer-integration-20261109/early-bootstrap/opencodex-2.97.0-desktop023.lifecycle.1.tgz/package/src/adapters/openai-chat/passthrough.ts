import { protectGlmSummaryBudget } from "./summary-budget";
import { openAIChatTransport, stripBracketedModelSuffix } from "./wire";
import type { AdapterRequest } from "../base";
import { frameAgentRouterMessages } from "../agentrouter";
import { applyExplicitChatDeveloperRole } from "./developer-role";
import { singleLeadingSystemMessages } from "./single-system";
import { openRouterProviderPayload, resolveOpenRouterRouting } from "../../providers/openrouter-routing";
import { resolveVercelGatewayRouting, vercelGatewayProviderPayload } from "../../providers/vercel-gateway-routing";
import { fastPolicyForModel } from "../../providers/service-tier";
import { applyGithubCopilotContextTier } from "../../providers/github-copilot-context";
import { canonicalFastTierMarker, decideTier, type ResolvedFastPolicy } from "../../providers/fastwire";
import { debugProviderDiagnostic } from "../../lib/debug";
import { isDebugEnabled } from "../../lib/debug-settings";
import { modelInList, type OcxProviderConfig } from "../../types";
import { mapReasoningEffort, modelRecordValue } from "../../reasoning-effort";
import { resolveReasoningCapabilities } from "../../providers/reasoning-capabilities";
import { chatParallelToolCallsWireValue } from "./parallel-tool-calls";
import { applyExplicitChatReasoningWirePolicy, declaresIndependentChatReasoningControls } from "./reasoning-wire";
import { declaresThinkingToggleWire, reasoningControlsAreUnsupported } from "../reasoning-controls";
import { planNativeChatReasoningReplay } from "./reasoning-replay";
import type { OcxReasoningReplayScopeRef } from "../../types";
import { jsonUtf8Bytes } from "../../lib/json-byte-size";
import { isTranslatorBudgetExceededError, TRANSLATOR_MAX_TURN_BYTES, TranslatorBudgetExceededError,
  type TranslatorBudget } from "../../lib/translator-budget";

const CHAT_PASSTHROUGH_FIELDS = [
  "audio",
  "frequency_penalty",
  "logit_bias",
  "logprobs",
  "max_completion_tokens",
  "max_tokens",
  "metadata",
  "modalities",
  "n",
  "prediction",
  "presence_penalty",
  "reasoning_effort",
  "response_format",
  "seed",
  "stop",
  "store",
  "temperature",
  "tool_choice",
  "tools",
  "top_logprobs",
  "top_p",
  "user",
  "web_search_options",
] as const;

/**
 * Build a provider request from an inbound Chat Completions body without translating it
 * through the Responses contract. This is deliberately a whitelist: Chat-only caller
 * fields retain their exact wire representation, while provider capability gates remain
 * centralized beside the ordinary openai-chat adapter.
 */
export function buildOpenAIChatPassthroughRequest(
  provider: OcxProviderConfig,
  rawBody: Record<string, unknown>,
  modelId: string,
  stream: boolean,
  fastPolicy: ResolvedFastPolicy = fastPolicyForModel(provider, modelId, undefined, "chat"),
  fastMode?: boolean,
  providerName?: string,
  replayScope?: OcxReasoningReplayScopeRef,
  maxSerializedBytes = TRANSLATOR_MAX_TURN_BYTES,
  translatorBudget?: TranslatorBudget,
): AdapterRequest {
  const { url, headers, hasCredential } = openAIChatTransport(provider);

  const body: Record<string, unknown> = {
    model: provider.modelSuffixBracketStrip ? stripBracketedModelSuffix(modelId) : modelId,
    // The caller's messages retain their wire shape. An operator who
    // recorded that this destination rejects the `developer` role gets that role converted in
    // place. Verbatim was not neutral there — it sent the role anyway and the turn failed
    // upstream with a 400 before the model saw it. An unrecorded destination is still verbatim,
    // and the conversion changes the role of those messages and nothing else, so the position
    // of every message and every other field survive unchanged. Missing thinking history is
    // repaired below using the same preserve policy as the translated Chat builder.
    // The explicit single-system policy can then merge instruction slots.
    messages: singleLeadingSystemMessages(applyExplicitChatDeveloperRole(
      frameAgentRouterMessages(provider.baseUrl, rawBody.messages),
      provider,
    ), provider),
    stream,
  };
  for (const field of CHAT_PASSTHROUGH_FIELDS) {
    if (rawBody[field] !== undefined) body[field] = rawBody[field];
  }
  const replayPlan = planNativeChatReasoningReplay(body.messages, provider, modelId, replayScope,
    Array.isArray(rawBody.tools) && rawBody.tools.length > 0, maxSerializedBytes);
  if (protectGlmSummaryBudget(body, provider.baseUrl, body.reasoning_effort)) body.reasoning_effort = "low";
  const toggleWire = declaresThinkingToggleWire(provider, modelId);
  const independentControls = declaresIndependentChatReasoningControls(provider, modelId);
  const rawEfforts = modelRecordValue(provider.modelReasoningEfforts, modelId) ?? provider.reasoningEfforts;
  const reasoningDisabled = modelInList(provider.noReasoningModels, modelId)
    || (!toggleWire && rawEfforts?.length === 0) || reasoningControlsAreUnsupported(provider, modelId);
  if (reasoningDisabled) {
    delete body.reasoning_effort;
  }
  const hasTools = Array.isArray(rawBody.tools) && rawBody.tools.length > 0;
  const requestedEffort = typeof body.reasoning_effort === "string" ? body.reasoning_effort : undefined;
  const explicitThinkingEnabled = rawBody.reasoning !== null && typeof rawBody.reasoning === "object"
    && typeof (rawBody.reasoning as { enabled?: unknown }).enabled === "boolean"
    ? (rawBody.reasoning as { enabled: boolean }).enabled
    : undefined;
  const explicitReasoning = applyExplicitChatReasoningWirePolicy({
    provider,
    modelId,
    hasTools,
    thinkingEnabled: explicitThinkingEnabled,
    requestedEffort,
    wireEffort: toggleWire && independentControls ? mapReasoningEffort(provider, modelId, requestedEffort) : requestedEffort,
    reasoningDisabled,
    body,
  });
  let reasoningLog = explicitReasoning.handled ? explicitReasoning.reasoningLog : undefined;
  // A native caller's own thinking object is already in the upstream wire shape. Forward it only
  // on a provider-declared toggle wire, below an explicit reasoning.enabled but above a default.
  if (!reasoningDisabled && toggleWire && independentControls
    && resolveReasoningCapabilities(provider, modelId).supportsThinkingToggle !== false
    && explicitThinkingEnabled === undefined
    && rawBody.thinking !== undefined) {
    body.thinking = rawBody.thinking;
    reasoningLog = undefined;
  }

  const openRouterRouting = resolveOpenRouterRouting(provider, modelId);
  if (openRouterRouting) body.provider = openRouterProviderPayload(openRouterRouting);
  const vercelRouting = resolveVercelGatewayRouting(provider, modelId);
  if (vercelRouting) body.provider = vercelGatewayProviderPayload(vercelRouting);

  if (modelInList(provider.noTemperatureModels, modelId)) delete body.temperature;
  if (modelInList(provider.noTopPModels, modelId)) delete body.top_p;
  if (modelInList(provider.noStopModels, modelId)) delete body.stop;
  if (modelInList(provider.noPenaltyModels, modelId)) {
    delete body.presence_penalty;
    delete body.frequency_penalty;
  }
  // Exact match, unlike the gates above: `noStructuredOutputModels` is documented as
  // "only an exact requested-model match omits the field" (#1424), and the Responses
  // ingress enforces exactly that. A prefix match here would strip response_format from
  // `<listed>:<tag>` siblings the operator never opted out, silently returning prose.
  if (provider.noStructuredOutputModels?.includes(modelId)) delete body.response_format;
  // Narrower neighbour: the model takes `json_object` but rejects `json_schema`. Downgrade
  // rather than drop, so a caller that asked for JSON still gets JSON. The type check also
  // makes the kill switch above win without an else — after its `delete` there is no type
  // left to match.
  const passthroughFormat = body.response_format;
  if (provider.noJsonSchemaModels?.includes(modelId)
      && typeof passthroughFormat === "object" && passthroughFormat !== null
      && (passthroughFormat as { type?: unknown }).type === "json_schema") {
    body.response_format = { type: "json_object" };
  }

  // Run the same complete Fast policy as the translated Chat path, including explicit
  // fastMode and foreign-tier handling. On inherited canonical Fast, the passthrough still
  // retains the caller's exact spelling; forced Fast uses the policy-owned wire value.
  const callerTier = typeof rawBody.service_tier === "string" ? rawBody.service_tier : undefined;
  const tierDecision = decideTier(fastPolicy, fastMode, callerTier);
  if (tierDecision.kind === "set") {
    body.service_tier = fastMode === undefined && canonicalFastTierMarker(callerTier) !== undefined
      ? callerTier
      : tierDecision.value;
  } else if (tierDecision.kind === "forward-caller" && rawBody.service_tier !== undefined) {
    body.service_tier = rawBody.service_tier;
  }
  if (provider.promptCacheKey && rawBody.prompt_cache_key !== undefined) {
    body.prompt_cache_key = rawBody.prompt_cache_key;
  }
  if (hasTools) {
    // Same three provider states as the translated path, and the same defect in the unset one:
    // a caller's explicit false was dropped here too (#5211). The native route reads the bit off
    // the raw request rather than the parsed options, since nothing projects this body.
    const requested = typeof rawBody.parallel_tool_calls === "boolean" ? rawBody.parallel_tool_calls : undefined;
    const parallelToolCalls = chatParallelToolCallsWireValue(provider, requested);
    if (parallelToolCalls !== undefined) body.parallel_tool_calls = parallelToolCalls;
  }
  if (stream) {
    const callerOptions = rawBody.stream_options !== null
        && typeof rawBody.stream_options === "object"
        && !Array.isArray(rawBody.stream_options)
      ? rawBody.stream_options as Record<string, unknown>
      : {};
    body.stream_options = { ...callerOptions, include_usage: true };
  } else if (rawBody.stream_options !== undefined) {
    body.stream_options = rawBody.stream_options;
  }

  const transformedBody = () => applyGithubCopilotContextTier(body, provider, modelId, providerName);
  // The binding constraint is the final size base + net, so a shrinking replay may legitimately
  // measure a base above the cap; only a base above max - net makes the result unserializable.
  let baseBytes = 0;
  try {
    baseBytes = jsonUtf8Bytes(transformedBody(), maxSerializedBytes - replayPlan.serializedBytes);
  } catch (error) {
    if (isTranslatorBudgetExceededError(error)) {
      throw new TranslatorBudgetExceededError("request_copies", maxSerializedBytes);
    }
    throw error;
  }
  if (replayPlan.serializedBytes > maxSerializedBytes - baseBytes) {
    throw new TranslatorBudgetExceededError("request_copies", maxSerializedBytes);
  }
  const preSerialization = translatorBudget?.reserveTransient(baseBytes + replayPlan.serializedBytes, {
    kind: "request_copies",
  });
  let bodyJson: string;
  try {
    if (replayPlan.hasChanges) {
      body.messages = replayPlan.apply();
    }
    bodyJson = JSON.stringify(transformedBody());
  } finally {
    preSerialization?.release();
  }

  if (isDebugEnabled()) {
    let host = "upstream";
    try { host = new URL(url).host; } catch { /* keep fallback */ }
    debugProviderDiagnostic("openai-chat", "passthrough-request", {
      host,
      model: body.model,
      stream,
      messageCount: Array.isArray(body.messages) ? body.messages.length : 0,
      toolCount: Array.isArray(body.tools) ? body.tools.length : 0,
      hasCredential,
      bodyBytes: Buffer.byteLength(bodyJson, "utf8"),
    });
  }

  return {
    url, method: "POST", headers, body: bodyJson,
    ...(reasoningLog ? { reasoningLog } : {}),
  };
}
