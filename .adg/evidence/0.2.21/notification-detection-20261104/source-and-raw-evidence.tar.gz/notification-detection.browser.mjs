// Render production Vue consumers using explicit in-memory DEV fixtures only.
// No native channel probe, key read, configuration write or Codex restart.
import fs from 'node:fs/promises'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
const code = process.env.OCX_CODE_ROOT || '/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes'
const { pickEngine } = await import(pathToFileURL(path.join(code, 'apps/desktop/ui/qa/engine.mjs')))
const engine = await pickEngine(), browser = await engine.launch()
const out = path.join(path.dirname(new URL(import.meta.url).pathname), engine.name)
await fs.mkdir(out, { recursive: true })
const checks = [], errors = [], external = [], screens = []
let current = '', completed = false, failure = null
function check(name, passed, detail) { checks.push({ variant: current, name, passed: !!passed, detail }); if (!passed) throw Error(current + ' ' + name + ': ' + JSON.stringify(detail)) }
const variants = [
  { width: 1180, height: 760, theme: 'light', effects: 'high', scale: 100 },
  { width: 900, height: 600, theme: 'dark', effects: 'low', scale: 100 },
  { width: 1180, height: 760, theme: 'dark', effects: 'mid', scale: 200 },
  { width: 900, height: 600, theme: 'light', effects: 'mid', scale: 50 },
]
try {
  for (const variant of variants) {
    current = [variant.width, variant.theme, variant.scale].join('-')
    const p = await browser.newPage({ viewport: { width: variant.width, height: variant.height } })
    p.setDefaultTimeout(10000)
    p.on('pageerror', error => errors.push({ variant: current, message: error.message }))
    await p.route('**/*', route => {
      if (new URL(route.request().url()).origin === 'http://127.0.0.1:52431') return route.continue()
      external.push({ variant: current, url: route.request().url() }); return route.abort()
    })
    await p.goto('http://127.0.0.1:52431/?__audit=1&route=models&env=ready&runtime=running&theme=' + variant.theme + '&effects=' + variant.effects)
    await p.locator('.channel-table').waitFor()
    await p.evaluate(async scale => {
      (await import('/src/app/appearance/scale.ts')).applyInterfaceScale(scale)
      ;(await import('/src/app/feedback/store.ts')).useFeedbackStore().clearToast()
      const { useModelsStore } = await import('/src/features/models/store.ts')
      const { modelApi } = await import('/src/features/models/api.ts')
      const models = useModelsStore(), channel = models.snapshot.policy.channels[0]
      channel.connection.nodes = Array.from({ length: 14 }, (_, index) => ({ id: 'fixture-node-' + index, name: index ? '备用节点 ' + index : '当前节点', url: 'https://node-' + index + '.example.test/v1/long-configuration-prefix' }))
      channel.connection.activeNodeId = 'fixture-node-0'
      models.restoreChannels()
      window.__savedBaseline = JSON.stringify(models.snapshot)
      window.__requests = []; window.__stops = []; window.__restarts = 0; window.__writes = 0
      modelApi.measureNodes = request => { window.__requests.push(request); return new Promise(resolve => { window.__finish = stopped => resolve({ runId: request.runId, stopped, results: request.nodes.slice(0, 2).map((node, i) => ({ nodeId: node.id, elapsedMs: i ? null : 42, modelCount: i ? null : 3, error: i ? 'discovery_timeout' : null })) }) }) }
      modelApi.stopNodeMeasurement = async id => { window.__stops.push(id) }
      modelApi.refreshCache = async () => { window.__restarts++; return { success: true, restarted: false, summary: 'Explicit mock only' } }
      modelApi.writeFile = async () => { window.__writes++; throw Error('Unexpected write in observation test') }
    }, variant.scale)
    const capture = async name => { const filename = current + '-' + name + '.png'; await p.screenshot({ path: path.join(out, filename) }); screens.push(filename) }
    const dialog = () => p.locator('dialog[open]').last()
    const firstRow = p.locator('.channel-table tbody tr').first(), trigger = firstRow.locator('.channel-node-detect')
    const geometry = async () => dialog().evaluate(element => { const r = element.getBoundingClientRect(); return { x: r.x, y: r.y, right: r.right, bottom: r.bottom, centerX: (r.left + r.right) / 2, centerY: (r.top + r.bottom) / 2, viewportX: innerWidth / 2, viewportY: innerHeight / 2, width: innerWidth, height: innerHeight, footer: !!element.querySelector('footer'), scroll: element.querySelector('.ui-dialog-content').scrollHeight > element.querySelector('.ui-dialog-content').clientHeight } })
    const header = await p.locator('.channel-table th').allTextContents()
    check('selection plus channel/model/enabled/actions only', JSON.stringify(header) === JSON.stringify(['', '渠道', '模型', '启用', '操作']), header)
    const columns = await firstRow.evaluate(row => { const c = row.cells, zoom = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ui-zoom')); return { channel: c[1].getBoundingClientRect().width / zoom, actions: c[4].getBoundingClientRect().width / zoom, choices: !!c[0].querySelector('input[type=checkbox]') } })
    check('channel 160–220px, actions 250px, selection retained', columns.channel >= 159.5 && columns.channel <= 220.5 && Math.abs(columns.actions - 250) < 1 && columns.choices, columns)
    check('two character detection in actions cell', (await trigger.innerText()).trim() === '检测' && await trigger.getAttribute('aria-haspopup') === 'dialog')
    await capture('list')
    await trigger.click(); await dialog().waitFor()
    const box = await geometry()
    check('native public modal is centered and fits viewport', box.x >= -1 && box.y >= -1 && box.right <= box.width + 1 && box.bottom <= box.height + 1 && Math.abs(box.centerX - box.viewportX) <= 2 && Math.abs(box.centerY - box.viewportY) <= 2, box)
    check('view has no footer or dropdown menu, content scrolls', !box.footer && box.scroll && await p.locator('[role=menu]').count() === 0, box)
    const lastControl = dialog().getByRole('button', { name: '检测节点 备用节点 13', exact: true })
    await lastControl.focus(); await p.keyboard.press('Tab')
    check('Tab loops from last action to header X', await dialog().getByRole('button', { name: '关闭', exact: true }).evaluate(e => document.activeElement === e))
    await p.keyboard.press('Shift+Tab')
    check('Shift+Tab loops from header X to last action', await lastControl.evaluate(e => document.activeElement === e))
    await dialog().evaluate(e => { e.querySelector('.ui-dialog-content').scrollTop = 0 })
    const choice = dialog().getByRole('button', { name: '选择节点 备用节点 1', exact: true })
    await p.mouse.move(0, 0)
    const style = await dialog().evaluate(element => [...element.querySelectorAll('.channel-node-choice')].slice(0, 2).map(node => ({ background: getComputedStyle(node).backgroundColor, weight: getComputedStyle(node).fontWeight })))
    check('selection has no permanent fill or bold', style.every(node => node.background === 'rgba(0, 0, 0, 0)' && node.weight === '400'), style)
    await dialog().getByRole('button', { name: '检测节点 备用节点 1', exact: true }).click()
    await choice.focus()
    await p.evaluate(() => { window.__sheet = document.querySelector('dialog[open]'); window.__choice = window.__sheet.querySelector('[aria-label="选择节点 备用节点 1"]'); window.dispatchEvent(new Event('resize')); window.dispatchEvent(new Event('scroll')); window.__sheet.querySelector('.ui-dialog-content').scrollTop = 150 })
    await p.setViewportSize({ width: variant.width - 20, height: variant.height })
    check('resize, window and content scroll preserve modal', await p.locator('dialog[open]').count() === 1)
    await p.evaluate(() => window.__finish(false))
    await dialog().getByText('42 ms · 3 个模型', { exact: true }).waitFor()
    check('result updates same modal and choice DOM with focus', await p.evaluate(() => document.querySelector('dialog[open]') === window.__sheet && window.__sheet.querySelector('[aria-label="选择节点 备用节点 1"]') === window.__choice && document.activeElement === window.__choice))
    check('measurement leaves selected draft and snapshot alone', await p.evaluate(async () => { const m = (await import('/src/features/models/store.ts')).useModelsStore(); return m.channelDraft.channels[0].connection.activeNodeId === 'fixture-node-0' && JSON.stringify(m.snapshot) === window.__savedBaseline && !m.channelDirty && !window.__writes }))
    await capture('detection-result')
    await p.keyboard.press('Escape'); await p.waitForFunction(() => !document.querySelector('dialog[open]'))
    check('Escape closes only observation and returns trigger', await trigger.evaluate(element => document.activeElement === element) && await p.evaluate(() => window.__stops.length === 0))
    await trigger.click(); await dialog().getByRole('button', { name: '一键检测', exact: true }).click()
    await dialog().getByRole('button', { name: '关闭', exact: true }).click()
    check('X closes running observer without stopping', await p.evaluate(() => window.__stops.length === 0 && window.__requests.length === 2))
    await p.evaluate(() => window.__finish(false))
    await trigger.click(); await dialog().getByText('请求超时', { exact: true }).waitFor()
    check('reopen preserves error and successful results', (await dialog().innerText()).includes('42 ms') && await dialog().getByRole('button', { name: '选择节点 当前节点', exact: true }).getAttribute('aria-pressed') === 'true')
    await dialog().getByRole('button', { name: '一键检测', exact: true }).click()
    await dialog().getByRole('button', { name: '停止', exact: true }).click()
    await p.evaluate(() => window.__finish(true)); await dialog().getByText('检测已停止，已完成结果保留。', { exact: true }).waitFor()
    check('explicit stop, one run id; completed results retained', await p.evaluate(() => window.__stops.length === 1 && window.__stops[0] === window.__requests[2].runId) && (await dialog().innerText()).includes('42 ms'))
    await dialog().getByRole('button', { name: '选择节点 备用节点 1', exact: true }).click(); await p.waitForFunction(() => !document.querySelector('dialog[open]'))
    check('choice only changes draft and restores trigger focus', await p.evaluate(async () => { const m = (await import('/src/features/models/store.ts')).useModelsStore(); return m.channelDraft.channels[0].connection.activeNodeId === 'fixture-node-1' && m.snapshot.policy.channels[0].connection.activeNodeId === 'fixture-node-0' && m.channelDirty && window.__writes === 0 }) && await trigger.evaluate(element => document.activeElement === element))
    await trigger.click(); check('reopen reflects chosen draft', await dialog().getByRole('button', { name: '选择节点 备用节点 1', exact: true }).getAttribute('aria-pressed') === 'true')
    await p.keyboard.press('Escape'); await p.waitForFunction(() => !document.querySelector('dialog[open]'))
    // Row filtering and detail navigation do not own measurement lifetime.
    await trigger.click(); await dialog().getByRole('button', { name: '检测节点 备用节点 1', exact: true }).click()
    await dialog().getByRole('button', { name: '关闭', exact: true }).click()
    await p.getByRole('searchbox', { name: '搜索渠道', exact: true }).fill('absent-channel')
    check('filtering the row does not cancel measurement', await p.locator('.channel-table tbody tr').count() === 0 && await p.evaluate(() => window.__stops.length === 1))
    await p.evaluate(() => window.__finish(false))
    await p.getByRole('searchbox', { name: '搜索渠道', exact: true }).fill('')
    await trigger.click(); check('result survives filtering and reopen', (await dialog().innerText()).includes('42 ms'))
    await dialog().getByRole('button', { name: '关闭', exact: true }).click()
    await trigger.click(); await dialog().getByRole('button', { name: '检测节点 当前节点', exact: true }).click()
    await dialog().getByRole('button', { name: '关闭', exact: true }).click()
    await firstRow.getByRole('button', { name: '编辑', exact: true }).click()
    check('detail node section remains; navigation does not stop observer task', await p.locator('#channel-nodes .node-picker').count() === 1 && await p.evaluate(() => window.__stops.length === 1))
    await p.evaluate(() => window.__finish(false))
    await p.getByRole('button', { name: '返回渠道列表', exact: true }).click()
    await p.locator('.channel-table').waitFor()
    await trigger.click(); check('result survives detail navigation and reopen', (await dialog().innerText()).includes('42 ms'))
    await dialog().getByRole('button', { name: '关闭', exact: true }).click()
    // Countdown uses Playwright's browser clock and production TaskProgressHost.
    await p.clock.install(); await p.clock.pauseAt(new Date(Date.now() + 1000))
    const search = p.getByRole('searchbox', { name: '搜索渠道', exact: true })
    await search.focus()
    await p.evaluate(async () => { (await import('/src/app/feedback/modelSave.ts')).useModelSaveFeedback().showSaved() })
    const card = p.locator('[data-notification-key^="model-save:"]')
    await card.waitFor()
    check('new save does not take focus', await search.evaluate(element => document.activeElement === element))
    await p.clock.runFor(2000)
    for (const exit of ['X', 'Escape', 'backdrop', 'cancel']) {
      await card.getByRole('button', { name: '立即重启 Codex', exact: true }).click()
      await p.clock.runFor(30000)
      check(exit + ' confirmation pauses notice', await card.count() === 1 && await p.evaluate(() => window.__restarts === 0))
      if (exit === 'X') await dialog().getByRole('button', { name: '关闭', exact: true }).click()
      else if (exit === 'Escape') await p.keyboard.press('Escape')
      else if (exit === 'backdrop') await p.mouse.click(1, 1)
      else await dialog().getByRole('button', { name: '取消', exact: true }).click()
      await p.waitForFunction(() => !document.querySelector('dialog[open]'))
      check(exit + ' only closes confirmation', await card.count() === 1 && await p.evaluate(() => window.__restarts === 0))
    }
    await p.mouse.move(0, 0); await search.focus()
    await p.clock.runFor(5999); check('remaining time resumes without reset', await card.count() === 1)
    await p.clock.runFor(601); check('expiry collapses without restart', await card.count() === 0 && await p.evaluate(() => window.__restarts === 0))
    await p.evaluate(async () => { (await import('/src/app/feedback/modelSave.ts')).useModelSaveFeedback().showSaved() }); await card.waitFor()
    await p.clock.runFor(4000)
    await p.evaluate(async () => { (await import('/src/app/feedback/modelSave.ts')).useModelSaveFeedback().showSaved() })
    await p.clock.runFor(4001); check('old countdown cannot collapse new card', await card.count() === 1)
    await capture('notification')
    await card.getByRole('button', { name: '稍后', exact: true }).click(); check('later collapses without restart', await card.count() === 0 && await p.evaluate(() => window.__restarts === 0))
    await p.close()
  }
  completed = true
} catch (error) {
  failure = { variant: current, message: error.message }
  const page = browser.contexts().flatMap(context => context.pages()).at(-1)
  if (page) { await page.screenshot({ path: path.join(out, 'failure.png') }); await fs.writeFile(path.join(out, 'failure-body.txt'), await page.locator('body').innerText()) }
  throw error
} finally {
  await browser.close()
  await fs.writeFile(path.join(out, 'report.json'), JSON.stringify({ completed, failure, engine: engine.name, scope: 'production Vue consumers, explicit DEV in-memory API; not native release acceptance', checks, errors, external, screens }, null, 2))
}
if (errors.length || external.length) throw Error(JSON.stringify({ errors, external }))
console.log(engine.name, checks.length, 'checks', screens.length, 'screenshots')
