# 当前默认引用模块交付

独占源码为代码分支 codex/0.2.21-fixes 的新增文件：

- apps/desktop/tauri/src/modules/model_config/client_selection_rename.rs
- apps/desktop/tauri/tests/client_selection_rename.rs

本 worker 未修改 mod.rs、cache_refresh.rs、management.rs、config_file.rs、channel_rename.rs、保存事务、UI、版本或 DMD；未暂存、提交或推送。共享 checkout 中其它文件变化属于并行主线，不包含在本模块交付范围。

## 精确接口与主线次序

    pub async fn preflight_current_selection(
        context: &ProcessContext,
        codex_executable: &Path,
        home_directory: &Path,
        codex_home: &Path,
        working_directory: &Path,
        active_profile: Option<&str>,
        provider_renames: &BTreeMap<String, String>,
    ) -> ModelResult<ClientSelectionRenamePlan>;

    impl ClientSelectionRenamePlan {
        pub async fn apply(self) -> ModelResult<ClientSelectionRename>;
    }

    pub enum ClientSelectionRename { Unchanged, Updated }

主线从 cache_refresh.rs 用 path module 注册 client_selection_rename.rs。在保存后的“立即重启 Codex”true 分支：先绑定官方实际 runtime/config owner 路径及受控 HOME，预检 → live reconcile/真实 producer → plan.apply() → 官方重启。false 分支不调用本模块。pending map 在完整流程明确成功之前保留，文件保存结果与客户端后续动作结果分别回报。

preflight 不执行 config/value/write，不修改客户端配置；只读取并建立单次内存意图。plan 不实现 Debug/Serialize，不持久化来源配置、凭据或 RPC 正文。apply 重新启动同一绑定身份的官方 owner，重新读取 model/origins/layers。只有来源 file/profile 和当前 model 均与预检相同时才写；允许 injection 改动其它字段和版本，CAS 使用 apply 新读到的 version。原始型号后缀包括大小写、Unicode、多级斜杠逐字保留。review_model、历史会话及非当前选择不迁移。

无映射完全不 spawn；无旧完整 provider 前缀不发送写 RPC、不修改配置字节。不会把 Krill-10、prefix-Krill-1、原始型号中的 Krill-1 当作 Krill-1 provider。

## 来源与平台边界

所有路径由调用方显式传入；模块不读任意服务字段、不搜索 PATH、不展开 ~、不猜日常目录。支持显式自定义 CODEX_HOME，无 HOME/.codex 结构要求。origin 必须为 user，file 必须等于明确 CODEX_HOME 下规范化的 config.toml 或已绑定 profile-v2 文件，且 origin/layer/version/model 一致；配置符号链接不能逃出明确 CODEX_HOME。project、system、MDM、enterprise、sessionFlags、legacy managed、来源缺失、不同文件、disabled layer、未绑定 profile 都写前拒绝。

官方 0.166.0 的 legacy profile = "active" 会在 config/read 被 owner 拒绝；同版本 app-server 也不接受 --profile。真实 profile 测试因此只证明预检拒绝、根配置与 profile 文件都未改，不能宣称该版本活动 profile 更新通过。模块可接受调用方明确绑定的 profile 名，并要求 owner 实际返回匹配的 user/profile layer；这条成功分支仅由合成 RPC 反例/正例检验。active_profile=None 且原生 config.profile 非空时拒绝，绝不以根 model 掩盖 profile 默认选择。

Unix 使用独占进程组；Windows 使用现有 OwnedQueryJob（挂起创建、分配 Job 后恢复、退出回收）。env_clear 后只固定 HOME/CODEX_HOME/临时 SQLite/TMP、系统 PATH 和必要平台环境，不继承渠道密钥、用户代理或任意宿主环境。RPC JSON 只写 stdin。Windows 只支持调用方已验证的原生 .exe；.cmd/.bat 在预检、spawn 之前明确 client_selection_executable 拒绝，不隐式使用系统 shell。实际 Windows owner 运行未测；MSVC 目标检查仅证明源文件的 Windows 分支可编译。

每阶段 20 秒、补偿 10 秒；stdout 单行最多 2 MiB/总量 8 MiB，stderr 最多 256 KiB，退出等待有界。正常、失败、超时和 future drop 都结束所拥有的进程边界；测试实际检查超时/输出超限后的 owned sleep 子进程退出。

## 写后核验与部分失败

只有 owner status=ok、overriddenMetadata 为空，且 config/read 的新值/同来源/版本与回执完全一致才返回 Updated。okOverridden 及被覆盖元数据均不算成功。写失败与 CAS 漂移不无条件重试。获得有效写回执后若核验失败，另起同身份 owner，以本次回执 expectedVersion 恢复原 model 并读回对应 layer；不采用后续外部新版本进行补偿。若用户已编辑，CAS 拒绝且保留外部新选择，返回 client_selection_repair_conflict。丢失或无效写回执/超时属于结果未确认，不能假称原值已恢复或整体成功。

## 实测证据

- verification.json：本次测试二进制 SHA、模块/测试源码运行前后 SHA、官方 Codex 二进制 SHA 与版本、退出码。
- tests.stdout / tests.stderr：完整 Rust 测试结果，包含真实官方 owner 和合成失败反例。
- real-root-default.json：真实根 owner 更新、自定义 CODEX_HOME、injection 版本变化、Unicode/多级原始型号、review_model/历史哨兵保持；全新官方进程无 model/config 覆盖 thread/start 的默认值。
- real-native-cas.json：真实原生 owner stale expectedVersion 拒绝，外部新配置字节保持。
- real-selection-profile-refusal.json：真实用户新选择不覆盖、0.166 不支持 profile 的写前拒绝。
- windows-typecheck.json / windows-typecheck.stderr：同模块、实际 platform/discovery/OwnedQueryJob 源文件的 x86_64-pc-windows-msvc 编译检查；最小周边 app 类型，无 Windows 运行验收。
- ConfigReadParams/Response.json、ConfigValueWriteParams.json、ConfigWriteResponse.json、ThreadStartParams.json：从同一个官方 0.166 二进制导出的原生 schema。
- root-owner-read.json、legacy-profile-owner-read.json、profile-inherited-owner-read.json：初始真实来源探针，均为临时合成配置。

复现先在代码根 apps/desktop/tauri 编译：cargo test --locked --offline --test client_selection_rename --no-run。然后把其报告的绝对测试二进制传给本目录 run-isolated.py --test-binary。该 runner 核对归档的官方 Codex SHA，使用临时 HOME/CODEX_HOME/TMP/work/SQLite、OS 拒绝所有网络（包括 loopback）与日常用户树/Keychain，且以两个合成父环境 canary 验证 env_clear。不调用 turn/start、exec、全局 restart endpoint、外部模型或真实工具/凭据。

上游生产者的候选实测由相邻 owned-client-routing-20261104/OWNER-SPIKE.md 与 owner-spike-result.json 拥有；本模块未重标其候选为产品验收。凭据 pool/headers 的 provider DTO 接纳与完整 live/restart 事务由主线负责，本模块不调用 provider REST、不宣称覆盖该范围。当前交付是实际生产模块源码及其隔离测试；主线注册、true 分支编排、桌面重启和完整产品发布 gate 仍需主线验收。
