# 保存后的 live provider 同步 adapter

**当前实现已由 [review2 两项 P2 修复](review2-p2/RESULT.md) 更新：完整 saved roster 逐行 reload，且 batch 必须返回 committed typed CatalogDisposition。当前 19/19 守卫及新源码真实 owner 正/拒绝例见该记录。下文保留首轮 15/15 的历史身份与边界，不作为更新后源码的测试回执。**

已实现生产最小 adapter，当前源码 15/15 隔离守卫通过，实际调用未修改的官方 2.84 服务也通过。本记录只证明 adapter 及所列 owner 边界；parent 的完整“立即重启 Codex”用户路径、pending CAS 清理及 Codex 默认配置 owner 集成不在本 worker 的验收范围。

## 交接接口

实现分支 `codex/0.2.21-fixes`，代码根 `ocx-0219-fixes`。生产文件 `apps/desktop/tauri/src/modules/model_config/saved_runtime_reconcile.rs`；独立测试 `apps/desktop/tauri/tests/saved_runtime_reconcile.rs`。

    pub async fn reconcile(
        management: &Management,
        context: &ProcessContext,
        renames: &BTreeMap<String, String>,
    ) -> ModelResult<()>

parent 从 cache_refresh.rs 以 path 注册，在既有明确确认的 true 准备阶段调用；false 不扩。模块使用 crate 绝对模块路径，不要求放在 model_config 顶层。Management 必须来自相同 ProcessContext 的既有 attestation 绑定。成功后由 parent 继续真实默认 owner/重启动作，仅整个动作完成才按 pending CAS id 清理。模块不拥有或清理 pending，不重启服务/客户端，不创建状态 UI。

顺序：验证绑定，读取保存后 config.json 的完整字节摘要和 provider 名单/default，检查 old→new 映射，按去重的新 targets 使用既有 bodyless HMAC reload，GET /api/config 取已保存行，PUT /api/providers baseline==next，要求 success===true，GET 回读完整 roster/default/公开行一致，在成功及错误退出时复核磁盘 SHA256。不存在、失效或 symlink 配置均拒绝。

行值只来自官方 safeConfigDTO；磁盘只提供完整名单和默认项。仅剔除 hasApiKey、hasHeaders、initialModelSelection、xaiResponsesOptInState 四项明确 derived；复用 provider_fields::PUBLIC 严格校验其余字段。[132 项字段合同](adapter-dto-policy.json) 与当前发布物 auth-cors.ts editor policy 精确相同。baseUrl/modelCosts/registry note/codexAccountMode 等特殊投影由官方 DTO 自己拥有，不自行重造。

## 当前验证

[总回执](adapter-verification.json)、[最终源码身份](adapter-final-source.json)、[15/15 原始结果](adapter-guards-final.stdout)。

15 组守卫包括：多 target 先 reload 后单 batch、共享 target 去重、完整 roster/default/行回读、空 rename map、幂等重试、原配置 bytes/mtime/inode 恒等、pending/cache sentinel 保留、409 不重试、404/405 不支持 owner、HTTP200 但 success=false/无效 JSON/错误 roster/default/行、五个阶段的仅换行摘要漂移、错误响应期间漂移、未知字段、apiKey/apiKeyPool/headers/proxy/mcpServers/desktopExecutor/嵌套秘密/URL 认证拒绝、缺行、复用 oldprefix 的失效映射、坏 attestation、runtime record 变化、缺失/损坏/disabled-default 配置、symlink。

测试通过实际链接的 Management 发出 HTTP。safety 是 crate-private，独立测试按路径注册未修改的生产 safety 源；Management/schema/字段校验仍链接真实生产库。构建离线且写入全新临时根，运行由 OS 沙箱拒绝真实用户树/Keychain/外网，仅放行 loopback。第一次独立测试构建因 safety 可见性失败，原错误保留在 adapter-guards-build.stderr；修正的是测试注册，未放宽生产 API 或修改 safety。最终构建及结果独立归档。

[生产 adapter 实际官方调用](adapter-real-owner-result.json)、[helper 回执](adapter-real-owner.stdout)、[隔离运行脚本](adapter-spike-run.py)。运行使用最终生产 adapter 源和真实 Management，调用未修改的已安装 2.84 官方 CLI，同一 runtime record 前后相同。改名前 live=[Krill-1,xai]/default=Krill-1；磁盘夹具保存改名后，adapter 令 live=[xai,Krill]/default=Krill，旧 provider 消失。原 config.json bytes/SHA/inode/mtime 全部一致，hasHeaders=true 保留，真实 xaiResponsesOptInState 已成功剔除。唯一 loopback POST 实际收到 model=owned-routing-model，合成认证匹配，固定响应消费成功。所有 owned 子进程退出，两端口关闭，上游源摘要前后相同。

该 adapter 直接调用验证禁用了 Codex clientIntegrations，不将其写成目录/当前默认配置/桌面重启完整产品链通过。完整目录及无 model 覆盖的新客户端候选链沿用 [OWNER-SPIKE.md](../owned-client-routing-20261104/OWNER-SPIKE.md) 的 17 项真实证据，candidate 与 product 边界保持。

## 错误与未外推范围

固定脱敏错误码：saved_runtime_file、saved_runtime_rename、saved_runtime_drift、saved_runtime_dto、saved_runtime_baseline、saved_runtime_unsupported、saved_runtime_owner、saved_runtime_response、saved_runtime_readback、stale_runtime。基线漂移/不支持/响应未知/部分 live 改动均返回错误，保留 pending 由 parent 重试；不执行补救 POST/delete，不把单次 reload 当成事务成功。HTTP 状态由 Management 的固定脱敏状态文案识别，不回显上游正文。

真实 owner 额外覆盖双 provider、disabled sibling、合成 headers=true、xai derived。真实 Keychain、OAuth/canonical、真实 key pool、profiles/managed/project 层未被这个运行证明；pool/headers 等秘密字段的 DTO 注入有拒绝反例，磁盘合成 pool/header 字节不变有守卫。Codex 层 owner 及其来源拒绝由 parent 独立适配，不外推为通过。

只写本 worker 的两份实现/测试及本证据目录；未改 management.rs/cache_refresh.rs/config_file.rs/channel_rename.rs，没有 git add/commit/push。
