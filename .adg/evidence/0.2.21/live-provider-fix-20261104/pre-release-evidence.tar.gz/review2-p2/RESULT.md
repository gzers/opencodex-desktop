# review2 两项 P2 已修复，生产源码稳定

独立报告 `01a1a575` 所列 full-roster baseline 与 catalog 结果漏检均已修复。公开函数保持 `reconcile(&Management, &ProcessContext, &BTreeMap<String,String>) -> ModelResult<()>`，仅改 adapter 和其独立测试。没有修改 parent 的 Management/cache_refresh/config_file/channel_rename 等文件。

生产模块 SHA256：`4ec184fea7cb950883de2cb400a9015289240ac090abf0c8596e2b07a861559e`。最终身份及结果见 [SUMMARY.json](SUMMARY.json)。

## 修复合同

- rename map 仍只校验当前已保存的改名关系。实际 reload 从保存后的完整 provider 名单取值，按 BTreeMap 顺序每行一次，包含 canonical 与未改名 sibling；空 map 也不跳过。每次 reload 前后检查同一原始磁盘摘要，任何变化即停止。
- no-op batch 必须同时满足 `success:true` 和真正 `CatalogDisposition.status:committed`；committed 结构要求 `changed`/`degraded` 为 boolean，notices 为最多三项官方闭集。failed/skipped/missing/null/畸形结果返回 `saved_runtime_catalog`，不进入 live 成功读回或交给 parent 继续 restart/清 pending。
- committed 的 changed=false、合法 degraded/notices 仍接受。没有使用 synced、目录文件存在或 changed=true 作为成功替代。最终 live roster/default/editor 及原磁盘摘要检查保留。

## 本轮验证

[受影响 adapter 守卫 19/19](guards.stdout)，[构建与二进制/源码身份](verification.json)。测试直接导入 parent 已注册的真实生产 library module，已不使用早期 test-local adapter/safety 注册。旧十五组的 full-roster 请求顺序已更新，补上：新增/修改 C 后再 A→B、canonical 行 reload、空 map 中修改行、failed/skipped/missing/畸形 catalog 拒绝、changed=false/degraded/synced=false 正例。只运行此 affected adapter suite，没有重跑主线全部套件。构建及测试期间所列源码无漂移。

[真实官方 committed 正例](real-owner-committed/adapter-real-owner-result.json)：未修改的 2.84 CLI，新的临时 user/Codex/official 根，官方 producer 初始化旧集成后保持同一服务。先保存新增 C 和修改 xai，再保存 Krill-1→Krill；当前生产 adapter reload 完整集合，batch 通过 committed typed 结果校验，live 包含 C/xai/Krill、default=Krill。唯一 loopback POST 收到原始 owned-routing-model 并消费固定响应，合成认证正确。

[真实官方非 committed 拒绝例](real-owner-skipped/adapter-real-owner-result.json)：另一全新临时根，关闭 Codex integration。即使 full live roster/default 已经更新，当前 adapter 仍返回 saved_runtime_catalog，没有继续生成模型请求。目录“skipped”是夹具模式名称；这里归档的是实际 adapter 错误回执，不伪造上游 batch 原始正文。failed/skipped/missing 的精确正文分支由上述受控 typed 响应守卫分别覆盖。

两次都保持原配置 bytes/SHA/inode/mtime 完全一致，runtime record 前后相同，生产模块及官方 provider-routes/auth-cors 源摘要前后相同；owned 服务组均退出、端口关闭。正例仅给新临时 CODEX_HOME 摘要的专属协调文件精确权限，已全部回收。OS 沙箱拒绝真实用户配置、Keychain 与外网。无官方全局重启、无日常 Codex 重启、无补救 POST/delete。

本轮 real helper 直接链接 parent 注册的当前生产模块，source SHA 与构建和两个运行一致，不复用早期旧源码的成功冒充当前实现。完整 true 准备/默认 owner/restart/pending CAS 闭环仍由 parent 统一验收。
