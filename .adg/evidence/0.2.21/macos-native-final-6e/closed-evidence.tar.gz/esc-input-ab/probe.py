import ast,datetime,hashlib,json,os,runpy,shutil,subprocess,time,traceback,types
from pathlib import Path
REPO=Path('/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes')
OUT=Path(__file__).resolve().parent
m=runpy.run_path(str(REPO/'test/smoke/ocx021-macos-native.py'),run_name='esc_only_bounded_native_input_probe')
args=types.SimpleNamespace(app='/private/tmp/ocx021-final-6e2197fd/unpacked/OpenCodeX Desktop.app',out=str(OUT),stage='signed-final-reverify',expected_build_commit='6e2197fd0b8a36dcb8d893b62693c5a2a77151cc',scope='esc-ab',hold_seconds=0,node=None,npm_cli=None,official_entry=None,bun=None)
run=m['NativeRun'](args);rounds=[];error=None
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# This A helper is the exact preserved old source: no instrumentation, no delay.
original_source=OUT/'original-helper.swift';changed_source=REPO/'test/smoke/ocx021-macos-native.swift'
shutil.copyfile(changed_source,OUT/'held-helper.swift')
try:
 run.prepare();run.launch()
 original=run.container/'original-ax'
 built=subprocess.run(['/usr/bin/xcrun','swiftc',str(original_source),'-o',str(original)],env=run.env,capture_output=True,text=True,timeout=40)
 (run.out/'original-helper-compile.log').write_text(built.stdout+built.stderr);assert built.returncode==0
 run.report['escExperiment']={'schedule':['A1-original','B1-held50ms','A2-original','B2-held50ms'],'sameCandidatePid':run.proc.pid,'sameFreshRoot':str(run.root),'code':53,'flags':0,'timeoutSeconds':8,'keyAttemptsPerRound':1,'inputRetries':0,'originalSourceSha256':sha(original_source),'heldSourceSha256':sha(changed_source),'originalBinarySha256':sha(original),'heldBinarySha256':sha(run.helper),'timerVerification':False};run.flush()
 for label,helper in [('A1-original',original),('B1-held50ms',run.helper),('A2-original',original),('B2-held50ms',run.helper)]:
  run.channels();run.press('编辑');run.set_text('渠道名称','native021-esc-'+label.lower());run.press('保存渠道草稿')
  run.wait(lambda s:run.matches(s,'立即重启 Codex'),name=label+'-saved-notice')
  run.press('立即重启 Codex')
  before=run.wait(lambda s:any(d.get('title')=='重启 Codex' for d in run.dialogs(s)),name=label+'-before')
  focus=[{'title':n.get('title'),'role':n.get('role'),'path':n['path']} for n in before['nodes'] if n.get('focused')]
  assert before['active'] and any(n['title']=='确认重启' for n in focus),'No eligible active focused confirmation'
  run.capture(label+'-before')
  start=time.monotonic_ns()
  sent=subprocess.run([str(helper),'key',str(run.proc.pid),str(run.exe),'53'],env=run.env,capture_output=True,text=True,timeout=10)
  end=time.monotonic_ns()
  assert sent.returncode==0,sent.stdout+sent.stderr
  event=json.loads(sent.stdout)
  rec={'round':label,'helper':str(helper),'pid':run.proc.pid,'beforeActive':before['active'],'beforeFocused':focus,'requestedKeyCode':53,'flags':0,'keyDispatches':1,'nativeEventsRequested':2,'retryCount':0,'hostMonotonicInvokeBeginNanoseconds':start,'hostMonotonicInvokeEndNanoseconds':end,'nativeHelperResult':event,'keyPostTimesForOriginal':'Not exposed by original unmodified helper; host invocation bounds recorded'}
  if label.startswith('B'):
   posts=event['posts'];assert len(posts)==2 and [p['keyDown'] for p in posts]==[True,False]
   assert all(p['targetPid']==run.proc.pid and p['keyCode']==53 and p['flags']==0 for p in posts)
   rec['actualDownToUpMilliseconds']=(posts[1]['monotonicBeforePostNanoseconds']-posts[0]['monotonicAfterPostNanoseconds'])/1e6
   assert rec['actualDownToUpMilliseconds']>=50
  try:
   after=run.wait(lambda s:not run.dialogs(s),seconds=8,name=label+'-after-closed')
   rec['closedWithinOriginal8Seconds']=True
  except AssertionError as exc:
   after=run.snapshot(label+'-after-failed');rec['closedWithinOriginal8Seconds']=False;rec['failure']=str(exc)
  rec['observedAfterSeconds']=(time.monotonic_ns()-end)/1e9
  rec['afterActive']=after['active'];rec['afterFocused']=[{'title':n.get('title'),'role':n.get('role'),'path':n['path']} for n in after['nodes'] if n.get('focused')]
  rec['afterDialogs']=[d.get('title') for d in run.dialogs(after)]
  rec['noticeContinuedAfterKey']=bool(run.matches(after,'立即重启 Codex'))
  run.capture(label+('-after-closed' if rec['closedWithinOriginal8Seconds'] else '-after-failed'))
  rounds.append(rec);m['write_json'](run.out/'esc-ab-rounds.json',rounds)
  run.check('esc-'+label,'pass' if rec['closedWithinOriginal8Seconds'] and rec['noticeContinuedAfterKey'] else 'fail',**rec)
  if not rec['closedWithinOriginal8Seconds']:
   # Separate recovery after the recorded failure. Never convert it to key pass.
   run.press('关闭');run.wait(lambda s:not run.dialogs(s),seconds=8,name=label+'-X-recovery')
   rec['separateRecovery']={'method':'header X','closed':True,'notCountedAsEscapePass':True};run.capture(label+'-X-recovery')
   run.check('recovery-'+label,'pass',method='header X after recorded Escape failure',escapePass=False)
  if run.matches(run.snapshot(),'稍后'):run.press('稍后')
  assert run.proc.poll() is None and run.proc.pid==run.report['escExperiment']['sameCandidatePid']
  m['write_json'](run.out/'esc-ab-rounds.json',rounds)
 run.report['scopeCompleted']=True
except BaseException as exc:
 error=str(exc);(run.out/'esc-ab-failure.log').write_text(traceback.format_exc());run.report['error']=str(exc);run.report['errorKind']='fail'
finally:
 run.close()
 a=[r for r in rounds if r['round'].startswith('A')];b=[r for r in rounds if r['round'].startswith('B')]
 summary={'schemaVersion':1,'sameOriginalApp':run.report['app'],'sourceCommit':run.report.get('startupBuildCommit'),'binarySha256':run.report['binarySha256After'],'sameFreshRoot':str(run.root),'candidatePid':run.report.get('pid'),'rounds':rounds,'originalPasses':sum(r['closedWithinOriginal8Seconds'] for r in a),'held50msPasses':sum(r['closedWithinOriginal8Seconds'] for r in b),'roundsPerHelper':2,'timerTested':False,'allResultsPreserved':True,'error':error,'reportResult':run.report['result'],'noProductChanges':True,'noRetryOrTimeoutIncrease':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 summary['boundedConclusion']='Native input timing difference observed: original failed at least once and held50ms closed twice; no claim of a product intermittent-failure fix' if len(a)==len(b)==2 and any(not r['closedWithinOriginal8Seconds'] for r in a) and all(r['closedWithinOriginal8Seconds'] and r['noticeContinuedAfterKey'] for r in b) else 'No complete A/B distinction established; inspect raw rounds without attributing product/input causation'
 m['write_json'](run.out/'esc-ab-summary.json',summary);m['write_json'](OUT/'latest-summary.json',dict(summary,report=str(run.out/'report.json'),summary=str(run.out/'esc-ab-summary.json')))
 print(json.dumps(summary,ensure_ascii=False,indent=2))
