import pathlib,subprocess,os,json,sys,time,hashlib
p=pathlib.Path(__file__).resolve().parent
binary='/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/target/debug/deps/opencodex_desktop_lib-1179d0dfc9266c75'
env=os.environ.copy();env.update({'TMPDIR':str(p/'runtime'),'OPENCODEX_SANDBOX':'1','OPENCODEX_SANDBOX_ROOT':str(p/'runtime/manager')})
filters=sys.argv[1:] or ['modules::model_config::config_file::rename_tests']
for index,scope in enumerate(filters):
 command=['/usr/bin/sandbox-exec','-f',str(p/'runtime.sb'),binary,scope,'--nocapture','--test-threads=1']
 started=time.time();binary_hash=hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest()
 result=subprocess.run(command,env=env,capture_output=True,text=True)
 name=scope.split('::')[-1]
 attempt=len(list((p/'logs').glob('rust-'+name+'*.log')))+1
 log=p/'logs'/('rust-'+name+'-'+str(attempt)+'.log')
 log.write_text(result.stdout+result.stderr)
 log.with_suffix('.json').write_text(json.dumps({'command':command,'exit_code':result.returncode,'elapsed_seconds':round(time.time()-started,3),'binary_sha256':binary_hash},indent=2)+'\n')
 print('exit='+str(result.returncode)+' scope='+scope);print((result.stdout+result.stderr)[-6000:]);
 if result.returncode:sys.exit(result.returncode)
