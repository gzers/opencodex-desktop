# AC02 隔离官方客户端目录与本地路由

**最新 1313：前缀已修但生产 prepare 仍被 native CAS 版本域拒绝，见 [FINAL-1313.md](FINAL-1313.md)。raw-file SHA 与实际 Codex origin version 实测不同；pending 保留，未放宽门禁或重跑。**

**f0 最终生产尝试被真实官方 integration 绑定 HTTP400 阻断：见 [FINAL-F0.md](FINAL-F0.md)。编译/服务启动成功，尚未保存或调用 prepare；发布门未放行，无 fallback。**

**新生产编排验证已静态准备：见 [PRODUCTION-PREPARE.md](PRODUCTION-PREPARE.md)，等待新 freeze；将直接调用真实 prepare_saved_rename_restart，不由 spike 自行补救。旧 d20 失败与候选可行性按原身份保留。**

**最新候选接线：真实 reload + no-op batch owner + Codex CAS 已在隔离 spike 跑通，见 [OWNER-SPIKE.md](OWNER-SPIKE.md)。这是候选可行性，现产品两项失败与发布门保持；d20 事实仍见 [FINAL-D20.md](FINAL-D20.md) 和 [CURRENT-DEFAULT.md](CURRENT-DEFAULT.md)。**

2026-11-04，macOS arm64。**真实生产保存、官方 Codex 新进程目录加载和本地路由已通过；采用显式手工绑定的临时客户端配置。默认自动注入及桌面 GUI 未验收，AC-021-02 不因此关闭。**

代码：ocx-0219-fixes / codex/0.2.21-fixes，HEAD f7866c762fdd755a7549ea7a54ebfead22e363f2。文档：governance-main / docs/governance-main。本轮只新增三个 test/smoke/ocx021-owned-routing.* 文件与本目录证据；没有改生产源码或其它测试，没有提交、推送或重启日常 Codex。

## 最小可执行入口

| 发布物 | 本机缓存入口 | 实测版本 |
| --- | --- | --- |
| OpenCodex | /tmp/ocx020-owned-official-284/installation/node_modules/@bitkyc08/opencodex/bin/ocx.mjs，由 /Users/ezio/.hermes/node/bin/node 启动 | 2.84.0 |
| 官方 Codex CLI | /tmp/ocx020-owned-codex-0166/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex | 0.166.0 |
| 配套 Bun | /tmp/ocx020-owned-official-284/installation/node_modules/bun/bin/bun.exe | 1.4.2 |

均为缓存 npm 工具依赖，registry URL、sha512、安装锁与当前文件 SHA-256 已归档。本轮无下载、用户渠道认证或外网请求。@bitkyc08/opencodex 是该项目发布包，@openai/codex 是 OpenAI 官方 CLI，不混称发布方。

在代码根执行，默认只读 inventory，不启动官方命令：

    python3 test/smoke/ocx021-owned-routing.py
    python3 test/smoke/ocx021-owned-routing.py --prepare
    python3 test/smoke/ocx021-owned-routing.py --run --manual-client

--run 不带 --manual-client 保留正常自动集成验证模式，当前宿主的真实阻塞见下节。脚本新建临时根、清空继承环境、先验证 OS 隔离，再运行官方命令。使用项目 Sandbox 和明确 ProcessContext；离线构建直接依赖当前原路径生产库的 helper，不复制或修改生产实现。只读构建缓存通过 APFS clone 复制到新临时根，原缓存不写入。从当前生产 Cargo.lock 起步，实际 helper 锁随回执保存。

--official、--codex、--node 可指定明确缓存入口；当前只实测上述版本与 macOS Seatbelt。临时根保留时可复用本轮编译，下面是实际成功命令；复用前核对 209 份生产源摘要、Rust helper 摘要和二进制摘要，任一不一致即停止：

    python3 test/smoke/ocx021-owned-routing.py --run --manual-client --reuse-build ../governance-main/.adg/evidence/0.2.21/owned-client-routing-20261104/run-20261104-134855

临时二进制已回收或源码变化时，使用不带 --reuse-build 的命令重新构建。

## 实际结果

最终 [result.json](run-20261104-135035/result.json) 状态为 passed-manual-client-directory-and-local-routing。复用 [真实编译](run-20261104-134855/build.stderr) 二进制前，生产源/helper/二进制摘要全部一致；编译期间无源码漂移。

| 检查 | 实际结果 | 原始证据 |
| --- | --- | --- |
| 隔离先于官方启动 | 合成受保护文件读取被拒绝；预备阶段全部网络拒绝；运行阶段仅两个明确本机端口放行，未列出端口仍拒绝 | [probe.sb](run-20261104-135035/probe.sb)、[runtime.sb](run-20261104-135035/runtime.sb)、两条 canary 输出 |
| 改名前真实目录 | 官方 Codex app-server 的 model/list 返回 Krill-1/owned-routing-model 和 Krill-1/owned-second-model，显示名一致 | [RPC](run-20261104-135035/codex-before.json)、[目录](run-20261104-135035/codex-before-models.json) |
| 实际生产保存 | config_file::save_with_context 返回 changed=true；稳定 channel.id、模型身份、默认项、顺序/禁用项断言通过 | [保存回执](run-20261104-135035/production-save.stdout)、[合成配置读回](run-20261104-135035/owned-config-after-save.json) |
| 新官方进程加载 | 新 OpenCodex 读取改名配置；新 Codex app-server 返回 Krill/owned-routing-model 和 Krill/owned-second-model，旧前缀消失 | [RPC](run-20261104-135035/codex-after.json)、[目录](run-20261104-135035/codex-after-models.json) |
| 真实请求路由 | 官方 Codex exec 选择 Krill/owned-routing-model；经实际 OpenCodex 到夹具的唯一 POST 为 /v1/responses，body.model=owned-routing-model，stream=true，合成认证匹配 | [完整请求](run-20261104-135035/fixture-requests.json) |
| 客户端消费响应 | 本机夹具返回最小合法 Responses SSE；Codex 输出 OCX021_LOCAL_FIXTURE_OK、turn.completed，退出码 0 | [事件](run-20261104-135035/codex-local-turn.stdout)、[最终消息](run-20261104-135035/codex-last-message.txt) |
| 收尾 | 受控子进程已回收；54930/54929 均返回 errno 61（macOS ECONNREFUSED），无残留监听 | 最终 result.json |

目录来自 **Codex app-server 自己的 model/list**，不是 OpenCodex 管理 API/config 读回。请求由 **官方 Codex exec** 发起，不把 helper/spike 自身重启计作官方客户端。没有供应商参与，响应和合成用量都由本机夹具构造。

## 自动注入阻塞与手工边界

[正常自动集成运行](run-20261104-134338/result.json) 使用 clientIntegrations.codex=true。发布版 OpenCodex 实际启动并绑定本机端口，但 service-home 保护拒绝 Codex 写入，/readyz 未通过。[只读官方诊断](run-20261104-134338/ownership-probe.stdout) 原因：

> launchd has a job loaded but its plist is missing

该诊断证明 Bun homedir 和 env.HOME 均是临时 home。原因是当前 OS 用户域已有同名 launchd job，HOME 无法隔离这个注册，并非 HOME 设置遗漏。官方 OCX_TEST_HOME_GUARD 只读诊断结果相同。没有读取日常 plist/配置/凭据，也没有修改、停止或重启那个注册或服务。

最终模式明确关闭 Codex 自动集成，让未经改动的官方 OpenCodex CLI 正常启动。smoke .mjs 调用发布包原有 gatherRoutedModels、filterCatalogVisibleModels、buildCatalogEntries；模板来自真实 Codex 的 debug models --bundled。没有手写预期目录行或注入假 ownership verdict。**测试脚本手工写入临时 Codex 的 model_catalog_json 和本机 model_provider/base_url**，客户端据此加载并实际路由。具体文件在 codex-before/after-manual-config.toml 和 manual-catalog.json。

因此没有证明正常启动自动注入会在本宿主通过，也没有证明桌面 GUI 可见选择器、重启提示或按钮操作。机器回执明确 manualClientSetup=true、automaticClientIntegrationVerified=false、desktopGuiVerified=false，不能将手工绑定改称自动集成通过。

## 待主线处理

1. 不 seed 的正常自动注入需独立 OS 用户/VM/测试宿主，或明确服务命名空间隔离接口。用户后来允许的旧安装文件夹具单列于 AUTOMATIC-CHAIN.md；它不代表真实 OS 服务所有权。不能把夹具认证冒称为日常注册属于测试，也不放开日常目录读取。
2. 在完整隔离桌面宿主验证官方 GUI、保存提示、实际重启和可见目录选择，按主线要求完成双平台原生验收。
3. 本轮覆盖单渠道真实保存和一次 Responses 路由。全页、冲突、回滚、Key 池等引用各自改名核心证据，不外推为本脚本覆盖。用户报告的 macOS 原生 keychain 改名 1/1 是独立凭据证据，本轮不重跑，也不计作客户端加载。
4. 保存版本 owner 本轮实际返回成功，没有 saved_content_version_unconfirmed。后续源码变化须重验。本轮不修改 DMD/IMP/TASK 状态，不宣称 AC02 或整版完全验收。

## 来源与尝试记录

- [PLAN.md](PLAN.md) 保存运行前计划；[包源摘要](cached-package-source-manifest.json) 覆盖 OpenCodex 2019 文件、Codex launcher 3 文件和 native 包 43 文件。安装锁、Bun/Node 摘要及 smoke 源快照在 provenance/；最终一致性在 verification.json。
- run-20261104-134101：隔离准备通过。
- run-20261104-134129：生产编译通过；本 smoke 的 Seatbelt IP 字面量不受支持，服务未启动。已修正为 localhost:端口。
- run-20261104-134338：正常自动集成遇 service-home 保护，没有放宽保护。
- run-20261104-134855：真实保存与旧 Codex 目录通过；新目录 sidecar 误从仅含 routed 行的目录挑选 native 模板而停止。后固定使用原始官方 bundled 模板，没有改发布包或生产保存逻辑。
- run-20261104-135035：最终真实 CLI 加载与本地往返通过。失败日志保留，未删断言或替换历史结果。

临时根保留合成状态与依赖，便于复用；没有活跃测试进程。全部归档请求、配置和认证均由本脚本生成，不含日常配置或真实凭据。
