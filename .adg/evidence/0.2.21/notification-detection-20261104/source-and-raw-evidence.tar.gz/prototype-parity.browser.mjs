// The reference is the adopted cf5b snapshot, verified against all 119 hashes.
import fs from 'node:fs/promises'
import path from 'node:path'
import { pathToFileURL, fileURLToPath } from 'node:url'
const ev = path.dirname(fileURLToPath(import.meta.url))
const manifest = JSON.parse(await fs.readFile(path.join(ev, 'adopted-prototype-snapshot.json'), 'utf8'))
const { pickEngine } = await import('/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/ui/qa/engine.mjs')
const engine = await pickEngine(), browser = await engine.launch()
const out = path.join(ev, engine.name, 'prototype-parity'); await fs.mkdir(out, { recursive: true })
const checks = [], errors = [], blocked = [], samples = []
let variant = '', completed = false, failure = null
function check(name, passed, detail) { checks.push({ variant, name, passed: !!passed, detail }); if (!passed) throw Error(variant + ' ' + name + ': ' + JSON.stringify(detail)) }
async function protect(page, label) {
  page.on('pageerror', error => errors.push({ variant, label, message: error.message }))
  await page.route('**/*', route => { const u = new URL(route.request().url()); if (u.protocol === 'file:' || u.origin === 'http://127.0.0.1:52431') return route.continue(); blocked.push(route.request().url()); return route.abort() })
}
try {
  for (const size of [{ width: 1180, height: 760, theme: 'light', scale: 100 }, { width: 900, height: 600, theme: 'dark', scale: 100 }, { width: 1180, height: 760, theme: 'dark', scale: 200 }, { width: 900, height: 600, theme: 'light', scale: 50 }]) {
    variant = [size.width, size.theme, size.scale].join('-')
    const proto = await browser.newPage({ viewport: size }), impl = await browser.newPage({ viewport: size })
    await protect(proto, 'reference'); await protect(impl, 'implementation')
    await proto.goto(pathToFileURL(manifest.entry).href + '#models'); await proto.waitForSelector('.mp-provider-heading')
    await proto.evaluate(size => { document.documentElement.style.setProperty('--win-w', size.width + 'px'); document.documentElement.style.setProperty('--win-h', size.height + 'px'); document.documentElement.dataset.theme = size.theme; if (window.applyInterfaceScale) window.applyInterfaceScale(size.scale); else document.documentElement.style.setProperty('--ui-zoom', String(size.scale / 100)); window.dispatchEvent(new Event('resize')) }, size)
    await impl.goto('http://127.0.0.1:52431/?__audit=1&route=models&env=ready&runtime=running&theme=' + size.theme + '&effects=low'); await impl.locator('.channel-table').waitFor()
    await impl.evaluate(async scale => { (await import('/src/app/appearance/scale.ts')).applyInterfaceScale(scale) }, size.scale)
    const reference = await proto.locator('.mp-provider').first().evaluate(row => { const c = row.children, zoom = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ui-zoom')) || 1; return { channel: c[1].getBoundingClientRect().width / zoom, actions: c[4].getBoundingClientRect().width / zoom, columns: c.length, headers: [...document.querySelector('.mp-provider-heading').children].map(e => e.textContent.trim()), actionsText: [...c[4].querySelectorAll('button')].map(e => e.textContent.trim()), detectionDialog: c[4].querySelector('[data-mp="node-picker-open"]')?.getAttribute('aria-haspopup') } })
    const implementation = await impl.locator('.channel-table tbody tr').first().evaluate(row => { const c = row.children, zoom = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ui-zoom')) || 1; return { channel: c[1].getBoundingClientRect().width / zoom, actions: c[4].getBoundingClientRect().width / zoom, columns: c.length, headers: [...document.querySelector('.channel-table thead tr').children].map(e => e.textContent.trim()), actionsText: [...c[4].querySelectorAll('button')].map(e => e.textContent.trim()), detectionDialog: c[4].querySelector('.channel-node-detect')?.getAttribute('aria-haspopup') } })
    samples.push({ variant, reference, implementation })
    check('same selection + four business columns', reference.columns === 5 && implementation.columns === 5 && JSON.stringify(reference.headers) === JSON.stringify(implementation.headers), { reference: reference.headers, implementation: implementation.headers })
    check('both channel widths in adopted 160–220 logical px interval', [reference.channel, implementation.channel].every(width => width >= 159.5 && width <= 220.5), { reference: reference.channel, implementation: implementation.channel })
    check('both action columns exactly 250 logical px', [reference.actions, implementation.actions].every(width => Math.abs(width - 250) <= .5), { reference: reference.actions, implementation: implementation.actions })
    check('same detection/edit/copy/delete/order controls', JSON.stringify(reference.actionsText) === JSON.stringify(implementation.actionsText) && reference.detectionDialog === 'dialog' && implementation.detectionDialog === 'dialog', { reference: reference.actionsText, implementation: implementation.actionsText })
    await proto.screenshot({ path: path.join(out, variant + '-prototype-list.png') }); await impl.screenshot({ path: path.join(out, variant + '-software-list.png') })
    await proto.locator('[data-mp="node-picker-open"]').first().click(); await impl.locator('.channel-node-detect').first().click()
    const referenceModal = await proto.locator('#modal').evaluate(e => { const r = e.getBoundingClientRect(); return { role: e.getAttribute('role'), modal: e.getAttribute('aria-modal'), x: (r.left + r.right) / 2, y: (r.top + r.bottom) / 2, width: innerWidth, height: innerHeight, footerClose: [...e.querySelectorAll('footer button,.modal-foot button')].some(b => getComputedStyle(b).display !== 'none' && b.textContent.trim() === '关闭') } })
    const softwareModal = await impl.locator('dialog[open]').evaluate(e => { const r = e.getBoundingClientRect(); return { role: e.getAttribute('role'), modal: e.getAttribute('aria-modal'), x: (r.left + r.right) / 2, y: (r.top + r.bottom) / 2, width: innerWidth, height: innerHeight, footerClose: !!e.querySelector('footer') } })
    check('both use centered labelled modal and no footer close', [referenceModal, softwareModal].every(m => m.role === 'dialog' && m.modal === 'true' && Math.abs(m.x - m.width / 2) <= 2 && Math.abs(m.y - m.height / 2) <= 2 && !m.footerClose), { referenceModal, softwareModal })
    await proto.screenshot({ path: path.join(out, variant + '-prototype-detection.png') }); await impl.screenshot({ path: path.join(out, variant + '-software-detection.png') })
    await proto.close(); await impl.close()
  }
  completed = true
} catch (error) { failure = { variant, message: error.message }; throw error }
finally { await browser.close(); await fs.writeFile(path.join(out, 'report.json'), JSON.stringify({ completed, failure, engine: engine.name, sourceRevision: manifest.sourceRevision, referenceSourceFilesVerified: manifest.filesVerified, scope: 'POST05 adopted source to production geometry; mock only', checks, samples, errors, blocked }, null, 2)) }
if (errors.length || blocked.length) throw Error(JSON.stringify({ errors, blocked }))
console.log(engine.name, checks.length, 'prototype → software parity checks')
