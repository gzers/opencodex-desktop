const test=require('node:test'),assert=require('node:assert/strict');
const {make}=require('./component-topic-harness.cjs');
const clean=h=>{assert.deepEqual(h.errors,[]);assert.equal(h.network.length,0);};
test('非功能专题整页布局，只有一个运行Logo，业务概览和配置不变',async t=>{
 const h=await make('#conversations'),{w,document:d}=h;t.after(()=>h.dispose());const before=JSON.stringify(w.conversationPrototype.state().saved),models=JSON.stringify(w.modelPrototype.state().saved);
 const frame=d.querySelector('.pv-backdrop');assert.equal(frame.hasAttribute('src'),false);h.click('[data-launch="connection-map"]');await h.settle();
 assert.equal(d.documentElement.dataset.route,'connection-map');assert.ok(d.querySelector('.pv-canvas'));assert.equal(d.querySelector('.cm-card'),null);assert.equal(d.querySelectorAll('.pv-proxy').length,1);assert.match(frame.src,/layout=hero/);assert.equal(d.querySelector('#connectionMapDemoCard').hidden,false);
 assert.equal(w.connectionMapPrototype.state().visibleClients.length,3);assert.equal(w.connectionMapPrototype.state().visibleChannels.length,3);assert.ok(!d.querySelector('#route-overview .pv-canvas'));assert.equal(JSON.stringify(w.conversationPrototype.state().saved),before);assert.equal(JSON.stringify(w.modelPrototype.state().saved),models);clean(h);
});
test('展示设置取消与应用分开，未安装不可选，已安装未接入不生成线路',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());const state=()=>w.connectionMapPrototype.state(),before=JSON.stringify(w.modelPrototype.state().saved);
 h.click('[data-pv="settings"]');assert.equal(d.querySelector('[data-client="cursor"]').disabled,true);h.change('[data-client="codex"]',false);h.change('[data-client="gemini"]',true);assert.equal(state().preferences.clients.includes('codex'),true);h.click('[data-pv="settings-cancel"]');assert.equal(state().preferences.clients.includes('gemini'),false);
 h.click('[data-pv="settings"]');h.change('[data-client="codex"]',false);h.change('[data-client="gemini"]',true);h.click('[data-pv="settings-apply"]');assert.equal(state().visibleClients.some(c=>c.id==='gemini'),true);assert.equal(state().visibleClients.some(c=>c.id==='codex'),false);assert.equal(state().connections.some(e=>e.from==='gemini'),false);assert.equal(JSON.stringify(w.modelPrototype.state().saved),before);clean(h);
});
test('大量渠道仅收敛三个，搜索临时展开和固定偏好不改变聚合目录',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());const state=()=>w.connectionMapPrototype.state();h.click('[data-pv-scene="many"]');assert.equal(state().visibleChannels.length,3);assert.equal(state().hiddenChannels.length,27);
 h.click('[data-pv="channels"]');h.input('#pvChannelSearch','渠道 21');assert.match(d.querySelector('.pv-channel-results').textContent,/渠道 21/);assert.equal(d.querySelectorAll('[data-pv="expand"]').length,1);h.click('[data-pv="expand"]');assert.equal(state().visibleChannels[0].id,'extra-20');assert.equal(state().hiddenChannels.length,27);
 h.click('[data-pv="settings"]');h.change('[data-pin="official"]',true);h.click('[data-pv="settings-apply"]');assert.ok(state().preferences.pins.includes('official'));assert.equal(state().visibleChannels.length+state().hiddenChannels.length,30);clean(h);
});
test('能力适配归Desktop，仅目标分支经过；普通模式没有适配一跳',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());let state=w.connectionMapPrototype.state();assert.equal(state.connections.some(e=>e.to==='adapter'),false);
 h.click('[data-pv-scene="adapter"]');state=w.connectionMapPrototype.state();assert.ok(d.querySelector('[data-node="adapter"]'));assert.ok(state.connections.some(e=>e.from==='proxy'&&e.to==='adapter'));assert.ok(state.connections.some(e=>e.from==='adapter'&&e.to==='krill'));assert.ok(state.connections.some(e=>e.from==='desktop'&&e.to==='adapter'&&e.kind==='manage'));assert.equal(state.connections.some(e=>e.from==='adapter'&&e.to==='newapi'),false);h.click('[data-pv="detail"][data-id="adapter"]');assert.match(d.querySelector('#pvFloat').textContent,/未生产接入/);clean(h);
});
test('直连、无观察、代理停止、过期分别表达，不伪造成功请求',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());const state=()=>w.connectionMapPrototype.state();
 h.click('[data-pv-scene="direct"]');assert.ok(state().connections.some(e=>e.bypass));assert.equal(state().connections.some(e=>e.kind!=='manage'&&(e.to==='proxy'||e.from==='proxy')),false);assert.match(d.querySelector('#pvRequest').textContent,/尚未观察/);
 h.click('[data-pv-scene="configured"]');assert.equal(state().connections.some(e=>e.kind==='observed'),false);h.click('[data-pv-scene="stopped"]');assert.equal(state().motion,'stopped');assert.match(d.querySelector('#pvStatus').textContent,/未运行/);h.click('[data-pv-scene="unavailable"]');assert.equal(state().motion,'stale');assert.match(d.querySelector('#pvRequest').textContent,/上次采样/);clean(h);
});
test('请求聚焦限制具体来源与回退目标，节点动作仅操作fixture',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());const state=()=>w.connectionMapPrototype.state();h.click('[data-pv="select"][data-id="claude"]');h.click('[data-pv="request"]');assert.equal(state().connections.filter(e=>e.kind!=='manage'&&e.to==='proxy').length,1);assert.equal(state().connections.find(e=>e.kind!=='manage'&&e.to==='proxy').from,'claude');
 h.click('[data-pv-scene="fallback"]');assert.ok(state().connections.some(e=>e.to==='krill'&&e.kind==='warning'));assert.ok(state().connections.some(e=>e.to==='newapi'&&e.kind==='observed'));h.click('[data-pv="more"]');h.click('[data-pv="stop"]');assert.equal(state().running,false);h.click('[data-pv="start"]');assert.equal(state().running,true);clean(h);
});
test('所有模型入口仍调用公共选择器，取消不改变业务模型或专题偏好',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());const before=JSON.stringify(w.modelPrototype.state().saved);h.click('[data-pv="model"][data-id="newapi"]');assert.equal(w.modelPickerPrototype.state().businessIntegration,true);assert.ok(d.querySelector('.mpk-table'));h.click('#modalCancel');assert.equal(JSON.stringify(w.modelPrototype.state().saved),before);clean(h);
});
test('同一Logo实例、离开暂停与返回保留显示偏好，不跨页写设置',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());const frame=d.querySelector('.pv-backdrop');h.click('[data-pv="settings"]');h.change('[data-option="sync"]',false);h.click('[data-pv="settings-apply"]');d.documentElement.dataset.theme='dark';await h.settle();assert.equal(d.querySelector('.pv-backdrop'),frame);
 h.click('[data-route="overview"]');await h.settle();assert.equal(d.querySelector('#connectionMapPage').dataset.active,'false');h.click('[data-launch="connection-map"]');await h.settle();assert.equal(w.connectionMapPrototype.state().preferences.sync,false);assert.equal(d.querySelector('[data-node="sync"]'),null);assert.equal(d.querySelector('.pv-backdrop'),frame);clean(h);
});

test('多个可见客户端按空间折叠，临时展开未接入对象不连线',async t=>{
 const h=await make('#connection-map'),{w,document:d}=h;t.after(()=>h.dispose());const state=()=>w.connectionMapPrototype.state();h.click('[data-pv="settings"]');h.change('[data-client="codex-cli"]',true);h.change('[data-client="gemini"]',true);h.click('[data-pv="settings-apply"]');assert.equal(state().visibleClients.length,3);assert.equal(state().hiddenClients.length,2);h.click('[data-pv="clients"]');h.click('[data-pv="expand-client"][data-id="gemini"]');assert.equal(state().visibleClients[0].id,'gemini');assert.equal(state().visibleClients.length,3);assert.equal(state().connections.some(e=>e.from==='gemini'),false);clean(h);
});
