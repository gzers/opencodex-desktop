/*
 * Derived from rsvedant/opencode-windsurf-auth (src/cloud-direct/), MIT licensed,
 * Copyright (c) 2026 Vedant. The full notice is in ./index.ts.
 */
/**
 * Per-account model catalog from Cognition's `GetCascadeModelConfigs`.
 *
 * Why this exists — issue #14:
 *   The cloud's `GetChatMessage` returns a single Connect-streaming EOS frame
 *   containing `{"error":{"code":"permission_denied","message":"an internal
 *   error occurred (trace ID: <hex>)"}}` whenever the caller's account tier
 *   does not include the requested `model_uid`. Reproduced byte-identical on a
 *   `TEAMS_TIER_DEVIN_FREE` account for every Anthropic/Gemini/Premium UID
 *   (only `swe-1-6-slow` streamed a real reply). The user-facing message is
 *   indistinguishable from a transient server fault — issue #14's reporter
 *   spent multiple sessions guessing.
 *
 *   The pre-flight here checks the per-account catalog (`disabled` flag on
 *   `ClientModelConfig` field #4) BEFORE we spend a roundtrip on a request
 *   the cloud will refuse. When the lookup fails (network, auth, schema
 *   drift) we silently fall back to the chat path so a transient catalog
 *   outage can't take chat down with it.
 *
 * Schema (#1/#4/#22 verified against the bundled `extension.js`,
 * `exa.codeium_common_pb.ClientModelConfig`; #18 identified from a live
 * catalog dump against vendor-known windows; #5 corroborated against the
 * public WindsurfAPI `ClientModelConfig` documentation):
 *
 *   GetCascadeModelConfigsResponse {
 *     #1 client_model_configs: repeated ClientModelConfig
 *   }
 *   ClientModelConfig {
 *     #1  label                string
 *     #4  disabled             bool   ← the gate this module reads
 *     #5  supports_images      bool   ← tri-state: absent stays unknown
 *     #18 max_input_tokens     varint ← per-account context window
 *     #22 model_uid            string ← what `GetChatMessage` accepts
 *     #23 model_info           ModelInfo { #6 features { #15 supports_thinking },
 *                                          #13 max_output_tokens, #23 model_family_uid }
 *     #30 family_metadata      ModelFamilyMetadata { #1 family_label,
 *                                          #2 repeated Entry { #1 axis key, #2 { #1 order, #2 name } },
 *                                          #3 is_default_model_in_family }
 *     #31 is_default_model_in_family bool
 *   }
 *
 *   #23/#30/#31 were read back from a live 267-row catalog (2026-09-27): every
 *   current row names its family, and each family marks one default member.
 *   Legacy `MODEL_*` rows carry no #30.
 *
 *   Disabled semantics: TRUE means "this UID exists in the catalog but the
 *   caller's account/tier cannot run inference against it." BYOK models
 *   surface as `disabled: false` so users with their own provider keys still
 *   pass through — the only way they fail at chat time is a missing key,
 *   which surfaces with a different message.
 *
 * Cache: per (apiServerUrl, apiKey) for {@link CATALOG_TTL_MS}. Cognition
 * doesn't bump catalog entries mid-session in normal operation, so a 10-min
 * TTL trades one extra roundtrip per ~10 min for clear errors on every chat.
 */

import * as crypto from 'crypto';
import { buildMetadata } from './metadata.js';
import { getCachedUserJwt } from './auth.js';
import { encodeMessage, iterFields } from './wire.js';
import { resolveDevinApiBaseUrl } from '../../../oauth/devin/api-base.js';

/** 10 minutes — see header. */
const CATALOG_TTL_MS = 10 * 60 * 1000;

/** Catalog endpoint inactivity timeout. Cognition responds in <500ms steady-state. */
const CATALOG_FETCH_TIMEOUT_MS = 10_000;

export interface ModelCatalogEntry {
  /** Cloud-side `model_uid` (e.g. `claude-opus-4-7-medium`). */
  modelUid: string;
  /** Human label (e.g. `Claude Opus 4.7 Medium`) — used in error messages. */
  label: string;
  /** True when the caller's account tier cannot use this UID for chat. */
  disabled: boolean;
  /**
   * Maximum input tokens the account may send this model, from
   * `ClientModelConfig` field #18.
   *
   * Cognition publishes no context-window numbers anywhere: not in the Devin
   * CLI or Desktop model pages, not in the SWE-2 or SWE-1.7 announcements, and
   * not in the Windsurf model reference, which has no such table. The only
   * numbers on those pages are long-context PRICING thresholds, which are a
   * different quantity. That makes this field the single first-party source,
   * and it is per account rather than per model id.
   *
   * Absent when the entry omits the field, which is how a future schema change
   * degrades: the caller keeps its static fallback instead of reporting zero.
   */
  contextWindow?: number;
  /**
   * Image-input support from `ClientModelConfig` field #5, kept as a
   * tri-state: a present `true` asserts text+image support, a present
   * `false` asserts text-only, and an OMITTED field stays `undefined`
   * (unknown). Deliberately unlike `disabled`, which defaults to false —
   * collapsing "never asserted" into "text-only" was the #1796 regression
   * (see src/providers/antigravity-models.ts).
   */
  supportsImages?: boolean;
  /** ModelInfo #13: the model's own output-token ceiling. */
  maxOutputTokens?: number;
  /** ModelInfo #6.15. */
  supportsThinking?: boolean;
  /** ModelInfo #23, e.g. `swe-1.7` for both `swe-1-7` and `swe-1-7-medium`. */
  familyUid?: string;
  /** ModelFamilyMetadata #1, e.g. `SWE-1.7`. */
  familyLabel?: string;
  /**
   * ModelFamilyMetadata #2: this row's position on each of its family's axes,
   * keyed by axis name (`Effort`, `Reasoning Effort`, `Fast Mode`, `1M Context`,
   * `Thinking`, ...). Toggle axes such as `Fast Mode` carry only an order.
   */
  familyAxes?: Record<string, DevinFamilyAxisValue>;
  /** #31 (or #30.3): the member the family selects when nothing is asked for. */
  isFamilyDefault?: boolean;
}

export interface DevinFamilyAxisValue {
  order: number;
  name?: string;
}

/**
 * Rows whose catalog entry claims image support that the model does not have.
 * Live 2026-09-27: `swe-1-6` answered "NOIMAGE" to a solid red PNG while
 * `swe-1-6-fast` and `swe-2-medium` named the colour, so the image is dropped
 * server-side without an error. Marking it text-only lets the vision fallback
 * describe the image instead of the model silently never seeing it.
 */
const IMAGE_BLIND_UIDS = new Set(['swe-1-6']);

function parseFamilyMetadata(buf: Buffer): { label?: string; axes: Record<string, DevinFamilyAxisValue>; isDefault: boolean } {
  let label: string | undefined;
  let isDefault = false;
  const axes: Record<string, DevinFamilyAxisValue> = {};
  for (const f of iterFields(buf)) {
    if (f.num === 1 && f.wire === 2 && Buffer.isBuffer(f.value)) label = f.value.toString('utf8');
    else if (f.num === 3 && f.wire === 0) isDefault = f.value === 1n;
    else if (f.num === 2 && f.wire === 2 && Buffer.isBuffer(f.value)) {
      let key = '';
      const value: DevinFamilyAxisValue = { order: 0 };
      for (const e of iterFields(f.value)) {
        if (e.num === 1 && e.wire === 2 && Buffer.isBuffer(e.value)) key = e.value.toString('utf8');
        else if (e.num === 2 && e.wire === 2 && Buffer.isBuffer(e.value)) {
          for (const v of iterFields(e.value)) {
            if (v.num === 1 && v.wire === 0) value.order = Number(v.value);
            else if (v.num === 2 && v.wire === 2 && Buffer.isBuffer(v.value)) value.name = v.value.toString('utf8');
          }
        }
      }
      if (key) axes[key] = value;
    }
  }
  return { ...(label ? { label } : {}), axes, isDefault };
}

function parseModelInfo(buf: Buffer): { maxOutputTokens?: number; familyUid?: string; supportsThinking?: boolean } {
  const out: { maxOutputTokens?: number; familyUid?: string; supportsThinking?: boolean } = {};
  for (const f of iterFields(buf)) {
    if (f.num === 13 && typeof f.value === 'bigint' && f.value > 0n) out.maxOutputTokens = Number(f.value);
    else if (f.num === 23 && f.wire === 2 && Buffer.isBuffer(f.value) && f.value.length > 0) out.familyUid = f.value.toString('utf8');
    else if (f.num === 6 && f.wire === 2 && Buffer.isBuffer(f.value)) {
      for (const g of iterFields(f.value)) if (g.num === 15 && g.wire === 0) out.supportsThinking = g.value === 1n;
    }
  }
  return out;
}

export interface CacheEntry {
  /** Lookup keyed by `model_uid`. */
  byUid: Map<string, ModelCatalogEntry>;
  fetchedAt: number;
  /** Cache key components, captured for invalidation/log purposes. */
  apiKey: string;
  host: string;
}

let cached: CacheEntry | null = null;
let inFlight: Promise<CacheEntry> | null = null;
let inFlightKey: string | null = null;
// Bumped on clearCachedCatalog so an in-flight fetch racing with a clear
// can't repopulate the cache with a just-invalidated catalog.
let cacheEpoch = 0;

function flightKey(apiKey: string, host: string): string {
  return `${host}\x1f${apiKey}`;
}

/**
 * Parse a GetCascadeModelConfigsResponse buffer into a UID-keyed map.
 * A malformed catalog returns an empty map.
 */
export function parseCatalogBuffer(buf: Buffer, apiKey: string, host: string): CacheEntry {
  // GetCascadeModelConfigsResponse #1 (repeated ClientModelConfig)
  const byUid = new Map<string, ModelCatalogEntry>();
  for (const f of iterFields(buf)) {
    if (f.num !== 1 || f.wire !== 2 || !Buffer.isBuffer(f.value)) continue;
    let label = '';
    let modelUid = '';
    let disabled = false;
    let contextWindow = 0;
    let supportsImages: boolean | undefined;
    let info: ReturnType<typeof parseModelInfo> = {};
    let family: ReturnType<typeof parseFamilyMetadata> | undefined;
    let isFamilyDefault = false;
    for (const sf of iterFields(f.value as Buffer)) {
      if (sf.num === 1 && sf.wire === 2 && Buffer.isBuffer(sf.value)) {
        label = (sf.value as Buffer).toString('utf8');
      } else if (sf.num === 4 && sf.wire === 0) {
        // #4 = disabled (bool, varint 0/1)
        disabled = sf.value === 1n;
      } else if (sf.num === 5 && sf.wire === 0) {
        // #5 = supportsImages (bool, varint 0/1). Absent stays unknown — see
        // ModelCatalogEntry; do not default it like disabled.
        supportsImages = sf.value === 1n;
      } else if (sf.num === 18 && sf.wire === 0) {
        // #18 = max input tokens. Identified by dumping a live catalog and
        // reading the varints back against models whose windows are known from
        // their upstream vendors: 1000000 on the Claude and GPT rows, 1048576
        // on Gemini/Kimi/GLM, 500000 on Grok, 262000 on swe-2.
        contextWindow = Number(sf.value);
      } else if (sf.num === 22 && sf.wire === 2 && Buffer.isBuffer(sf.value)) {
        modelUid = (sf.value as Buffer).toString('utf8');
      } else if (sf.num === 23 && sf.wire === 2 && Buffer.isBuffer(sf.value)) {
        info = parseModelInfo(sf.value);
      } else if (sf.num === 30 && sf.wire === 2 && Buffer.isBuffer(sf.value)) {
        family = parseFamilyMetadata(sf.value);
      } else if (sf.num === 31 && sf.wire === 0) {
        isFamilyDefault = sf.value === 1n;
      }
    }
    if (IMAGE_BLIND_UIDS.has(modelUid)) supportsImages = false;
    if (modelUid.length > 0) {
      byUid.set(modelUid, {
        modelUid,
        label: label || modelUid,
        disabled,
        ...(contextWindow > 0 ? { contextWindow } : {}),
        ...(supportsImages !== undefined ? { supportsImages } : {}),
        ...info,
        ...(family?.label ? { familyLabel: family.label } : {}),
        ...(family ? { familyAxes: family.axes } : {}),
        ...(isFamilyDefault || family?.isDefault ? { isFamilyDefault: true } : {}),
      });
    }
  }
  return { byUid, fetchedAt: Date.now(), apiKey, host };
}

/**
 * Fetch the cascade model catalog for `(apiKey, host)` and parse the
 * subset of `ClientModelConfig` we care about into a UID-keyed map.
 *
 * Throws on transport/auth failure so the caller can decide whether to fall
 * back to "skip pre-flight". Does NOT throw on an unexpected response body —
 * a malformed catalog returns an empty map, treated the same as "model not
 * listed" by the chat pre-flight.
 *
 * Uses only an internal timeout — caller cancellation is handled by
 * getCachedCatalog racing each caller's signal against the shared promise.
 */
async function fetchCatalog(apiKey: string, host: string): Promise<CacheEntry> {
  const userJwt = await getCachedUserJwt(apiKey, host);

  const metadata = buildMetadata({
    apiKey,
    userJwt,
    sessionId: crypto.randomUUID(),
    requestId: BigInt(Date.now()),
    triggerId: crypto.randomUUID(),
  });
  // GetCascadeModelConfigsRequest { metadata: Metadata }  — Metadata is #1.
  const reqBody = encodeMessage(1, metadata);

  // Internal 10s timeout so a stalled catalog endpoint can't deadlock chat.
  // The shared fetch uses only this internal timeout — caller cancellation is
  // handled by racing each caller's signal against the shared promise in
  // getCachedCatalog, so one caller's abort never propagates to unrelated
  // callers sharing the same in-flight fetch.
  const ac = new AbortController();
  const timer = setTimeout(
    () => ac.abort(new Error(`catalog: fetch timeout (${CATALOG_FETCH_TIMEOUT_MS}ms)`)),
    CATALOG_FETCH_TIMEOUT_MS,
  );

  let resp: Response;
  try {
    resp = await fetch(`${resolveDevinApiBaseUrl(host)}/exa.api_server_pb.ApiServerService/GetCascadeModelConfigs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/proto', 'Connect-Protocol-Version': '1' },
      body: new Uint8Array(reqBody),
      // This body carries the api_key; a redirect would replay it elsewhere.
      redirect: 'error',
      signal: ac.signal,
    });
    if (!resp.ok) {
      // Status only: the error body can quote the api_key-bearing request.
      throw new Error(`GetCascadeModelConfigs failed (HTTP ${resp.status})`);
    }
    // Read the body BEFORE clearing the timeout — fetch resolves on headers,
    // not body completion. A stalled body would otherwise block indefinitely.
    const buf = Buffer.from(await resp.arrayBuffer());
    return parseCatalogBuffer(buf, apiKey, host);
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Get the cached catalog for `(apiKey, host)`, fetching when missing or stale.
 *
 * Concurrent callers for the SAME (apiKey, host) share one in-flight fetch
 * (no thundering herd on startup). Concurrent callers for DIFFERENT keys
 * serialise the in-flight slot but only one of them holds it at a time —
 * good enough for opencode's single-account-at-a-time usage pattern.
 *
 * Returns `null` on fetch failure (network, transient 5xx, auth issue). The
 * caller treats `null` as "skip pre-flight and let the chat path surface the
 * server-side error itself."
 */
export async function getCachedCatalog(
  apiKey: string,
  host: string,
  signal?: AbortSignal,
): Promise<CacheEntry | null> {
  if (cached && cached.apiKey === apiKey && cached.host === host) {
    if (Date.now() - cached.fetchedAt < CATALOG_TTL_MS) {
      return cached;
    }
  }

  const key = flightKey(apiKey, host);
  // Race the caller's signal against the shared promise so one caller's
  // cancellation doesn't propagate to unrelated callers sharing the fetch.
  const raceSignal = <T>(p: Promise<T>): Promise<T> =>
    signal
      ? Promise.race([
          p,
          new Promise<T>((_, reject) => {
            if (signal.aborted) reject(signal.reason);
            else signal.addEventListener('abort', () => reject(signal.reason), { once: true });
          }),
        ])
      : p;

  if (inFlight && inFlightKey === key) {
    try {
      return await raceSignal(inFlight);
    } catch {
      return null;
    }
  }

  const promise = fetchCatalog(apiKey, host);
  inFlight = promise;
  inFlightKey = key;
  const epochAtStart = cacheEpoch;
  try {
    const result = await raceSignal(promise);
    if (cacheEpoch === epochAtStart) {
      cached = result;
    }
    return result;
  } catch {
    return null;
  } finally {
    if (inFlight === promise) {
      inFlight = null;
      inFlightKey = null;
    }
  }
}

/**
 * Drop the cached catalog. Call after logout/account switch so a fresh
 * sign-in doesn't see a previous account's allow-list. Bumps the cache
 * epoch so an in-flight fetch racing with this clear can't repopulate
 * the cache with the just-invalidated catalog.
 */
export function clearCachedCatalog(): void {
  cached = null;
  inFlight = null;
  inFlightKey = null;
  cacheEpoch++;
}

/**
 * Test seam: install a catalog as the live cache entry. Mirrors
 * clearCachedCatalog's invalidation — the in-flight slot is dropped and the
 * epoch bumped — so a fetch racing the seed cannot overwrite it, and a null
 * entry resets the cache between tests.
 */
export function setCachedCatalogForTests(entry: CacheEntry | null): void {
  cached = entry;
  inFlight = null;
  inFlightKey = null;
  cacheEpoch++;
}

/**
 * Tier-disabled error — thrown by the chat pre-flight when the catalog lists
 * a model as `disabled: true` for this account. The message names the model
 * and points at the plan page, replacing Cognition's opaque
 * "an internal error occurred" trailer.
 */
export class ModelNotAvailableError extends Error {
  constructor(
    public readonly modelUid: string,
    public readonly label: string,
    public readonly reason: 'disabled' | 'not_listed',
  ) {
    super(
      reason === 'disabled'
        ? `Model "${label}" (uid=${modelUid}) is not enabled for your Cognition account. ` +
          `The Cognition catalog returned it with disabled=true — meaning your current plan/tier ` +
          `does not include this model. ` +
          `Check the model picker on https://codeium.com/account, or pick a different model. ` +
          `(This message replaces Cognition's "an internal error occurred" — same root cause.)`
        : `Model uid "${modelUid}" is not listed in the Cognition catalog for your account. ` +
          `Either the UID has been retired upstream or your account/region doesn't serve it. ` +
          `Run \`curl http://127.0.0.1:42100/v1/models\` to see the canonical names your plan accepts.`,
    );
    this.name = 'ModelNotAvailableError';
  }
}
