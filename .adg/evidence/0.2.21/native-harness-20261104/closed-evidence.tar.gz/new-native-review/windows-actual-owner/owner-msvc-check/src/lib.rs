pub mod errors {
 pub type AppResult<T> = Result<T,AppError>;
 #[derive(Debug)] pub enum AppError { NotConfigured, FileSystem{operation:String,detail:String} }
}
pub mod state {
 #[derive(Clone)] pub struct ProcessContext {pub runtime:crate::infrastructure::runtime_executable::SharedRuntimeExecutable,pub working_directory:std::path::PathBuf,pub opencodex_home:std::path::PathBuf}
}
pub mod types {pub mod discovery {
 pub struct EnvironmentPaths {pub node:std::path::PathBuf,pub npm:std::path::PathBuf,pub ocx:std::path::PathBuf}
 impl EnvironmentPaths {pub fn new(node:std::path::PathBuf,npm:std::path::PathBuf,ocx:std::path::PathBuf)->Self{Self{node,npm,ocx}}}
}}
pub mod modules {
 #[path="/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/modules/test_sandbox/mod.rs"] pub mod test_sandbox;
 pub mod backup { pub mod safety {
  pub fn check_path(_: &std::path::Path,_:&std::path::Path,_:bool)->std::io::Result<()> {unimplemented!("typecheck only")}
  pub fn read_file(_: &std::path::Path,_:u64)->std::io::Result<Vec<u8>> {unimplemented!("typecheck only")}
 }}
 pub mod model_config {
  pub mod schema {
   #[derive(Debug)] pub struct ModelError {pub code:String,pub message:String}
   pub type ModelResult<T> = Result<T,ModelError>;
   pub fn invalid(code:&str,message:impl Into<String>)->ModelError{ModelError{code:code.into(),message:message.into()}}
  }
  pub mod store {pub fn sha256(_: &[u8])->String {unimplemented!("typecheck only")}}
  pub mod cache_refresh {
   #[path="/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/modules/model_config/client_selection_rename.rs"] pub mod client_selection_rename;
   #[path="/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/modules/model_config/client_npm_runtime.rs"] pub mod client_npm_runtime;
  }
 }
}
pub mod infrastructure {
 #[path="/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/infrastructure/platform.rs"] pub mod platform;
 #[path="/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/infrastructure/discovery_paths.rs"] pub mod discovery_paths;
 #[path="/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/infrastructure/windows_query_job.rs"] pub mod windows_query_job;
 #[path="/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/infrastructure/runtime_executable.rs"] pub mod runtime_executable;
}
