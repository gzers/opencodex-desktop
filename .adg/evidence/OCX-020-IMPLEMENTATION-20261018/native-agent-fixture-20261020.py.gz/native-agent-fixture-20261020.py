import os,json,socket,subprocess,threading,time,signal
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
root=Path('/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-020-model-config/test/runtime/ocx020-native-agent-20261020')
info=json.loads((root/'environment.json').read_text());anchor=Path(info['anchor']);user=Path(info['user']);home=anchor/'opencodex-home'
counts={'modelsGet':0,'generationPost':0}
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path.split('?')[0] not in ['/v1/models','/models']:
   self.send_error(404);return
  counts['modelsGet']+=1;data=json.dumps({'object':'list','data':[{'id':model,'object':'model'} for model in ['gpt-6-astra','claude-fable-5-1','fixture-raw-long-id']]}).encode()
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_POST(self):
  counts['generationPost']+=1
  raw=self.rfile.read(int(self.headers.get('Content-Length','0')));body=json.loads(raw)
  try:
   prompt=json.loads(body['input'][-1]['content']);task=prompt['task'];targets=task['targets'];proposals=[]
   for target in targets:
    buffer=target.get('buffer') or {};content=json.loads(json.dumps(buffer.get('content') or target['revision']['content']))
    content['description']='回环固定建议第'+str(counts['generationPost'])+'轮'
    content['rules']['contextWindow']={'mode':'custom','value':131072+counts['generationPost']*1024}
    proposals.append({'templateId':target['templateId'],'baseRevision':target['revision']['id'],'label':buffer.get('label') or target['label'],'content':content})
   (root/'request-observation.json').write_text(json.dumps({'round':counts['generationPost'],'targets':len(targets),'history':prompt.get('conversation',[]),'providerModel':body.get('model'),'scoped':all(p.get('templateId') for p in proposals)},ensure_ascii=False,indent=2))
   result={'submissionId':__import__('uuid').uuid4().__str__(),'contractVersion':1,'proposals':proposals,'report':'回环固定建议第'+str(counts['generationPost'])+'轮，等待明确接受'}
   payload={'id':'resp_fixture','object':'response','status':'completed','model':body.get('model'),'output':[{'type':'message','role':'assistant','content':[{'type':'output_text','text':json.dumps(result,ensure_ascii=False)}]}],'output_text':json.dumps(result,ensure_ascii=False)}
   if (root/'hold-generation').exists():
    for _ in range(300):
     if not (root/'hold-generation').exists():break
     time.sleep(.1)
   data=json.dumps(payload,ensure_ascii=False).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  except Exception as e:
   (root/'fixture-error.txt').write_text(repr(e));self.send_error(500)
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();base='http://127.0.0.1:'+str(server.server_port)+'/v1'
config={'port':port,'hostname':'127.0.0.1','defaultProvider':'fixture-one','providers':{name:{'adapter':'openai-responses','authMode':'key','baseUrl':base,'apiKey':'fixture-only-key','models':['gpt-6-astra','claude-fable-5-1','fixture-raw-long-id'],'liveModels':False,'allowPrivateNetwork':True,'newModelPolicy':'off','selectedModels':['gpt-6-astra','claude-fable-5-1']} for name in ['fixture-one','fixture-two']},'claudeCode':{'systemEnv':False,'enabled':False},'clientIntegrations':{'codex':True,'grok':False,'claude':False},'syncResumeHistory':False,'serviceHealthRecovery':{'enabled':False},'oauthOpenBrowser':False}
(home/'config.json').write_text(json.dumps(config,indent=2))
env=dict(os.environ);env.update(HOME=str(user),CODEX_HOME=str(user/'.codex'),XDG_CONFIG_HOME=str(user/'.config'),OPENCODEX_HOME=str(home))
log=(root/'official.log').open('wb');child=subprocess.Popen(['/Users/ezio/.local/bin/node',info['entry'],'start','--port',str(port)],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
for i in range(600):
 if child.poll() is not None:raise SystemExit('official exited '+str(child.returncode))
 if (home/'runtime-port.json').is_file():break
 time.sleep(.1)
else:raise SystemExit('official startup timeout')
info.update(officialPid=child.pid,modelPort=server.server_port,servicePort=port,runnerPid=os.getpid());(root/'environment.json').write_text(json.dumps(info,indent=2));print('isolated fixture ready',json.dumps({k:info[k] for k in ['officialPid','modelPort','servicePort']}),flush=True)
stop=threading.Event()
def quit(*_):stop.set()
signal.signal(signal.SIGTERM,quit);signal.signal(signal.SIGINT,quit)
while not stop.wait(1):
 (root/'request-counts.json').write_text(json.dumps(counts))
server.shutdown();os.killpg(child.pid,signal.SIGTERM)
try:child.wait(timeout=10)
except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL)
(root/'request-counts.json').write_text(json.dumps(counts));print('fixture stopped',json.dumps(counts),flush=True)
