#!/usr/bin/env python3
"""Run the registered product resolver tests, including verified public files.

The public package directory was fetched and checked against official archive
integrities separately. This runner has no network access and executes neither
codex.cmd nor the native codex.exe; it intercepts the unchanged JS spawn only.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--test-binary", type=Path, required=True)
parser.add_argument("--public-root", type=Path, required=True)
parser.add_argument("--node", type=Path, required=True)
args = parser.parse_args()
out = Path(__file__).resolve().parent
code = Path("/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes")
test, public, node = (p.resolve(strict=True) for p in (args.test_binary, args.public_root, args.node))
sources = [code / "apps/desktop/tauri/src/modules/model_config/client_npm_runtime.rs",
           code / "apps/desktop/tauri/tests/client_npm_runtime.rs"]
fixtures = code / "apps/desktop/tauri/tests/fixtures/ocx021-codex-npm"
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before = {str(path): digest(path) for path in sources}
root = Path(tempfile.mkdtemp(prefix="npm-native-isolated-", dir="/private/tmp"))
for name in ["home", "tmp"]: (root / name).mkdir()
quote = lambda value: json.dumps(str(value))
policy = root / "isolated.sb"
policy.write_text("\n".join([
    "(version 1)", "(allow default)", "(deny network*)", "(deny file-write*)",
    f'(allow file-write* (subpath {quote(root)}) (subpath {quote(out)}) (literal "/dev/null"))',
    '(deny file-read* (subpath "/Users/ezio"))',
    f'(allow file-read* (literal {quote(test)}) (literal {quote(node)}) (subpath {quote(fixtures)}))',
    '(deny file-read* (subpath "/Library/Keychains"))',
    '(deny mach-lookup (global-name "com.apple.securityd") (global-name "com.apple.securityd.xpc") (global-name "com.apple.security.agent"))',
]) + "\n")
shutil.copyfile(policy, out / "isolation.sb")
env = {"HOME": str(root / "home"), "TMPDIR": str(root / "tmp"), "PATH": "/usr/bin:/bin",
       "OCX_TEST_CODEX_NPM_PUBLIC": str(public), "OCX_TEST_CODEX_NPM_NODE": str(node),
       "OCX_TEST_CODEX_NPM_EVIDENCE": str(out)}
record = {"sourcesBefore": before, "testBinary": str(test), "testSha256": digest(test),
          "nodeSha256": digest(node), "publicRoot": str(public),
          "nativeCodexExecuted": False, "cmdExecuted": False, "allNetworkDenied": True,
          "dailyConfigAccessed": False, "windowsRuntimeOwnerVerifiedHere": False}
try:
    with (out / "tests.stdout").open("w") as stdout, (out / "tests.stderr").open("w") as stderr:
        process = subprocess.Popen(["/usr/bin/sandbox-exec", "-f", str(policy), str(test),
                                    "--include-ignored", "--nocapture"], cwd=root, env=env,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        try: record["exitCode"] = process.wait(timeout=35)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait(timeout=3); raise
    record["sourcesAfter"] = {str(path): digest(path) for path in sources}
    record["sourcesUnchanged"] = record["sourcesAfter"] == before
    record["passed"] = record["exitCode"] == 0 and record["sourcesUnchanged"]
finally:
    shutil.rmtree(root)
    (out / "verification.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
raise SystemExit(0 if record.get("passed") else 1)
