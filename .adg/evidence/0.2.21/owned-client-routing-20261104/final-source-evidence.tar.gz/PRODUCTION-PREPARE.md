> 最终执行结果：43c6253b5 的真实生产 prepare/default/catalog/provider/rawModel/response 和 copy ack gate 已通过，见 [FINAL-43.md](FINAL-43.md)。下文保留准备/历史合同，不替代最终源身份。

# 生产 parent prepare：静态接线完成，等待新 freeze

**本模式不再由测试脚本自己执行 reload/no-op PUT/Codex CAS 来补救。真实保存之后只调用公共生产入口 cache_refresh::prepare_saved_rename_restart(root,context)，再从新的官方 Codex 观察默认选择、目录和实际路由。尚未编译或运行本模式，不将 parent 单测或先前 spike 报为新产物验收。**

入口：代码根 test/smoke/ocx021-owned-routing.production.py。默认只输出准备状态；显式 --run 加用户确认的 full SHA 才构建和执行。准备态源快照在 prepared-production-prepare/，摘要与说明在 production-prepare-pre-freeze.json。Python AST 和两份 Rust 的 rustfmt 语法解析通过；未做 Cargo/typecheck，没有启动官方进程。

收到 parent cargo/check 通过及明确 freeze SHA 后，一次执行：

    python3 test/smoke/ocx021-owned-routing.production.py --run --source-freeze-head NEW_FULL_PARENT_SHA

## helper 模式

| 模式 | 实际操作 | 边界 |
| --- | --- | --- |
| save | 实际 config_file::save_with_context；返回新 clientRenamePending 摘要/ID | 走真实新增 ClientEffects 事务，不由 smoke 构造实际 pending |
| observe-production-bindings | 实际 Management::bind、public_settings、codex_integration、public_config | 只读 attested 服务返回，不注入 runtime/configPath/state |
| production-prepare | 直接 await cache_refresh::prepare_saved_rename_restart | 不自己调用两个 adapter；要求返回 Some(id) 且实际 pending 字节未清除或改变 |
| simulate-owned-restart-commit | 在独立复制的 manager/home 调实际 sync_cache_after_save(true)；HTTP 指向新建 synthetic attested fixture | 只模拟 IO/重启回执，先 incomplete 后 completed；原先真实 pending 保留，绝不发官方全局 restart |

helper 模式全部链接本轮冻结的实际原路径产品库，不复制 prepare、adapter 或确认逻辑实现。对生产 cache_refresh 私有 helper 的单测不做外部复制以“适配”编译；parent 的 19/19 等检查由 parent 自身真实 cargo 回执负责，本 harness 不冒称重跑。

## 正常整体链

1. 新临时 root/home/官方 home/manager/work，完整显式环境及 Seatbelt，拒绝日常用户树、Keychains 与外网。先运行拒绝 canary，再读取已缓存官方客户端接口。只允许两个 owned loopback 数据端口；官方协调锁只允许新临时 CODEX_HOME 摘要对应的精确新文件，之后清理。
2. 旧侧安装态由此前已验证的真实官方 producer 建立；旧 v1 service-state/plist 只作为临时文件夹具，不注册/修改/停止 OS job。旧 producer 和协调器初始化发生在改名前，不在改名后补目录。
3. 调 actual Management 的 settings/integration，只接受 installed=true、state=current/stale、绝对 configPath。使用 configPath 的 parent 作 Codex home；若末段为 .codex，仅其 parent 作绑定 HOME。settings.codexRuntime.path 必须指向实文件，若为 ~/ 仅相对这个绑定 HOME 展开，不使用 expanduser 或日常 HOME。观察用客户端必须与实际返回 runtime 的已核验 native 文件 SHA 一致。
4. 在写任何旧选择 fixture 前，actual Codex config/read 确认未绑定 active profile、没有已有选择；仅改名前在服务返回的实际 configPath seed 旧根默认 model。profile/source 无法绑定直接拒绝，不将 root 用例成功外推 active profile。
5. 实际 production save 创建 durable pending。随后只调用 production-prepare。它拥有 load pending map、attested settings/integration、client preflight、saved_runtime_reconcile、client plan.apply 和 file/pending CAS verify；smoke 不发送修复写请求、不改 catalog/config。
6. prepare 后原保存 config.json 字节/SHA/inode/mtime 保持；实际 pending id/bytes 保持。用 read-only actual Management 观察 live roster/default 只剩 Krill。新 official Codex 的 config/read、model/list、无 model/config override 的 thread/start 均需使用 Krill/原始ID，旧标识不得残留。
7. 官方 Codex exec 不加 --model。唯一 model POST 必须到本机夹具、body.model=原始ID、合成认证匹配；官方 usage.provider=Krill、routeKind=explicit-provider、resolvedModel=原始ID；消费固定响应并 exit0。该闭环通过后 pending 仍存在，不能以完成 prepare 或本机回包代替真实 restart acknowledgement。

## 安全 restart commit 检查

真实 public prepare 返回的 pending id 全程保留。commit 测试复制 manager 状态及合成官方 config 到独立 temp 子目录，保持 pending ID/map，只按模拟 home 重新绑定副本 identity。它构造 attested loopback owner、settings/config DTO 与空 restart 回执，不连接真实官方 restart，不枚举任何 Codex。

调用实际 production sync_cache_after_save(true) 两次：先返回 desktop test_environment，要求副本 pending 未清除；再返回合成的完整成功回执，要求生产 acknowledge CAS 只清除匹配 ID 的副本 pending。最后要求原 manager pending 逐字节未变。该阶段的 settings/current selection 绑定被明确 stand down（模拟 client file 缺失），因为真实目录/client 准备已在前一阶段完成；它只证明生产提交守卫，不代替真实 prepare 或 GUI 重启。

结果将分别记录 productionPrepareIntegrationPassed、safeRestartCommitCopy、actualPendingRetained、actualDesktopRestartVerified=false、releaseGatePassed=false。原 pending 留给真实 restart 成功后的生产 acknowledge；smoke 不自行清除原 pending。

## 冻结前接口核对提示

当前读到的 Management::codex_integration 路径为 /api/client-integrations/codex；缓存 2.84.0 的 integration-routes.ts 通用 registry 未列 Codex，native-integration-routes.ts 则在 GET /api/native-integrations 的 clients 内返回 Codex 状态与 configPath。这是只读源码发现，尚未在新 production mode 发请求。若 parent 尚未适配，正式运行会保留真实接口拒绝，不在测试中换路由、伪造 installed/state 或改名后补旧安装状态。

已有合法 producer 构成的旧安装夹具若仍报告 not_installed/current 绑定不满足，应在改名前通过合法官方安装 owner 接口解决并保留来源；不可造返回 DTO 或在改名后手改配置使 production preflight 通过。当前脚本遇到不符合绑定即停止，不自动扩大 owner 作用域。

parent 报告的 cache19/19、clientadapter16、live15/15、ClientEffects 2/2 及无 priorlayout 首改修复不在本准备态冒充已复验。最终 freeze 后以实际完整源摘要、一次构建/运行日志为准；旧 d20 和 candidate spike 证据保持原身份。

没有改产品源码、其它测试、native 脚本/CI 或治理状态，没有提交/推送。写集只在指定 smoke 前缀和本证据目录。等待用户下一条明确 freeze SHA 后再运行。
