# Windows npm Codex 原生入口解析

接口固定：resolve_npm_native(launcher: &Path, expected_version: &str) -> ModelResult<PathBuf>。源码为 apps/desktop/tauri/src/modules/model_config/client_npm_runtime.rs；测试直接链接 parent 已注册的 cache_refresh::client_npm_runtime。此次独占写集只有该模块、tests/client_npm_runtime.rs、tests/fixtures/ocx021-codex-npm/ 和本证据目录；未修改 parent 的路径恢复/绑定、current-selection、保存或重启编排，未提交。

## 解析链及可核对来源

完整 npm cmd-shim 8.0.0 模板逐字匹配（仅允许 CRLF/LF 差异），本地 node_modules/.bin/codex.cmd 的目标必须是 ..\@openai\codex\bin\codex.js；global-prefix/codex.cmd 必须是 node_modules\@openai\codex\bin\codex.js。不同模板、额外命令/参数、不同包、绝对目标、跳出目标、拼接和 BOM 全拒绝，不抽取一个看似安全的子串执行。

实际 Windows run41804287942/codex.cmd SHA256 为 2b3dd1940b0bedfcb54528a42694a6a85fdac196ea877115419a25381ed1005f，与从真实 cmd-shim 生成的 local fixture 字节完全一致。global fixture 来自同一生成器，SHA256=c54db6755e710c39703f7c37512f9e35ed41042d8080558d2b84b8d2694323c3。没有自行拼接一个未知 wrapper 再计为官方正常形态。

主包的 name 必须 @openai/codex，version 必须等于绑定 expected_version，bin 必须仅 codex: bin/codex.js，type 必须 module。JS 全文件 SHA256=e14fc83739c13c1074b12bd1acce4010c893c7f6fbfc1593b4a31d74cabb57af，来自官方 0.166.0 公开 npm 发布包，与真实 Windows artifact、缓存副本均相同。

该 JS 的 PLATFORM_PACKAGE_BY_TARGET 明确 win32/x64 对应 x86_64-pc-windows-msvc 和 @openai/codex-win32-x64。findCodexExecutable() 实际先 require.resolve(platformPackage/package.json)，再从该 package 的 vendor/<triple>/bin/codex.exe 取文件；只有 require.resolve 抛错才回退主包 vendor。模块按真实 createRequire 的 ancestor node_modules 位置检查文件系统候选，只接受安装树内标准 hoisted/nested optional 包；上层/其它位置 shadow、多个候选或未知 exports 一律拒绝，不错把 optional 包内缺失 native 当成允许回退 embedded。

root optionalDependencies 的 alias 必须为 npm:@openai/codex@<expected>-win32-x64（arm64 声明也要求同版本）。optional 包实际 name 为 @openai/codex，version 为 <expected>-win32-x64，os=[win32]，cpu=[x64]，均逐项核对。返回文件必须在已验证包的实际 vendor 路径且为 x64 PE executable image，拒绝文本、DLL、错误机器和截断头。

source-provenance.json 与 fixture provenance.json 拥有公开来源、官方 SHA-512 integrity、文件摘要及真实 Windows artifact 对照。本地 registry.npmjs.org TLS 连接失败，公开包经 registry.npmmirror.com 下载；三个归档 SHA-512 都与已归档 run41802736384 的官方 lock integrity 匹配，不接受镜像自行更换内容。仅提取明确 package.json、官方 JS 和 native 供验证，未执行 npm install scripts、cmd 或 native。

## 最小支持与扩展合同

正式平台范围为 Windows x64 / x64 Node；Windows 非 x64 构建在 IO 前拒绝。只有 arm64 optional 或 embedded、多个 Windows target、多个 x64 optional 候选都拒绝。若 shim 旁存在其优先使用的 node.exe，要求它也为 x64 PE；不存在时不搜索 PATH，沿正式 x64 Node 平台合同。不能据此宣称支持 ARM Windows 上的混合 Node/模拟架构，也不声称发现了 PATH 中实际 Node；如将来支持这种平台，需要调用方提供明确 Node 架构绑定。

生产没有固定 native EXE hash，也没有把版本写死为 0.166.0。expected_version 仅接受明确稳定版 x.y.z，包/alias/optional 元数据必须相同版本；升级沿用相同已核验 JS selector 合同即可解析。新 JS 若字节变动则明确 selector 拒绝；可在核验新的发布 JS 后小范围新增 selector 合同摘要，若 selector 算法变化再更新对应逻辑。测试中的合成 0.167.0 只证明版本解耦合同，不代表该未来发布物已实际验收。

不认证整份 native 文件发布签名或执行 --version：生产信任已绑定的安装包元数据与读取到的文件；公开原生 EXE 的 SHA256 只用于测试来源证明。x64 实测公开文件 SHA256=9d563ee4e0441ff9d59d612013e0460ddf8e5709735c2d9f6b98b7ef8ca4eb42、371735856 bytes，与 Windows thin trace 的真实 Node spawn 文件一致。

## 有界与拒绝条件

纯同步文件读取，无 spawn、shell 字符串、网络访问、PATH/日常配置/凭据读取或写入。文本每文件上限 64 KiB，路径/祖先至多 64 层，PE 头偏移上限 64 KiB，只读取固定头。非普通文件在 open 前拒绝，避免 FIFO 阻塞。Windows 只支持本地 Disk/VerbatimDisk，网络/设备命名空间、alternate stream 在 IO 前拒绝。路径的 symlink、junction/reparse 分量都拒绝，不把 canonicalize 后的外包路径当合法来源。

原 exe 绑定由 parent 原有 owner 直接处理；本函数只处理标准 codex.cmd，不负责 [USER] 或 ~ 恢复，不发 RPC、不更新客户端 model，也不改变 false 缓存分支。

## 验证与未验边界

- verification.json、tests.stdout、tests.stderr：实际链接生产库的测试与源码摘要。
- actual-public-selector.json：四种安装形式（local/global、hoisted/nested optional、embedded）中实际公开 Windows EXE 的摘要核对，并将 resolver 结果与未修改官方 JS 的 selector 输出比较。
- 测试只在专用 Node 中绑定 process.platform=win32 / arch=x64，截获 child_process.spawn 并返回一个立即退出的事件对象；没有启动所选 native。该测试证明 selector 的路径等价，不冒充 Windows owner 的进程启动验收。
- 默认测试使用明确标注的合成 PE 验证路径与格式合同，不冒充官方二进制。公开文件测试独立且显式要求已核对的 package root 与 Node；本次运行包含该测试。
- windows-typecheck.json：同一 resolver 源码的 x86_64-pc-windows-msvc 编译检查，最小周边 schema 类型；不等于 Windows runtime。

后续实际 Windows agent 应基于新 freeze 使用本产品函数输出跑原生 config owner 链，另外验收重启与 release。薄 trace 属于旧产品树的观察证据，未据此把新产品 owner、完整生产链或发布 gate 标通过。

复现：先 cargo test --locked --offline --test client_npm_runtime --no-run；把测试二进制绝对路径、已校验公开包目录和 Node 绝对路径交给本目录 run-isolated.py --test-binary ... --public-root ... --node ...。runner 使用 tmp HOME/work、拒绝所有网络和日常用户树/Keychain，只额外允许读指定 fixtures 与 Node。大型公开归档/EXE 留在专用临时目录，不入源码或 fixtures。
