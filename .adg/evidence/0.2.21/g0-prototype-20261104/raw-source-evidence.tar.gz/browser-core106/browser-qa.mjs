import fs from 'node:fs/promises';
import path from 'node:path';
import {pickEngine} from '/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/ui/qa/engine.mjs';
const engine=await pickEngine(),out=path.join(path.dirname(new URL(import.meta.url).pathname),engine.name);await fs.mkdir(out,{recursive:true});
const browser=await engine.launch(),checks=[],errors=[],blocked=[],localFailures=[];
const base='http://127.0.0.1:53967/'+['docs','04-项目资料','01-项目支撑资料','01-产品原型','原型','index.html'].map(encodeURIComponent).join('/');
function check(name,ok,detail){checks.push({name,passed:!!ok,...(detail?{detail}:{})});if(!ok)throw Error(name);}
async function shot(page,name){await page.screenshot({path:path.join(out,name+'.png')});}
async function close(page,kind='close'){if(kind==='escape')await page.keyboard.press('Escape');else if(kind==='backdrop'){const point=await page.evaluate(()=>{const mask=document.querySelector('#modalMask');for(let y=12;y<innerHeight;y+=20)for(let x=12;x<innerWidth;x+=20)if(document.elementFromPoint(x,y)===mask)return {x,y};return null;});if(!point)throw Error('no visible backdrop hit target');await page.mouse.click(point.x,point.y);}else await page.locator(kind==='cancel'?'#modalCancel':'#modalClose').click();}
async function pageAt(vp,hash){const page=await browser.newPage({viewport:vp});page.setDefaultTimeout(6000);page.on('pageerror',e=>errors.push(e.stack||e.message));page.on('response',r=>{if(r.status()>=400&&r.url().startsWith('http://127.0.0.1'))localFailures.push({url:r.url(),status:r.status()});});await page.route('**/*',route=>{if(new URL(route.request().url()).hostname==='127.0.0.1')return route.continue();blocked.push(route.request().url());return route.abort();});await page.goto(base+hash);await page.waitForFunction(()=>window.syncPrototype&&window.modelPrototype);return page;}
async function flow(name,fn){try{await fn();}catch(error){checks.push({name,passed:false,error:error.stack});}}
try{
 for(const vp of [{width:1440,height:900},{width:1180,height:760},{width:900,height:650}]){
  const prefix=String(vp.width),page=await pageAt(vp,'#sync?tab=webdav');if(vp.width===1180)await page.evaluate(()=>document.documentElement.dataset.theme='dark');
  await flow(prefix+' POST04',async()=>{
   for(const scene of ['unknown-time','same-time','legacy-mtime','invalid-time','unbound-version','clock-skew']){
    await page.evaluate(scene=>{syncPrototype.setScenario(scene);syncPrototype.open({tab:'webdav',scope:['skill:review'],action:'check'});},scene);
    check(prefix+' '+scene+' reason and disabled confirmation',await page.locator('#modalBody').innerText().then(t=>t.includes('无法判定新版'))&&await page.locator('#modalConfirm').isDisabled());
    check(prefix+' '+scene+' source undetermined',await page.evaluate(()=>syncPrototype.state().preview.source==='undetermined'&&!syncPrototype.state().running));
    if(scene==='same-time'){check(prefix+' modal fits viewport',await page.locator('#modal').evaluate(el=>{const r=el.getBoundingClientRect();return r.width>0&&r.left>=-1&&r.right<=innerWidth+1&&r.top>=-1&&r.bottom<=innerHeight+1;}));await shot(page,prefix+'-post04-undetermined');}await close(page);
   }
   for(const [scene,source] of [['local-no-baseline','local'],['remote-no-baseline','remote'],['same','unchanged']]){await page.evaluate(scene=>{syncPrototype.setScenario(scene);syncPrototype.open({tab:'webdav',scope:['skill:review'],action:'check'});},scene);check(prefix+' '+scene+' source',await page.evaluate(()=>syncPrototype.state().preview.source)===source);await close(page);}
  });
  await flow(prefix+' POST07/08',async()=>{
   await page.evaluate(()=>{syncPrototype.setConnectionScenario('configured');syncPrototype.open({tab:'webdav',action:'connection'});});
   check(prefix+' saved config is unchecked',await page.locator('#sxConnectionTest').innerText().then(t=>t.includes('已配置')&&t.includes('未检测')));
   for(const scene of ['loading','error','objects','empty']){await page.evaluate(scene=>syncPrototype.setCandidateScenario(scene),scene);check(prefix+' candidates '+scene,await page.locator('#sxImportedConnectionEntry').evaluate((el,scene)=>scene==='empty'?el.hidden:!el.hidden,scene));if(scene==='error')await shot(page,prefix+'-post08-read-error');}
   await page.evaluate(()=>syncPrototype.setCandidateScenario('missing-password'));await page.locator('[data-sx=imported-connections]').click();await page.locator('[data-sx=activate-imported]').click();
   check(prefix+' missing password blocks activation',await page.locator('#modalConfirm').isDisabled());await page.locator('#sxCandidatePassword').fill('mock-only');await page.locator('[data-sx=test-imported]').click();await page.waitForFunction(()=>document.querySelector('#sxCandidateTest')?.textContent.includes('成功'));
   check(prefix+' candidate test does not observe saved endpoint',await page.evaluate(()=>syncPrototype.connectionStatus().state==='configured'));await shot(page,prefix+'-post08-activation');await close(page,'escape');
   check(prefix+' Esc does not activate',await page.evaluate(()=>syncPrototype.connectionStatus().connection.url==='https://dav.example.com'));
   await page.evaluate(()=>syncPrototype.open({tab:'webdav',action:'connection'}));await page.locator('#sxDavPath').fill('/changed');await page.locator('[data-sx=test-connection]').click();await page.waitForFunction(()=>document.querySelector('#sxConnectionTest')?.textContent.includes('未保存连接最近检测成功'));
   check(prefix+' unsaved test isolated',await page.evaluate(()=>syncPrototype.connectionStatus().state==='configured'));await page.locator('#modalConfirm').click();
   const observation=await page.evaluate(()=>syncPrototype.connectionStatus().observation);check(prefix+' exact tested form saves proof',observation?.status==='success'&&!!observation?.endpointRevision&&!!observation?.observedAt);await page.evaluate(()=>syncPrototype.setConnectionScenario('reload'));check(prefix+' reload keeps timed observation',JSON.stringify(await page.evaluate(()=>syncPrototype.connectionStatus().observation))===JSON.stringify(observation));
  });
  await page.close();
  const model=await pageAt(vp,'#models');if(vp.width===1180)await model.evaluate(()=>document.documentElement.dataset.theme='dark');
  await flow(prefix+' POST02',async()=>{
   await model.locator('[data-mp=edit-provider][data-id=newapi]').click();await model.locator('#mpChannelInline-name').fill('Krill');check(prefix+' name follows runtime identifier',await model.locator('#mpChannelInline-providerId').inputValue()==='Krill');
   await model.locator('#mpChannelInline-providerId').fill('a6api__anthropic');check(prefix+' derived conflict inline',await model.locator('#mpChannelRenameError').innerText().then(t=>t.includes('占用')));await model.locator('#mpChannelInline-providerId').fill('Krill');await shot(model,prefix+'-post02-rename');
   await model.locator('[data-mp=back-channels]').click();await model.locator('#mpPolicySave').click();check(prefix+' full save shows target',await model.locator('#modalBody').innerText().then(t=>t.includes('Krill/gpt-5.4')));await shot(model,prefix+'-post02-save-preview');await close(model,'cancel');check(prefix+' cancel no saved mutation',await model.evaluate(()=>modelPrototype.state().saved.providers[0].providerId==='newapi'));
  });
  await model.close();
 }
 const page=await pageAt({width:1440,height:900},'#models');
 await flow('POST01 real timer',async()=>{
  await page.locator('[data-mp=toggle-provider][data-id=aimami]').click();await page.locator('#mpPolicySave').click();await page.locator('#modalConfirm').click();await page.mouse.move(5,5);await page.waitForFunction(()=>modelPrototype.state().operation?.status==='written');
  const selector='[data-task-notification^="model-policy-save:"]';check('POST01 no automatic focus',await page.locator(selector).evaluate(el=>!el.contains(document.activeElement)));await shot(page,'1440-post01-written');
  for(const kind of ['close','escape','backdrop','cancel']){await page.locator('[data-task-act=model-restart]').click();await page.waitForTimeout(80);check('POST01 '+kind+' confirmation pauses',await page.locator(selector).evaluate(el=>NotificationCountdown.get(el).state().phase==='paused'));await close(page,kind);await page.mouse.move(5,5);check('POST01 '+kind+' only closes confirmation',await page.locator(selector).count()===1&&await page.locator(selector).evaluate(el=>NotificationCountdown.get(el).state().phase==='running'));}
  await page.waitForTimeout(8400);check('POST01 elapsed hides without restart',await page.locator(selector).count()===0&&await page.evaluate(()=>modelPrototype.state().operation.status==='written'));
 });await page.close();
 check('no browser exceptions',errors.length===0);check('no missing local resources',localFailures.length===0);check('no external requests attempted',blocked.length===0);
}finally{await browser.close();await fs.writeFile(path.join(out,'result.json'),JSON.stringify({engine:engine.name,scope:'G0 active total mock prototype; external requests blocked; no production acceptance',checks,errors,blocked,localFailures},null,2));}
console.log(JSON.stringify({engine:engine.name,passed:checks.filter(c=>c.passed).length,failed:checks.filter(c=>!c.passed).length}));if(checks.some(c=>!c.passed))process.exitCode=1;
