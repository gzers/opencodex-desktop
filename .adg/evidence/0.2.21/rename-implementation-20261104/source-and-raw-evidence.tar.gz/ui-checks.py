import pathlib,subprocess,os,json,time,sys
p=pathlib.Path(__file__).resolve().parent
cwd='/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/ui'
env=os.environ.copy();env['npm_config_offline']='true'
checks=[('ui-tests',['npm','test','--','--run','tests/channel-rename.test.ts','tests/channel-editor-direct.test.ts','tests/channel-key-edit.test.ts','tests/model-channel-scoped-save.test.ts','tests/file-channel-save.test.ts','tests/channel-detail-save-flow.test.ts']),('ui-build',['npm','run','build'])]
for name,command in checks:
 started=time.time();result=subprocess.run(command,cwd=cwd,env=env,capture_output=True,text=True)
 (p/'logs'/(name+'.log')).write_text(result.stdout+result.stderr)
 (p/'logs'/(name+'.json')).write_text(json.dumps({'command':command,'exit_code':result.returncode,'elapsed_seconds':round(time.time()-started,3)},indent=2)+'\n')
 print(name+' exit='+str(result.returncode));print((result.stdout+result.stderr)[-3500:]);
 if result.returncode:sys.exit(result.returncode)
