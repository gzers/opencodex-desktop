//! Real temporary stores and the production immutable/conditional WebDAV path.
use super::super::{content_versions, remote::tests::Memory, sync_state};
use super::*;
use crate::modules::preferences::{self, Preferences, PreferencesStore};
struct Device {
    data: tempfile::TempDir,
    config_home: tempfile::TempDir,
}
impl Device {
    fn new() -> Self {
        file_objects::test_credentials::install();
        let d = Self {
            data: tempfile::tempdir().unwrap(),
            config_home: tempfile::tempdir().unwrap(),
        };
        std::fs::write(
            d.config_home.path().join("config.json"),
            br#"{"providers":{}}"#,
        )
        .unwrap();
        save_scope(d.root(), d.scope()).unwrap();
        d
    }
    fn root(&self) -> &Path {
        self.data.path()
    }
    fn scope(&self) -> Scope {
        Scope {
            preferences: true,
            extensions: false,
            upstream_root: Some(self.config_home.path().into()),
            ..Default::default()
        }
    }
    fn preferences(&self) -> Preferences {
        PreferencesStore::new(self.root()).load().unwrap()
    }
    // Actual save/read-back with a deterministic historical clock. The separate
    // lifecycle test below exercises the production now() hook.
    fn save_at(&self, scale: i32, time: &str) {
        let before = capture_save(self.root(), &self.scope()).unwrap();
        let value = Preferences {
            interface_scale: scale,
            ..self.preferences()
        };
        preferences::save_preferences(&PreferencesStore::new(self.root()).path(), &value).unwrap();
        assert_eq!(self.preferences(), value);
        let after = capture_save(self.root(), &self.scope()).unwrap();
        content_versions::record_at(self.root(), &before, &after, time).unwrap();
    }
    fn fact(&self) -> file_objects::ContentFact {
        source_fact(self.root(), &self.scope()).unwrap()
    }
    fn bytes(&self) -> Vec<u8> {
        std::fs::read(PreferencesStore::new(self.root()).path()).unwrap()
    }
}
fn config() -> WebDavConfig {
    WebDavConfig {
        base_url: "https://fixture.invalid".into(),
        remote_path: "isolated".into(),
        username: "synthetic".into(),
        password: "synthetic-transport-only".into(),
    }
}
async fn check(d: &Device, remote: &Memory, binding: &str) -> sync_state::Check {
    check_source_with_password(d.root(), remote, &config(), binding, &d.scope(), None, None)
        .await
        .unwrap()
}
async fn upload(d: &Device, remote: &Memory) -> UploadView {
    assert_eq!(check(d, remote, "fixture").await.source, "local");
    let p = prepare(
        d.root(),
        remote,
        &config(),
        "fixture",
        d.scope(),
        None,
        || Ok(()),
    )
    .await
    .unwrap();
    publish(d.root(), remote, &config(), &p.id, "fixture", || Ok(()))
        .await
        .unwrap()
}
async fn download(d: &Device, remote: &Memory) -> IncomingPlan {
    download_sync(
        d.root(),
        remote,
        &config(),
        None,
        None,
        d.config_home.path(),
        "fixture",
        || Ok(()),
    )
    .await
    .unwrap()
}
fn same_instant(a: Option<&str>, b: Option<&str>) -> bool {
    a.and_then(|s| chrono::DateTime::parse_from_rfc3339(s).ok())
        == b.and_then(|s| chrono::DateTime::parse_from_rfc3339(s).ok())
}
#[test]
fn actual_preference_save_readback_noop_touch_copy_and_legacy_are_distinct() {
    let d = Device::new();
    assert!(d.fact().empty);
    let legacy = Preferences {
        interface_scale: 125,
        ..Default::default()
    };
    preferences::save_preferences(&PreferencesStore::new(d.root()).path(), &legacy).unwrap();
    assert!(d.fact().saved_at.is_none());
    PreferencesStore::new(d.root()).save(&legacy).unwrap();
    assert!(
        d.fact().saved_at.is_none(),
        "no-op must not certify discovered legacy data"
    );
    let start = chrono::Utc::now();
    let saved = Preferences {
        interface_scale: 150,
        ..legacy
    };
    PreferencesStore::new(d.root()).save(&saved).unwrap();
    let original = d.fact();
    let instant =
        chrono::DateTime::parse_from_rfc3339(original.saved_at.as_ref().unwrap()).unwrap();
    assert!(instant >= start && instant <= chrono::Utc::now());
    assert_eq!(d.preferences(), saved);
    let f = std::fs::OpenOptions::new()
        .write(true)
        .open(PreferencesStore::new(d.root()).path())
        .unwrap();
    f.set_times(std::fs::FileTimes::new().set_modified(std::time::SystemTime::now()))
        .unwrap();
    PreferencesStore::new(d.root()).save(&saved).unwrap();
    assert_eq!(d.fact(), original);
    let copy = Device::new();
    std::fs::copy(
        PreferencesStore::new(d.root()).path(),
        PreferencesStore::new(copy.root()).path(),
    )
    .unwrap();
    assert_eq!(copy.fact().content_digest, original.content_digest);
    assert!(copy.fact().saved_at.is_none());
    assert_eq!(source_fact(d.root(), &d.scope()).unwrap(), original);
}
#[tokio::test]
async fn no_baseline_and_both_modified_choose_saved_time_in_both_directions_and_inherit() {
    let cloud = Memory::default();
    let a = Device::new();
    a.save_at(125, "2026-10-30T00:00:00Z");
    upload(&a, &cloud).await;
    let b = Device::new();
    b.save_at(150, "2026-11-04T00:00:00Z");
    let c = check(&b, &cloud, "new-connection-no-baseline").await;
    assert_eq!(c.source, "local");
    assert_eq!(c.reason, "local_saved_later");
    assert!(same_instant(
        c.local_saved_at.as_deref(),
        Some("2026-11-04T00:00:00Z")
    ));
    upload(&b, &cloud).await;
    let older = Device::new();
    older.save_at(100, "2026-10-30T00:00:00Z");
    assert_eq!(check(&older, &cloud, "fixture").await.source, "remote");
    let before = older.bytes();
    let incoming = download(&older, &cloud).await;
    assert_eq!(
        older.bytes(),
        before,
        "preview/cancel never changes business files"
    );
    sync_state::verify_pending(older.root(), &incoming.id, "fixture", &cloud, &config())
        .await
        .unwrap();
    file_objects::accept_extended(older.root(), &incoming.id, false, false, false, None).unwrap();
    assert_eq!(older.preferences().interface_scale, 150);
    assert!(same_instant(
        older.fact().saved_at.as_deref(),
        b.fact().saved_at.as_deref()
    ));
    assert_eq!(
        check(&older, &cloud, "different-binding").await.source,
        "unchanged"
    );
    assert_eq!(
        prepare(
            older.root(),
            &cloud,
            &config(),
            "different-binding",
            older.scope(),
            None,
            || Ok(())
        )
        .await
        .unwrap_err()
        .code,
        "sync_unchanged"
    );
    older.save_at(175, "2026-11-05T00:00:00Z");
    assert_eq!(check(&older, &cloud, "fixture").await.source, "local");
    b.save_at(200, "2026-11-06T00:00:00Z");
    upload(&b, &cloud).await;
    assert_eq!(check(&older, &cloud, "fixture").await.source, "remote");
}
#[tokio::test]
async fn unknown_bad_same_instant_or_unbound_versions_refuse_both_write_directions() {
    let cloud = Memory::default();
    let a = Device::new();
    a.save_at(125, "2026-11-04T00:00:00Z");
    upload(&a, &cloud).await;
    for mode in [
        "legacy",
        "bad-time",
        "wrong-digest",
        "clock",
        "same-instant",
    ] {
        let b = Device::new();
        if mode == "legacy" {
            preferences::save_preferences(
                &PreferencesStore::new(b.root()).path(),
                &Preferences {
                    interface_scale: 150,
                    ..Default::default()
                },
            )
            .unwrap();
        } else {
            b.save_at(150, "2026-11-04T08:00:00+08:00");
            let p = b.root().join("manager-state/saved-content-versions.json");
            let mut records: serde_json::Value =
                serde_json::from_slice(&std::fs::read(&p).unwrap()).unwrap();
            for record in records.as_object_mut().unwrap().values_mut() {
                match mode {
                    "bad-time" => record["savedAt"] = serde_json::json!("invalid-time"),
                    "wrong-digest" => record["contentDigest"] = serde_json::json!("stale-digest"),
                    "clock" => record["timeKind"] = serde_json::json!("clockUnreliable"),
                    _ => {}
                }
            }
            std::fs::write(p, serde_json::to_vec(&records).unwrap()).unwrap();
        }
        let before = b.bytes();
        let writes = cloud.writes();
        assert_eq!(
            check(&b, &cloud, "fixture").await.source,
            "undetermined",
            "{mode}"
        );
        assert_eq!(
            prepare(
                b.root(),
                &cloud,
                &config(),
                "fixture",
                b.scope(),
                None,
                || Ok(())
            )
            .await
            .unwrap_err()
            .code,
            "sync_undetermined",
            "{mode}"
        );
        assert_eq!(
            download_sync(
                b.root(),
                &cloud,
                &config(),
                None,
                None,
                b.config_home.path(),
                "fixture",
                || Ok(())
            )
            .await
            .unwrap_err()
            .code,
            "sync_undetermined",
            "{mode}"
        );
        assert_eq!(b.bytes(), before);
        assert_eq!(cloud.writes(), writes);
    }
}
#[tokio::test]
async fn check_then_prepare_cannot_rebase_onto_a_new_cloud_pointer_even_if_local_still_newer() {
    let cloud = Memory::default();
    let a = Device::new();
    a.save_at(125, "2026-10-30T00:00:00Z");
    upload(&a, &cloud).await;
    let b = Device::new();
    b.save_at(150, "2026-11-04T00:00:00Z");
    assert_eq!(check(&b, &cloud, "fixture").await.source, "local");
    a.save_at(175, "2026-11-02T00:00:00Z");
    upload(&a, &cloud).await;
    let writes = cloud.writes();
    assert_eq!(
        prepare(
            b.root(),
            &cloud,
            &config(),
            "fixture",
            b.scope(),
            None,
            || Ok(())
        )
        .await
        .unwrap_err()
        .code,
        "sync_preview_changed"
    );
    assert_eq!(cloud.writes(), writes);
    assert_eq!(check(&b, &cloud, "fixture").await.source, "local");
    a.save_at(200, "2026-11-06T00:00:00Z");
    upload(&a, &cloud).await;
    assert_eq!(
        prepare(
            b.root(),
            &cloud,
            &config(),
            "fixture",
            b.scope(),
            None,
            || Ok(())
        )
        .await
        .unwrap_err()
        .code,
        "sync_preview_changed"
    );
    assert_eq!(check(&b, &cloud, "fixture").await.source, "remote");
}
#[tokio::test]
async fn confirmation_rechecks_local_versions_remote_pointer_and_scope_without_business_writes() {
    let cloud = Memory::default();
    let a = Device::new();
    a.save_at(125, "2026-10-30T00:00:00Z");
    upload(&a, &cloud).await;
    let b = Device::new();
    b.save_at(150, "2026-11-04T00:00:00Z");
    check(&b, &cloud, "fixture").await;
    let plan = prepare(
        b.root(),
        &cloud,
        &config(),
        "fixture",
        b.scope(),
        None,
        || Ok(()),
    )
    .await
    .unwrap();
    b.save_at(175, "2026-11-05T00:00:00Z");
    let writes = cloud.writes();
    assert_eq!(
        publish(b.root(), &cloud, &config(), &plan.id, "fixture", || Ok(()))
            .await
            .unwrap_err()
            .code,
        "sync_source_changed"
    );
    assert_eq!(cloud.writes(), writes);
    check(&b, &cloud, "fixture").await;
    let plan = prepare(
        b.root(),
        &cloud,
        &config(),
        "fixture",
        b.scope(),
        None,
        || Ok(()),
    )
    .await
    .unwrap();
    let versions_path = b.root().join("manager-state/saved-content-versions.json");
    let mut versions: serde_json::Value =
        serde_json::from_slice(&std::fs::read(&versions_path).unwrap()).unwrap();
    for version in versions.as_object_mut().unwrap().values_mut() {
        version["revision"] = serde_json::json!(version["revision"].as_u64().unwrap() + 1);
    }
    std::fs::write(versions_path, serde_json::to_vec(&versions).unwrap()).unwrap();
    let writes = cloud.writes();
    assert_eq!(
        publish(b.root(), &cloud, &config(), &plan.id, "fixture", || Ok(()))
            .await
            .unwrap_err()
            .code,
        "sync_source_changed",
        "metadata-only save version drift is rechecked too"
    );
    assert_eq!(cloud.writes(), writes);
    check(&b, &cloud, "fixture").await;
    let plan = prepare(
        b.root(),
        &cloud,
        &config(),
        "fixture",
        b.scope(),
        None,
        || Ok(()),
    )
    .await
    .unwrap();
    a.save_at(200, "2026-11-06T00:00:00Z");
    upload(&a, &cloud).await;
    assert!(
        publish(b.root(), &cloud, &config(), &plan.id, "fixture", || Ok(()))
            .await
            .is_err()
    );
    check(&b, &cloud, "fixture").await;
    let incoming = download(&b, &cloud).await;
    b.save_at(150, "2026-11-07T00:00:00Z");
    let before = b.bytes();
    assert_eq!(
        sync_state::verify_pending(b.root(), &incoming.id, "fixture", &cloud, &config())
            .await
            .unwrap_err()
            .code,
        "sync_source_changed"
    );
    assert_eq!(b.bytes(), before);
    let c = Device::new();
    check(&c, &cloud, "fixture").await;
    let incoming = download(&c, &cloud).await;
    save_scope(
        c.root(),
        Scope {
            preferences: true,
            extensions: true,
            upstream_root: Some(c.config_home.path().into()),
            ..Default::default()
        },
    )
    .unwrap();
    assert_eq!(
        sync_state::verify_pending(c.root(), &incoming.id, "fixture", &cloud, &config())
            .await
            .unwrap_err()
            .code,
        "sync_source_changed"
    );
    assert!(!PreferencesStore::new(c.root()).path().exists());
}

#[tokio::test]
async fn partial_upload_and_download_preserve_outside_content_and_its_save_receipts() {
    let cloud = Memory::default();
    let a = Device::new();
    a.save_at(125, "2026-10-30T00:00:00Z");
    upload(&a, &cloud).await;
    let template = super::tests::create(a.root(), "outside-preferences");
    let template_scope = Scope {
        template_ids: vec![template.clone()],
        preferences: false,
        extensions: false,
        upstream_root: Some(a.config_home.path().into()),
        ..Default::default()
    };
    let original_template = source_fact(a.root(), &template_scope).unwrap();
    assert!(original_template.saved_at.is_some());
    save_scope(a.root(), template_scope.clone()).unwrap();
    assert_eq!(
        check_source_with_password(
            a.root(),
            &cloud,
            &config(),
            "fixture",
            &template_scope,
            None,
            None
        )
        .await
        .unwrap()
        .source,
        "local"
    );
    let p = prepare(
        a.root(),
        &cloud,
        &config(),
        "fixture",
        template_scope.clone(),
        None,
        || Ok(()),
    )
    .await
    .unwrap();
    publish(a.root(), &cloud, &config(), &p.id, "fixture", || Ok(()))
        .await
        .unwrap();
    let head = remote::pointer_for(remote::CONFIG, &cloud, &config())
        .await
        .unwrap()
        .unwrap();
    let bytes = remote::fetch_for(remote::CONFIG, &cloud, &config(), &head.pointer)
        .await
        .unwrap();
    let cloud_preferences = remote_projection(&bytes, None, &a.scope()).unwrap();
    assert!(same_instant(
        cloud_preferences.saved_at.as_deref(),
        Some("2026-10-30T00:00:00Z")
    ));
    assert_eq!(cloud_preferences.content_digest, a.fact().content_digest);
    let b = Device::new();
    b.save_at(150, "2026-11-04T00:00:00Z");
    upload(&b, &cloud).await;
    let head = remote::pointer_for(remote::CONFIG, &cloud, &config())
        .await
        .unwrap()
        .unwrap();
    let bytes = remote::fetch_for(remote::CONFIG, &cloud, &config(), &head.pointer)
        .await
        .unwrap();
    assert_eq!(
        remote_projection(&bytes, None, &template_scope).unwrap(),
        original_template,
        "outside object versions survive the merge unchanged"
    );
    save_scope(a.root(), a.scope()).unwrap();
    assert_eq!(check(&a, &cloud, "fixture").await.source, "remote");
    let original_library = std::fs::read(a.root().join(LIBRARY_PATH)).unwrap();
    let incoming = download(&a, &cloud).await;
    sync_state::verify_pending(a.root(), &incoming.id, "fixture", &cloud, &config())
        .await
        .unwrap();
    file_objects::accept_extended(a.root(), &incoming.id, false, false, false, None).unwrap();
    assert_eq!(a.preferences().interface_scale, 150);
    assert_eq!(
        std::fs::read(a.root().join(LIBRARY_PATH)).unwrap(),
        original_library
    );
    assert_eq!(
        source_fact(a.root(), &template_scope).unwrap(),
        original_template
    );
    assert_eq!(check(&a, &cloud, "fixture").await.source, "unchanged");
}

#[test]
fn extension_save_noop_and_migration_do_not_relabel_old_content_as_new() {
    use crate::modules::extensions::{projection, ClientId, ClientTarget, ExtensionConfig};
    let d = Device::new();
    let home = tempfile::tempdir().unwrap();
    let targets = [ClientTarget::user_target(
        ClientId::Codex,
        home.path(),
        true,
        true,
    )];
    let mut config = ExtensionConfig::default();
    projection::save_with_config(d.root(), &mut config, &targets).unwrap();
    let scope = Scope {
        preferences: false,
        extensions: true,
        ..d.scope()
    };
    let original = source_fact(d.root(), &scope).unwrap();
    assert!(original.saved_at.is_some());
    projection::save_with_config(d.root(), &mut config, &targets).unwrap();
    assert_eq!(
        source_fact(d.root(), &scope).unwrap(),
        original,
        "revision-only writes are not new content"
    );
    std::fs::remove_file(d.root().join("manager-state/saved-content-versions.json")).unwrap();
    let transaction = projection::ConfigTransaction::acquire(d.root(), &targets).unwrap();
    config.sync_method = "copy".into();
    transaction.save(&mut config).unwrap();
    drop(transaction);
    assert!(
        source_fact(d.root(), &scope).unwrap().saved_at.is_none(),
        "migration must not generate now"
    );
}

#[tokio::test]
async fn a_reintroduced_old_cloud_snapshot_cannot_win_just_because_the_pointer_is_new() {
    let cloud = Memory::default();
    let a = Device::new();
    a.save_at(125, "2026-10-30T00:00:00Z");
    upload(&a, &cloud).await;
    let old = remote::pointer_for(remote::CONFIG, &cloud, &config())
        .await
        .unwrap()
        .unwrap();
    let bytes = remote::fetch_for(remote::CONFIG, &cloud, &config(), &old.pointer)
        .await
        .unwrap();
    let b = Device::new();
    b.save_at(150, "2026-11-04T00:00:00Z");
    upload(&b, &cloud).await;
    let baseline = remote::pointer_for(remote::CONFIG, &cloud, &config())
        .await
        .unwrap()
        .unwrap();
    let id = uuid::Uuid::new_v4().to_string();
    remote::publish_blob(
        remote::CONFIG,
        &cloud,
        &config(),
        &id,
        Some(&baseline),
        bytes,
        false,
        |_| Ok(()),
        || Ok(()),
    )
    .await
    .unwrap();
    assert_eq!(check(&b, &cloud, "fixture").await.source, "local");
    let incoming = download_sync(
        b.root(),
        &cloud,
        &config(),
        None,
        None,
        b.config_home.path(),
        "fixture",
        || Ok(()),
    )
    .await
    .unwrap_err();
    assert_eq!(incoming.code, "sync_direction_changed");
    assert_eq!(b.preferences().interface_scale, 150);
}

#[test]
fn post04_review_preferences_and_templates_replay_receipts_after_real_version_lock_contention() {
    use crate::infrastructure::locking::TargetFileLock;
    let instant = |value: &str| chrono::DateTime::parse_from_rfc3339(value).unwrap();
    let receipt_time = |root: &Path, owner: &str| {
        let receipt: serde_json::Value = serde_json::from_slice(
            &std::fs::read(
                root.join("manager-state/content-save-events")
                    .join(format!("{owner}.json")),
            )
            .unwrap(),
        )
        .unwrap();
        receipt["savedAt"].as_str().unwrap().to_owned()
    };
    let d = Device::new();
    let guard =
        TargetFileLock::lock(&d.root().join("manager-state/saved-content-versions.json")).unwrap();
    let desired = Preferences {
        interface_scale: 150,
        ..Default::default()
    };
    assert_eq!(
        PreferencesStore::new(d.root()).save(&desired).unwrap_err(),
        preferences::PreferencesError::VersionPending
    );
    assert_eq!(
        preferences::load_preferences(&PreferencesStore::new(d.root()).path()).unwrap(),
        desired
    );
    let original_time = receipt_time(d.root(), "preferences");
    drop(guard);
    PreferencesStore::new(d.root()).load().unwrap();
    assert_eq!(
        instant(d.fact().saved_at.as_ref().unwrap()),
        instant(&original_time)
    );
    let versions =
        std::fs::read(d.root().join("manager-state/saved-content-versions.json")).unwrap();
    PreferencesStore::new(d.root()).save(&desired).unwrap();
    assert_eq!(
        std::fs::read(d.root().join("manager-state/saved-content-versions.json")).unwrap(),
        versions
    );
    let root = tempfile::tempdir().unwrap();
    let store = ModelStore::new(root.path());
    let snapshot = store.load_library().unwrap();
    let guard = TargetFileLock::lock(
        &root
            .path()
            .join("manager-state/saved-content-versions.json"),
    )
    .unwrap();
    let mut content = TemplateContent::default();
    content.matching.include.push(Pattern {
        kind: MatchKind::Prefix,
        value: "locked-template-unique".into(),
    });
    let error = store
        .save(SaveTemplate {
            expected_library: snapshot.library_digest,
            template_id: None,
            base_revision: None,
            label: "locked-template".into(),
            content: content.clone(),
        })
        .unwrap_err();
    assert_eq!(error.code, "saved_content_version_unconfirmed");
    let original_time = receipt_time(root.path(), "templates");
    let written: Library =
        serde_json::from_slice(&std::fs::read(root.path().join(LIBRARY_PATH)).unwrap()).unwrap();
    assert!(written
        .templates
        .iter()
        .any(|t| t.label == "locked-template"));
    drop(guard);
    let (library, digest) = store.library_only().unwrap();
    let template = library
        .templates
        .iter()
        .find(|t| t.label == "locked-template")
        .unwrap();
    let state = file_objects::template_save_state(&Library {
        schema_version: library.schema_version,
        templates: vec![template.clone()],
        submission_receipts: Default::default(),
    })
    .unwrap();
    assert!(content_versions::observe(root.path(), &state)
        .unwrap()
        .iter()
        .all(|v| v.instant() == Some(instant(&original_time))));
    let versions = std::fs::read(
        root.path()
            .join("manager-state/saved-content-versions.json"),
    )
    .unwrap();
    let no_op = store
        .save(SaveTemplate {
            expected_library: digest,
            template_id: Some(template.id.clone()),
            base_revision: Some(template.revisions[0].id.clone()),
            label: template.label.clone(),
            content,
        })
        .unwrap();
    assert!(!no_op.changed);
    assert_eq!(
        std::fs::read(
            root.path()
                .join("manager-state/saved-content-versions.json")
        )
        .unwrap(),
        versions
    );
}
#[test]
fn post04_review_extension_receipt_replays_after_version_contention_and_noop_keeps_time() {
    use crate::{
        infrastructure::locking::TargetFileLock,
        modules::extensions::{projection, ClientId, ClientTarget, ExtensionConfig},
    };
    let d = Device::new();
    let home = tempfile::tempdir().unwrap();
    let targets = [ClientTarget::user_target(
        ClientId::Codex,
        home.path(),
        true,
        true,
    )];
    let mut config = ExtensionConfig::default();
    projection::save_with_config(d.root(), &mut config, &targets).unwrap();
    config.sync_method = "copy".into();
    let guard =
        TargetFileLock::lock(&d.root().join("manager-state/saved-content-versions.json")).unwrap();
    assert_eq!(
        projection::save_with_config(d.root(), &mut config, &targets).unwrap_err(),
        projection::ProjectionError::VersionPending
    );
    let pending: serde_json::Value = serde_json::from_slice(
        &std::fs::read(
            d.root()
                .join("manager-state/content-save-events/extensions.json"),
        )
        .unwrap(),
    )
    .unwrap();
    let original_time =
        chrono::DateTime::parse_from_rfc3339(pending["savedAt"].as_str().unwrap()).unwrap();
    let actual: serde_json::Value =
        serde_json::from_slice(&std::fs::read(projection::config_path(d.root())).unwrap()).unwrap();
    assert_eq!(actual["config"]["sync_method"], "copy");
    drop(guard);
    let (mut loaded, _, _) = projection::load(d.root(), &targets).unwrap();
    let scope = Scope {
        preferences: false,
        extensions: true,
        ..d.scope()
    };
    assert_eq!(
        source_fact(d.root(), &scope)
            .unwrap()
            .saved_at
            .as_deref()
            .map(|s| chrono::DateTime::parse_from_rfc3339(s).unwrap()),
        Some(original_time)
    );
    let versions =
        std::fs::read(d.root().join("manager-state/saved-content-versions.json")).unwrap();
    projection::save_with_config(d.root(), &mut loaded, &targets).unwrap();
    assert_eq!(
        std::fs::read(d.root().join("manager-state/saved-content-versions.json")).unwrap(),
        versions
    );
}
