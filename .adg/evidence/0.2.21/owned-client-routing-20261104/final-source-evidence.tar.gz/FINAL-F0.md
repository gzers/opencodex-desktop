# f0a6a13d0 生产 prepare 最终尝试：官方绑定 HTTP400，未放行

**最终发布门未过。构建及官方启动成功，但真实生产 Management 的 Codex integration 读取返回 HTTP400；在改名前即停止，没有执行 save、production prepare、新客户端路由或 safe commit。没有 fallback 或手工 owner 补救。**

冻结完整提交 f0a6a13d0830841b1e3147b69be850833f8f0498。当前产品 src 无未提交改动；本轮构建一次、整体运行一次。[原始运行](run-20261104-154805/result.json)、[分析结果](production-prepare-f0-result.json)。

## 实际结果

- 隔离文件/网络 canary、缓存 Codex/OpenCodex 版本/帮助/模型目录/schema 读取均通过。
- 新 helper 链接真实 f0 生产库，build exit0；二进制 SHA256=f0c3a4b12b5db46c0087aa2a0615027aa1c36ffa850e530b95ec2fcf5db2ba0d。
- 209 份 Rust 源及四份构建输入共 213 项，从编译前、编译后到运行后 SHA 完全一致。未跟踪 UI/native/test 工具未纳入漂移判断。
- 旧合法安装夹具通过原官方 coordinator/producer 建立；未修改发布包、未注册/停止 OS 服务。未修改的官方 OpenCodex 2.84.0 CLI 启动并 /readyz 成功，实际注入旧目录与本机路由配置。
- 在 production helper 的 observe-production-bindings（真实 Management::bind → public_settings → codex_integration → public_config）中，真实 adapter 返回 management_rejected / 官方管理接口返回HTTP400；helper exit22。
- 配置选择/来源绑定未通过，故没有写旧 model fixture，没有执行任何实际改名保存，也没有调用 prepare_saved_rename_restart。不能把本轮写成 prepare 已运行失败或已验证其内部两 adapter。
- 没有 global restart，没有 fallback、接口替换或伪造 integration DTO；owned 进程全部回收，55038/55037 均 ECONNREFUSED；新 home 专属两个 coordinator SQLite 文件已精确清理。

[真实错误 stdout](run-20261104-154805/official-binding-before-rename.stdout)，[官方启动日志](run-20261104-154805/official-before.stdout)，[编译日志](run-20261104-154805/build.stderr)，[清理](run-20261104-154805/owned-coordinator-cleanup.json)。完整实际 smoke 和生成的 Rust helper 源在该 run/source/，逐文件 hash 在 source-manifest.json。

## 接口原因与最小修复入口

生产 management.rs::codex_integration 请求 GET /api/client-integrations/codex。2.84.0 发布物的 integration-routes.ts 在这个路径解码 clientId，然后对通用 INTEGRATION_CLIENT_IDS 做严格检查；该 registry 不包含 Codex。静态对应拒绝是 HTTP400 invalid_integration_client。

生产 Management 出于脱敏合同抛弃 HTTP 错误正文，因此本次**实际保留的是 HTTP400 / management_rejected**。invalid integration client/code 的正文来自所核对发布物的静态源码，不能冒称捕获了被丢弃的 HTTP body；这一区分写入 [actual-interface-refusal.json](run-20261104-154805/actual-interface-refusal.json)。

Codex 属于 native integration：实际发布物 GET /api/native-integrations 返回 clients[]，其 Codex 行由 codexStatus 生成，包含 clientId=codex、installed、state、configPath。最小产品入口修正是由同一 attested Management 读取这个原生 collection，严格选择**唯一** clientId=codex 行；保持真实 installed/state/configPath，不通过 fallback 或 hardcode 路径填造成功。随后仍沿现有 prepare 的 runtime/version/路径、当前来源、file/pending CAS 检查。

这是读取合同修正，不需要扩大 false sync-cache 合同、不需要服务或桌面全局重启。测试端不会换接口来掩盖产品请求错误；修复归 parent，新的产品 SHA 冻结后再进行一次真实 prepare 闭环。当前未改任何产品源码。

## 证据身份与保留

先前 d20 的两项失败、候选真实 owner spike 成功、parent 单测各保留原身份。本轮没有用旧 spike 回填新产品结果；parent 的 clippy/cache19/live19/client25/wholetrue 等检查也没有冒称是本 harness 新运行。

所有业务状态仅本次临时根，工具仅已缓存发布物；无日常配置/凭据读取写入，无供应商/WebDAV 请求，无日常 Codex 重启。没有 git add/commit/push。当前 releaseGatePassed=false。
