# Windows 原生链只读复核：1313 与最终 freeze 43c6253b

本轮没有修改任何测试驱动、产品或 workflow，没有执行新增验证、改日常配置、发布、读取签名密钥或 git add/commit/push。只读取 GitHub 当前结果、原始 job 日志、原始 CI artifact 和已存在的隔离 provider 采集。旧结果不作为最终验收。

## 已确认的 1313 失败

PR68 run 41797501271，head 1313e676cb6f10607dddc8cf91a7d01db5818f7d，Windows job 126464959645 最终 failure。cargo clippy --locked --workspace --all-targets -- -D warnings 失败；release build、Windows final EXE smoke、安装恢复矩阵与 ordinary final EXE smoke 均 skipped，故不存在可据此修复的“后续 native smoke driver 失败”。dc26 的两层版本管理确认修复没有在这轮 Windows EXE 中得到执行。

原始日志：run-41797501271-backend-windows.original.log，SHA-256 7c2cdb0a7b67162cc436b8e2e6cc53e1c55d91fe4c76605eaec64e9eea396957。完整结果见 run-41797501271.final-jobs.json，便于阅读的错误片段见 run-41797501271.error-excerpts.json。

六项错误都来自 apps/desktop/tauri/tests/client_selection_rename.rs：

| 1313 源码位置 | Windows Clippy 错误 |
| --- | --- |
| 9 | unused import Value |
| 13 | unused import time::Duration |
| 17 | constant NEW is never used |
| 18 | constant REVIEW_OLD is never used |
| 19 | constant REVIEW_NEW is never used |
| 86 / 92 / 103（同一项诊断） | methods model / seed_current / review_model are never used |

这属于 Rust 测试代码的 Windows 条件编译边界，超出本 worker 的 windows-* 驱动写集；交父级处理，不能通过改 smoke 或降低 -D warnings 修复。macOS Clippy 通过不能证明 Windows 这一配置通过。

always 运行的原生凭据门实际执行且通过：provider_auth_native 1、channel_rename_native 1、native_secure_store_round_trip 1。这三项不启动官方 Codex owner，不提供 settings.codexRuntime.path 证据。

## 官方 Windows Codex 入口的证据边界

结论：当前检查到的真实采集无法确认 Windows 官方 settings 的 codex runtime path 是原生 .exe 还是 npm .cmd；既不能声称一定是 .exe，也不能据此认定真实返回 .cmd。

- 已下载并校验原始 windows-startup-evidence artifact 13306094149，ZIP SHA-256 与 GitHub digest 一致：6fbdc4385542f251d62f41de51f5d744a4589456b824841d129a1457e1fe8424。该 ZIP 只有 12 个 Windows 后端依赖诊断文件（含 Rust test EXE），没有 startup/official settings/provider 启动采集。成员清单和有界文本检查见 run-41797501271.artifact-inspection.json；没有在本机运行归档里的 EXE。
- 当前 Windows smoke 使用停用的合成模型渠道和独立配置；这些 DOM/IPC 流程不采集官方 settings.codexRuntime.path。早轮失败也不能提供该字段。
- 既有 MSVC 证据 client-default-fix-20261104/windows-typecheck.json 明确是编译/类型检查，不是 Windows runtime execution。
- 真实 owner 的集成测试模块在 apps/desktop/tauri/tests/client_selection_rename.rs 由 cfg(target_os = "macos") 限定。Unix fake adapter 的反例及 Windows wrapper 拒绝测试都不能替代真实 Windows 官方 owner。
- 已存在 provider 采集 run-20261104-162210/official-binding-before-rename.stdout、official-binding-after-prepare.stdout，以及 160341 / 160917 采集的 bindings.codexRuntime.path 都是 /private/tmp/ocx020-owned-codex-0166/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex，版本 0.166.0。这是可靠的 macOS 原生二进制证据，不是 Windows 路径证据。
- 产品 cache_refresh::client_binding 从实际 settings["codexRuntime"] 读取 path/version；client_selection_rename::validate_executable_kind 对 Windows 要求 exe 扩展，并在 spawn 前拒绝 cmd/bat。现有 absolute_batch_wrapper_and_relative_identity_are_rejected_before_spawn 只证明拒绝合成 codex.cmd，不能证明真实官方 Windows 的绑定形态。

因此 Windows 实际 owner 仍有一个需要原平台直接采集的准入证据缺口；若未来真实 settings 返回 .cmd，将在产品中按现有门禁拒绝，不能改测试改绑、解包猜路径或启用 shell 来伪装通过。本轮依用户要求不新增大型验证、不改产品、不启动真实 provider。

## 最终源绑定

用户冻结并推送 43c6253b582c3fe19ba67c8d1ccfeb4adabd7068，新的 run 41798940600 已核对 headSha。Windows job 126469682908 的最新读取显示 Clippy failure，原生凭据 always 步仍在执行，EXE smoke 尚未执行；此时完整日志未归档，因此这里只断言该步骤失败，不把 1313 的具体六项日志冒充 43 的日志。见 run-41798940600.windows-step-snapshot.json。

本地 Windows smoke 源码与 1313 run 源一致的 SHA-256 绑定已留在 run-41797501271.smoke-source-binding.json；产品推进到 43 后没有运行旧源最终验收。父级处理 Windows Clippy 后，仍需最终源码构建出的真实 Windows EXE 执行 smoke / ready WebDAV / owner 准入门，不能用旧 artifact 或 macOS 实跑代替。
