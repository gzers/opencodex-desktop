#!/usr/bin/env python3
"""Run the exact Rust module/tests against the archived official Codex 0.166.

Build separately with cargo test --locked --offline --test client_selection_rename
--no-run, then pass that executable. No daily identity or real keys are used.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--test-binary", type=Path, required=True)
args = parser.parse_args()
out = Path(__file__).resolve().parent
test = args.test_binary.resolve(strict=True)
codex = Path("/private/tmp/ocx020-owned-codex-0166/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex")
expected = "39acf979729dd290f9a24ee38b2914e036c91b65952872e28ae2a6b88a7db7c1"
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(codex) == expected
code = Path("/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes")
sources = [code / "apps/desktop/tauri/src/modules/model_config/client_selection_rename.rs",
           code / "apps/desktop/tauri/tests/client_selection_rename.rs"]
before = {str(path): digest(path) for path in sources}
root = Path(tempfile.mkdtemp(prefix="client-default-isolated-", dir="/private/tmp"))
for name in ["home", "tmp", "home/client"]:
    (root / name).mkdir(parents=True, exist_ok=True)
q = lambda value: json.dumps(str(value))
policy = root / "deny-network.sb"
policy.write_text("\n".join([
    "(version 1)", "(allow default)", "(deny network*)", "(deny file-write*)",
    f'(allow file-write* (subpath {q(root)}) (subpath {q(out)}) (literal "/dev/null") (literal "/dev/tty"))',
    '(deny file-read* (subpath "/Users/ezio"))',
    f'(allow file-read* (literal {q(test)}))',
    '(deny file-read* (subpath "/Library/Keychains"))',
    '(deny mach-lookup (global-name "com.apple.securityd") (global-name "com.apple.securityd.xpc") (global-name "com.apple.security.agent"))',
]) + "\n")
shutil.copyfile(policy, out / "isolation.sb")
env = {
    "HOME": str(root / "home"), "CODEX_HOME": str(root / "home/client"),
    "TMPDIR": str(root / "tmp"), "TMP": str(root / "tmp"), "TEMP": str(root / "tmp"),
    "PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "LANG": "C.UTF-8",
    "OCX_CLIENT_SELECTION_ISOLATED": "1", "OCX_CLIENT_SELECTION_CODEX": str(codex),
    "OCX_CLIENT_SELECTION_EVIDENCE": str(out),
    # Assert env_clear removes arbitrary parent secrets, without real keys.
    "OPENAI_API_KEY": "fixture-parent-environment-must-not-reach-owner",
    "OCX_CHANNEL_SECRET": "fixture-parent-channel-must-not-reach-owner",
}
result = {"officialCodex": str(codex), "officialSha256": expected,
          "testBinary": str(test), "testSha256": digest(test),
          "sourcesBefore": before, "osNetworkDenied": True, "keys": "synthetic parent canaries only",
          "scope": "registered production module; model and review_model current scalars",
          "mainlineRestartVerified": False, "releaseGatePassed": False}
try:
    version = subprocess.run(["/usr/bin/sandbox-exec", "-f", str(policy), str(codex), "--version"],
                             cwd=root, env=env, capture_output=True, text=True, timeout=10)
    result["version"] = version.stdout.strip()
    assert version.returncode == 0 and "0.166.0" in version.stdout
    with (out / "tests.stdout").open("w") as stdout, (out / "tests.stderr").open("w") as stderr:
        process = subprocess.Popen(["/usr/bin/sandbox-exec", "-f", str(policy), str(test),
                                    "--include-ignored", "--nocapture"], cwd=root, env=env,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            result["exitCode"] = process.wait(timeout=55)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=3)
            raise
    result["sourcesAfter"] = {str(path): digest(path) for path in sources}
    result["sourcesUnchangedDuringRun"] = before == result["sourcesAfter"]
    result["passed"] = result["exitCode"] == 0 and result["sourcesUnchangedDuringRun"]
finally:
    shutil.rmtree(root)
    (out / "verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if result.get("passed") else 1)
