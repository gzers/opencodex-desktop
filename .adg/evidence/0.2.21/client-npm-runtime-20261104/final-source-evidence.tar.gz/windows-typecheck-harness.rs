#![allow(dead_code)]
pub mod modules {pub mod model_config {pub mod schema {
 #[derive(Debug)] pub struct ModelError {pub code:String,pub message:String}
 pub type ModelResult<T>=Result<T,ModelError>;
 pub fn invalid(code:&str,message:impl Into<String>)->ModelError{ModelError{code:code.into(),message:message.into()}}
}}}
#[path="/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/modules/model_config/client_npm_runtime.rs"]pub mod implementation;
