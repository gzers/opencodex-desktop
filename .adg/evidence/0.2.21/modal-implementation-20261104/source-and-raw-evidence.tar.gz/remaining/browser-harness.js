import { createApp, defineComponent, h, ref, computed, reactive, nextTick } from 'vue'
import { createPinia, setActivePinia } from 'pinia'
import App from '/src/App.vue'
import OverviewRoute from '/src/routes/OverviewRoute.vue'
import SettingsRoute from '/src/routes/SettingsRoute.vue'
import ModelsRoute from '/src/routes/ModelsRoute.vue'
import AgentExecutionField from '/src/features/models/AgentExecutionField.vue'
import ChannelModelTable from '/src/features/models/ChannelModelTable.vue'
import AppModal from '/src/components/AppModal.vue'
import { useLifecycleController } from '/src/app/useLifecycleController'
import { useAppStore } from '/src/stores/app'
import { useRouteStore } from '/src/stores/routes'
import { useModelsStore } from '/src/features/models/store'
import { useRuntimeStore } from '/src/features/runtime/store'
import { useAboutStore } from '/src/features/about/store'
import { useDataRootStore } from '/src/features/data-root/store'
import { useEnvironmentStore } from '/src/features/environment/store'
import { useFeedbackStore } from '/src/app/feedback/store'
import { useEffectsStore } from '/src/app/appearance/effects'
import { runtimeScenarios, actionLabels } from '/src/features/runtime/scenarios'
import { modelApi, emptyRules, emptyContent } from '/src/features/models/api'
import { createModelRowsState, rowFields, copy } from '/src/features/models/modelRows'
import { managerUpdateStatus } from '/src/features/updates/update'
import '/src/styles/tokens.css'
import '/src/styles/base.css'
import '/src/styles/materials.css'
import '/src/styles/effects.css'
const pinia=createPinia();setActivePinia(pinia)
const app=useAppStore(), routes=useRouteStore(), models=useModelsStore(), runtime=useRuntimeStore(), environment=useEnvironmentStore(), feedback=useFeedbackStore(), effects=useEffectsStore()
const mode=ref(''),calls=[]
const found={found:true,path:'/isolated/fixture/bin',version:'2.50.0'}
const env=(ready=true)=>({node:{...found},npm:{...found},ocx:{...found,found:ready},gate:ready?'ready':'missing_ocx',shortCircuited:false,brewFound:true})
environment.set(env());useAboutStore().app={version:'0.2.21',platform:'darwin'};useDataRootStore().config={currentDataRoot:'/isolated/fixture',activeDataRoot:'/isolated/fixture',opencodexHomeMode:'data_root',opencodexHome:'/isolated/fixture/home',currentOpencodexHome:'/isolated/fixture/home',runtimeActive:true}
const source={kind:'managed',path:'/isolated/fixture/runtime/bin/ocx',version:'2.50.0',resolvedAt:null,insideDataRoot:true,managedEntry:'/isolated/fixture/runtime/bin/ocx',managedPrefix:'/isolated/fixture/runtime/opencodex',defaultPrefix:'/isolated/fixture/runtime/opencodex',explicitPath:null,history:[]};runtime.source=source
const plan={sourceKind:'managed',sourcePath:source.path,managed:true,backupId:null,removable:true,reason:null,removeObjects:['@bitkyc08/opencodex',source.managedPrefix],runtimeObjects:['service'],dataObjects:['/isolated/fixture/home/config.json'],residueCandidates:[],officialCommand:'ocx uninstall',externalCommand:null}
const uninstallResult={scope:'full',sourceKind:'unresolved',sourcePath:null,backupId:'fixture-backup',backupDirectory:'/isolated/fixture/backups',steps:[{name:'执行官方 ocx uninstall',status:'ok',detail:'fixture'},{name:'移除包体与入口',status:'ok',detail:'fixture'}],residue:[{path:source.managedPrefix,status:'cleared'}],officialOutput:['fixture output'],needsRestart:false,message:'fixture complete'}
let finishUninstall,finishDelete,finishProject,finishSave,finishMatch,finishDirectory,finishRecheck
window.__qaInvoke=async(command,args)=>{calls.push({command,args});if(command==='runtime_source')return source;if(command==='runtime_protection_status')return {state:'none',version:null,backupId:null};if(command==='plan_runtime_uninstall')return plan;if(command==='uninstall_runtime')return new Promise(resolve=>{finishUninstall=()=>resolve(uninstallResult)});if(command==='discover_environment')return env();if(command==='get_data_root_config')return useDataRootStore().config;if(command==='get_update_status')return managerUpdateStatus.value;if(command==='restore_risk_summary')return {guidance:{runtimeState:'at_risk',health:'degraded',startupStatus:'at-risk',protection:'none',rebootSafe:false,servicePresent:false,shimPresent:false,versionDrift:'2.50.0',dataRoot:'/isolated/fixture',opencodexHome:'/isolated/fixture/home'},preferencesConfigured:true,extensionConfigured:false,syncEndpointConfigured:false,opencodexHome:'/isolated/fixture/home'};if(command==='create_restore_backup')return {backupId:'fixture-restore',directory:'/isolated/fixture/backups',targetPath:'/isolated/fixture/preferences.json'};if(command==='plugin:event|listen')return 1;return null}
managerUpdateStatus.value={channel:'stable',currentVersion:'0.2.21',availableVersion:'0.2.21',lastCheckedAt:'2026-11-04T00:00:00Z',signatureVerified:false,error:null}
const channel=reactive({id:'channel',label:'示例渠道',connection:{providerId:'provider',protocol:'openai-chat',nodes:[{id:'node',name:'主站',url:'https://example.test'}],activeNodeId:'node',credentialRef:null,enabled:true,allowPrivateNetwork:false},selection:{mode:'whitelist',models:['raw/a']},modelOrder:['raw/a','raw/b'],discovered:['raw/a','raw/b'].map(id=>({id,label:id,rules:emptyRules()})),templateRefs:[],modelRefs:{},defaults:emptyRules(),overrides:{},familyOverrides:{}})
const snapshot=()=>({library:{schemaVersion:1,templates:[{id:'family',label:'示例模版族',source:'user',defaultRevision:'old',revisions:['old','new'].map((id,i)=>({id,createdAt:'2026-11-04T00:00:0'+i+'Z',savedLabel:id,digest:id,baseRevision:null,changes:[],content:emptyContent()}))}]},policy:{schemaVersion:1,templateRefs:[],channels:[JSON.parse(JSON.stringify(channel))]},libraryDigest:'library',policyDigest:'policy',workspaceDigest:'workspace',workspace:null})
models.acceptTransfer(snapshot());models.view.tab='templates'
const state=reactive(createModelRowsState());const fields=rowFields(channel,'raw/a');state.buffers['raw/a']={...copy(fields),base:copy(fields),error:''};state.buffers['raw/a'].rules.fast={mode:'custom',value:false}
const saved={providerId:'original',modelId:'old',reasoningEffort:null,fast:null,channelId:'old-channel',connectionDigest:'old-binding'}
const directory={channels:[{id:'new-channel',label:'新渠道',providerId:'new-provider'}],rows:[{channelId:'new-channel',providerId:'new-provider',modelId:'raw/new',label:'raw/new',enabled:true,selected:false,discovered:true,templateRef:null,rules:emptyRules(),source:{},connectionDigest:'new-binding'}]}
const flags=reactive({pendingDelete:false,pendingProject:false,pendingSave:false,pendingMatch:false,pendingDirectory:false,pendingRecheck:false})
const projection=()=>({rows:[],knownActiveModels:0,exactCatalogCount:0,notices:[]})
modelApi.load=async()=>snapshot()
modelApi.agentSettings=async()=>saved
modelApi.executionDirectory=async()=>{calls.push({command:'execution-directory'});return flags.pendingDirectory?new Promise(resolve=>{finishDirectory=()=>resolve(directory)}):directory}
modelApi.saveAgentSettings=async value=>{calls.push({command:'save-execution',value});return flags.pendingSave?new Promise(resolve=>{finishSave=()=>resolve(value)}):value}
modelApi.project=async value=>{calls.push({command:'project-channel',value});return flags.pendingProject?new Promise(resolve=>{finishProject=()=>resolve(projection())}):projection()}
modelApi.delete=async(...args)=>{calls.push({command:'delete-versions',args});const next=snapshot();next.library.templates[0].revisions=next.library.templates[0].revisions.filter(r=>!args[4].includes(r.id));return flags.pendingDelete?new Promise(resolve=>{finishDelete=()=>resolve(next)}):next}
modelApi.setDefault=async(...args)=>{calls.push({command:'set-default',args});const next=snapshot();next.library.templates[0].defaultRevision=args[2];return next}
modelApi.preview=async()=>{calls.push({command:'match-preview'});return flags.pendingMatch?new Promise(resolve=>{finishMatch=()=>resolve({matched:true,reason:'过期匹配响应',variantId:null})}):{matched:true,reason:'已匹配',variantId:null}}
modelApi.externalResult=async()=>({task:{targets:[{label:'示例模版族'}]},receipt:{state:'report',report:'只读外部任务结果'},outcomes:[]})
window.qaController={scenario:computed(()=>runtimeScenarios.stopped),actionLabels,runAction:action=>calls.push({command:'runtime-action',action}),refreshEnvironment:()=>{calls.push({command:'environment-recheck'});return flags.pendingRecheck?new Promise(resolve=>{finishRecheck=()=>resolve(true)}):Promise.resolve(true)}}
const lifecycle=useLifecycleController({runDoctor:()=>{},loadLogs:()=>{}})
async function show(value){mode.value=value;if(value==='fault')routes.go('tray');if(value==='overview'){routes.go('overview');environment.set(env())}if(value==='uninstall'){runtime.source=source;routes.go('settings',{section:'installation'})};if(value==='versions'||value==='match'||value==='receipt'){models.view.tab='templates';routes.go('models')}await nextTick();if(value==='fault')feedback.reportUiFault('界面出现异常：隔离验证错误详情。关闭只清理提示，保留当前任务。');if(value==='receipt')models.notificationTarget={taskId:'fixture-task',submissionId:crypto.randomUUID()};if(value==='guide')await lifecycle.openRestoreConfirm('at_risk');if(value==='match'){models.edit(models.snapshot.library.templates[0]);models.view.templateEditor=true}}
window.qa={ready:false,show,mode,flags,calls,app,models,runtime,environment,feedback,effects,channel,state,blockEnvironment(){runtime.source={...source,kind:'unresolved',path:null};environment.set(env(false))},finishUninstall:()=>finishUninstall?.(),finishDelete:()=>finishDelete?.(),finishProject:()=>finishProject?.(),finishSave:()=>finishSave?.(),finishMatch:()=>finishMatch?.(),finishDirectory:()=>finishDirectory?.(),finishRecheck:()=>finishRecheck?.()}
const Root=defineComponent({setup:()=>()=>h('div',{style:'padding:20px'},[h('h1',{style:'font-size:18px'},'POST-09 · 剩余真实消费者隔离验证'),h('div',{style:'display:flex;gap:8px;flex-wrap:wrap'},['fault','overview','uninstall','versions','match','receipt','agent','table','guide'].map(value=>h('button',{class:'btn',id:'open-'+value,onClick:()=>show(value)},value))),mode.value==='fault'?h(App):h(AppModal),mode.value==='overview'?h(OverviewRoute):null,mode.value==='uninstall'?h(SettingsRoute):null,['versions','match','receipt'].includes(mode.value)?h(ModelsRoute):null,mode.value==='agent'?h(AgentExecutionField):null,mode.value==='table'?h(ChannelModelTable,{channel,models:channel.discovered,state,templates:[]}):null])})
createApp(Root).use(pinia).mount('#app');window.qa.ready=true
