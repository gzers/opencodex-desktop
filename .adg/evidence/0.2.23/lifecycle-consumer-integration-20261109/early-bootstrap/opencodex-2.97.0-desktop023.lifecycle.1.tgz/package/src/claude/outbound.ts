import { anthropicProgressEnvelope, isAnthropicProgressMirror } from "../responses/anthropic-progress";
/**
 * Claude Code outbound: internal /v1/responses output -> Anthropic Messages API shapes.
 *
 * Wire contract pinned in devlog/260711_claude_inbound/003_evidence.md (all Tier 2):
 *  - Transport-only `ping` events may appear at any point, including before
 *    message_start. Semantic framing stays message_start ->
 *    (content_block_start -> deltas -> content_block_stop)* -> message_delta -> message_stop.
 *  - thinking blocks get thinking_delta(s), then one signature_delta containing the
 *    genuine replay signature or a bounded ocxr1 fallback envelope.
 *  - message_delta.usage is cumulative; message_start embeds a full message snapshot.
 *  - errors: {type:"error", error:{type,message}}; may arrive mid-stream after HTTP 200.
 */
import { createHash } from "node:crypto";
import { httpStatusFromTerminalError, UNDECLARED_TOOL_CALL_ERROR_CODE } from "../lib/errors";
import { isTransientUpstreamStatus } from "../lib/upstream-retry";
import {
  isTranslatorBudgetExceededError,
  TRANSLATOR_MAX_TURN_BYTES,
  TranslatorBudgetExceededError,
  type TranslatorBudget,
} from "../lib/translator-budget";
import { sseFieldOffset, sseFieldValue } from "../lib/sse-decoder";
import { decodeReasoningEnvelope, encodeReasoningEnvelope, OCX_REASONING_PREFIX } from "../responses/reasoning-envelope";

type Rec = Record<string, unknown>;

function isRec(v: unknown): v is Rec {
  return !!v && typeof v === "object" && !Array.isArray(v);
}

function reasoningIdentityDigest(value: string): string {
  return createHash("sha256").update(value).digest("base64url");
}

/** Fixed-size identity that preserves protocol boundaries without retaining upstream strings. */
export function boundedReasoningIdentity(value: unknown): string {
  if (typeof value === "number") {
    if (Number.isSafeInteger(value) && value >= 0) return `n${value}`;
    if (Number.isFinite(value)) return `d${value}`;
    return Number.isNaN(value) ? "dnan" : value > 0 ? "dinf" : "d-inf";
  }
  if (typeof value === "string") {
    return `s${reasoningIdentityDigest(value)}`;
  }
  if (value === null) return "z";
  if (typeof value === "boolean") return value ? "b1" : "b0";
  if (Array.isArray(value)) return `a${reasoningIdentityDigest(JSON.stringify(value) ?? "[]")}`;
  // Preserve the prior String(record) category semantics without serializing untrusted trees.
  return typeof value === "object" ? "o" : "u";
}

function uuid(): string {
  return crypto.randomUUID().replace(/-/g, "");
}

/** HTTP status -> Anthropic error taxonomy (010 amendment #4; full official table per devlog 100). */
export function anthropicErrorType(status: number): string {
  switch (status) {
    case 400: return "invalid_request_error";
    case 401: return "authentication_error";
    case 402: return "billing_error";
    case 403: return "permission_error";
    case 404: return "not_found_error";
    case 409: return "conflict_error";
    case 413: return "request_too_large";
    case 429: return "rate_limit_error";
    case 504: return "timeout_error";
    case 529: return "overloaded_error";
    default: return status >= 500 ? "api_error" : "invalid_request_error";
  }
}

/**
 * Claude Code compacts reactively only when an oversized-prompt refusal is worded the way the
 * Anthropic API words it: it looks for `prompt is too long` (or `input is too long for requested
 * model`) in the message and reads `prompt is too long: <actual> tokens > <limit> maximum` for the
 * gap (2.1.288 binary). Routed providers word the same refusal differently, so a
 * context_length_exceeded envelope is rewritten into that form. Counts are carried over only when
 * the upstream states both of them; otherwise the original text is prefixed and no number is
 * guessed. Without this the client ends the turn on a fatal error instead of compacting
 * (devlog/_plan/261009_claude_1m_default/010).
 */
const CLAUDE_PROMPT_TOO_LONG_RE = /prompt is too long|input is too long for requested model/i;
const MAX_OVERFLOW_MESSAGE_CHARS = 64 * 1024;
const STATED_CONTEXT_LIMIT_RE = /maximum context length is (\d+) tokens/i;
const STATED_REQUEST_COUNT_RE = /(?:resulted in|you requested) (\d+) tokens/i;

export function claudePromptTooLongMessage(message: string): string {
  message = message.slice(0, MAX_OVERFLOW_MESSAGE_CHARS);
  if (CLAUDE_PROMPT_TOO_LONG_RE.test(message)) return message;
  const limit = STATED_CONTEXT_LIMIT_RE.exec(message);
  const requested = limit && STATED_REQUEST_COUNT_RE.exec(message.slice(limit.index + limit[0].length));
  if (limit && requested) return `prompt is too long: ${requested[1]} tokens > ${limit[1]} maximum`;
  return `prompt is too long: ${message}`;
}

/** Provider wordings of an oversized-input refusal, for lanes that relay a provider's own error text. */
const CONTEXT_OVERFLOW_TEXT_RE = /prompt is too long|input is too long|context window|context length|maximum context|too many tokens|model token limit/i;

export function isContextOverflowText(message: string): boolean {
  return CONTEXT_OVERFLOW_TEXT_RE.test(message);
}

/**
 * SSE payload rewrite for the native Messages lane: an `error` event that refuses an oversized
 * input gets the Anthropic wording; every other payload passes through byte-identical. The type
 * gate keeps a rate limit that happens to mention the context window untouched.
 */
export function claudeOverflowSsePayload(payload: string): string {
  if (!payload.includes("\"error\"")) return payload;
  let parsed: unknown;
  try { parsed = JSON.parse(payload); } catch { return payload; }
  if (!isRec(parsed) || parsed.type !== "error" || !isRec(parsed.error)) return payload;
  const error = parsed.error;
  const message = typeof error.message === "string" ? error.message : "";
  const sized = error.type === "invalid_request_error" || error.type === "request_too_large";
  if (!sized || isThroughputLimitText(message)) return payload;
  if (!(error.code === "context_length_exceeded" || isContextOverflowText(message))) return payload;
  const next = claudePromptTooLongMessage(message);
  return next === message ? payload : JSON.stringify({ ...parsed, error: { ...error, message: next } });
}

/**
 * A throughput limit that the shared classifier files under context_length_exceeded (its "too many
 * tokens" match also catches "too many tokens per minute"). Worded as an overflow it would make
 * Claude Code compact a conversation that only needs to wait, so it keeps its own text.
 */
const THROUGHPUT_LIMIT_TEXT_RE = /\bper (?:second|minute|hour|day)\b|\brate limit|\bquota\b|\btpm\b/i;

export function isThroughputLimitText(message: string): boolean {
  return THROUGHPUT_LIMIT_TEXT_RE.test(message);
}

/** Codes that say nothing about the cause, so the message decides (#8127). */
const GENERIC_FAILURE_CODES: ReadonlySet<string> = new Set(["server_error", "upstream_error", "api_error", "internal_error"]);
const NON_OVERFLOW_ERROR_TYPES: ReadonlySet<string> = new Set(["rate_limit_error", "authentication_error", "permission_error"]);
const NON_OVERFLOW_STATUSES: ReadonlySet<number> = new Set([401, 403, 429]);
/**
 * Wording that asserts the request itself is over a size limit. Narrower than
 * CONTEXT_OVERFLOW_TEXT_RE on purpose: without a code, a message that only mentions the context
 * window (for example a configuration failure or a validation error) must not make Claude Code
 * compact. Quoted values are removed first, a stated maximum counts only when the stated request
 * is larger, and a negated verdict ("does not exceed") never counts.
 */
const TOO_LONG_TEXT_RE = /\b(?:prompt|input) is too long\b([^.\n]{0,60})/i;
const CONDITIONAL_LEAD_RE = /\b(?:if|whether|unless)\b[^.\n]{0,40}$/i;
const STATED_COUNTS_RE = /maximum context length is (\d+)[^]{0,200}?\b(?:resulted in|you requested|requested) (\d+) tokens/i;
const EXCEEDS_TEXT_RE = /\b(?:input|prompt|request|messages?|conversation)\b[^.\n]{0,60}\bexceed(?:s|ed|ing)?\b[^.\n]{0,40}\b(?:context (?:window|length)|maximum context|token limit)/i;
const NEGATION_RE = /\b(?:not|never|no|neither|nor)\b|n['\u2019]t\b/i;
/** A quoted value inside a message (a field, enum or tool name), ASCII or typographic; an apostrophe inside a word does not open one. */
const QUOTED_SPAN_RE = /(?<!\w)(['"`])[^'"`\n]{1,200}\1(?!\w)|\u2018[^\u2019\n]{1,200}\u2019|\u201c[^\u201d\n]{1,200}\u201d/g;

function assertsOverflow(message: string): boolean {
  const text = message.replace(QUOTED_SPAN_RE, " ");
  const tooLong = TOO_LONG_TEXT_RE.exec(text);
  if (tooLong && !NEGATION_RE.test(tooLong[1] ?? "") && !CONDITIONAL_LEAD_RE.test(text.slice(0, tooLong.index))) return true;
  const counts = STATED_COUNTS_RE.exec(text);
  if (counts && Number(counts[2]) > Number(counts[1])) return true;
  const exceeds = EXCEEDS_TEXT_RE.exec(text);
  return exceeds !== null && !NEGATION_RE.test(exceeds[0]);
}

/**
 * Whether a translated refusal is an oversized-input refusal. A coded context_length_exceeded
 * always is. Some Responses upstreams send the refusal uncoded or as a generic server_error
 * ("Your input exceeds the context window of this model"); as a 502 Claude Code retries it
 * instead of compacting (#8127). Those count only when the wording is an overflow, is not a
 * throughput limit, and the type is not a rate-limit or credential refusal. Any other specific
 * code keeps its own classification.
 */
export function isContextOverflowError(error: { type?: unknown; code?: unknown }, message: string): boolean {
  const code = error.code;
  if (code === "context_length_exceeded") return true;
  if (code != null && !(typeof code === "string" && GENERIC_FAILURE_CODES.has(code))) return false;
  if (typeof error.type === "string" && NON_OVERFLOW_ERROR_TYPES.has(error.type)) return false;
  const status = (error as { status?: unknown }).status;
  if (typeof status === "number" && NON_OVERFLOW_STATUSES.has(status)) return false;
  return assertsOverflow(message) && !isThroughputLimitText(message);
}

export function anthropicErrorBody(status: number, message: string, type?: string, code?: string): Rec {
  const overflow = code === "context_length_exceeded" && !isThroughputLimitText(message);
  const text = overflow ? claudePromptTooLongMessage(message) : message;
  return { type: "error", error: { type: type ?? anthropicErrorType(status), message: text, ...(code ? { code } : {}) } };
}

export function anthropicErrorResponse(status: number, message: string, type?: string, code?: string): Response {
  return new Response(JSON.stringify(anthropicErrorBody(status, message, type, code)), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

/**
 * Responses usage -> Anthropic usage. Responses `input_tokens` is INCLUSIVE of cache
 * read+write (types.ts convention); Anthropic `input_tokens` excludes both, so
 * subtract the full cache detail (devlog 070 — subtracting reads only inflated the
 * non-cached input Claude Code displays by the write share).
 */
export function anthropicUsage(usage: unknown, webSearchRequests = 0): Rec {
  const u = isRec(usage) ? usage : {};
  const details = isRec(u.input_tokens_details) ? u.input_tokens_details : {};
  const cached = typeof details.cached_tokens === "number" ? details.cached_tokens : 0;
  const cacheWrite = typeof details.cache_write_tokens === "number" ? details.cache_write_tokens : 0;
  const cacheWrite1h = typeof details.cache_write_1h_tokens === "number"
    ? Math.max(0, Math.min(details.cache_write_1h_tokens, cacheWrite)) : undefined;
  const input = typeof u.input_tokens === "number" ? u.input_tokens : 0;
  const output = typeof u.output_tokens === "number" ? u.output_tokens : 0;
  return {
    input_tokens: Math.max(0, input - cached - cacheWrite),
    output_tokens: output,
    cache_read_input_tokens: cached,
    cache_creation_input_tokens: cacheWrite,
    ...(cacheWrite1h !== undefined
      ? { cache_creation: { ephemeral_5m_input_tokens: cacheWrite - cacheWrite1h, ephemeral_1h_input_tokens: cacheWrite1h } }
      : {}),
    // Only successful searches are billed/counted (Anthropic contract; Claude Code cost accounting).
    ...(webSearchRequests > 0 ? { server_tool_use: { web_search_requests: webSearchRequests } } : {}),
  };
}

export function sseFrame(name: string, data: Rec): string {
  return `event: ${name}\ndata: ${JSON.stringify(data)}\n\n`;
}

function appendedUtf8Bytes(previous: string, previousBytes: number, fragment: string): number {
  let nextBytes = previousBytes + Buffer.byteLength(fragment);
  const previousLast = previous.charCodeAt(previous.length - 1);
  const fragmentFirst = fragment.charCodeAt(0);
  if (previousLast >= 0xd800 && previousLast <= 0xdbff
    && fragmentFirst >= 0xdc00 && fragmentFirst <= 0xdfff) {
    nextBytes -= 2;
  }
  return nextBytes;
}

/**
 * Claude Code / Anthropic WebSearch domain filters are optional and mutually exclusive.
 * Empty arrays are rejected ("ambiguous"); both fields together are rejected. Routed models
 * often emit both shapes — sanitize before Claude Code sees the tool_use / server_tool_use
 * input (issue #381).
 */
export function isClaudeWebSearchToolName(name: string): boolean {
  const trimmed = name.trim();
  return trimmed === "WebSearch" || /^web_search/i.test(trimmed);
}

function normalizeWebSearchDomainList(value: unknown): string[] | undefined {
  if (!Array.isArray(value)) return undefined;
  const domains = value
    .filter((entry): entry is string => typeof entry === "string" && entry.trim().length > 0)
    .map(entry => entry.trim());
  return domains.length > 0 ? domains : undefined;
}

/** Strip empty domain filters; if both remain, keep `allowed_domains` and drop `blocked_domains`. */
export function sanitizeWebSearchInput(input: unknown): Rec {
  const src: Rec = isRec(input) ? { ...input } : {};
  const allowed = normalizeWebSearchDomainList(src.allowed_domains);
  const blocked = normalizeWebSearchDomainList(src.blocked_domains);
  delete src.allowed_domains;
  delete src.blocked_domains;
  if (allowed && blocked) {
    // Prefer allow-list (restrict-to) when a routed model sets both non-empty fields.
    src.allowed_domains = allowed;
  } else if (allowed) {
    src.allowed_domains = allowed;
  } else if (blocked) {
    src.blocked_domains = blocked;
  }
  return src;
}

/**
 * Map a Responses `web_search_call` item to its Anthropic pair: the server_tool_use
 * input (query/queries) and the web_search_tool_result content (hits, or the error
 * object when the search failed). An item carrying `anthropic_blocks` came from Anthropic's
 * own server-side call and maps back to those blocks verbatim (`srvtoolu_` id,
 * `encrypted_content`, web_fetch), so the client can replay them on its next turn.
 * Shared by the SSE, JSON and direct translation paths.
 */
export function webSearchPairFromItem(item: Rec): {
  id: string; name: string; resultType: string; input: Rec; resultContent: unknown; completed: boolean;
} {
  const action = isRec(item.action) ? item.action : {};
  const completed = item.status !== "failed";
  const { use, result } = isRec(item.anthropic_blocks) ? item.anthropic_blocks : {};
  if (isRec(use) && isRec(result) && typeof use.id === "string" && isRec(use.input)
    && (use.name === "web_search" || use.name === "web_fetch")
    && result.tool_use_id === use.id && result.type === `${use.name}_tool_result`) {
    return { id: use.id, name: use.name, resultType: result.type, input: use.input, resultContent: result.content, completed };
  }
  const id = typeof item.id === "string" && item.id.length > 0 ? item.id : `srvtoolu_${uuid()}`;
  // An item emitted before `anthropic_blocks` carried a server web_fetch as `fetch_result`.
  if (item.fetch_result !== undefined) {
    const input = { url: typeof action.url === "string" ? action.url : "" };
    return { id, name: "web_fetch", resultType: "web_fetch_tool_result", input, resultContent: item.fetch_result, completed };
  }
  const queries = Array.isArray(action.queries)
    ? action.queries.filter((q): q is string => typeof q === "string" && q.length > 0)
    : [];
  const query = typeof action.query === "string" ? action.query : "";
  const input = sanitizeWebSearchInput(
    queries.length > 1 ? { queries } : { query: queries[0] ?? query },
  );
  let resultContent: unknown;
  if (completed) {
    const hits: Rec[] = [];
    if (Array.isArray(item.sources)) {
      for (const s of item.sources) {
        if (isRec(s) && typeof s.url === "string" && s.url.length > 0) {
          hits.push({ type: "web_search_result", title: typeof s.title === "string" ? s.title : "", url: s.url });
        }
      }
    }
    resultContent = hits;
  } else {
    resultContent = { type: "web_search_tool_result_error", error_code: "unavailable" };
  }
  return { id, name: "web_search", resultType: "web_search_tool_result", input, resultContent, completed };
}

/**
 * `inputTokenFloor` is this proxy's own count of the prompt it forwarded, used only when the
 * upstream sent no confirmed usage before the first frame.
 *
 * Real Anthropic fills `message_start.message.usage.input_tokens` with the turn's prompt size,
 * and third-party clients read it there — Paseo's context meter takes input from this frame and
 * output from `message_delta`, so a hardcoded zero showed a nearly-empty ring for a turn whose
 * `/context` reported ~97k (#4857). #4891 fixed the destinations that report usage up front;
 * the internal bridge attaches `usage: null` to its lifecycle frames, so those paths had
 * nothing to report and kept sending zero.
 *
 * A floor is a measurement, which is what makes it publishable here: it counts the prompt this
 * proxy actually sent, the same estimate `claude-messages.ts` already trusts as a log floor. It
 * is not a claim about upstream's tokenizer, and it is not final — `message_delta` carries the
 * authoritative count for every reader that waits for it, exactly as before.
 */
export function messageSnapshot(model: string, confirmedUsage?: Rec, inputTokenFloor?: number): Rec {
  const usage = confirmedUsage
    ?? (typeof inputTokenFloor === "number" && Number.isFinite(inputTokenFloor) && inputTokenFloor > 0
      ? { input_tokens: Math.trunc(inputTokenFloor), output_tokens: 0 }
      : { input_tokens: 0, output_tokens: 0 });
  return {
    id: `msg_${uuid()}`,
    type: "message",
    role: "assistant",
    content: [],
    model,
    stop_reason: null,
    stop_sequence: null,
    usage,
  };
}

/**
 * A Responses incomplete reason as the Anthropic client sees it: an output cap and a content
 * filter are real stop reasons; every other reason is a retryable overload so Claude Code backs
 * off instead of accepting a truncated turn.
 */
export function anthropicIncompleteOutcome(
  reason: unknown,
  message: unknown,
): { stopReason: "max_tokens" | "refusal" } | { failMessage: string } {
  if (reason === "max_output_tokens") return { stopReason: "max_tokens" };
  if (reason === "content_filter") return { stopReason: "refusal" };
  return {
    failMessage: typeof message === "string" && message.trim()
      ? message
      : `upstream response was incomplete${typeof reason === "string" ? ` (${reason})` : ""}`,
  };
}

/**
 * The HTTP status a Responses `response.failed` error object maps to on the Anthropic wire.
 * Internal failure envelopes carry the classified {type, code, message} but no numeric status,
 * so it is derived with the same mapping /api/logs uses; a classified 429/401/400 then reaches
 * Claude Code as its real Anthropic error type instead of a retryable overload.
 */
export function anthropicFailedStatus(error: Rec, message: string): number {
  const code = typeof error.code === "string" ? error.code : undefined;
  if (isContextOverflowError(error, message)) return 400;
  return code === "translation_buffer_limit"
    ? 413
    : typeof error.status === "number"
      ? error.status
      : httpStatusFromTerminalError({
        type: typeof error.type === "string" ? error.type : undefined,
        code: typeof error.code === "string" ? error.code : null,
        message,
      });
}

interface OpenBlock {
  kind: "text" | "thinking" | "tool_use";
  index: number;
  /** Responses item_id (tool calls) so output_item.done can match. */
  itemId?: string;
  /** Buffer WebSearch args and emit one sanitized input_json_delta on close (#381). */
  bufferWebSearchArgs?: boolean;
  argsBuf?: string;
  argsBufBytes?: number;
  webSearchArgsEmitted?: boolean;
  /** True once ordinary function-call arguments were emitted to Anthropic SSE. */
  toolArgsEmitted?: boolean;
  callId?: string;
  /** Last fixed-size reasoning identity (item + summary/content index) seen by this block. */
  reasoningPartKey?: string;
  /** Fixed-size item identity; missing IDs only match other missing IDs. */
  reasoningItemKey?: string;
  thinkingBuf?: string;
  thinkingBufBytes?: number;
  reasoningSig?: string;
  /** The provider's own encrypted reasoning for this item; signed into the block on close. */
  reasoningNative?: { enc: string; id?: string };
}

/** A provider-minted (not ocxr1) `encrypted_content`, or `""`. */
function nativeEncryptedReasoning(encrypted: string): string {
  return encrypted.length > 0 && !encrypted.startsWith(OCX_REASONING_PREFIX) ? encrypted : "";
}

/** Streaming: Responses SSE bytes -> Anthropic Messages SSE bytes. */
export function responsesSseToAnthropicSse(
  upstream: ReadableStream<Uint8Array>,
  model: string,
  opts: {
    pingIntervalMs?: number;
    translatorBudget: TranslatorBudget;
    /**
     * This proxy's count of the prompt it forwarded, published on `message_start` only when the
     * upstream sent no confirmed usage before the first frame. See `messageSnapshot` (#4857).
     */
    inputTokenFloor?: number;
    nativeReasoningTagFor?: (blob: string) => string | undefined;
  },
): ReadableStream<Uint8Array> {
  const translatorBudget = opts.translatorBudget;
  const pingIntervalMs = opts?.pingIntervalMs ?? 20_000;
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";
  let bufferBytes = 0;
  let started = false;
  let terminated = false;
  // Starting termination can still throw while closing a block or emitting its
  // terminal frame. Only a delivered terminal forbids the bounded overflow error.
  let terminalDelivered = false;
  let cancelled = false;
  let blockIndex = 0;
  let open: OpenBlock | null = null;
  let sawToolUse = false;
  let webSearchRequests = 0;
  let earlyAnthropicUsage: Rec | undefined;
  let pingTimer: ReturnType<typeof setInterval> | undefined;
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
  const utf8SliceBytes = (value: string, start: number, end: number): number => {
    let bytes = 0;
    for (let index = start; index < end; index++) {
      const codePoint = value.codePointAt(index)!;
      if (codePoint <= 0x7f) bytes += 1;
      else if (codePoint <= 0x7ff) bytes += 2;
      else if (codePoint <= 0xffff) bytes += 3;
      else { bytes += 4; index += 1; }
    }
    return bytes;
  };
  const queuedLiveFrameBytes: number[] = [];
  const releaseDeliveredFrame = () => {
    const bytes = queuedLiveFrameBytes.shift();
    if (bytes !== undefined) translatorBudget.releaseRetained(bytes, { kind: "live_transient" });
  };
  const releaseThinkingBuffer = (block: OpenBlock | null | undefined) => {
    if (block?.kind !== "thinking") return;
    translatorBudget.releaseRetained(block.thinkingBufBytes ?? 0, { kind: "reasoning" });
    block.thinkingBufBytes = 0;
  };

  return new ReadableStream<Uint8Array>({
    start(controller) {
      const emit = (name: string, data: Rec) => {
        const frame = encoder.encode(sseFrame(name, data));
        const reservation = translatorBudget.reserveTransient(frame.byteLength, { kind: "live_transient" });
        controller.enqueue(frame);
        reservation.commitRetained();
        queuedLiveFrameBytes.push(frame.byteLength);
      };
      const ensureStarted = () => {
        if (started) return;
        started = true;
        emit("message_start", {
          type: "message_start",
          message: messageSnapshot(model, earlyAnthropicUsage, opts.inputTokenFloor),
        });
        emit("ping", { type: "ping" });
      };
      // Keepalive pings protect remote deployments behind LB/NAT idle timeouts even
      // before semantic output. They are transport-only and must not manufacture a
      // message before a possible initial error.
      if (pingIntervalMs > 0) {
        pingTimer = setInterval(() => {
          if (terminated || (controller.desiredSize ?? 0) <= 0) return;
          try {
            emit("ping", { type: "ping" });
          } catch { /* controller torn down; the read loop is ending anyway */ }
        }, pingIntervalMs);
      }
      const closeOpenBlock = () => {
        if (!open) return;
        if (open.kind === "tool_use" && open.bufferWebSearchArgs && !open.webSearchArgsEmitted) {
          // Emit sanitized args even if output_item.done never supplied a full arguments field
          // (finish/fail paths, or deltas-only streams).
          let parsed: unknown = {};
          const rawArgs = open.argsBuf ?? "";
          try { parsed = rawArgs.length > 0 ? JSON.parse(rawArgs) : {}; } catch { parsed = {}; }
          emit("content_block_delta", {
            type: "content_block_delta",
            index: open.index,
            delta: { type: "input_json_delta", partial_json: JSON.stringify(sanitizeWebSearchInput(parsed)) },
          });
          open.webSearchArgsEmitted = true;
        }
        if (open.kind === "thinking") {
          const native = open.reasoningNative;
          const tag = native && opts.nativeReasoningTagFor?.(native.enc);
          if (!open.thinkingBuf && !open.reasoningSig && !tag) {
            releaseThinkingBuffer(open);
            open = null;
            return;
          }
          // Delay the index and all thinking frames until closure so a matching
          // done envelope can put its redacted blocks first. The existing buffer
          // remains charged through signature emission, including queued frames.
          open.index = blockIndex++;
          emit("content_block_start", {
            type: "content_block_start", index: open.index,
            content_block: { type: "thinking", thinking: "", signature: "" },
          });
          if (open.thinkingBuf) {
            emit("content_block_delta", {
              type: "content_block_delta", index: open.index,
              delta: { type: "thinking_delta", thinking: open.thinkingBuf },
            });
          }
          const signature = open.reasoningSig ?? encodeReasoningEnvelope({
            txt: open.thinkingBuf ?? "",
            ...(tag ? { nat: { ...native, model, tag } } : {}),
          }, translatorBudget);
          emit("content_block_delta", {
            type: "content_block_delta", index: open.index,
            delta: { type: "signature_delta", signature },
          });
        }
        emit("content_block_stop", { type: "content_block_stop", index: open.index });
        releaseThinkingBuffer(open);
        if (open.callId) translatorBudget.closeCall(open.callId);
        open = null;
      };
      const ensureBlock = (kind: "text" | "thinking") => {
        ensureStarted();
        if (open && open.kind === kind) return;
        closeOpenBlock();
        if (kind === "thinking") {
          open = { kind, index: -1, thinkingBuf: "", thinkingBufBytes: 0 };
          return;
        }
        const index = blockIndex++;
        emit("content_block_start", { type: "content_block_start", index, content_block: { type: "text", text: "" } });
        open = { kind, index };
      };
      const finish = (stopReason: string, usage: unknown) => {
        if (terminated) return;
        terminated = true;
        ensureStarted();
        closeOpenBlock();
        emit("message_delta", {
          type: "message_delta",
          delta: { stop_reason: stopReason, stop_sequence: null },
          usage: anthropicUsage(usage, webSearchRequests),
        });
        emit("message_stop", { type: "message_stop" });
        terminalDelivered = true;
      };
      // upstreamDerived: transient upstream statuses become overloaded_error so the
      // Anthropic-SDK client retries with backoff; proxy-internal exceptions stay
      // api_error — a deterministic ocx bug must not be masked as retryable
      // (devlog/_plan/260716_claudecode_hardening/020). On win32 mid-stream socket
      // resets reach the reader catch (no failed-tail relay) and stay api_error —
      // same as today, deliberate residual.
      const fail = (status: number, message: string, upstreamDerived = false, code?: string) => {
        // finish/fail sets terminated before closeOpenBlock. A closure-time
        // allocation failure must still emit one error, without retrying closure.
        if (terminated && (code !== "translation_buffer_limit" || terminalDelivered)) return;
        terminated = true;
        if (code === "translation_buffer_limit") {
          releaseThinkingBuffer(open);
          if (open?.callId) translatorBudget.closeCall(open.callId);
          open = null;
          terminalDelivered = true;
          // No normal close frames are valid after overflow. Emit exactly one bounded
          // typed terminal without consulting the exhausted budget.
          controller.enqueue(encoder.encode(sseFrame("error", anthropicErrorBody(
            413,
            message,
            "request_too_large",
            "translation_buffer_limit",
          ))));
          return;
        }
        const type = upstreamDerived && isTransientUpstreamStatus(status) ? "overloaded_error" : undefined;
        if (!started) {
          // An initial upstream failure is an Anthropic error stream, not a partial message.
          // Do not manufacture message_start before the terminal error. Earlier transport-only
          // pings remain valid and do not turn the failure into a partial message.
          emit("error", anthropicErrorBody(status, message, type, code));
          terminalDelivered = true;
          return;
        }
        closeOpenBlock();
        emit("error", anthropicErrorBody(status, message, type, code));
        terminalDelivered = true;
      };

      let progressMirrorId: string | undefined;
      const handleFrame = (eventName: string, data: Rec) => {
        const frameItem = isRec(data.item) ? data.item : null;
        if (progressMirrorId && (data.item_id === progressMirrorId || frameItem?.id === progressMirrorId)) {
          if (eventName === "response.output_item.done") progressMirrorId = undefined;
          return;
        }
        switch (eventName) {
          case "response.created":
          case "response.in_progress": {
            // Lifecycle preludes do not start Anthropic framing, but some upstreams attach
            // confirmed input usage before semantic output. Retain only its bounded Anthropic
            // projection so message_start can report measurements that already arrived.
            const response = isRec(data.response) ? data.response : {};
            const usage = isRec(response.usage) ? response.usage : undefined;
            if (!started && usage && typeof usage.input_tokens === "number") {
              earlyAnthropicUsage = anthropicUsage(usage);
            }
            break;
          }
          case "response.heartbeat":
            if ((controller.desiredSize ?? 0) > 0) emit("ping", { type: "ping" });
            break;
          case "response.output_text.delta": {
            if (typeof data.delta !== "string" || data.delta.length === 0) break;
            ensureBlock("text");
            const active = open;
            if (!active || active.kind !== "text") break;
            emit("content_block_delta", {
              type: "content_block_delta", index: active.index,
              delta: { type: "text_delta", text: data.delta },
            });
            break;
          }
          case "response.reasoning_summary_text.delta":
          case "response.reasoning_text.delta": {
            if (typeof data.delta !== "string" || data.delta.length === 0) break;
            const itemKey = boundedReasoningIdentity(data.item_id);
            if (open?.kind === "thinking" && open.reasoningItemKey !== itemKey) closeOpenBlock();
            ensureBlock("thinking");
            const active = open;
            if (!active || active.kind !== "thinking") break;
            // The JSON path joins reasoning summary/content parts with "\n\n"
            // (responsesJsonToAnthropicMessage); mirror that at part boundaries
            // so multi-part summaries do not glue into one run-on paragraph. Frames
            // without part indices produce a constant key and never get a separator.
            const slot = eventName === "response.reasoning_summary_text.delta"
              ? `s${boundedReasoningIdentity(data.summary_index)}`
              : `c${boundedReasoningIdentity(data.content_index)}`;
            // Upstream string metadata can be arbitrarily large. Hash strings into fixed-size
            // components while retaining item and part equality, rather than dropping item_id and
            // accidentally joining distinct malformed reasoning items.
            const partKey = `${itemKey}:${slot}`;
            const needsPartSeparator = active.reasoningPartKey !== undefined
              && active.reasoningPartKey !== partKey;
            const appended = `${needsPartSeparator ? "\n\n" : ""}${data.delta}`;
            const previous = active.thinkingBuf ?? "";
            const previousBytes = active.thinkingBufBytes ?? 0;
            const nextBytes = appendedUtf8Bytes(previous, previousBytes, appended);
            const scope = { kind: "reasoning" } as const;
            const reservation = translatorBudget.reserveTransient(nextBytes, scope);
            try {
              active.thinkingBuf = previous + appended;
              active.thinkingBufBytes = nextBytes;
              reservation.commitRetained();
              translatorBudget.releaseRetained(previousBytes, scope);
            } catch (error) {
              reservation.release();
              throw error;
            }
            active.reasoningItemKey = itemKey;
            active.reasoningPartKey = partKey;
            break;
          }
          case "response.output_item.added": {
            const item = isRec(data.item) ? data.item : null;
            if (!item || item.type !== "function_call") break;
            ensureStarted();
            closeOpenBlock();
            sawToolUse = true;
            const index = blockIndex++;
            const name = typeof item.name === "string" ? item.name : "";
            const bufferWebSearchArgs = isClaudeWebSearchToolName(name);
            const callId = typeof item.call_id === "string" ? item.call_id : `toolu_${uuid()}`;
            emit("content_block_start", {
              type: "content_block_start", index,
              content_block: {
                type: "tool_use",
                id: callId,
                name,
                input: {},
              },
            });
            translatorBudget.openCall(callId);
            open = {
              kind: "tool_use",
              index,
              callId,
              itemId: typeof item.id === "string" ? item.id : undefined,
              bufferWebSearchArgs,
              argsBuf: "",
              argsBufBytes: 0,
              webSearchArgsEmitted: false,
              toolArgsEmitted: false,
            };
            break;
          }
          case "response.function_call_arguments.delta": {
            if (typeof data.delta !== "string" || data.delta.length === 0) break;
            if (!open || open.kind !== "tool_use") break;
            if (open.bufferWebSearchArgs) {
              const previous = open.argsBuf ?? "";
              const previousBytes = open.argsBufBytes ?? 0;
              const nextBytes = appendedUtf8Bytes(previous, previousBytes, data.delta);
              const scope = {
                kind: "tool_args",
                ...(open.callId ? { callId: open.callId } : {}),
              } as const;
              const reservation = translatorBudget.reserveTransient(nextBytes, scope);
              try {
                open.argsBuf = previous + data.delta;
                open.argsBufBytes = nextBytes;
                reservation.commitRetained();
                translatorBudget.releaseRetained(previousBytes, scope);
              } catch (error) {
                reservation.release();
                throw error;
              }
              break;
            }
            emit("content_block_delta", {
              type: "content_block_delta", index: open.index,
              delta: { type: "input_json_delta", partial_json: data.delta },
            });
            open.toolArgsEmitted = true;
            break;
          }
          case "response.function_call_arguments.done": {
            if (!open || open.kind !== "tool_use" || open.bufferWebSearchArgs || open.toolArgsEmitted) break;
            if (typeof data.arguments !== "string" || data.arguments.length === 0) break;
            emit("content_block_delta", { type: "content_block_delta", index: open.index, delta: { type: "input_json_delta", partial_json: data.arguments } });
            open.toolArgsEmitted = true;
            break;
          }
          case "response.output_item.done": {
            const item = isRec(data.item) ? data.item : null;
            if (!item) break;
            // Server-side web search (native passthrough or sidecar bridge): translate the
            // finished call into the Anthropic pair Claude Code natively parses —
            // server_tool_use (query via input_json_delta) + web_search_tool_result.
            // Never marks sawToolUse (stop_reason stays end_turn unless a real tool ran).
            if (item.type === "web_search_call") {
              ensureStarted();
              closeOpenBlock();
              const pair = webSearchPairFromItem(item);
              const toolIndex = blockIndex++;
              emit("content_block_start", {
                type: "content_block_start", index: toolIndex,
                content_block: { type: "server_tool_use", id: pair.id, name: pair.name },
              });
              emit("content_block_delta", {
                type: "content_block_delta", index: toolIndex,
                delta: { type: "input_json_delta", partial_json: JSON.stringify(pair.input) },
              });
              emit("content_block_stop", { type: "content_block_stop", index: toolIndex });
              const resultIndex = blockIndex++;
              emit("content_block_start", {
                type: "content_block_start", index: resultIndex,
                content_block: { type: pair.resultType, tool_use_id: pair.id, content: pair.resultContent },
              });
              emit("content_block_stop", { type: "content_block_stop", index: resultIndex });
              if (pair.completed && pair.name === "web_search") webSearchRequests++;
              break;
            }
            // Close the matching open block (message/reasoning items close implicitly on
            // the next block; function_call items must close here so tool input parses).
            if (open && open.kind === "tool_use" && item.type === "function_call") {
              if (open.bufferWebSearchArgs && !open.webSearchArgsEmitted) {
                const rawArgs = typeof item.arguments === "string" && item.arguments.length > 0
                  ? item.arguments
                  : (open.argsBuf ?? "");
                let parsed: unknown = {};
                try { parsed = rawArgs.length > 0 ? JSON.parse(rawArgs) : {}; } catch { parsed = {}; }
                emit("content_block_delta", {
                  type: "content_block_delta",
                  index: open.index,
                  delta: { type: "input_json_delta", partial_json: JSON.stringify(sanitizeWebSearchInput(parsed)) },
                });
                open.webSearchArgsEmitted = true;
              } else if (!open.bufferWebSearchArgs && !open.toolArgsEmitted
                && typeof item.arguments === "string" && item.arguments.length > 0) {
                emit("content_block_delta", {
                  type: "content_block_delta", index: open.index,
                  delta: { type: "input_json_delta", partial_json: item.arguments },
                });
                open.toolArgsEmitted = true;
              }
              closeOpenBlock();
            }
            else if (open && open.kind === "text" && item.type === "message") closeOpenBlock();
            else if (item.type === "reasoning") {
              const encrypted = typeof item.encrypted_content === "string" ? item.encrypted_content : "";
              const env = encrypted ? decodeReasoningEnvelope(encrypted, translatorBudget) : null;
              const red = env?.red ?? [];
              const itemKey = boundedReasoningIdentity(item.id);
              // A late/unrelated done cannot reorder or sign another item's text.
              if (open?.kind === "thinking" && open.reasoningItemKey !== itemKey) {
                closeOpenBlock();
              }
              if (red.length > 0) {
                ensureStarted();
                if (open?.kind !== "thinking") closeOpenBlock();
              }
              for (const data of red) {
                const idx = blockIndex++;
                emit("content_block_start", { type: "content_block_start", index: idx, content_block: { type: "redacted_thinking", data } });
                emit("content_block_stop", { type: "content_block_stop", index: idx });
              }
              // A provider's own blob is the only copy of its reasoning the client can hold, so
              // it gets a thinking block even when no summary text arrived.
              const native = nativeEncryptedReasoning(encrypted);
              if ((env?.sig || native) && open?.kind !== "thinking") {
                ensureBlock("thinking");
              }
              if (open?.kind === "thinking") {
                if (env?.upd && typeof env.txt === "string") {
                  // This plaintext was deliberately surfaced as commentary, unlike hidden reasoning.
                  progressMirrorId = env.upd;
                  const bytes = Buffer.byteLength(env.txt);
                  translatorBudget.chargeRetained(bytes, { kind: "reasoning" });
                  translatorBudget.releaseRetained(open.thinkingBufBytes ?? 0, { kind: "reasoning" });
                  open.thinkingBuf = env.txt;
                  open.thinkingBufBytes = bytes;
                }
                if (env?.sig) open.reasoningSig = env.sig;
                if (native) open.reasoningNative = typeof item.id === "string" && item.id.length > 0 ? { enc: native, id: item.id } : { enc: native };
                closeOpenBlock();
              }
            }
            break;
          }
          case "response.completed": {
            const response = isRec(data.response) ? data.response : {};
            if (response.end_turn === false && !sawToolUse) {
              fail(529, "upstream turn ended without a final answer", true);
              break;
            }
            finish(sawToolUse ? "tool_use" : "end_turn", response.usage);
            break;
          }
          case "response.incomplete": {
            const response = isRec(data.response) ? data.response : {};
            const details = isRec(response.incomplete_details) ? response.incomplete_details : {};
            const outcome = anthropicIncompleteOutcome(details.reason, details.message);
            if ("stopReason" in outcome) finish(outcome.stopReason, response.usage);
            else fail(529, outcome.failMessage, true);
            break;
          }
          case "response.failed": {
            const response = isRec(data.response) ? data.response : {};
            const error = isRec(response.error) ? response.error : {};
            const message = typeof error.message === "string" ? error.message : "upstream request failed";
            const code = typeof error.code === "string" ? error.code : undefined;
            if (code === "translation_buffer_limit") {
              throw new TranslatorBudgetExceededError("live_transient", TRANSLATOR_MAX_TURN_BYTES);
            }
            const status = anthropicFailedStatus(error, message);
            // Unclassified status-absent response.failed (relaySseWithFailedTail synthetic
            // tail) still lands on a transient 5xx here — the mid-stream reset shape maps to
            // overloaded_error by design.
            // The undeclared-tool refusal is deterministic and proxy-owned, not an upstream
            // condition: keep its api_error type and code instead of a retryable overload.
            const deterministic = code === UNDECLARED_TOOL_CALL_ERROR_CODE;
            fail(
              status,
              message,
              !deterministic,
              deterministic ? code : isContextOverflowError(error, message) ? "context_length_exceeded" : undefined,
            );
            break;
          }
          default:
            break; // web_search_call / custom_tool_call / content_part frames: ignored v1
        }
      };

      reader = upstream.getReader();
      void (async () => {
        try {
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            const decodedReservation = translatorBudget.reserveTransient(value.byteLength, { kind: "live_transient" });
            let decodedCommitted = false;
            try {
              const fragment = decoder.decode(value, { stream: true });
              decodedReservation.commitRetained();
              decodedCommitted = true;
              const nextBufferBytes = appendedUtf8Bytes(buffer, bufferBytes, fragment);
              const appendReservation = translatorBudget.reserveTransient(nextBufferBytes, { kind: "live_transient" });
              try {
                buffer += fragment;
                appendReservation.commitRetained();
                translatorBudget.releaseRetained(bufferBytes, { kind: "live_transient" });
                bufferBytes = nextBufferBytes;
              } catch (error) {
                appendReservation.release();
                throw error;
              }
              let sep: number;
              while ((sep = buffer.indexOf("\n\n")) !== -1) {
                const rawFrameBytes = utf8SliceBytes(buffer, 0, sep);
                const residualBytes = bufferBytes - rawFrameBytes - 2;
                const rawReservation = translatorBudget.reserveTransient(rawFrameBytes, { kind: "live_transient" });
                let residualReservation: ReturnType<TranslatorBudget["reserveTransient"]> | undefined;
                try {
                  residualReservation = translatorBudget.reserveTransient(residualBytes, { kind: "live_transient" });
                  const rawFrame = buffer.slice(0, sep);
                  const residual = buffer.slice(sep + 2);
                  rawReservation.commitRetained();
                  residualReservation.commitRetained();
                  residualReservation = undefined;
                  buffer = residual;
                  translatorBudget.releaseRetained(bufferBytes, { kind: "live_transient" });
                  bufferBytes = residualBytes;
                  try {
                    let eventName = "";
                    let dataLine = "";
                    let dataLineBytes = 0;
                    try {
                      let lineStart = 0;
                      while (lineStart <= rawFrame.length) {
                        const newline = rawFrame.indexOf("\n", lineStart);
                        const lineEnd = newline === -1 ? rawFrame.length : newline;
                        // The space after the colon is optional in text/event-stream (#1170);
                        // compute the value offset the same way sseFieldValue does, without
                        // slicing the line first — the byte accounting below is keyed to
                        // offsets into rawFrame.
                        const eventOffset = sseFieldOffset(rawFrame, lineStart, lineEnd, "event");
                        const dataOffset = sseFieldOffset(rawFrame, lineStart, lineEnd, "data");
                        if (eventOffset !== -1) {
                          eventName = rawFrame.slice(eventOffset, lineEnd).trim();
                        } else if (dataOffset !== -1) {
                          const fragmentStart = dataOffset;
                          const fragmentBytes = utf8SliceBytes(rawFrame, fragmentStart, lineEnd);
                          const fragmentReservation = translatorBudget.reserveTransient(fragmentBytes, { kind: "live_transient" });
                          let fragmentCommitted = false;
                          try {
                            const fragment = rawFrame.slice(fragmentStart, lineEnd);
                            fragmentReservation.commitRetained();
                            fragmentCommitted = true;
                            const nextDataLineBytes = appendedUtf8Bytes(dataLine, dataLineBytes, fragment);
                            const dataReservation = translatorBudget.reserveTransient(nextDataLineBytes, { kind: "live_transient" });
                            try {
                              dataLine += fragment;
                              dataReservation.commitRetained();
                              translatorBudget.releaseRetained(dataLineBytes, { kind: "live_transient" });
                              dataLineBytes = nextDataLineBytes;
                            } catch (error) {
                              dataReservation.release();
                              throw error;
                            }
                          } finally {
                            if (fragmentCommitted) {
                              translatorBudget.releaseRetained(fragmentBytes, { kind: "live_transient" });
                            } else fragmentReservation.release();
                          }
                        }
                        if (newline === -1) break;
                        lineStart = newline + 1;
                      }
                      if (!dataLine) continue;
                      let data: unknown;
                      try { data = JSON.parse(dataLine); } catch { continue; }
                      if (!isRec(data)) continue;
                      // Responses-compatible gateways may omit the optional SSE event field
                      // while retaining the event name in the JSON payload's required type.
                      const resolvedEventName = eventName || (typeof data.type === "string" ? data.type : "");
                      if (!resolvedEventName || terminated) continue;
                      handleFrame(resolvedEventName, data);
                    } finally {
                      translatorBudget.releaseRetained(dataLineBytes, { kind: "live_transient" });
                    }
                  } finally {
                    translatorBudget.releaseRetained(rawFrameBytes, { kind: "live_transient" });
                  }
                } catch (error) {
                  rawReservation.release();
                  residualReservation?.release();
                  throw error;
                }
              }
            } finally {
              if (decodedCommitted) translatorBudget.releaseRetained(value.byteLength, { kind: "live_transient" });
              else decodedReservation.release();
            }
          }
          // EOF without a terminal frame is a TRUNCATION, not success (devlog 100:
          // gateways that close such streams politely hand Claude Code an empty/partial
          // turn with no retryable error — CLIProxyAPI#2189 failure pattern). Fail closed
          // with a mid-stream Anthropic error event so the client can retry.
          if (!cancelled) fail(502, "upstream stream ended before a terminal frame (truncated response)", true);
        } catch (err) {
          if (isTranslatorBudgetExceededError(err)) {
            try { await reader.cancel(err); } catch { /* already closed */ }
            fail(413, "upstream translation buffer exceeded the safe limit", false, "translation_buffer_limit");
          } else fail(500, err instanceof Error ? err.message : String(err));
        } finally {
          releaseThinkingBuffer(open);
          translatorBudget.releaseRetained(bufferBytes, { kind: "live_transient" });
          if (pingTimer !== undefined) clearInterval(pingTimer);
          reader.releaseLock();
          if (!cancelled) controller.close();
        }
      })();
    },
    pull() {
      releaseDeliveredFrame();
    },
    cancel(reason) {
      cancelled = true;
      while (queuedLiveFrameBytes.length > 0) releaseDeliveredFrame();
      releaseThinkingBuffer(open);
      if (open?.callId) translatorBudget.closeCall(open.callId);
      if (pingTimer !== undefined) clearInterval(pingTimer);
      return reader?.cancel(reason);
    },
  });
}

/** Non-streaming: /v1/responses JSON -> Anthropic message JSON. */
export function responsesJsonToAnthropicMessage(json: unknown, model: string, translatorBudget?: TranslatorBudget, nativeReasoningTagFor?: (blob: string) => string | undefined): Rec {
  const body = isRec(json) ? json : {};
  const output = Array.isArray(body.output) ? body.output : [];
  const content: Rec[] = [];
  let sawToolUse = false;
  let webSearchRequests = 0;

  for (const [index, raw] of output.entries()) {
    if (index > 0 && isAnthropicProgressMirror(raw, anthropicProgressEnvelope(output[index - 1], translatorBudget))) continue;
    if (!isRec(raw)) continue;
    switch (raw.type) {
      case "message": {
        if (!Array.isArray(raw.content)) break;
        for (const part of raw.content) {
          if (isRec(part) && part.type === "output_text" && typeof part.text === "string" && part.text.length > 0) {
            content.push({ type: "text", text: part.text });
          }
        }
        break;
      }
      case "reasoning": {
        const parts: string[] = [];
        if (Array.isArray(raw.summary)) {
          for (const s of raw.summary) {
            if (isRec(s) && typeof s.text === "string" && s.text.length > 0) parts.push(s.text);
          }
        }
        if (Array.isArray(raw.content)) {
          for (const s of raw.content) {
            if (isRec(s) && typeof s.text === "string" && s.text.length > 0) parts.push(s.text);
          }
        }
        const encrypted = typeof raw.encrypted_content === "string" ? raw.encrypted_content : "";
        const env = encrypted ? decodeReasoningEnvelope(encrypted, translatorBudget) : null;
        // Legacy combined envelopes place redacted blocks before the signed block,
        // matching the Anthropic adapter. New bridge output uses separate items.
        for (const data of env?.red ?? []) content.push({ type: "redacted_thinking", data });
        // env.txt may be locally hidden text. Do not expose it here. A provider's own blob is
        // carried in the envelope so the next request can hand it back (see inbound.ts).
        const native = nativeEncryptedReasoning(encrypted);
        const tag = native && nativeReasoningTagFor?.(native);
        if (parts.length > 0 || env?.sig || tag) {
          const text = env?.upd ? env.txt! : parts.join("\n\n");
          const nat = tag ? { enc: native, model, tag, ...(typeof raw.id === "string" && raw.id.length > 0 ? { id: raw.id } : {}) } : undefined;
          content.push({ type: "thinking", thinking: text, signature: env?.sig ?? encodeReasoningEnvelope({ txt: text, ...(nat ? { nat } : {}) }, translatorBudget) });
        }
        break;
      }
      case "function_call": {
        sawToolUse = true;
        let input: unknown = {};
        if (typeof raw.arguments === "string" && raw.arguments.length > 0) {
          try { input = JSON.parse(raw.arguments); } catch { input = {}; }
        }
        const name = typeof raw.name === "string" ? raw.name : "";
        content.push({
          type: "tool_use",
          id: typeof raw.call_id === "string" ? raw.call_id : `toolu_${uuid()}`,
          name,
          input: isClaudeWebSearchToolName(name) ? sanitizeWebSearchInput(input) : input,
        });
        break;
      }
      case "web_search_call": {
        // Server-side search: emit the Anthropic pair. Does NOT set sawToolUse.
        const pair = webSearchPairFromItem(raw);
        content.push({ type: "server_tool_use", id: pair.id, name: pair.name, input: pair.input });
        content.push({ type: pair.resultType, tool_use_id: pair.id, content: pair.resultContent });
        if (pair.completed && pair.name === "web_search") webSearchRequests++;
        break;
      }
      default:
        break;
    }
  }

  const details = isRec(body.incomplete_details) ? body.incomplete_details : {};
  if (body.status === "incomplete"
    && details.reason !== "max_output_tokens"
    && details.reason !== "content_filter") {
    const message = typeof details.message === "string" && details.message.trim()
      ? details.message
      : `upstream response was incomplete${typeof details.reason === "string" ? ` (${details.reason})` : ""}`;
    return anthropicErrorBody(529, message, "overloaded_error");
  }
  if (body.status === "completed" && body.end_turn === false && !sawToolUse) {
    return anthropicErrorBody(529, "upstream turn ended without a final answer", "overloaded_error");
  }
  const stopReason = body.status === "incomplete" && details.reason === "max_output_tokens"
    ? "max_tokens"
    : body.status === "incomplete" && details.reason === "content_filter"
      ? "refusal"
    : sawToolUse ? "tool_use" : "end_turn";

  return {
    id: `msg_${uuid()}`,
    type: "message",
    role: "assistant",
    content,
    model,
    stop_reason: stopReason,
    stop_sequence: null,
    usage: anthropicUsage(body.usage, webSearchRequests),
  };
}

/**
 * Fold an Anthropic SSE stream (our own emission vocabulary) into a message JSON.
 * Used for non-streaming client requests: the internal replay always streams
 * (routed adapters do not support non-stream turns), so the translated stream is
 * aggregated here instead of translating a JSON body.
 */
export async function collectAnthropicMessage(
  stream: ReadableStream<Uint8Array>,
  model: string,
  translatorBudget: TranslatorBudget,
): Promise<Rec> {
  const decoder = new TextDecoder();
  const reader = stream.getReader();
  let buffer = "";
  const content: Rec[] = [];
  let openBlock: Rec | null = null;
  let toolJson = "";
  let stopReason: string | null = "end_turn";
  let usage: Rec = anthropicUsage(undefined);
  let error: Rec | null = null;
  const replaceRetained = (previous: string, next: string, kind: "live_transient" | "retained_collectors") => {
    const reservation = translatorBudget.reserveTransient(Buffer.byteLength(next), { kind });
    reservation.commitRetained();
    translatorBudget.releaseRetained(Buffer.byteLength(previous), { kind });
    return next;
  };

  const closeBlock = () => {
    if (!openBlock) return;
    // server_tool_use streams its query via input_json_delta exactly like tool_use (audit F3).
    if (openBlock.type === "tool_use" || openBlock.type === "server_tool_use") {
      try { openBlock.input = toolJson.length > 0 ? JSON.parse(toolJson) : {}; } catch { openBlock.input = {}; }
    }
    translatorBudget.chargeRetained(Buffer.byteLength(JSON.stringify(openBlock)), { kind: "retained_collectors" });
    content.push(openBlock);
    openBlock = null;
    toolJson = "";
  };

  const handle = (name: string, data: Rec) => {
    switch (name) {
      case "content_block_start":
        closeBlock();
        if (isRec(data.content_block)) openBlock = { ...data.content_block };
        break;
      case "content_block_delta": {
        const delta = isRec(data.delta) ? data.delta : {};
        if (!openBlock) break;
        if (delta.type === "text_delta" && typeof delta.text === "string") {
          const previous = typeof openBlock.text === "string" ? openBlock.text : "";
          openBlock.text = replaceRetained(previous, previous + delta.text, "retained_collectors");
        } else if (delta.type === "thinking_delta" && typeof delta.thinking === "string") {
          const previous = typeof openBlock.thinking === "string" ? openBlock.thinking : "";
          openBlock.thinking = replaceRetained(previous, previous + delta.thinking, "retained_collectors");
        } else if (delta.type === "signature_delta" && typeof delta.signature === "string") {
          openBlock.signature = delta.signature;
        } else if (delta.type === "input_json_delta" && typeof delta.partial_json === "string") {
          toolJson = replaceRetained(toolJson, toolJson + delta.partial_json, "retained_collectors");
        }
        break;
      }
      case "content_block_stop":
        closeBlock();
        break;
      case "message_delta": {
        const delta = isRec(data.delta) ? data.delta : {};
        if (typeof delta.stop_reason === "string") stopReason = delta.stop_reason;
        if (isRec(data.usage)) usage = data.usage;
        break;
      }
      case "error":
        error = data;
        break;
      default:
        break;
    }
  };

  const drainFrames = () => {
    let sep: number;
    while ((sep = buffer.indexOf("\n\n")) !== -1) {
        const rawFrame = buffer.slice(0, sep);
        buffer = replaceRetained(buffer, buffer.slice(sep + 2), "live_transient");
        // Event name and data as SSE dispatches them: the last event field, untrimmed, and the
        // data fields joined by newlines.
        let eventName = "";
        const dataLines: string[] = [];
        for (const line of rawFrame.split("\n")) {
          const eventValue = sseFieldValue(line, "event");
          if (eventValue !== null) { eventName = eventValue; continue; }
          const dataValue = sseFieldValue(line, "data");
          if (dataValue !== null) dataLines.push(dataValue);
        }
        const dataLine = dataLines.join("\n");
        if (!dataLine) continue;
        let data: unknown;
        try { data = JSON.parse(dataLine); } catch { continue; }
        if (!isRec(data)) continue;
        // A data-only frame is named by its payload type, the same rule the stream tap applies.
        const name = eventName || (typeof data.type === "string" ? data.type : "");
        if (name) handle(name, data);
    }
  };

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      // Frame on LF only after normalizing CRLF/CR line endings, holding a trailing CR until the
      // next chunk shows whether its LF follows, so a CRLF stream folds like an LF one.
      const incoming = buffer + decoder.decode(value, { stream: true });
      const heldCr = incoming.endsWith("\r");
      const normalized = (heldCr ? incoming.slice(0, -1) : incoming).replace(/\r\n?/g, "\n") + (heldCr ? "\r" : "");
      buffer = replaceRetained(buffer, normalized, "live_transient");
      drainFrames();
    }
    // At EOF a held CR is a line ending: it can complete the final frame.
    if (buffer.endsWith("\r")) {
      buffer = replaceRetained(buffer, buffer.slice(0, -1) + "\n", "live_transient");
      drainFrames();
    }
  } finally {
    reader.releaseLock();
  }
  // Error is authoritative. In particular, do not allocate another copy of an
  // unfinished thinking block after the translator reported closure overflow.
  if (error) return error;
  closeBlock();
  return {
    id: `msg_${uuid()}`,
    type: "message",
    role: "assistant",
    content,
    model,
    stop_reason: stopReason,
    stop_sequence: null,
    usage,
  };
}
