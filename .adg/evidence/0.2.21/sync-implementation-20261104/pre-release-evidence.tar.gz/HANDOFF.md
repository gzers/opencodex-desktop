# POST04 后端最终交接（0.2.21）

TASK-OPENCODEX-UI021-SYNC-20261104 / AC-021-03。产品源码已稳定；交接后不再修改生产逻辑或追加全量。整版最终 Cargo/CI、第三轮独立复核、实际客户端/原生和发布由主线接续。当前通过的是下列有界后端检查，不宣称整版关闭。本 worker 未执行 git add / commit / push；共享工作区其它提交和 UI、版本号修改由主线负责。

代码根 /Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes；分支 codex/0.2.21-fixes。最终编译版本0.2.21。精确 HEAD、源码 sha256 和版本文件摘要见 source-final.json。

## 源清单

以下路径相对 apps/desktop/tauri/src/：

- modules/model_config/content_versions.rs：规范化原子摘要、保存版本、timeKind、trustedFloor、摘要匹配读取、原时间继承、幂等版本写入。
- modules/model_config/file_save_versions.rs（新增）：渠道文件保存 admission、读回时冻结原事件、条件认证、读/保存入口恢复。
- modules/model_config/owner_save_versions.rs（新增）：偏好/模板/扩展共用 write-ahead 回执及原时间重放。
- modules/model_config/file_objects.rs：便携 contentVersions、同范围内容/时间及凭据投影、范围外保留、接收继承；不使用 mtime。
- modules/model_config/config_remote.rs、sync_state.rs：解密四态、检查观察、prepare/confirm两端版本/范围/指针重验；无基线/双改不固定 remote。
- modules/model_config/store.rs、modules/preferences/mod.rs、modules/extensions/projection.rs：owner回执、读回认证、读取恢复、明确版本待恢复错误态。
- commands/model_transfer.rs：当前/旧口令读取，不用 bare package.createdAt给接收端盖时间。
- modules/model_config/file_objects_file_tests.rs、sync_version_tests.rs（新增）、sync_test_credentials.rs（新增）：真实临时文件/事务/传输、竞态/回拨/崩溃、进程内凭据。

经用户后续明确分配的协作修改：modules/model_config/config_file.rs 仅保存版本接线（snapshot/save/恢复 admission、save/save_with_context外围、原读回callback冻结事件；改名事务核心仍归rename worker）；commands/extensions.rs只加ProjectionError::VersionPending映射一臂。未改commands/sync.rs、modules/sync/config.rs或UI；未修改config_file_mapping/provider_auth/agent/execution_directory/protocol_groups实现。主线已将命令接到save_with_context。

## 接口

config_sync_check参数不变，camelCase返回：

~~~ts
interface SyncCheck {
  source: 'local' | 'remote' | 'unchanged' | 'undetermined'
  reason: string
  hasRemote: boolean
  localSavedAt: string | null
  remoteSavedAt: string | null
  lastSyncedAt?: string
}
~~~

reason：both_empty、no_remote、same_content、remote_selection_empty、local_selection_empty、local_saved_later、remote_saved_later、same_instant_different_content、unreliable_save_time。

只有local/remote才准备传输，unchanged无需业务写，undetermined后端拒写。连接/范围/本机版本/远端指针漂移返回sync_preview_changed / sync_source_changed / sync_scope_changed / remote_changed，需重查/重预览。sync_direction_changed表示方向已改变；prepare不能默默替换检查时云端指针。

capture_save(root,&Scope)->SaveState及record_save(root,&before,&after)继续存在，但它们自身不是通用owner事务入口。渠道真实保存已内置file_saves::begin -> 核心读回acknowledge(root,home,event,snapshot,raw) -> finish，主线不要在命令层重复盖时间。transfer仍走不产生新时间的save_observed_checked，之后只继承实际采用的来源版本。

WebDAV非秘密端点：file_objects::webdav_save_state；密码：webdav_password_save_state接受endpoint_id -> content_versions::key(&password_str)本地摘要，安全存储写入且读回成功后才能认证。密码不进IPC/journal，credential.updated_at/观察revision不是保存时间。commands/sync.rs最终接线由主线负责，不在本交接冒称已验。

## 实际锁序及恢复

1. 渠道：saved-file-save-pending admission（同线程可重入、跨进程互斥）先于rename admission，再到config.json/layout/原改名关联文件锁。begin按请求有效目标捕获：单渠道只该ID；全页实际变化/明确凭据编辑；新ID before可为空。global只读公共状态，无关渠道凭据不读。
2. 业务读回callback在事务仍可回滚时，从已读回raw+Snapshot冻结after（含选中凭据复合摘要）及原时间并持久化。不存在after=None等恢复再补未来值。rename只有callback成功才标记committed并清理旧凭据。
3. 核心锁释放后仍持file admission：snapshot/ModelStore/凭据核验在version锁外。versions锁内只校验有界raw/layout字节摘要，不调用snapshot、ModelStore或安全存储。之后再核对业务和冻结凭据，版本文件准确读回后才清pending。
4. 模板：ModelStore事务锁 -> templates回执锁 -> versions。偏好：preferences文件锁 -> preferences回执锁 -> versions。扩展写：原config锁 -> extensions回执锁 -> versions。只读恢复可直接回执锁 -> versions，绝不反向请求owner锁。version内CAS均只读有界字节摘要。
5. owner_saves::begin在实际保存中冻结before/after、目标字节摘要及保存操作时间；回执guard保持至写/读回/认证，读取不能删在写事件。失败补偿或当前字节不等于原after时不认证。重放只用原时间，不调用now。

file事件在snapshot/save/source_state前恢复。owner事件在PreferencesStore读/保存、ModelStore读/保存、扩展严格读/保存及相应同步源读取恢复。noop不刷新未知legacy；丢回执重放不增加revision/时间。回拨保留ClockUnreliable及trustedFloor，未严格越过上次可信下限不能恢复Saved。

业务已落盘而版本锁失败：渠道/模板返回saved_content_version_unconfirmed，偏好PreferencesError::VersionPending，扩展ProjectionError::VersionPending，提示“配置已保存，原保存版本回执待恢复，请重新读取核对”；不伪完全成功、不回滚已完成改名。解除竞争后用原摘要/时间重放。K1读回后崩溃、同引用外部变K2，恢复只核验原摘要，K2不匹配保持unknown，不认证为Saved(t0)。不可便携未来字段/未解析引用不放宽导出校验，不阻断原有效保存，也不获得伪造认证。

## 反例及最终检查

修前保留review-counterexamples-before.log（回拨/锁失败恢复/凭据子集）、review-race-counterexample-before.log（A末次check后B真正提交的竞态）、review-second-round-before.log（K1/K2与owner失败）、review-lock-order-counterexample-before.log（旧version->snapshot与真实新增模板形成交错超时）。首版模板夹具未产生新内容，后明确修正并复现旧锁反序，未拿无效夹具当证明。

集合有重叠，不相加为覆盖总数：

| 日志 | 结果 |
| --- | --- |
| review-final-targeted.log | 审阅11/11；原问题、锁反序、K1/K2、真实退出86、三入口恢复、noop、丢回执、三owner版本锁竞争 |
| final-content-versions-tests.log | 12/12 |
| final-rename-receipt-tests.log | 2/2；真实改名进程退出/回滚/凭据失败 |
| final-lifecycle-tests.log | 10/10；真实保存/双端传输/继承/范围外/确认漂移 |
| final-preferences-tests.log | 12/12 |
| final-model-store-tests.log | 11/11 |
| final-extensions-tests.log | 39/39 |
| clippy-final-review-second.log | --lib --tests --features integration-test -- -D warnings通过 |

git diff --check通过，格式结果见result.json。未重复主线workspace全量；主线首轮结果不能替代本批新测试，最终整版仍需冻结源重跑。

新反例和最终传输测试使用tempfile、内存WebDAV、合成凭据/进程内credential builder。早期旧文件测试曾未强制替换系统安全存储适配器，不能据其声称从未访问钥匙串，不当最终隔离证明；未读取日常秘密追查。最终测试入口强制内存适配器，早期日志保留。

## 旧格式和实际使用限制（供REL）

- 新后端读Objects v1～3。缺contentVersions、旧本机记录缺timeKind、仅createdAt/legacy mtime均无可靠时间。新增scopeKey/contentDigest/revision/savedAt/timeKind及可选trustedFloor；必须匹配当前摘要/范围。
- 没有改成Objects v4。新包仍用v1～3编号、带可选contentVersions；0.2.20的deny_unknown_fields拒读带该字段的新包，不是双向兼容或静默忽略。参与同步/读取新包的客户端须升级，旧版本不能继续共同写新快照。
- 同内容仍unchanged；一端确实空按已确认新增规则。两侧非空且异内容，所选组合任一相关atom未知会使整体undetermined。
- 首次默认全选中的旧渠道/模板/Skill/MCP/账户可能未有新保存事件。升级、读取、打包、切范围、mtime、复制、无变化重新保存均不认证。真实内容变化且有保存钩子的成功事件，或可靠来源继承，才能有可信时间；未纳入真实钩子的外部资产也不自动变新。不能承诺“全升级自动取新”或“再按一次保存即可认证”。这是REL需披露的边界，没有用mtime补齐或扩大产品规则。

## 未完

分配后端实现、两轮阻断修复与定向证据已完成；无继续实施项。第三轮独立复核由主线跟进。最终workspace/CI、真实客户端/双平台原生、WebDAV endpoint/password事件集成核验、REL兼容说明及正式发布均归主线。本worker未提交/发布，不据局部绿灯关闭整版任务。


## 第三轮补记：R21-07 / R21-08（本节为最新冻结状态）

原冻结在第三轮收到两个新增P1后已解除；现已完成最小修复并重新稳定。新增源码仅4份：content_versions.rs、owner_save_versions.rs、file_save_versions.rs、sync_version_tests.rs，未改改名核心、UI或对外Check字段。精确摘要已刷新source-final.json，本轮机器结果见review3-result.json。

R21-07：真实10/30保存A、外部未记录修改B、11/4显式保存回A，按旧digest去重会错误保留10/30。改为每次真实保存独立UUID：owner回执持久id、文件回执沿用既有id，版本新增可选lastEvent。只有同事件且同摘要/时间才幂等；新B->A即使命中旧摘要也登记本次时间和revision。noop仍按本次before==after跳过，不认证未知旧内容。旧版本记录缺lastEvent继续可读；旧pending缺id在其回执锁内补一次UUID并持久化，不改变原时间/原摘要。transfer继承同内容不改时的规则保持。

R21-08：偏好真实变更已写入、版本锁超时，随后真实Agent渠道改名重写同一preferences文件，不应因整文件hash不同删除便携偏好回执。回执新增readbackVerified：只有原afterFile完整字节先精确读回才持久标记；已验证回执恢复时可按冻结可移植偏好SaveState核验，忽略Agent/非便携字段变化。后来便携偏好改变或只有未读回intent则不认证旧时间，当前内容保持unknown。该方案无需改channel_rename或预取PreferencesStore，避免新增跨owner锁序。

锁序保持owner->receipt->versions。版本锁内现在允许有界preferences字节解析与便携语义摘要比较，但不调用PreferencesStore、snapshot、ModelStore或安全存储，不反取任何owner锁。回执原UUID、原时间和原语义摘要在恢复时保持。afterFile仍是最初写入字节摘要，未用后来的Agent文档替换。

review3-counterexamples-before.log：2失败，分别确认旧A时间与Agent改名丢回执。review3-fixes-final.log：2通过；除本来两条反例，还覆盖同UUID重复重放/正常noop不动版本、真实上传云端11/1后本机新保存取胜、Agent-only保时、后来portable变化拒绝旧时间、未验证intent拒绝语义回退。review3-file-event-replay.log：既有丢文件回执反例1/1通过；clippy/格式/diff检查通过。旧11项绿灯日志保留，未重跑无关大套。

兼容说明仍是Objects v1～3携带contentVersions、无v4升版；lastEvent是该版本记录中的新增可选字段。缺timeKind/legacy/未知atom限制与0.2.20严格拒读新包的边界不变。主线继续独立复核、最终CI/原生和发布。本worker未git add/commit/push。
