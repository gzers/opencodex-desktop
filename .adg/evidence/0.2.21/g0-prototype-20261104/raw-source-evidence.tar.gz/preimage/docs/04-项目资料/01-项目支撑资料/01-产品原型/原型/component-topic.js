/* 非功能菜单 / 组件与样式。目录同源、连续正文；全部交互仅持有本页fixture。 */
(() => {
 'use strict';
 const catalog=window.PrototypeComponentCatalog,root=document.documentElement,page=document.getElementById('componentTopicPage');
 if(!page||!catalog)return;
 const $=(q,r=document)=>r.querySelector(q),$$=(q,r=document)=>[...r.querySelectorAll(q)],esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const button=(label,action,cls='',attrs='')=>'<button type="button" class="btn '+cls+'" data-ct="'+action+'" '+attrs+'>'+label+'</button>';
 const icon='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 3v14M3 10h14"/></svg>';
 const state={section:'brand',theme:'light',effects:'high',zoom:100,size:'fluid',long:false,pickerMode:'single',pickerScenario:'normal',pickerResult:null,nodeScene:'normal',nodeSelected:'primary',nodeResults:{},nodeRun:0,nodeRunning:false,window:{platform:'win11',focus:'active',material:'mica',close:'tray',visibility:'visible',maximized:false},tray:{os:'mac',state:'stopped',open:true,settings:{launchWithCodex:false,showMainWindow:true}},tab:'general',local:'empty',exampleSaved:'默认工作空间',exampleSavedOnce:false};
 const main=$('.main'),nav=document.createElement('nav');nav.className='component-side-nav';nav.setAttribute('aria-label','组件目录');$('.side').appendChild(nav);
 let entered=false,previous=null,returnRoute='settings',savedScroll=0,navQuery='',queued=false,topicDialog=false,nodePopup=null,nodeAnchor=null;
 let nodes=[{id:'primary',name:'默认节点',url:'https://primary.example.com/v1'},{id:'hk',name:'香港节点',url:'https://hk.example.com/v1'},{id:'us',name:'北美节点',url:'https://us.example.com/v1'}];
 const treeNodes=[{id:'config',label:'配置',depth:0},{id:'models',parent:'config',label:'模型配置',depth:1},{id:'channels',parent:'models',label:'渠道',depth:2},{id:'templates',parent:'models',label:'模型模版',depth:2},{id:'preferences',parent:'config',label:'偏好设置',depth:1}],collapsed=new Set();
 function annotation(id,title,body){return '<div class="ct-note-anchor"><div class="proto-annotation" id="ann-component-'+id+'" data-annotation-number="01" data-annotation-title="'+esc(title)+'" data-annotation-category="组件约定"><button type="button" class="annotation-marker" aria-expanded="false" aria-controls="annotationPopover" aria-label="原型注释：'+esc(title)+'"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 2.5h7l3 3v8H3zM10 2.5v3h3M5.5 8h5M5.5 10.5h3"/></svg><span>原型</span><span class="annotation-number">01</span><span class="annotation-marker-plus" aria-hidden="true">＋</span></button><div class="annotation-source" hidden><p>'+esc(body)+'</p><div class="annotation-footer">组件约定 · 0.2.0开发交接</div></div></div></div>';}
 function metadata(id){return '<details class="ct-meta"><summary>登记与采用状态 · '+catalog.entries(id).length+' 项</summary>'+catalog.entries(id).map(c=>'<div class="ct-meta-row" data-component-id="'+c.id+'"><strong>'+esc(c.name)+'<br><code>'+c.id+'</code></strong><div>所属 '+esc(c.layer)+' · '+esc(c.version)+'<br>规格：UI规范；原型：本节 · 正式：'+esc(c.layer==='brand'?'现有品牌素材目录（直接引用）':c.implementation||(c.id==='navigation.tree'?'公共组件探索 · 版本待定':'待0.2.0开发/平台适配'))+'<br>已登记 / 已有原型 · '+(c.layer==='brand'?'素材已存在；生产采用待逐平台核对':c.status.production?'正式文件存在（固定main基线）':'正式组件待实现')+' · 消费者采用待迁移核对 · 实屏待验</div></div>').join('')+'</details>';}
 function usage(section){
  const labels={existing:'已有规则',proposal:'方案约定',suggestion:'建议待确认'};
  return '<aside class="ct-usage" data-ct-usage="'+esc(section.id)+'" aria-labelledby="ctUsageTitle-'+esc(section.id)+'"><h4 id="ctUsageTitle-'+esc(section.id)+'">使用建议</h4><dl>'+section.usage.map(item=>'<div class="ct-usage-row" data-usage-status="'+item.status+'"><dt>'+esc(item.label)+'</dt><dd><span class="ct-usage-status '+item.status+'">'+labels[item.status]+'</span><span>'+esc(item.text)+'</span><a class="ct-usage-source" href="'+esc(item.source.href)+'" target="_blank" rel="noopener noreferrer" aria-label="'+esc(section.title+' · '+item.label+'依据：'+item.source.label)+'">'+esc(item.source.label)+' ↗</a></dd></div>').join('')+'</dl></aside>';
 }
 const assetRoot='../../../04-品牌与图标素材/';
 const asset=(path,label,size,cls='')=>'<img class="ct-brand-image '+cls+'" src="'+assetRoot+path+'" alt="'+esc(label)+'" width="'+size+'" height="'+size+'" loading="lazy">';
 const assetSizes=(path,label,sizes)=>'<div class="ct-icon-sizes">'+sizes.map(n=>'<figure>'+asset(path,label+' · '+n+'px',n)+'<figcaption>'+n+'px</figcaption></figure>').join('')+'</div>';
 const trayIconCanvas=(platform,dark)=>{const mac=platform==='macOS',path='03-平台交付/'+platform+'/Tray/'+(mac?(dark?'tray-white.svg':'tray-template.svg'):(dark?'tray-light.svg':'tray-dark.svg'));return '<div class="ct-brand-canvas '+(dark?'is-dark':'is-light')+'"><strong>'+platform+' · '+(dark?'深色背景':'浅色背景')+'</strong>'+assetSizes(path,platform+'托盘图标',mac?[16,18,24,32]:[16,20,24,32])+'</div>';};
/* 时间范围组件：状态与校验放在 renderers 之前，避免初始化时访问未声明变量 */
const HOUR=3600*1000,MAXSPAN=90*24*HOUR;
const trState={preset:'24h',from:'2026-11-01T00:00',to:'2026-11-02T00:00',zone:'local'};
const ctPad=n=>String(n).padStart(2,'0');
const toLocalInput=d=>d.getFullYear()+'-'+ctPad(d.getMonth()+1)+'-'+ctPad(d.getDate())+'T'+ctPad(d.getHours())+':'+ctPad(d.getMinutes());
const fmtLocal=s=>{const d=new Date(s);return isNaN(d)?'—':d.getFullYear()+'-'+ctPad(d.getMonth()+1)+'-'+ctPad(d.getDate())+' '+ctPad(d.getHours())+':'+ctPad(d.getMinutes())};
/* 自定义时间范围的玻璃面板：以浮层形式挂在页面里，不占排版空间；Esc 或点遮罩关闭，未应用即撤销 */
let trPanel=null,trDraft=null,trRestore=null;
/* ---------- 双月日历：点选起止日期，悬停预览候选区间 ---------- */
let trCalMonth=null,trPick=null,trHover=null;
const trYmd=d=>d.getFullYear()+'-'+ctPad(d.getMonth()+1)+'-'+ctPad(d.getDate());
const trDayKey=s=>{const d=trParse(s);return d?trYmd(d):''};
function calMonthHtml(base,side){
  const first=new Date(base.getFullYear(),base.getMonth(),1);
  const startPad=(first.getDay()+6)%7;/* 周一为一周第一天 */
  const days=new Date(base.getFullYear(),base.getMonth()+1,0).getDate();
  const from=trDayKey(trDraft.from),to=trDayKey(trDraft.to);
  const a=trPick?trPick:from,b2=trPick?null:to;
  const hoverRange=trPick&&trHover?[trPick,trHover].sort():null;
  let cells=[];
  for(let i=0;i<startPad;i++)cells.push('<span class="ct-cal-d is-empty"></span>');
  for(let d=1;d<=days;d++){
    const key=trYmd(new Date(base.getFullYear(),base.getMonth(),d));
    const isStart=key===(hoverRange?hoverRange[0]:a),isEnd=key===(hoverRange?hoverRange[1]:b2);
    const inRange=hoverRange?(key>hoverRange[0]&&key<hoverRange[1]):(b2&&key>a&&key<b2);
    const cls='ct-cal-d'+(isStart?' is-start':'')+(isEnd?' is-end':'')+(inRange?' is-in':'')+(key===from||key===to?' is-picked':'');
    cells.push('<button type="button" class="'+cls+'" data-ct="tr-day" data-day="'+key+'" aria-label="'+key+(isStart||isEnd?'（已选）':'')+'">'+d+'</button>')}
  /* 补齐 6 行：两列月份不同时行数也不同，补齐后高度一致 */
  while(cells.length<42)cells.push('<span class="ct-cal-d is-empty"></span>');
  return'<div class="ct-cal-m"><div class="ct-cal-h">'+
    '<button type="button" class="ct-tr-x ct-cal-nav" data-ct="tr-yprev" data-side="'+side+'" aria-label="'+side+' 上一年">«</button>'+
    '<button type="button" class="ct-tr-x ct-cal-nav" data-ct="tr-mprev" data-side="'+side+'" aria-label="'+side+' 上个月">‹</button>'+
    '<b>'+base.getFullYear()+' 年 '+(base.getMonth()+1)+' 月</b>'+
    '<button type="button" class="ct-tr-x ct-cal-nav" data-ct="tr-mnext" data-side="'+side+'" aria-label="'+side+' 下个月">›</button>'+
    '<button type="button" class="ct-tr-x ct-cal-nav" data-ct="tr-ynext" data-side="'+side+'" aria-label="'+side+' 下一年">»</button></div>'+
    '<div class="ct-cal-w">'+['一','二','三','四','五','六','日'].map(w=>'<span>'+w+'</span>').join('')+'</div>'+
    '<div class="ct-cal-g">'+cells.join('')+'</div></div>'}
function calHtml(){const base=trCalMonth||new Date(trParse(trDraft.from)||new Date());
  const next=new Date(base.getFullYear(),base.getMonth()+1,1);
  return'<div class="ct-cal">'+
    '<div class="ct-cal-bar"><span>'+(trPick?'已选 '+trPick+'，再点一天作为结束':'点选开始日期，再点结束日期；每月的 « ‹ › » 各自翻页')+'</span></div>'+
    '<div class="ct-cal-pair">'+calMonthHtml(base,'左')+calMonthHtml(next,'右')+'</div></div>'}
function paintCal(){const host=trPanel&&trPanel.querySelector('#ctTrCal');if(host)host.innerHTML=calHtml()}
function pickDay(key){if(!trDraft)return;
  const cur=trParse(trDraft.from),end=trParse(trDraft.to);
  if(!trPick){
    const t=cur?ctPad(cur.getHours())+':'+ctPad(cur.getMinutes()):'00:00';
    trDraft.from=key+'T'+t;trDraft.to='';trPick=key;trHover=null;paintRange();paintCal();return}
  const lo=key<trPick?key:trPick,hi=key<trPick?trPick:key;
  const s=trParse(trDraft.from)||new Date(),e=end||new Date();
  trDraft.from=lo+'T'+ctPad(s.getHours())+':'+ctPad(s.getMinutes());
  trDraft.to=hi+'T'+(end?ctPad(e.getHours())+':'+ctPad(e.getMinutes()):'23:59');
  trPick=null;trHover=null;paintRange();paintCal()}

function trPanelHtml(){
  const chips=[['today','今天'],['yesterday','昨天'],['last7','最近 7 天'],['last30','最近 30 天'],['month','本月']];
  return'<div class="ct-tr-mask" data-tr-mask></div>' +
    '<section class="ct-tr-sheet" role="dialog" aria-modal="true" aria-labelledby="ctTrTitle">'+
      '<header class="ct-tr-head"><div><h3 id="ctTrTitle">自定义时间范围</h3><p>结束时间不含在范围内，跨度上限 90 天。</p></div>'+
        window.PrototypeModal.closeButton('data-ct="tr-close"')+'</header>'+
      '<div class="ct-tr-fields">'+
        '<div class="ct-tr-dt"><label class="ui-field">开始日期<input id="ctTrFromDate" type="text" inputmode="numeric" placeholder="YYYY-MM-DD" value="'+trField(trDraft.from).slice(0,10)+'" aria-label="开始日期"></label>'+
          '<label class="ui-field">开始时间<span class="ct-tr-time"><input id="ctTrFromTime" type="text" inputmode="numeric" placeholder="HH:mm" value="'+trField(trDraft.from).slice(11,16)+'" aria-label="开始时间" aria-haspopup="listbox" aria-expanded="false" autocomplete="off" data-time="from"></span></label></div>'+
        '<div class="ct-tr-dt"><label class="ui-field">结束日期<input id="ctTrToDate" type="text" inputmode="numeric" placeholder="YYYY-MM-DD" value="'+trField(trDraft.to).slice(0,10)+'" aria-label="结束日期"></label>'+
          '<label class="ui-field">结束时间<span class="ct-tr-time"><input id="ctTrToTime" type="text" inputmode="numeric" placeholder="HH:mm" value="'+trField(trDraft.to).slice(11,16)+'" aria-label="结束时间" aria-haspopup="listbox" aria-expanded="false" autocomplete="off" data-time="to"></span></label></div>'+
        '<label class="ui-field">时区<select id="ctTrZone"><option value="local"'+(trDraft.zone==='local'?' selected':'')+'>本机时区</option><option value="utc"'+(trDraft.zone==='utc'?' selected':'')+'>UTC</option></select></label>'+
      '</div>'+
      '<div class="ct-tr-chips" role="group" aria-label="快捷区间">'+chips.map(([k,l])=>'<button type="button" class="ui-chip" data-ct="tr-chip" data-chip="'+k+'">'+l+'</button>').join('')+'</div>'+
      '<div id="ctTrCal" class="ct-tr-cal"></div>'+
      /* 错误与区间摘要共用底部同一行：同一位置先显示错误，恢复后接回时间展示 */
      '<footer class="ct-tr-foot"><span class="ct-tr-note"><span id="ctTrSummary" class="ct-tr-sum"></span><span id="ctTrError" class="ct-tr-err" role="alert" aria-live="polite" hidden></span></span><span class="ui-inline">'+
        button('取消','tr-cancel','ghost')+button('应用','tr-apply','primary')+'</span></footer>'+
    '</section></div>'}
function openTrPanel(){if(trPanel)return;
  trDraft={from:trState.from,to:trState.to,zone:trState.zone};
  trPick=null;trHover=null;trCalMonth=new Date(trParse(trState.from)||new Date());
  trRestore=document.activeElement;
  trPanel=document.createElement('div');trPanel.id='ctTrPanel';trPanel.className='ct-tr-host';
  trPanel.innerHTML=trPanelHtml();
  page.appendChild(trPanel);
  paintRange();paintCal();
  const first=trPanel.querySelector('#ctTrFromDate');if(first)first.focus({preventScroll:true})}
function closeTrPanel(){if(!trPanel)return;trPanel.remove();trPanel=null;trDraft=null;
  trPick=null;trHover=null;
  closeTimePop();
  if(trRestore&&trRestore.focus)trRestore.focus({preventScroll:true});trRestore=null}

/* 输入框用“YYYY-MM-DD HH:mm”文本，避免浏览器按地区显示成 10/26/2026 12:00 AM */
function trField(s){return String(s||'').replace('T',' ').slice(0,16)}
function trParse(s){var m=/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})$/.exec(String(s||'').trim());
  if(!m)return null;var d=new Date(+m[1],+m[2]-1,+m[3],+m[4],+m[5]);
  if(isNaN(d)||d.getMonth()!==+m[2]-1||d.getDate()!==+m[3])return null;return d}
/* 日期与时间拆成两列输入：日期固定 10 位、时间固定 5 位，提交时再拼成 YYYY-MM-DD HH:mm */
/* 时间下拉：既是可编辑输入，也能从列表选；列表按 15 分钟一档，输入时不打断手输 */
let trTimePop=null;
/* 时间面板：左边选小时（00–23），右边选分钟（可选 5 分钟一档或逐分钟），选中即时回填 */
let trMinStep=1;
function trHours(){const out=[];for(let h=0;h<24;h++)out.push(ctPad(h));return out}
function trMinutes(){const out=[];for(let m=0;m<60;m+=trMinStep)out.push(ctPad(m));return out}
function trTimeParts(v){const m=/^(\d{1,2}):(\d{1,2})$/.exec(String(v||'').trim());return m?[ctPad(Math.min(23,+m[1])),ctPad(Math.min(59,+m[2]))]:['00','00']}
let trSuppress=false;function closeTimePop(){if(!trTimePop)return;const id=trTimePop.dataset.owner;trTimePop.remove();trTimePop=null;const b=id?document.getElementById(id):null;if(b){b.setAttribute('aria-expanded','false');trSuppress=true;b.focus({preventScroll:true});setTimeout(()=>{trSuppress=false},0)}}
function openTimePop(which){
  const input=which==='from'?$('#ctTrFromTime'):$('#ctTrToTime');if(!input)return;
  if(trTimePop&&trTimePop.dataset.owner===input.id)return;
  closeTimePop();
  const parts=trTimeParts(input.value),hh=parts[0],mm=parts[1];
  const pop=document.createElement('div');pop.className='ct-tr-tpop ct-tr-tpop2';pop.id='ctTrTimePop';pop.dataset.owner=input.id;
  pop.innerHTML='<div class="ct-tp-cols" role="group" aria-label="选择小时与分钟">'+
    '<div class="ct-tp-col" role="listbox" aria-label="小时"><div class="ct-tp-h">时</div>'+
      trHours().map(h=>'<button type="button" role="option" data-ct="tr-hour" data-which="'+which+'" data-v="'+h+'"'+(h===hh?' aria-selected="true"':'')+'>'+h+'</button>').join('')+'</div>'+
    '<div class="ct-tp-col" role="listbox" aria-label="分钟"><div class="ct-tp-h">分</div>'+
      trMinutes().map(m=>'<button type="button" role="option" data-ct="tr-minute" data-which="'+which+'" data-v="'+m+'"'+(m===mm?' aria-selected="true"':'')+'>'+m+'</button>').join('')+'</div>'+
  '</div>'+
  /* 只保留“此刻”：分钟列固定逐分钟，避免在一屏里塞进多组密度切换 */
  '<div class="ct-tp-foot"><button type="button" class="ct-tp-step" data-ct="tr-now">此刻</button></div>';
  const r=input.getBoundingClientRect();
  pop.style.left=Math.round(r.left)+'px';pop.style.top=Math.round(r.bottom+6)+'px';
  document.body.appendChild(pop);input.setAttribute('aria-expanded','true');trTimePop=pop;
  const sel=pop.querySelector('[aria-selected="true"]');if(sel)sel.scrollIntoView({block:'center'})}

function pickTime(which,t){const input=which==='from'?$('#ctTrFromTime'):$('#ctTrToTime');if(!input)return;
  input.value=t;applyTimeInputs();
  /* 选完小时保留面板以便继续选分钟；选的是完整时间才收起 */
  if(!trTimePop)return}
function setTimePart(which,kind,v){const input=which==='from'?$('#ctTrFromTime'):$('#ctTrToTime');if(!input)return;
  const parts=trTimeParts(input.value);parts[kind==='hour'?0:1]=v;
  input.value=parts[0]+':'+parts[1];applyTimeInputs();
  if(trTimePop){
    trTimePop.querySelectorAll('[data-ct="tr-hour"]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.v===parts[0])));
    trTimePop.querySelectorAll('[data-ct="tr-minute"]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.v===parts[1])))}}
/* 手动输入或下拉选择后统一刷新草稿、摘要与校验 */
function applyTimeInputs(){const el=trEls();if(!el.fd||!trDraft)return;
  const from=trJoin(el.fd.value,el.ft.value),to=trJoin(el.td.value,el.tt.value);
  trDraft.from=from.replace(' ','T');trDraft.to=to.replace(' ','T');
  const msg=validateRange(from,to);
  el.err.hidden=!msg;el.err.textContent=msg||'';
  if(!msg)el.sum.textContent=fmtLocal(from)+' → '+fmtLocal(to)+' · '+durationText(new Date(trParse(to))-new Date(trParse(from)));else el.sum.textContent=''}

function trEls(){return{fd:$('#ctTrFromDate'),ft:$('#ctTrFromTime'),td:$('#ctTrToDate'),tt:$('#ctTrToTime'),zone:$('#ctTrZone'),sum:$('#ctTrSummary'),err:$('#ctTrError')}}
function durationText(ms){const h=Math.round(ms/HOUR);return h<48?h+' 小时':(h/24).toFixed(h%24?1:0)+' 天'}
function validateRange(from,to){
  if(!from||!to)return'请填写开始与结束时间';
  const a=trParse(from)||new Date(from),b=trParse(to)||new Date(to);
  if(isNaN(a)||isNaN(b))return'请填写完整的开始与结束时间';
  if(b<=a)return'结束时间需要晚于开始时间';
  if(b-a>MAXSPAN)return'跨度超过 90 天，请缩小范围';
  return''}
/* 摘要与预设状态永远由 trState 渲染；面板内的日期/时间输入只在面板打开时同步草稿 */
function paintRange(){
  const cur=$('#ctTrCurrent');
  if(cur)cur.textContent='当前 '+fmtLocal(trState.from)+' → '+fmtLocal(trState.to)+' · '+durationText(new Date(trState.to)-new Date(trState.from));
  const e=trEls();
  if(e.fd&&trDraft){
    const fv=trField(trDraft.from),tv=trField(trDraft.to);
    e.fd.value=fv.slice(0,10);e.ft.value=fv.slice(11,16);
    e.td.value=tv.slice(0,10);e.tt.value=tv.slice(11,16);
    e.zone.value=trDraft.zone;
    const msg=validateRange(trDraft.from,trDraft.to);
    if(e.err){e.err.hidden=!msg;e.err.textContent=msg||''}
    if(e.sum)e.sum.textContent=msg?'':fmtLocal(trDraft.from)+' → '+fmtLocal(trDraft.to)+' · '+durationText(new Date(trDraft.to)-new Date(trDraft.from));
  }
  $$('[data-ct="tr-preset"]',page).forEach(b=>b.setAttribute('aria-pressed',String(!trDraft&&b.dataset.preset===trState.preset)));
}
function setDraft(from,to){
  if(!trDraft)trDraft={from:trState.from,to:trState.to,zone:trState.zone};
  trDraft.from=toLocalInput(from);trDraft.to=toLocalInput(to);paintRange();
}
function applyPreset(k){
  if(k==='custom'){openTrPanel();return}
  const now=new Date('2026-11-02T00:00'),h={'6h':6,'24h':24,'3d':72,'7d':168}[k]||24;
  trState.from=toLocalInput(new Date(now-h*HOUR));trState.to=toLocalInput(now);trState.preset=k;
  paintRange();
}
function applyChip(k){
  if(!trDraft)return;
  const end=new Date('2026-11-02T00:00'),start=new Date(end);
  if(k==='today')start.setHours(0,0,0,0);
  else if(k==='yesterday'){start.setDate(start.getDate()-1);start.setHours(0,0,0,0);end.setHours(0,0,0,0)}
  else if(k==='last7')start.setDate(start.getDate()-7);
  else if(k==='last30')start.setDate(start.getDate()-30);
  else if(k==='month'){start.setDate(1);start.setHours(0,0,0,0)}
  setDraft(start,end);
}
function resetRange(){trState.preset='24h';trState.from='2026-11-01T00:00';trState.to='2026-11-02T00:00';trState.zone='local';closeTrPanel();paintRange()}
/* 日期与时间分开输入，提交时拼成 YYYY-MM-DD HH:mm */
function trJoin(d,t){return String(d||'').trim()+' '+String(t||'').trim()}
function commitRange(){
  if(!trPanel||!trDraft)return;
  const e=trEls();
  const from=trJoin(e.fd.value,e.ft.value),to=trJoin(e.td.value,e.tt.value);
  const msg=validateRange(from,to);
  if(msg){e.err.hidden=false;e.err.textContent=msg;return}
  const fa=trParse(from),fb=trParse(to);
  if(!fa||!fb){e.err.hidden=false;e.err.textContent='请填写完整的开始与结束时间';return}
  trState.from=toLocalInput(fa);trState.to=toLocalInput(fb);trState.zone=e.zone.value;trState.preset='custom';
  closeTrPanel();paintRange();
}

 const renderers={
  brand:()=>'<div class="ct-brand-lockup">'+asset('04-品牌组件/Logo/logo.svg','OpenCodex Logo',64)+'<div><strong>OpenCodeX-Desktop</strong><span>Desktop Manager</span></div></div><div class="ct-brand-grid"><div class="ct-brand-canvas is-light"><strong>原色 / 浅色背景</strong>'+assetSizes('04-品牌组件/Logo/logo.svg','原色Logo',[32,64,128])+'</div><div class="ct-brand-canvas is-dark"><strong>原色 / 深色背景</strong>'+assetSizes('04-品牌组件/Logo/logo.svg','原色Logo',[32,64,128])+'</div><div class="ct-brand-canvas is-light"><strong>深色单色</strong>'+assetSizes('04-品牌组件/Logo/logo-dark.svg','深色单色Logo',[32,64])+'</div><div class="ct-brand-canvas is-dark"><strong>白色单色</strong>'+assetSizes('04-品牌组件/Logo/logo-light.svg','白色单色Logo',[32,64])+'</div></div>'+annotation('brand','品牌素材来源','本节直接引用品牌素材目录中的现有Logo，不生成新标识。原色、深色/白色单色分别展示；文件存在与生产采用状态分开记录。'),
  'app-icons':()=>'<div class="ct-brand-grid"><div class="ct-brand-canvas ct-checker"><strong>macOS</strong>'+assetSizes('03-平台交付/macOS/AppIcon/AppIcon.svg','macOS应用图标',[16,32,64,128])+'<p>白色圆角底板</p></div><div class="ct-brand-canvas ct-checker"><strong>Windows</strong>'+assetSizes('03-平台交付/Windows/AppIcon/AppIcon.svg','Windows应用图标',[16,32,64,128])+'<p>透明背景 · 90%主体</p></div></div>'+annotation('app-icons','平台应用图标','macOS使用既有白底应用图标；Windows使用2026-10-14确认的透明90%主体素材，不加macOS底板。仅展示已管理的SVG，不修改ICO/ICNS或生产资源；生产采用以实现SHA/发布记录为准。'),
  'tray-icons':()=>'<div class="ct-brand-grid">'+trayIconCanvas('macOS',false)+trayIconCanvas('macOS',true)+trayIconCanvas('Windows',false)+trayIconCanvas('Windows',true)+'</div>'+annotation('tray-icons','托盘图标与应用图标分开','macOS以Template Image语义交付纯黑/白前景；Windows浅色背景用tray-dark，深色背景用tray-light。两者不使用AppIcon底板、渐变或阴影。此处展示真实素材在小尺寸的外观，不代表原生状态栏/DPI验收。'),
  typography:()=>['micro','caption','label','control','body','subtitle','title','display'].map(name=>{const size=parseFloat(getComputedStyle(root).getPropertyValue('--text-'+name));return '<div class="ct-type-row"><code>'+name+' · '+size+' / '+Math.round(size*1.5)+'</code><span style="font-size:var(--text-'+name+');line-height:1.5">OpenCodex 管理工作空间 0123456789</span></div>';}).join('')+'<div class="ui-inline ct-sample">'+[400,500,600,700].map(w=>'<span style="font-weight:'+w+'">字重 '+w+'</span>').join('')+'</div><p class="ct-long" data-ct-long>中文、English 与数字 1,280 tokens · 2026-10-15</p><pre class="ct-code">/workspace/opencodex-desktop/very-long-project-name/preferences/model-policy.example.json\n{ "reasoningEffort": "high", "fast": false }</pre><div class="ct-surface"><strong>内容与代码</strong><p>富文本保留标题、列表与行内代码。正文链接可辨认；原始HTML、脚本与不安全URL不执行。</p><p><a href="#components?section=overlays" data-ct-section="overlays">查看弹窗样例</a> · <code>modelRef</code> · <em>强调内容</em></p></div>',
  materials:()=>'<div class="ct-grid">'+[['shell','窗口'],['page','页面'],['panel','分组'],['control','控件'],['emphasis','强调'],['overlay','浮层']].map(([id,label])=>'<div class="ct-surface glass-'+(id==='control'?'control':id)+'" data-surface="'+id+'"><strong>'+label+'</strong><p>共享文字、边框与材质层级</p></div>').join('')+'</div><div class="ct-sample">'+[['blue','信息'],['green','成功'],['amber','注意'],['red','错误']].map(([c,l])=>'<div class="ct-swatch-row"><span class="ct-swatch" style="background:var(--'+c+')"></span>'+l+' · 不只靠颜色区分</div>').join('')+'</div><div class="ui-inline"><div class="ct-motion" aria-hidden="true"></div><span class="ct-label">高档装饰运动示例；中档静止，低档实底</span></div>'+annotation('materials','亮暗与画质规则','高档保留玻璃与装饰运动；中档保留相同玻璃并停止装饰运动；低档关闭玻璃/环境光，保留功能与状态。用户选择不由系统减少动态选项自动改写。真实对比度与合成效果须实屏复核。'),
  'icons-spacing':()=>'<div class="ui-inline">'+[14,16,20].map(n=>'<span class="ui-inline"><svg width="'+n+'" height="'+n+'" viewBox="0 0 20 20" fill="none" stroke="currentColor" aria-hidden="true"><path d="m4 10 4 4 8-8"/></svg>'+n+'px</span>').join('')+button(icon,'noop','ghost ui-icon-button','aria-label="添加项目"')+'<span class="ct-label">16px图标 / 32px点击区域</span></div>'+[4,8,12,16,20,24,32,40].map(n=>'<div class="ct-measure"><code>'+n+'px</code><span class="ct-spacing" style="width:'+n+'px"></span></div>').join('')+'<div class="ui-inline">'+[4,6,8,12,16].map(n=>'<span class="ct-swatch" style="border-radius:'+n+'px" title="圆角 '+n+'px"></span>').join('')+'</div>',
  layout:()=>'<div class="ct-demo-split"><nav class="ct-demo-sidebar" aria-label="布局示例导航">主从分栏<br>左侧固定<br>右侧伸展</nav><div class="ui-stack"><strong>Stack · 纵向间距</strong><div class="ui-inline">'+button('主要操作','noop')+button('次要操作','noop','ghost')+'<span class="ct-long">内容随宽度自然换行</span></div></div></div><div class="ct-sample ct-sticky-demo" tabindex="0" aria-label="局部滚动与固定Tab样例"><div class="ct-demo-tabs">渠道配置　服务节点　模型列表</div><div class="ct-demo-detail"><strong>NewApi</strong><small>详情标题在主Tab下方固定</small></div>'+[1,2,3].map(n=>'<article><strong>区段 '+n+'</strong><p>向下滚动此区域，Tab到顶后固定。详情标题在主Tab下方避让。</p></article>').join('')+'</div>'+annotation('layout','固定条和布局范围','除概览、面板外，页面主Tab滚动到主容器顶部后固定；详情标题继续向下避让，背景延伸两侧，内容对齐不变。公共适配归0.2.0；对话和多平台扩展功能沿各自版本，不因此提前实施。窄窗通过折叠目录、换行、合理局部滚动保持可用。'),
  buttons:()=>'<div class="ct-button-matrix">'+[['sm','小号 · 28px'],['md','标准 · 34px'],['lg','大号 · 40px']].map(([s,l])=>'<div class="ct-matrix-row"><strong>'+l+'</strong>'+button('普通','noop','btn-'+s)+button('保存','sample-save','primary btn-'+s)+button('取消','noop','ghost btn-'+s)+button('删除','sample-delete','danger btn-'+s)+button(icon+'新建','noop','ghost btn-'+s)+'</div>').join('')+'<div class="ct-matrix-row"><strong>密度 / 图标</strong>'+button('紧凑','noop','ghost btn-compact')+button(icon,'noop','ghost ui-icon-button','aria-label="添加样例"')+'</div><div class="ct-matrix-row"><strong>展示态</strong>'+button('Hover','noop','ghost is-hover')+button('Active','noop','ghost is-active')+button('Focus','noop','ghost is-focus')+button('已禁用','noop','ghost','disabled')+button('<span class="ui-spinner" aria-hidden="true"></span>处理中','noop','ghost','disabled aria-busy="true"')+'</div></div><p class="ct-label">展示态用于对照；真实焦点请使用Tab键，真实Hover/Active请使用指针。</p><p class="ct-result" id="ctButtonResult" role="status"></p>'+annotation('buttons','尺寸与语义独立','默认标准md34；列表行内用sm28；大号lg40只用于明确的大尺寸区域。primary/ghost/danger代表语义，不代表大小。通知操作采用通知专用profile，不全局覆盖；状态框和并列按钮同高。新样式先登记再采用。'),
  forms:()=>'<div class="ct-grid"><div class="ui-stack"><label class="ui-field">名称<input id="ctName" placeholder="输入名称" aria-describedby="ctNameHelp"><small id="ctNameHelp">必填，最多40个字符</small><small id="ctNameError" class="ui-error" hidden>请输入1～40个字符</small></label><label class="ui-field">说明<textarea id="ctDescription" placeholder="多行内容"></textarea></label><label class="ui-field">只读字段<input value="内置基线" readonly></label><label class="ui-field">禁用字段<input value="不可修改" disabled></label>'+button('校验表单','validate','ghost')+'</div><div class="ui-stack"><label><input id="ctCheckbox" type="checkbox" checked>复选项</label><label><input id="ctIndeterminate" type="checkbox">半选项</label><div role="group" aria-label="选择模式"><label><input type="radio" name="ctRadio" value="auto" checked>自动</label> <label><input type="radio" name="ctRadio" value="manual">手动</label></div>'+button('开启同步','switch','ghost','role="switch" aria-checked="false"')+'<label class="ui-field">强度<input type="range" id="ctSlider" min="0" max="100" value="50"><output for="ctSlider" id="ctSliderValue">50</output></label><label><input type="checkbox" disabled>禁用选择</label><p class="ct-result" id="ctFormResult" role="status"></p></div></div><div class="ui-inline ct-sample">'+[['sm','小号28'],['md','标准34'],['lg','大号40']].map(([size,label])=>'<label class="ui-field ui-field-'+size+'">'+label+'<input placeholder="输入内容" aria-label="'+label+'字段样例"></label>').join('')+'</div>',
  'menus-tabs':()=>'<div class="ct-grid"><label class="ui-field">单选<select id="ctSelect"><option>自动</option><option>手动</option><option disabled>当前不可用</option><option>很长的选项名称用于检查边界与省略规则</option></select></label><label class="ui-field">多选<select id="ctMultiSelect" multiple><option selected>渠道配置</option><option>模型模版</option><option>偏好设置</option><option disabled>凭据未就绪</option></select></label></div><div class="ui-inline ct-sample">'+button('操作菜单','menu','ghost','aria-haspopup="menu" aria-expanded="false"')+'<span id="ctMenuResult" class="ct-label" role="status"></span></div><div class="ct-tabs" role="tablist" aria-label="样例分区">'+[['general','基本设置'],['advanced','高级设置']].map(([id,label])=>'<button type="button" id="ctTab-'+id+'" data-ct-tab="'+id+'" role="tab" aria-selected="'+(id==='general')+'" aria-controls="ctTabPanel" tabindex="'+(id==='general'?0:-1)+'">'+label+'</button>').join('')+'</div><div id="ctTabPanel" role="tabpanel" aria-labelledby="ctTab-general" class="ct-tab-content">基本设置内容。切换分区保留表单输入。</div>',
  status:()=>{
   const tone=[['正常运行','state-running'],['进行中','state-starting'],['需注意','state-warn'],['失败','state-bad'],['中性','state-muted']];
   const rows=[
    ['未修改','state-muted'],['未保存修改','state-warn'],['有待确认编辑','state-warn'],['超出激活预算','state-bad'],
    ['正在保存','state-starting'],['已保存 · 待重启','state-warn'],['保存失败','state-bad'],['保存已取消','state-muted'],['保存结果待核对','state-warn']
   ];
   const phase=[['校验','state-starting'],['备份','state-starting'],['写入','state-starting'],['核对目录','state-starting'],['发布快照','state-starting']];
   return '<div class="ui-stack">'+
    '<div><strong class="ct-label">五类语义</strong><div class="ui-inline">'+tone.map(([t,c])=>'<span class="state-pill '+c+'">'+t+'</span>').join('')+'</div></div>'+
    '<div><strong class="ct-label">渠道保存的九种状态（与模型页一致）</strong><div class="ui-inline">'+rows.map(([t,c])=>'<span class="state-pill '+c+'" data-channel-state="'+t+'">'+t+'</span>').join('')+'</div></div>'+
    '<div><strong class="ct-label">进行中：默认只写结论，阶段名放 hover / focus</strong><div class="ui-inline ct-state-phases"><span class="state-pill state-starting" title="校验…">正在保存</span>'+phase.map(([t,c])=>'<span class="state-pill '+c+'" title="阶段名只在悬浮时出现">'+t+'</span>').join('')+'</div><p class="ct-label">上排右五枚仅作阶段名对照，实际界面不常驻显示。</p></div>'+
    '<div><strong class="ct-label">子标签：同一状态区里表达「上次结果」</strong><div class="ui-inline"><span class="state-pill state-warn">未保存修改<span class="ct-state-sub">上次保存待重启</span></span><span class="state-pill state-running">已写入<span class="ct-state-sub">待重启 Codex</span></span></div></div>'+
    '<div><strong class="ct-label">计数与状态分开</strong><div class="ui-inline"><span class="ui-tag">12</span><span class="state-pill state-muted">12 / 30</span></div></div>'+
    '</div><p class="ct-label">同一状态只出现在一个承载处：模型页把它放在 Tab 右侧，列表上方不再重复。颜色不单独承担语义，每枚都带文字。</p>';
  },
  'tree-navigation':()=>'<div id="ctTreeNavigationDemo"></div>',
  'interactive-collections':()=>'<div id="ctInteractiveCollectionDemo"></div>',
  /* 时间范围选择：预设分段 + 起止时间 + 快捷区间 + 校验 */
  'time-range':()=>{
    const presets=[['6h','近 6 小时'],['24h','近 24 小时'],['3d','近 3 天'],['7d','近 7 天'],['custom','自定义']];
    const chips=[['today','今天'],['yesterday','昨天'],['last7','最近 7 天'],['last30','最近 30 天'],['month','本月']];
    return'<div class="ui-stack">'+
      '<div class="ct-tr-row"><div class="ct-tr-seg" role="group" aria-label="时间范围预设">'+
        presets.map(([k,l])=>'<button type="button" data-ct="tr-preset" data-preset="'+k+'" aria-pressed="'+(k==='24h')+'">'+l+'</button>').join('')+'</div></div>'+
      '<p class="ct-tr-sum" id="ctTrCurrent">当前 2026-11-01 00:00 → 2026-11-02 00:00 · 24 小时</p>'+
      '<p class="ct-label">点「自定义」在弹出的玻璃面板里选起止时间；面板不占页面空间，关闭即撤销未应用的修改。</p>'+
    '</div>'},
  data:()=>'<div class="ui-inline">'+['默认','已启用','待确认','失败'].map((s,i)=>'<span class="state-pill '+(['state-muted','state-running','state-warn','state-bad'][i])+'">'+s+'</span>').join('')+'<span class="ui-tag">12</span></div><div class="ct-sample ct-table-scroll" tabindex="0" aria-label="长列表滚动样例"><table class="ct-table"><thead><tr><th scope="col"><label><input type="checkbox" id="ctTableAll">全选</label></th><th scope="col">'+button('名称 ↕','sort-table','ghost btn-sm')+'</th><th scope="col">状态</th><th scope="col">操作</th></tr></thead><tbody id="ctTableBody"></tbody></table></div><p id="ctTableResult" class="ct-result" role="status">已选0项</p><div id="ctTree" class="ct-sample" aria-label="配置树表"></div>',
  overlays:()=>'<div class="ui-inline">'+button('确认弹窗','dialog-confirm','ghost')+button('内容弹窗','dialog-detail','ghost')+button('表单弹窗','dialog-form','ghost')+'</div><p class="ct-result" id="ctDialogResult" role="status">从本节打开共享弹窗，关闭后焦点返回入口。</p>'+annotation('overlay','浮层层级与焦点','共用Modal / Select / action menu宿主。Escape先关闭最上层菜单，再关闭弹窗；Tab在弹窗内循环，关闭后返回触发点。此注释绝对定位，不挤占操作区。表单错误就地展示，不发通知。'),
  feedback:()=>'<div class="ui-inline">'+[['empty','空态'],['loading','加载'],['error','失败'],['success','完成']].map(([s,l])=>button(l,'local-'+s,'ghost')).join('')+'</div><div id="ctLocalFeedback" class="ct-local ct-sample" role="status"></div><ol class="ct-steps"><li class="done">✓ 选择范围</li><li class="active">2 核对内容</li><li>3 完成</li></ol><p class="ct-label">字段错误、空态与步骤留在上下文；跨页任务和需要处理的结果通过登记事件进入通知宿主。</p>',
  'model-picker':()=>'<div class="ui-inline">'+button('选择模型','picker','ghost')+'<span class="ui-tag" id="ctPickerMode">单选</span></div><div id="ctPickerInline" class="ct-picker-inline"></div><div id="ctPickerResult" class="ct-result" role="status">尚未返回选择。</div>'+annotation('model','公共模型选择器','完整渠道/型号浏览、搜索排序、已选区、推理和Fast由既有model-picker renderer提供；本页fixture和业务目录相互独立。工具板可切单/多选、目录场景、页内/弹窗。确认返回本页；取消不改变已确认值。未知能力不伪造推理或Fast支持。'),
  'node-picker':()=>'<div class="ui-inline">'+button('默认节点 ▾','node-open','ghost','id="ctNodeTrigger" aria-haspopup="dialog" aria-expanded="false"')+'<span class="ct-label">服务节点</span></div><div id="ctNodeInline" class="ct-node-inline ct-sample"></div><p class="ct-result" id="ctNodeResult" role="status"></p>'+annotation('nodes','选择与检测相互独立','同一渠道的节点只换URL，共用协议与Key。选节点不自动测速，测速不自动选节点。逐项/一键/停止/失败/超时/过期均为会话mock。切场景或离开章节停止当前检测，晚回凭runId丢弃。此处不请求网络。'),
  notifications:()=>'<div class="ui-inline">'+button('短结果反馈','notify-toast','ghost')+button('开始任务A','notify-task-a','ghost')+button('开始任务B','notify-task-b','ghost')+button('待处理事项','notify-attention','ghost')+'</div><div class="ui-inline ct-sample">'+button('模拟失败A','notify-fail','ghost')+button('打开通知中心','notify-center','ghost')+button('重置演示通知','notify-reset','ghost')+'</div><p class="ct-label">使用右上角既有铃铛、任务卡和通知历史。收起后可从同一条通知恢复。</p>'+'<div class="ct-sample" id="ctNotificationCountdown"><h4>自动收起进度条</h4><div class="ui-inline">'+button('成功通知','notify-countdown-success','ghost')+button('错误通知','notify-countdown-error','ghost')+button('警告通知','notify-countdown-warning','ghost')+button('信息通知','notify-countdown-info','ghost')+button('已完成任务','notify-countdown-task','ghost')+'</div><p class="ct-label">8秒收起 · 按类型着色 · 左端清晰 · 右端渐隐 · 悬停或键盘焦点停留时暂停</p></div>'+annotation('countdown','通知公共宿主已采用','component.demo.countdown先注册再从公共发布器投到既有Toast/任务卡。通知不带左侧强调条。已取消明暗和流动，保留按通知类型着色的固定半透明、左端不渐隐及右端渐隐；只有长度递减表示剩余停留时间，与业务执行进度分开。悬停和焦点停留时计时暂停；减少动态时按秒递减。当前主原型的Toast与终态任务卡共用本组件；运行任务及铃铛历史列表不显示自动收起倒计时。')+annotation('notify','通知必须先注册','component.demo.feedback/task/attention仅原型demo事件，登记于maintenance-events。生产通知仍需0.2.0统一publisher/生命周期接线。每个taskId更新同一实体；已读/已解决/删除独立；删除后的晚回不复活。重置只清demo命名空间，主题/章节切换不新增通知。'),
  windows:()=>'<div id="ctWindowSample"></div><p class="ct-label">浏览器外观模拟。真实Mica、拖拽、Snap、Alt+F4、DPI和原生恢复仍需Windows实机验收。</p>',
  tray:()=>'<div id="ctTraySample" class="ct-tray-preview"></div><p id="ctTrayResult" class="ct-result" role="status"></p><p class="ct-label">复用托盘菜单模板，操作仅更新本节演示数据；原生菜单尺寸与快捷键须实机复核。</p>',
  examples:()=>'<div class="ct-surface"><strong>工作空间设置</strong><div class="ct-setting-row"><div><strong>自动检查更新</strong><p>按所选周期检查，结果进入统一通知。</p></div>'+button('已开启','switch','ghost','role="switch" aria-checked="true"')+'</div><div class="ct-setting-row"><label class="ui-field">工作空间名称<input id="ctExampleName" value="默认工作空间"></label>'+button('保存','example-save')+'</div><p id="ctExampleResult" role="status" class="ct-result"></p></div><div class="ui-inline ct-sample"><span>渠道模型</span>'+button('预览选择器','picker','ghost')+'<span id="ctSaveState" class="state-pill state-muted">未修改</span>'+button('还原修改','example-reset','ghost')+button('保存','example-save','ghost')+'</div>'
 };
 function render(){
  page.innerHTML='<header class="ct-intro"><div><h1>组件与样式</h1><p>选择目录定位章节；右侧工具板切换评审条件。</p><p class="ct-usage-legend">使用建议区分已有规则、方案约定和建议待确认；规格有依据，生产采用与验证另行记录。</p></div><div class="ui-inline">'+button('目录','toggle-nav','ghost ct-mobile-nav','aria-controls="componentNavLinks" aria-expanded="true"')+button('返回功能原型','back','ghost')+'<div id="ctNotificationMount"></div></div></header>'+catalog.sections.map(s=>'<section class="ct-section" id="'+s.anchor+'" data-ct-section-id="'+s.id+'" aria-labelledby="ctHeading-'+s.id+'"><header class="ct-section-head"><h3 id="ctHeading-'+s.id+'">'+s.title+'</h3><span class="ct-description">'+s.description+'</span></header><div class="ct-sample ct-zoom">'+renderers[s.renderer]()+'</div>'+usage(s)+metadata(s.id)+'</section>').join('');
  /* 章节挂载后：时间范围回填状态并校验，交互列表与树导航挂到各自容器 */
  if(document.getElementById('ctTrCurrent'))paintRange();
  window.treeNavigationDemo?.mount?.(document.getElementById('ctTreeNavigationDemo'));
  window.interactiveCollectionDemo?.mount?.(document.getElementById('ctInteractiveCollectionDemo'));
  nav.innerHTML='<label class="ui-field"><span class="ct-label">组件目录</span><input type="search" class="ct-search" id="componentNavSearch" aria-label="搜索组件目录" placeholder="搜索组件"></label><div id="componentNavLinks"></div>';
  renderNav();const demoTabs=$('.ct-demo-tabs',page),measureTabs=()=>demoTabs.parentElement.style.setProperty('--ct-demo-tabs-height',(demoTabs.offsetHeight||40)+'px');measureTabs();new ResizeObserver(measureTabs).observe(demoTabs);$('#ctIndeterminate').indeterminate=true;renderTable();renderTree();window.treeNavigationDemo?.mount($('#ctTreeNavigationDemo'));renderLocal();renderNodes();renderWindow();renderTraySample();renderExampleState();window.prototypeSelect?.enhance(page);mountPicker();
 }
 function renderNav(){
  const q=navQuery.trim().toLowerCase();let count=0;
  $('#componentNavLinks',nav).innerHTML=catalog.groups.map(g=>{const sections=catalog.sections.filter(s=>s.group===g.id&&(!q||(s.title+' '+s.id+' '+s.description+' '+catalog.entries(s.id).map(c=>c.name+' '+c.id).join(' ')).toLowerCase().includes(q)));count+=sections.length;return sections.length?'<div class="ct-nav-group"><strong>'+g.label+'</strong>'+sections.map(s=>'<a class="ct-nav-link" data-ct-section="'+s.id+'" href="#components?section='+s.id+'" '+(state.section===s.id?'aria-current="location"':'')+'>'+s.title+'</a>').join('')+'</div>':'';}).join('')+(!count?'<p class="ct-nav-empty" role="status">没有匹配组件</p>':'');
 }
 function navigate(id,push=true){
  const section=catalog.section(id);if(!section)return false;
  if(state.section==='node-picker'&&id!==state.section)stopNodes();state.section=id;closeNodePopup();renderNav();
  const el=document.getElementById(section.anchor);if(entered&&el)main.scrollTop+=el.getBoundingClientRect().top-main.getBoundingClientRect().top-12;
  if(push)writeHash(true);updateToolContext();return true;
 }
 function writeHash(push=false){
  const p=new URLSearchParams({section:state.section,theme:state.theme,effects:state.effects,zoom:String(state.zoom),size:state.size,long:state.long?'1':'0'}),hash='#components?'+p;
  if(location.hash!==hash)(push?history.pushState:history.replaceState).call(history,null,'',hash);
 }
 function readHash(){
  const p=new URLSearchParams(location.hash.split('?')[1]||'');
  for(const key of ['theme','effects','zoom','size','long'])if(p.has(key))setEnvironment(key,p.get(key),false);
  const id=p.get('section');if(catalog.section(id))state.section=id;
 }
 function setEnvironment(key,value,write=true){
  if(key==='theme'&&['light','dark'].includes(value))state.theme=value;
  else if(key==='effects'&&['high','mid','low'].includes(value))state.effects=value;
  else if(key==='zoom'&&[50,100,150,200].includes(Number(value)))state.zoom=Number(value);
  else if(key==='size'&&['fluid','1180','900'].includes(String(value)))state.size=String(value);
  else if(key==='long')state.long=value===true||value==='1';else return false;
  if(entered){root.dataset.theme=state.theme;setEffects(state.effects);page.style.setProperty('--ct-preview-width',state.size==='fluid'?'100%':state.size+'px');page.style.setProperty('--ct-zoom',state.zoom/100);page.dataset.long=String(state.long);$$('[data-ct-long]',page).forEach(el=>el.textContent=state.long?'中文与English混排的很长工作空间名称 · workspace-with-a-very-long-model-definition-2026-10-15-0123456789':'中文、English 与数字 1,280 tokens · 2026-10-15');updateSizeReadout();}
  const el=$('[data-ct-env="'+key+'"]',tool);if(el){if(el.type==='checkbox')el.checked=state[key];else el.value=String(state[key]);}
  if(write&&entered)writeHash();return true;
 }
 function updateToolContext(){
  $$('[data-ct-for]',tool).forEach(el=>el.hidden=el.dataset.ctFor!==state.section);
  $('#ctToolSection',tool).textContent=catalog.section(state.section)?.title||'';
 }
 function renderTable(){
  const rows=Array.from({length:24},(_,i)=>i+1);if(state.tableReverse)rows.reverse();
  $('#ctTableBody').innerHTML=rows.map(i=>'<tr><td><input type="checkbox" data-ct-row="'+i+'" aria-label="选择项目 '+i+'" '+(state.selectedRows?.has(i)?'checked':'')+'></td><th scope="row">项目 '+String(i).padStart(2,'0')+'</th><td><span class="state-pill '+(i%4===0?'state-warn':'state-running')+'">'+(i%4===0?'待确认':'已启用')+'</span></td><td>'+button('编辑','table-edit','ghost btn-sm','data-row="'+i+'"')+'</td></tr>').join('');
 }
 function renderTree(){
  $('#ctTree').innerHTML=window.PrototypeTreeTable.rows(window.PrototypeTreeTable.visible(treeNodes,collapsed),n=>({label:n.label,depth:n.depth,expanded:!collapsed.has(n.id),toggleAttrs:treeNodes.some(c=>c.parent===n.id)?'data-ct-tree="'+n.id+'"':null,className:'ct-tree-row',cells:['<span class="ct-label">'+(n.parent?'子项':'分组')+'</span>']}));
 }
 function renderLocal(){const messages={empty:'暂无内容，选择一个范围后开始。',loading:'正在读取示例内容…',error:'内容读取失败。请重试或调整范围。',success:'内容已就绪。'};const el=$('#ctLocalFeedback');el.classList.toggle('error',state.local==='error');el.setAttribute('aria-busy',String(state.local==='loading'));el.textContent=messages[state.local];}
 function pickerCatalog(){
  if(state.pickerScenario==='empty')return [];
  return Array.from({length:state.pickerScenario==='long'?108:24},(_,i)=>({ref:{kind:'channel',channelId:i%2?'aimami':'newapi',modelId:i<2?'gpt-5.4':i<4?'claude-sonnet-4.6':'model-'+i},channelName:i%2?(state.long?'AIMAMI · 很长的渠道名称用于检查列表边界':'Aimami'):'NewApi',name:(state.long?'很长的模型定义名称 · ':'')+(i<2?'GPT 5.4':i<4?'Claude Sonnet 4.6':'Model '+i),context:i%3?128000:null,effort:i%3?'high':null,efforts:i%3?['low','medium','high']:[],fastCapability:i%3?'supported':'unknown',fastDefault:false,modalities:['text'],reason:state.pickerScenario==='failed'?'目录暂不可用':state.pickerScenario==='loading'?'正在读取':i===12?'渠道已停用':''}));
 }
 // 读取中 / 读取失败两个场景需要演示“已有选择保持”，因此没有已确认结果时给一条既有选择。
 const pickerRetained=[{kind:'channel',channelId:'newapi',modelId:'gpt-5.4'}];
 function pickerOptions(){
  const retained=state.pickerResult?.models?.length?state.pickerResult.models:(['loading','failed'].includes(state.pickerScenario)?pickerRetained:[]);
  return {title:'选择模型',scenario:state.pickerScenario,mode:state.pickerMode,reasoning:true,fast:true,ordered:state.pickerMode==='multiple',models:state.pickerScenario==='missing'?[{kind:'channel',channelId:'removed',modelId:'unavailable'}]:retained,getCatalog:pickerCatalog,onScenarioReady:()=>{state.pickerScenario='normal';$('#ctPickerScene').value='normal';},onSelect:result=>{state.pickerResult=result;$('#ctPickerResult').textContent=result.models.map(m=>m.channelId+' / '+m.modelId+(m.reasoningEffort?' · '+m.reasoningEffort:'')+(m.fast?' · Fast':'')).join('；')||'已清空选择。';},onCancel:()=>{}};}
 function mountPicker(){
  $('#ctPickerMode').textContent=state.pickerMode==='multiple'?'多选':'单选';
  // 页内形态复用同一renderer；同一时刻只挂载一个选择器实例。
  if(entered&&root.dataset.route==='components')window.modelPickerPrototype?.mount?.($('#ctPickerInline'),pickerOptions());
 }
 const nodeText=n=>state.nodeResults[n.id]||'未检测';
 function nodeMarkup(prefix,close){return window.PrototypeNodeView.picker({titleId:prefix+'Title',title:'NewApi · 服务节点',close:close?window.PrototypeModal.closeButton('data-ct="node-close"'):'' ,all:button(state.nodeRunning?'停止检测':'一键检测',state.nodeRunning?'node-stop':'node-all','ghost btn-sm'),summaryId:prefix+'Summary',summary:state.nodeRunning?'正在检测…':'接口响应耗时 · 不代表生成速度',rows:nodes.map(n=>window.PrototypeNodeView.row({id:n.id,choiceId:prefix+'Choice-'+n.id,choiceAttrs:'data-ct-node="'+n.id+'"',selected:state.nodeSelected===n.id,title:n.url,name:state.long?n.name+' · 备用服务节点长名称':n.name,speedId:prefix+'Speed-'+n.id,speed:esc(nodeText(n)),test:button('检测','node-one','ghost btn-sm','data-node="'+n.id+'" '+(state.nodeRunning?'disabled':''))})).join('')});}
 function renderNodes(){
  const active=document.activeElement,scope=active?.closest?.('#ctNodeInline,.ct-node-popup'),focusId=scope?active.id:'',focusAction=scope?active.dataset.ct:null,focusNode=scope?active.dataset.node:null;
  $('#ctNodeInline').innerHTML=nodeMarkup('ctInlineNode',false);if(nodePopup)nodePopup.innerHTML=nodeMarkup('ctPopupNode',true);
  const n=nodes.find(n=>n.id===state.nodeSelected);$('#ctNodeTrigger').textContent=n.name+' · '+nodeText(n)+' ▾';$('#ctNodeResult').textContent='当前节点：'+n.name+'；选择和检测相互独立。';
  if(scope){const target=focusId?document.getElementById(focusId):scope.querySelector('[data-ct="'+focusAction+'"]'+(focusNode?'[data-node="'+focusNode+'"]':''));if(target&&!target.disabled)target.focus({preventScroll:true});else scope.querySelector('[data-ct=node-stop]')?.focus({preventScroll:true});}
 }
 function stopNodes(){state.nodeRun++;if(state.nodeRunning){for(const n of nodes)if(['检测中…','等待'].includes(state.nodeResults[n.id]))state.nodeResults[n.id]='已停止';}state.nodeRunning=false;renderNodes();}
 function detectNodes(id){
  if(state.nodeRunning)return;const run=++state.nodeRun,targets=id?nodes.filter(n=>n.id===id):nodes;state.nodeRunning=true;targets.forEach(n=>state.nodeResults[n.id]='等待');renderNodes();
  targets.forEach((n,i)=>{setTimeout(()=>{if(run!==state.nodeRun)return;state.nodeResults[n.id]='检测中…';renderNodes();},40+i*160);setTimeout(()=>{if(run!==state.nodeRun)return;state.nodeResults[n.id]=state.nodeScene==='timeout'?'超时':state.nodeScene==='mixed'&&n.id==='hk'?'连接失败':(84+i*56)+' ms';if(i===targets.length-1)state.nodeRunning=false;renderNodes();},160+i*160);});
 }
 function closeNodePopup(focus=false){if(!nodePopup)return;nodePopup.remove();nodePopup=null;nodeAnchor?.setAttribute('aria-expanded','false');if(focus)nodeAnchor?.focus();nodeAnchor=null;}
 function openNodePopup(anchor){
  if(nodePopup){closeNodePopup(true);return;}window.prototypeSelect?.close();window.prototypeActionMenu?.close();nodeAnchor=anchor;nodePopup=document.createElement('div');nodePopup.className='mp-node-picker ct-node-popup prototype-ui';nodePopup.setAttribute('role','dialog');nodePopup.setAttribute('aria-modal','false');nodePopup.setAttribute('aria-labelledby','ctPopupNodeTitle');nodePopup.innerHTML=nodeMarkup('ctPopupNode',true);document.body.appendChild(nodePopup);anchor.setAttribute('aria-expanded','true');
  const a=anchor.getBoundingClientRect(),b=$('.window').getBoundingClientRect(),width=Math.max(180,Math.min(400,b.width-20));nodePopup.style.width=width+'px';nodePopup.style.maxHeight=Math.max(100,b.height-24)+'px';nodePopup.style.left=Math.max(b.left+10,Math.min(a.left,b.right-width-10))+'px';nodePopup.style.top=Math.max(b.top+10,Math.min(a.bottom+5,b.bottom-260))+'px';nodePopup.querySelector('[data-ct-node][aria-pressed=true]')?.focus();
 }
 function renderWindow(){
  const w=state.window,visible=w.visibility==='visible';$('#ctWindowSample').innerHTML='<div class="ct-platform-window" data-focus="'+w.focus+'" data-material="'+(w.platform==='win10'||w.focus==='inactive'||state.effects==='low'?'solid':w.material)+'"><div '+(!visible?'hidden':'')+'><div class="ct-platform-caption">'+window.windowsPrototype.captionMarkup().replaceAll('data-win-action','data-ct-window')+'</div><div class="ct-platform-content">工作空间 · '+(w.maximized?'最大化示意':'普通窗口')+'<p>当前'+(w.focus==='active'?'活动':'非活动')+'窗口 · '+w.platform+'</p></div></div><div class="ct-platform-content" '+(visible?'hidden':'')+'>'+esc({minimized:'窗口已最小化',tray:'窗口已收起到托盘',exited:'桌面壳已退出'}[w.visibility])+'<p>'+button('重新打开','window-reopen','ghost')+'</p></div></div>';
 }
 function renderTraySample(){const t=state.tray;$('#ctTraySample').innerHTML='<div class="ct-tray-caption">'+(t.os==='windows'?'Windows 通知区':'macOS 菜单栏')+'</div>'+button(t.open?'收起菜单':'打开菜单','tray-toggle','ghost btn-sm','aria-expanded="'+t.open+'"')+(t.open?window.PrototypePlatformViews.tray(t.os,t.state,t.settings):'');}
 function renderExampleState(){
  const dirty=$('#ctExampleName').value!==state.exampleSaved;$('#ctSaveState').textContent=dirty?'有未保存修改':state.exampleSavedOnce?'已保存':'未修改';
  $$('[data-ct=example-save]',page).forEach(b=>{b.disabled=!dirty;b.classList.toggle('primary',dirty);b.classList.toggle('ghost',!dirty);});$('[data-ct=example-reset]',page).disabled=!dirty;
 }
 function dialog(kind){
  closeNodePopup();let html,handler=null,confirm='确定';
  if(kind==='confirm'){confirm='删除';html='<p>删除这条示例项目？</p>';handler=()=>{$('#ctDialogResult').textContent='示例项目已删除。';};}
  else if(kind==='detail'){html='<dl><dt>名称</dt><dd>默认工作空间</dd><dt>状态</dt><dd>已启用</dd></dl>';confirm='关闭';}
  else {confirm='保存';html='<div class="prototype-ui ct-demo-dialog"><label class="ui-field">名称<input id="ctDialogName" aria-describedby="ctDialogError" value="示例项目"><small id="ctDialogError" class="ui-error" hidden>请输入名称</small></label><label class="ui-field">处理方式<select id="ctDialogSelect"><option>默认处理</option><option>稍后处理</option></select></label></div>';handler=()=>{const el=$('#ctDialogName'),invalid=!el.value.trim();el.setAttribute('aria-invalid',String(invalid));$('#ctDialogError').hidden=!invalid;if(invalid){el.focus();return;}$('#ctDialogResult').textContent='已保存：'+el.value.trim();closeModal();};}
  openModal(kind==='confirm'?'删除示例项目':kind==='detail'?'项目内容':'编辑示例项目',html,confirm,handler,{mode:kind==='detail'?'view':kind,hideNote:true,confirmKeepsOpen:kind==='form'});topicDialog=true;window.prototypeSelect?.enhance($('#modalBody'));window.__modalOnClose=()=>{topicDialog=false;};
 }
 const tool=document.createElement('div');tool.id='componentTopicDemoCard';tool.className='proto-card component-tool-card';tool.dataset.protoContexts='components';tool.hidden=true;
 tool.innerHTML='<div class="proto-note-title">组件与样式 · 评审条件</div><p class="pctl-hint" id="ctToolSection"></p>'+[
 ['theme','主题',[['light','亮色'],['dark','暗色']]],['effects','画质',[['high','高'],['mid','中'],['low','低']]],['zoom','样例缩放',[['50','50%'],['100','100%'],['150','150%'],['200','200%']]],['size','样例内容宽度',[['fluid','占满可用空间'],['1180','最大1180px'],['900','最大900px']]]
 ].map(([k,l,opts])=>'<label>'+l+'<select data-ct-env="'+k+'">'+opts.map(([v,t])=>'<option value="'+v+'">'+t+'</option>').join('')+'</select></label>').join('')+'<label><span><input type="checkbox" data-ct-env="long">长文案</span></label><div data-ct-for="model-picker"><label>选择模式<select id="ctPickerModeTool"><option value="single">单选</option><option value="multiple">多选</option></select></label><label>目录场景<select id="ctPickerScene"><option value="normal">正常</option><option value="long">超过100项</option><option value="empty">为空</option><option value="loading">读取中</option><option value="failed">失败</option><option value="missing">失效引用</option></select></label></div><div data-ct-for="node-picker"><label>检测结果<select id="ctNodeScene"><option value="normal">正常</option><option value="mixed">部分失败</option><option value="timeout">超时</option><option value="stale">结果过期</option></select></label></div><div data-ct-for="windows">'+[['platform','系统',[['win11','Windows 11'],['win10','Windows 10']]],['focus','焦点',[['active','活动'],['inactive','非活动']]],['material','材质',[['mica','Mica示意'],['solid','实底']]],['close','关闭行为',[['tray','留托盘'],['exit','退出']]]].map(([k,l,opts])=>'<label>'+l+'<select data-ct-win="'+k+'">'+opts.map(([v,t])=>'<option value="'+v+'">'+t+'</option>').join('')+'</select></label>').join('')+'</div><div data-ct-for="tray"><label>平台<select id="ctTrayOs"><option value="mac">macOS</option><option value="windows">Windows</option></select></label><label>运行状态<select id="ctTrayState"><option value="stopped">未运行</option><option value="running">运行中</option><option value="starting">启动中</option><option value="failed">失败</option><option value="at_risk">存在问题</option></select></label></div><p class="pctl-hint">仅当前专题内存状态。环境随深链接恢复，不保存为软件偏好。样例缩放不缩放外部工具板。</p>';
 ($('#protoStdCards .proto-group-body')||$('#protoStdCards')).appendChild(tool);window.treeNavigationDemo?.attachTools(tool);
 function enter(){
  if(entered)return;entered=true;previous={theme:root.dataset.theme,effects:root.dataset.effects,w:root.style.getPropertyValue('--win-w'),h:root.style.getPropertyValue('--win-h'),scroll:main.scrollTop};
  previous.brandSubtitle=$('.brand span').textContent;$('.brand span').textContent='组件与样式';const bell=$('.notification-wrap');previous.bell=bell;previous.bellMarker=document.createComment('notification-return');bell.before(previous.bellMarker);$('#ctNotificationMount').appendChild(bell);
  state.theme=previous.theme==='dark'?'dark':'light';state.effects=previous.effects||'high';readHash();document.body.classList.add('component-topic-mode');
  for(const k of ['theme','effects','zoom','size','long'])setEnvironment(k,state[k],false);updateToolContext();window.prototypePanel?.refresh();requestAnimationFrame(()=>{navigate(state.section,false);if(savedScroll&&!new URLSearchParams(location.hash.split('?')[1]||'').has('section'))main.scrollTop=savedScroll;mountPicker();});
 }
 function leave(){
  if(!entered)return;savedScroll=main.scrollTop;entered=false;stopNodes();closeNodePopup();window.modelPickerPrototype?.unmount?.();if(topicDialog)closeModal();window.prototypeSelect?.close();window.prototypeActionMenu?.close();document.body.classList.remove('component-topic-mode','component-nav-collapsed');
  $('.brand span').textContent=previous.brandSubtitle;previous.bellMarker.replaceWith(previous.bell);root.dataset.theme=previous.theme;setEffects(previous.effects);for(const [k,v] of [['--win-w',previous.w],['--win-h',previous.h]]){if(v)root.style.setProperty(k,v);else root.style.removeProperty(k);}main.scrollTop=previous.scroll;previous=null;updateSizeReadout();
 }
 function syncRoute(){const active=root.dataset.route==='components';if(active)enter();else{if(entered)leave();if(!['model-picker','annotations','tray'].includes(root.dataset.route))returnRoute=root.dataset.route||'settings';}}
 render();updateToolContext();
 nav.addEventListener('input',e=>{if(e.target.id==='componentNavSearch'){navQuery=e.target.value;renderNav();}});
 document.addEventListener('input',e=>{
  if(!entered)return;
  if(e.target.id==='ctSlider')$('#ctSliderValue').value=e.target.value;
  if(e.target.id==='ctExampleName')renderExampleState();
  /* 手动改日期或时间时同步草稿：摘要、时长与校验跟着变 */
  if(trPanel&&trDraft&&['ctTrFromDate','ctTrFromTime','ctTrToDate','ctTrToTime'].includes(e.target.id))applyTimeInputs();
 });
 document.addEventListener('change',e=>{
  if(!entered)return;const el=e.target;
  if(el.dataset.ctEnv){setEnvironment(el.dataset.ctEnv,el.type==='checkbox'?el.checked:el.value);renderWindow();}
  if(el.id==='ctPickerModeTool'||el.id==='ctPickerScene'){window.modelPickerPrototype?.unmount?.();if(el.id==='ctPickerModeTool')state.pickerMode=el.value;else state.pickerScenario=el.value;mountPicker();}
  if(el.id==='ctNodeScene'){stopNodes();state.nodeScene=el.value;if(el.value==='stale')nodes.forEach(n=>state.nodeResults[n.id]='结果已过期');renderNodes();}
  if(el.dataset.ctWin){state.window[el.dataset.ctWin]=el.value;renderWindow();}
  if(el.id==='ctTrayOs'){state.tray.os=el.value;renderTraySample();}if(el.id==='ctTrayState'){state.tray.state=el.value;renderTraySample();}
  if(el.id==='ctTableAll'){$$('[data-ct-row]',page).forEach(c=>c.checked=el.checked);}
  if(el.id==='ctTableAll'||el.dataset.ctRow){state.selectedRows=new Set($$('[data-ct-row]:checked',page).map(c=>Number(c.dataset.ctRow)));const all=$('#ctTableAll');all.checked=state.selectedRows.size===24;all.indeterminate=state.selectedRows.size>0&&!all.checked;$('#ctTableResult').textContent='已选'+state.selectedRows.size+'项';}
 });
 document.addEventListener('click',e=>{
  /* 时间下拉：点外部关闭；点自己保持 */
  if(trTimePop&&!e.target.closest('#ctTrTimePop')&&!/^ctTr(From|To)Time$/.test(e.target.id||''))closeTimePop();
  /* 时间范围浮层：点遮罩关闭，未应用即撤销 */
  if(trPanel&&e.target.closest('[data-tr-mask]')===trPanel.querySelector('[data-tr-mask]'))closeTrPanel();
  /* 日历悬停预览：选了开始日期后，鼠标所在日期到开始日期之间高亮 */
  if(trPanel&&trPick){
    const day=e.target.closest&&e.target.closest('[data-ct="tr-day"]');
    if(day&&day.dataset.day!==trHover){trHover=day.dataset.day;paintCal()}
  }
  const link=e.target.closest('[data-ct-section]');if(link&&entered){e.preventDefault();navigate(link.dataset.ctSection);return;}
  if(!entered)return;const node=e.target.closest('[data-ct-node]'),win=e.target.closest('[data-ct-window]'),tray=e.target.closest('[data-ct-tray]'),tab=e.target.closest('[data-ct-tab]'),tree=e.target.closest('[data-ct-tree]'),b=e.target.closest('[data-ct]');
  if(node){state.nodeSelected=node.dataset.ctNode;renderNodes();if(nodePopup)closeNodePopup(true);return;}
  if(win){const a=win.dataset.ctWindow;if(a==='maximize')state.window.maximized=!state.window.maximized;else state.window.visibility=a==='close'?(state.window.close==='tray'?'tray':'exited'):'minimized';renderWindow();return;}
  if(tray){const a=tray.dataset.ctTray;if(a in state.tray.settings)state.tray.settings[a]=!state.tray.settings[a];else if(['start','restart'].includes(a))state.tray.state='running';else if(['stop','quit'].includes(a))state.tray.state='stopped';$('#ctTrayResult').textContent='已模拟：'+tray.textContent.trim();renderTraySample();return;}
  if(tab){selectTab(tab.dataset.ctTab);return;}if(tree){const id=tree.dataset.ctTree;if(collapsed.has(id))collapsed.delete(id);else collapsed.add(id);renderTree();$('[data-ct-tree="'+id+'"]')?.focus();return;}
  /* 时间弹层：点面板外部即关闭 */
  if(trTimePop&&!e.target.closest('#ctTrTimePop')&&!e.target.closest('[data-time]')){closeTimePop();}
  if(!b){if(nodePopup&&!nodePopup.contains(e.target)&&!nodeAnchor.contains(e.target))closeNodePopup();return;}
  const action=b.dataset.ct;
  if(action==='tr-preset'){applyPreset(b.dataset.preset);return;}
  if(action==='tr-time'){openTimePop(b.dataset.which);return;}
  if(action==='tr-time-pick'){pickTime(b.dataset.which,b.dataset.t);return;}
  if(action==='tr-hour'){setTimePart(b.dataset.which,'hour',b.dataset.v);return;}
  if(action==='tr-minute'){setTimePart(b.dataset.which,'minute',b.dataset.v);return;}
  if(action==='tr-step'){trMinStep=Number(b.dataset.step);
    const which=b.closest('#ctTrTimePop')?.dataset.owner==='ctTrToTime'?'to':'from';
    openTimePop(which);return;}
  if(action==='tr-now'){const d=new Date(),v=ctPad(d.getHours())+':'+ctPad(d.getMinutes());
    const which=b.closest('#ctTrTimePop')?.dataset.owner==='ctTrToTime'?'to':'from';
    const input=which==='from'?$('#ctTrFromTime'):$('#ctTrToTime');
    if(input){input.value=v;applyTimeInputs()}return;}
  if(action==='tr-day'){pickDay(b.dataset.day);return;}
  if(action==='tr-prev'||action==='tr-next'){const m=trCalMonth||new Date();
    trCalMonth=new Date(m.getFullYear(),m.getMonth()+(action==='tr-next'?1:-1),1);paintCal();return;}
  if(action==='tr-mprev'||action==='tr-mnext'){const side=b.dataset.side,m=trCalMonth||new Date();
    /* 左列翻页直接改基准月；右列翻页等价于基准月 +1 个月，因此两边各按自己的月份走 */
    const step=action==='tr-mnext'?1:-1;
    trCalMonth=new Date(m.getFullYear(),m.getMonth()+(side==='右'?1:0)+step,1);paintCal();return;}
  if(action==='tr-yprev'||action==='tr-ynext'){const side=b.dataset.side,m=trCalMonth||new Date();
    const step=action==='tr-ynext'?12:-12;
    trCalMonth=new Date(m.getFullYear(),m.getMonth()+(side==='右'?1:0)+step,1);paintCal();return;}
  if(action==='tr-chip'){applyChip(b.dataset.chip);return;}
  if(action==='tr-cancel'){resetRange();return;}
  if(action==='tr-close'){closeTrPanel();return;}
  if(action==='tr-apply'){commitRange();return;}
  if(action==='back'){setRoute(returnRoute);return;}
  if(action==='toggle-nav'){document.body.classList.toggle('component-nav-collapsed');b.setAttribute('aria-expanded',String(!document.body.classList.contains('component-nav-collapsed')));return;}
  if(action==='sample-save')$('#ctButtonResult').textContent='保存按钮已触发。';if(action==='sample-delete')dialog('confirm');
  if(action==='validate'){const el=$('#ctName'),invalid=!el.value.trim()||el.value.trim().length>40;el.setAttribute('aria-invalid',String(invalid));$('#ctNameError').hidden=!invalid;$('#ctFormResult').textContent=invalid?'请修正名称':'校验通过';if(invalid)el.focus();}
  if(action==='switch'){const value=b.getAttribute('aria-checked')!=='true';b.setAttribute('aria-checked',String(value));b.textContent=value?'已开启':'已关闭';}
  if(action==='menu')window.prototypeActionMenu.open({anchor:b,label:'样例操作',items:[{label:'复制名称',onSelect:()=>$('#ctMenuResult').textContent='已选择复制名称'},{label:'当前不可用',disabled:true,reason:'请先选择项目'},{label:'删除示例项目',danger:true,separatorBefore:true,onSelect:()=>dialog('confirm')}]});
  if(action==='sort-table'){state.tableReverse=!state.tableReverse;renderTable();}
  if(action==='table-edit'){$('#ctTableResult').textContent='正在编辑项目 '+b.dataset.row;dialog('form');}
  if(action.startsWith('dialog-'))dialog(action.slice(7));
  if(action.startsWith('local-')){state.local=action.slice(6);renderLocal();}
  if(action==='picker'){window.modelPickerPrototype?.unmount?.();window.modelPickerPrototype.choose({...pickerOptions(),onCancel:()=>mountPicker(),onSelect:r=>{pickerOptions().onSelect(r);mountPicker();}});}
  if(action==='node-open')openNodePopup(b);if(action==='node-close')closeNodePopup(true);if(action==='node-all')detectNodes();if(action==='node-one')detectNodes(b.dataset.node);if(action==='node-stop')stopNodes();
  if(action==='window-reopen'){state.window.visibility='visible';renderWindow();}if(action==='tray-toggle'){state.tray.open=!state.tray.open;renderTraySample();}
  if(action.startsWith('notify-countdown-'))window.prototypeNotificationPublisher.publish('component.demo.countdown',{variant:action.slice('notify-countdown-'.length)});
  if(action==='notify-toast')window.prototypeNotificationPublisher.publish('component.demo.feedback');
  if(action==='notify-task-a'||action==='notify-task-b')window.prototypeNotificationPublisher.publish('component.demo.task',{taskId:action.endsWith('a')?'a':'b'});
  if(action==='notify-fail')window.prototypeNotificationPublisher.publish('component.demo.task',{taskId:'a',state:'failed',step:1});
  if(action==='notify-attention')window.prototypeNotificationPublisher.publish('component.demo.attention');
  if(action==='notify-center')$('#notificationBtn').click();if(action==='notify-reset')window.prototypeNotificationPublisher.reset();
  if(action==='example-save'){state.exampleSaved=$('#ctExampleName').value;state.exampleSavedOnce=true;$('#ctExampleResult').textContent='示例已保存：'+state.exampleSaved;renderExampleState();}
  if(action==='example-reset'){$('#ctExampleName').value=state.exampleSaved;$('#ctExampleResult').textContent='';renderExampleState();}
 });
 function selectTab(id){state.tab=id;$$('[data-ct-tab]',page).forEach(b=>{b.setAttribute('aria-selected',String(b.dataset.ctTab===id));b.tabIndex=b.dataset.ctTab===id?0:-1;});$('#ctTabPanel').setAttribute('aria-labelledby','ctTab-'+id);$('#ctTabPanel').textContent=id==='general'?'基本设置内容。切换分区保留表单输入。':'高级设置内容。与基本设置共用状态。';}
 document.addEventListener('keydown',e=>{
  if(!entered)return;
  if(nodePopup){if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closeNodePopup(true);return;}if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){const items=$$('[data-ct-node]',nodePopup),i=items.indexOf(document.activeElement),n=e.key==='Home'?0:e.key==='End'?items.length-1:Math.max(0,Math.min(items.length-1,i+(e.key==='ArrowDown'?1:-1)));e.preventDefault();items[n]?.focus();return;}if(e.key==='Tab')closeNodePopup(true);}
  if(e.target.dataset.ctTab&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();selectTab(e.key==='Home'?'general':e.key==='End'?'advanced':state.tab==='general'?'advanced':'general');$('#ctTab-'+state.tab).focus();}
  if(topicDialog&&e.key==='Tab'){const items=$$('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href]',$('#modal')).filter(el=>!el.hidden&&!el.closest('[hidden]'));const first=items[0],last=items.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
 },true);
 // 外部全局主题按钮在专题中同样只改会话，不落软件主题偏好。
 document.addEventListener('click',e=>{if(!entered)return;const b=e.target.closest('#themeSeg [data-theme-option]');if(b){e.preventDefault();e.stopImmediatePropagation();setEnvironment('theme',b.dataset.themeOption==='system'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):b.dataset.themeOption);}},true);
 main.addEventListener('scroll',()=>{if(!entered||queued)return;queued=true;requestAnimationFrame(()=>{queued=false;const top=main.getBoundingClientRect().top;const visible=catalog.sections.filter(s=>document.getElementById(s.anchor).getBoundingClientRect().top<=top+40).at(-1);if(visible&&visible.id!==state.section){if(state.section==='node-picker')stopNodes();state.section=visible.id;renderNav();updateToolContext();mountPicker();writeHash();}});},{passive:true});
 window.addEventListener('hashchange',()=>{if(root.dataset.route==='components'){readHash();navigate(state.section,false);mountPicker();}});
 document.addEventListener('focusin',e=>{if(nodePopup&&!nodePopup.contains(e.target)&&!nodeAnchor?.contains(e.target))closeNodePopup();});
/* 时间输入获得焦点即列出时间点，不再需要单独的箭头按钮 */
document.addEventListener('focusin',e=>{
  const which=e.target&&e.target.dataset&&e.target.dataset.time;
  if(which&&trPanel&&!trSuppress)openTimePop(which);
});
/* 选了开始日期后，悬停日期即时预览区间；移出日历清除预览 */
document.addEventListener('pointerover',e=>{
  if(!trPanel||!trPick)return;
  const day=e.target.closest&&e.target.closest('[data-ct="tr-day"]');
  if(day&&day.dataset.day!==trHover){trHover=day.dataset.day;paintCal()}
});
document.addEventListener('pointerout',e=>{
  if(!trPanel||!trPick||!trHover)return;
  const to=e.relatedTarget;
  if(!to||!to.closest||!to.closest('#ctTrCal')){trHover=null;paintCal()}
});
 document.addEventListener('scroll',e=>{if(nodePopup&&!nodePopup.contains(e.target))closeNodePopup();},true);
 window.addEventListener('resize',()=>closeNodePopup());
 new MutationObserver(syncRoute).observe(root,{attributes:true,attributeFilter:['data-route']});
 window.componentTopicPrototype={navigate,setEnvironment,state:()=>JSON.parse(JSON.stringify({...state,selectedRows:[...(state.selectedRows||[])],nodeResults:{...state.nodeResults}})),stopNodes,detectNodes,resetNotifications:()=>window.prototypeNotificationPublisher.reset(),catalog};syncRoute();
})();
