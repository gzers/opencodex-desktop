//! Real Management HTTP requests against a synthetic attested loopback owner.
//! No installed runtime, user configuration, credential backend, or restart.
pub use opencodex_desktop_lib::{errors, state};
// Register the unchanged production reader locally because its library module
// is crate-private. Management/schema/field validation remain the linked library.
pub use opencodex_desktop_lib::modules::backup::{
    BackupManifest, BackupRecord, ACTIONS, MANIFEST_NAME, SCHEMA_VERSION,
};
#[allow(dead_code)]
#[path = "/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/modules/backup/safety.rs"]
pub mod production_safety;
pub mod modules {
    pub use opencodex_desktop_lib::modules::model_config;
    pub mod backup {
        pub use crate::production_safety as safety;
    }
}
#[path = "/Users/ezio/WorkSpace/Code/tools/opencodex-desktop/ocx-0219-fixes/apps/desktop/tauri/src/modules/model_config/saved_runtime_reconcile.rs"]
mod saved_runtime_reconcile;


#[tokio::main]
async fn main() {
    let home = std::path::PathBuf::from(std::env::args_os().nth(1).expect("owned home"));
    assert!(home.is_absolute() && home.is_dir());
    let context = state::ProcessContext {
        runtime: opencodex_desktop_lib::infrastructure::runtime_executable::FixedRuntimeExecutable::unresolved(),
        working_directory: home.parent().unwrap().join("work"),
        opencodex_home: home,
    };
    let result = async {
        let management = modules::model_config::management::Management::bind(&context).await?;
        let renames = std::collections::BTreeMap::from([("Krill-1".into(), "Krill".into())]);
        saved_runtime_reconcile::reconcile(&management, &context, &renames).await
    }.await;
    let success = result.is_ok();
    println!("{}", serde_json::json!({"success":success,"error":result.err()}));
    if !success { std::process::exit(2); }
}
