> 后续采用：以用户澄清后的 true 重启路径为准。最新执行合同见 [AUTOMATIC-CHAIN.md](AUTOMATIC-CHAIN.md)，不要求 false 分支生成目录。最终运行等待新 freeze；本文件保留最初准备历史。

# AC-021-02 隔离客户端实测方案

2026-11-04。用户明确授权本次隔离验证；仅写 ocx-0219-fixes/test/smoke/ocx021-owned-routing.*、本证据目录及新建系统临时根。代码分支 codex/0.2.21-fixes；文档分支 docs/governance-main。不提交或推送，不关闭 AC/TASK。

先只读检查 runtime_executable.rs、state.rs、modules/test_sandbox/mod.rs、tests/model_config_official_real.rs、tests/channel_rename_native.rs、生产 save_with_context 及缓存包。OpenCodex runtime provider 只是入口解析边界，不能单独保证 HOME 隔离；测试必须用全新环境字典与 OS 沙箱补齐。

## 执行顺序

1. 脚本默认只输出源码/包清单，不运行官方命令。--prepare 先运行合成文件与未放行本机端口的 Seatbelt 拒绝探针，成功后才在临时 HOME/CODEX_HOME/OPENCODEX_HOME/XDG/SQLite/work 下执行官方帮助、内置目录和 JSON schema 命令。整个预备阶段拒绝全部网络。
2. --run 在新临时根离线构建一个依赖当前原路径生产库的 Rust helper；使用项目 Sandbox 的数据根/边界解析与实际 ProcessContext，不复制/改写生产实现。编译前后校验全部 Rust 源摘要；失败时区分并行源码漂移与脚本/接口错误，不绕过保存版本 owner。
3. 本地 HTTP 夹具绑定 127.0.0.1 随机端口，OpenCodex 使用另一个随机本机端口。运行沙箱只允许这两个明确端口、只允许临时根写入，拒绝真实用户目录与原生 keychain IPC。所有子进程的环境为显式新字典，不继承渠道、代理、账号或凭据。
4. 使用未修改发布包启动 OpenCodex 2.84.0，先用真实 Codex 0.166.0 app-server 的 model/list 证明旧 Krill-1 目录。退出该隔离官方进程后，用实际 config_file::save_with_context 完成单渠道 Krill-1→Krill 保存，校验稳定身份与当前引用。
5. 启动新的隔离官方 OpenCodex 和 Codex app-server，检查 model/list 含 Krill/原始模型ID 且无 Krill-1/。再由真实 Codex exec 选择该新模型，只让本地夹具返回合法最小 Responses SSE；同时记录终点原始模型、合成认证匹配、Codex 最终消费的固定文本。
6. 回收本次进程组，保留完整命令/退出码/源码与二进制摘要/发布包来源、原始目录回执和本地请求证据。脚本不调用 WebDAV、供应商或用户认证；默认无需下载。

## 缓存来源与隔离依据

- @bitkyc08/opencodex 2.84.0：/tmp/ocx020-owned-official-284/installation/node_modules/@bitkyc08/opencodex；package-lock 记录 registry.npmjs.org tarball 与 sha512。检查 bin/ocx.mjs 的 OPENCODEX_HOME、src/codex/paths.ts 的 CODEX_HOME/SQLite、src/cli/index.ts 的启动/退出注入、clientIntegrations/syncResumeHistory/serviceHealthRecovery/tokenGuardian 开关。
- @openai/codex 0.166.0 / 0.166.0-darwin-arm64：/tmp/ocx020-owned-codex-0166；package-lock 记录 registry.npmjs.org 及 sha512。直接运行缓存 native 二进制，隔离后保存它自身的 help/schema/version/bundled 输出。
- 本轮禁止外网，不查询在线 OpenAI 文档；接口以已缓存发布物及其自身帮助/schema 为准。版本不外推其它版本。

## 证据边界与未解决接口

model/list 来自实际 Codex app-server，可以证明新 Codex 进程加载选择目录；OpenCodex 管理 API/config 读回不能替代此证据。Codex exec→官方 OpenCodex→夹具的实际请求和返回才能证明路由。本 helper 的重新启动不作为官方客户端证据。

本方案不启动/重启当前宿主 Codex 桌面，不操纵日常账号/配置。桌面 GUI 的可见选择器、重启提示交互、macOS/Windows 双平台原生验收仍由主线负责。原生 Keychain 迁移本轮不验证（helper 使用进程内存凭据后端与合成 inline key）。保存版本 owner 正在并行变化；运行前后摘要与保存错误必须保留，不能改用旧 save 或 G0 spike 避开。
