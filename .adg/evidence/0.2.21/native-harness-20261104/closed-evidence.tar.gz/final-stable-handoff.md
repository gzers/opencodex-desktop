# Windows smoke 最终稳定交接

已稳定，交主线统一提交推送和最终 Windows CI。本记录取代 host-followup-handoff.md 中“写集外未修”和“ready 门待接线”的状态。源码全写集 21 个文件见 final-stable-write-set.txt，逐文件 SHA-256 / 当前基准 HEAD 见 final-stable-source-manifest.json；本 worker 不再改源码。

确定的实际链旧宿主依赖已实装修复：query 五处退出及其内容读取使用版本对应的打开 UpdateCenter；OTA verify 在 100/150/200 缩放下采样真实 native dialog 和公共标题 X，保留原视口、比例、配置 hash、签名与版本读回，020 继续旧宿主；offline-drop 按真实版本检查当前 UI fault，且在整个预览流程多次核验，不关闭/掩盖 fault。公共原生 dialog 关闭后保留 DOM 的情况已处理：安装 UI、恢复、offline-drop 只定位 open 宿主和其后代，关闭等待不再要求持久节点从 DOM 删除。

ready WebDAV 已实际接线：

- windows-webview 向 verifyWindowsInstallUi 传入 runner 明确拥有的 modelSandbox；ManagedInstall 真实安装完成后，核对既有 startup 021 探针保存的合成 endpoint，正常 reload；offline-drop 前后分别调用 verify021ReadyWebdav。两次都必须实际呈现概览“已配置 · 未检测”、无远程状态点、无成功/失败 observation，endpoint revision 保持；任一次退回环境门禁均失败并留 JSON。
- windows-install-recovery 在既有真实 2.93.0 恢复升级完成、生产 source 读回后调用同一门。该独立 sandbox 若尚无 endpoint，只有这个显式 owner 入口可用生产 save_sync_endpoint 建立合成 .invalid 连接，再生产读回并 reload。绝不调用测试/同步连接。
- 环境事实严格沿用产品实际口径：真实 Node/npm 发现通过，且 discover_environment=ready，或 discover_environment=missing_ocx 加真实 managed runtime source（产品既有 ready_via_source 分支）。托管安装本来不属于全局 ocx 自动发现；没有伪造 gate=ready。所有路径仍要求可见 ready 概览卡片且实际无环境门禁。原先未安装路径的 gated 证据保留，不能混为 ready 通过。
- 每次重新核对 app_about、不可变/保存数据根、内部 OPENCODEX_HOME、真实 runtime_source 与 endpoint revision；只读生产状态，不赋值环境/store，不加生成/连接请求。真实 invoke 命令观测与 sentinel 门保留。

原安装/恢复 300 秒期限、业务来源/manifest/Key/配置字节读回、预写备份、fixture 隔离与 EXE 身份门没有降低。真实安装/OTA/签名业务未修改。ocx021-owned-routing.*、产品代码、workflow 和其他 worker 文件未触碰。

本轮最终仅跑新增对应定向：node --test test/smoke/windows-021-public-hosts.test.mjs test/smoke/windows-021-ready-webdav.test.mjs，16/16 通过、零跳过；包含普通 V8 Inspector 实际命令观测、两次 ready 编排、后续环境回退失败、020/021 宿主和故障检测。全写集 20 个 JS 文件 node --check 和 git diff --check 均通过，见 final-stable-checks.json。未重复前面的 35/49/60 或主线正在跑的全 Windows Node 组。

原生待执行由主线最终提交后的 Windows CI 完成。新原生证据为 native021-ready-webdav-managed-before-offline-drop.json/png、native021-ready-webdav-managed-after-offline-drop.json/png，以及 recovery 链的 native021-ready-webdav-recovery-installed.json/png；runtime-install-ready-webdav.json 汇总安装链两个门，offline-drop-host.json 保存故障宿主检查。没有实际 Windows EXE 执行结果被伪造为通过；本机为 macOS arm64。未触发 CI、发布、git add/commit/push。
